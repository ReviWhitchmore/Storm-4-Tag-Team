#pragma once
// Chronicle boss ENCOUNTER DESIGN. No game code or memory is changed here.
// Phase changes require confirmed fighter health, engine action IDs and a
// verified in-game battle loader before they can become runtime behavior.
#include "chronicles_classic.h"
#include <array>
#include <cstdint>

namespace chronicles_classic {
struct BossEncounter {
  int mission;                 // 0-based catalog index
  const char* name;
  uint8_t phaseCount;          // 2 or 3 phases (design only)
  uint8_t phase2AtHp;          // HP percentage to enter phase 2
  uint8_t phase3AtHp;          // 0 if there is no third phase
  const char* phase1;
  const char* phase2;
  const char* phase3;
  bool requiresSpecialForm;    // do NOT force unavailable costume/character IDs
};
constexpr std::array<BossEncounter,8> kBosses{{
  { 0,"KAKASHI",2,50,0,
    "FASE 1: AVALIACAO E ESQUIVAS",
    "FASE 2: CONTRA-ATAQUES MAIS RAPIDOS","",false},
  { 5,"ZABUZA E HAKU",2,50,0,
    "FASE 1: ZABUZA PRESSAO FRONTAL",
    "FASE 2: HAKU OFENSIVA COORDENADA","",false},
  { 7,"OROCHIMARU",2,45,0,
    "FASE 1: CONTROLE DE ESPACO",
    "FASE 2: PRESSAO CONTINUA","",false},
  {17,"GAARA",3,65,30,
    "FASE 1: DEFESA DE AREIA",
    "FASE 2: ATAQUES DE AREA",
    "FASE 3: TRANSFORMACAO SE DISPONIVEL",true},
  {18,"OROCHIMARU",3,65,30,
    "FASE 1: COMBATE CONTRA HIRUZEN",
    "FASE 2: PRESSAO SOBRE HIRUZEN",
    "FASE 3: ATAQUE FINAL",false},
  {19,"ITACHI",2,50,0,
    "FASE 1: PRECISAO E PUNICAO",
    "FASE 2: GENJUTSU SE VALIDADO","",true},
  {34,"KIMIMARO",2,40,0,
    "FASE 1: OSSOS / CURTA DISTANCIA",
    "FASE 2: AGRESSIVIDADE E RESISTENCIA","",false},
  {36,"SASUKE",3,70,35,
    "FASE 1: TAIJUTSU E CHIDORI",
    "FASE 2: MARCA DA MALDICAO",
    "FASE 3: PODER FINAL DA MARCA",true}
}};
constexpr const BossEncounter* BossForMission(int mission){
  if(!ValidMission(mission))return nullptr;
  for(const auto& b:kBosses)if(b.mission==mission)return &b;
  return nullptr;
}
constexpr int PlannedBossPhase(const BossEncounter& boss,int healthPercent){
  if(healthPercent<0)healthPercent=0;
  if(healthPercent>100)healthPercent=100;
  return boss.phaseCount>=3 && healthPercent<=boss.phase3AtHp?3:
         healthPercent<=boss.phase2AtHp?2:1;
}
constexpr const char* BossPhaseLabel(const BossEncounter& boss,int phase){
  return phase==1?boss.phase1:phase==2?boss.phase2:
         phase==3 && boss.phaseCount==3?boss.phase3:"";
}
} // namespace chronicles_classic
