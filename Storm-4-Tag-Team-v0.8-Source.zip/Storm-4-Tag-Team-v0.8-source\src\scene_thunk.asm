; Entrada de FUN_14076BA88(lado, tipo): guarda os registradores preservados de quem chamou, onde fica
; o lutador que iniciou a cena, e os entrega em r8 para HookSceneStartImpl.
EXTERN HookSceneStartImpl:PROC

.code
SceneStartThunk PROC FRAME
  sub rsp, 68h
  .allocstack 68h
  .endprolog
  mov [rsp+20h], rbx
  mov [rsp+28h], rdi
  mov [rsp+30h], rsi
  mov [rsp+38h], rbp
  mov [rsp+40h], r12
  mov [rsp+48h], r13
  mov [rsp+50h], r14
  mov [rsp+58h], r15
  lea r8, [rsp+20h]
  mov r9, [rsp+68h]
  call HookSceneStartImpl
  add rsp, 68h
  ret
SceneStartThunk ENDP
END