#pragma once
#include <algorithm>
#include <cmath>
#include <limits>

// CPU target selection for six-way FFA.  A CPU keeps its current LIVE target
// until another enemy is substantially nearer. This reduces per-tick target
// thrashing and prevents a stale target surviving a KO.
inline int FfaStableCpuTarget(const float positions[6][3],
                             const bool alive[6], int fighters,
                             int owner, int current) {
  if (!positions || !alive || fighters < 2 || fighters > 6 ||
      owner < 0 || owner >= fighters || !alive[owner]) return -1;
  bool valid[6]{};
  float squared[6]{};
  int nearest = -1;
  float nearestSquared = std::numeric_limits<float>::infinity();
  for(int opponent=0;opponent<fighters;++opponent) {
    if(opponent==owner || !alive[opponent])continue;
    const float dx=positions[opponent][0]-positions[owner][0];
    const float dy=positions[opponent][1]-positions[owner][1];
    const float dz=positions[opponent][2]-positions[owner][2];
    const float dist=dx*dx+dy*dy+dz*dz;
    if(!std::isfinite(dist) || dist<0)continue;
    valid[opponent]=true;
    squared[opponent]=dist;
    if(dist<nearestSquared) {
      nearestSquared=dist;
      nearest=opponent;
    }
  }
  if(current>=0 && current<fighters && current!=owner && valid[current] &&
     squared[current]<=std::max(nearestSquared*1.69f,nearestSquared+900.0f))
    return current;
  return nearest;
}

inline bool FfaValidWinner(int candidate, const bool alive[6],int count) {
  if (!alive || count<2 || count>6 || candidate<0 || candidate>=count ||
      !alive[candidate])return false;
  for(int i=0;i<count;++i)if(i!=candidate && alive[i])return false;
  return true;
}
