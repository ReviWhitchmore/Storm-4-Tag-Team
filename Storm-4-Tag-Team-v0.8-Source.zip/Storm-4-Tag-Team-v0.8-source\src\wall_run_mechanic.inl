// Incluido em wall_run.cpp (dentro do namespace anonimo). Mecanica de Wall Running (parede=1).
//
// Paredes por arena: segmentos verticais (no chao, de (ax, ay) ate (bx, by)) com a altura util acima do chao. A tabela
// wall_run_walls.inl e GERADA por tools/gen_wall_table.js a partir da colisao do proprio cenario (nuccChunkModelHit
// de data/stage/<cenario>.xfbin) e so traz paredes altas DENTRO do limite da luta (o limite tambem e lido da colisao).
// Arena fora da tabela: a mecanica fica desligada.
struct WallSeg {
  float ax, ay, bx, by;
  float top;  // altura maxima da corrida (acima do chao)
};
struct WallArena {
  uint32_t code;
  const char* name;
  const WallSeg* segs;
  int count;
};
#include "wall_run_walls.inl"  // kWallArenas[]

std::atomic<bool> g_enabled{false};
int g_cpuChance = 35;  // % de chance de a CPU subir quando encosta na parede correndo
int g_maxMs = 3500;    // tempo maximo na parede; depois salta sozinho
const WallArena* g_arena = nullptr;
bool g_groundKnown = false;
float g_ground = 0.0f;
constexpr float kSpeed = 700.0f;  // unidades/s na parede (a corrida no chao e ~600)
constexpr float kSkin = 10.0f;    // distancia dos pes ate a parede
constexpr float kTouch = 70.0f;   // encostado na parede
constexpr float kEnd = 80.0f;     // folga nas pontas de uma parede sem continuacao

struct Contact {
  float dist = 1e9f;  // distancia ate a parede (do lado em que o lutador esta)
  float n[3]{};       // normal da parede, apontando para o lado do lutador
  float pt[3]{};      // ponto da parede mais perto
  int seg = -1;       // segmento da tabela
  float along = 0.0f, length = 0.0f;
};

bool ContactWith(const WallSeg& w, int index, const float p[3], Contact* c) {
  const float ux0 = w.bx - w.ax, uy0 = w.by - w.ay;
  const float L = std::hypot(ux0, uy0);
  if (!(L > 1.0f)) return false;
  const float ux = ux0 / L, uy = uy0 / L;
  const float raw = (p[0] - w.ax) * ux + (p[1] - w.ay) * uy;
  const float along = std::fmin(std::fmax(raw, 0.0f), L);
  const float qx = w.ax + ux * along, qy = w.ay + uy * along;
  float nx = uy, ny = -ux;
  const float s = (p[0] - w.ax) * nx + (p[1] - w.ay) * ny;
  // Lado do lutador; colado na linha (parede que coincide com o limite) o lado e indefinido: usa o do centro da arena.
  const float side = std::fabs(s) > 15.0f ? s : (0.0f - w.ax) * nx + (0.0f - w.ay) * ny;
  if (side < 0.0f) {
    nx = -nx;
    ny = -ny;
  }
  c->dist = (raw >= 0.0f && raw <= L) ? std::fabs(s) : std::hypot(p[0] - qx, p[1] - qy);
  c->n[0] = nx;
  c->n[1] = ny;
  c->n[2] = 0.0f;
  c->pt[0] = qx;
  c->pt[1] = qy;
  c->pt[2] = p[2];
  c->seg = index;
  c->along = along;
  c->length = L;
  return true;
}

// Parede mais perto de p. prefer (opcional): so aceita paredes com a normal parecida (continuar numa curva).
bool NearestWall(const WallArena& a, const float p[3], Contact* out, const float* prefer = nullptr) {
  bool found = false;
  for (int i = 0; i < a.count; ++i) {
    Contact c;
    if (!ContactWith(a.segs[i], i, p, &c)) continue;
    if (prefer && c.n[0] * prefer[0] + c.n[1] * prefer[1] < 0.5f) continue;
    if (!found || c.dist < out->dist) {
      *out = c;
      found = true;
    }
  }
  return found;
}

bool ReadDir(uintptr_t player, float out[2]) {
  __try {
    out[0] = *reinterpret_cast<const float*>(player + 0xA8);
    out[1] = *reinterpret_cast<const float*>(player + 0xAC);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
  const float l = std::hypot(out[0], out[1]);
  if (!(l > 0.01f)) return false;
  out[0] /= l;
  out[1] /= l;
  return true;
}

bool Damaged(int s) { return s >= 0x18 && s <= 0x3E; }
bool Moving(int s) { return s == 0x2 || s == 0xA || s == 0xB || s == 0xC || s == 0xD || s == 0x10 || s == 0x13; }
bool JumpIntent(int s) { return s == 0x4 || s == 0x5; }
bool AttackIntent(int s) { return s == 0x3F || s == 0x40 || s == 0x42 || s == 0x10 || s == 0xD || s == 0x13; }
bool Calm(int s) {
  return s == 0x1 || s == 0x2 || s == 0x3 || s == 0x6 || s == 0x7 || s == 0x8 || s == 0x9 || s == 0xA || s == 0xB ||
         s == 0xC;
}

struct Runner {
  bool on = false;
  bool cpu = false;
  bool forced = false;  // roteiro do modo de teste (a entrada e real)
  uint64_t since = 0, last = 0, cooldownUntil = 0, touchSince = 0, fixAt = 0;
  float touchDist = 0.0f;  // distancia ao encostar: so sobe se a parede o SEGURA (a distancia para de diminuir)
  float h = 0.0f;              // altura acima do chao
  Contact wall;                // parede atual
  float forward[3]{0, 0, 1};  // frente do corpo (no plano da parede)
  int cpuPlan = 0;             // CPU: 0 sobe, 1 lado, 2 ataca
  float cpuSide = 1.0f;
  int prevState = -1;
  WORD prevButtons = 0;
};

// Analogico (relativo a camera) -> direcao no chao do mundo.
bool WorldFromStick(short lx, short ly, float out[2]) {
  const float sx = lx / 32767.0f, sy = ly / 32767.0f;
  if (std::hypot(sx, sy) < 0.3f) return false;
  float view[3];
  if (!CameraViewDirection(view)) return false;
  const float l = std::hypot(view[0], view[1]);
  if (!(l > 0.01f)) return false;
  const float fx = view[0] / l, fy = view[1] / l;
  out[0] = fy * sx + fx * sy;  // direita da camera = (fy, -fx)
  out[1] = -fx * sx + fy * sy;
  return true;
}
Runner g_run[6];
uintptr_t g_runPlayer[6]{};  // quem esta em cada indice (para WallRunActive)

const WallArena* FindArena(uint32_t code) {
  for (const auto& w : kWallArenas)
    if (w.code && w.code == code) return &w;
  return nullptr;
}

void Release(int k, const GrabFighterView& v, float inward, float z, const char* why) {
  Runner& r = g_run[k];
  MatrixLock(v.player, false);
  const float p[3] = {r.wall.pt[0] + r.wall.n[0] * inward, r.wall.pt[1] + r.wall.n[1] * inward, z};
  fighter::SetPos(v.player, p);
  ZeroMotion(v.player);
  r.on = false;
  r.cooldownUntil = GetTickCount64() + 1200;
  Log("PAREDE: J%d saiu da parede (%s) a %.0f de altura, %llums na parede.", v.number, why, r.h,
      static_cast<unsigned long long>(GetTickCount64() - r.since));
}

void Enter(int k, const GrabFighterView& v, const Contact& c, bool cpu, bool forced, uint64_t now) {
  Runner& r = g_run[k];
  if (!MatrixLock(v.player, true)) {
    Log("PAREDE: trava da matriz indisponivel; J%d nao sobe.", v.number);
    r.cooldownUntil = now + 5000;
    return;
  }
  r.on = true;
  g_runPlayer[k] = v.player;
  r.cpu = cpu;
  r.forced = forced;
  r.since = r.last = now;
  r.wall = c;
  r.h = std::fmax(40.0f, v.pos[2] - g_ground + 40.0f);
  r.forward[0] = r.forward[1] = 0.0f;
  r.forward[2] = 1.0f;
  r.cpuPlan = 0;
  r.cpuSide = (now / 7) % 2 ? 1.0f : -1.0f;
  r.prevState = 0x1;
  XINPUT_GAMEPAD gp{};
  r.prevButtons = (v.pad >= 0 && v.pad < 4 && InputPadStatus(v.pad, &gp)) ? gp.wButtons : 0;
  clash3d::SetActionNow(v.player, 0x1);
  clash3d::PlayAnm(v.player, 77);  // PL_ANM_RUN1: a corrida nativa do personagem
  Log("PAREDE: J%d subiu na parede (%s%s) em (%.0f,%.0f), normal (%.2f,%.2f).", v.number, cpu ? "CPU" : "jogador",
      forced ? ", roteiro de teste" : "", c.pt[0], c.pt[1], c.n[0], c.n[1]);
}

void WallJump(int k, const GrabFighterView& v, const char* why) {
  Runner& r = g_run[k];
  Release(k, v, 90.0f, g_ground + r.h, why);
  const float px = r.wall.pt[0] + r.wall.n[0] * 90.0f, py = r.wall.pt[1] + r.wall.n[1] * 90.0f;
  fighter::FaceToward(v.player, px + r.wall.n[0] * 100.0f, py + r.wall.n[1] * 100.0f);
  clash3d::SetActionNow(v.player, 0x5);  // PL_ACT_JMP_F: salto nativo para longe da parede
}

void WallAttack(int k, const GrabFighterView* f, int n, const char* why) {
  Runner& r = g_run[k];
  const GrabFighterView& v = f[k];
  Release(k, v, 90.0f, g_ground + r.h, why);
  const int t = PromoteTargetOf(k);
  if (t >= 0 && t < n && f[t].valid) fighter::FaceToward(v.player, f[t].pos[0], f[t].pos[1]);
  else fighter::FaceToward(v.player, v.pos[0] + r.wall.n[0] * 100.0f, v.pos[1] + r.wall.n[1] * 100.0f);
  // PL_ACT_CHAKRA_DASH: a investida nativa que persegue o alvo e termina em golpe (ou erra).
  Log("PAREDE: J%d mergulha no alvo J%d (CHAKRA_DASH %s).", v.number, (t >= 0 && t < n) ? f[t].number : 0,
      clash3d::SetActionNow(v.player, 0x10) ? "ok" : "falhou");
}

void GroundReturn(int k, const GrabFighterView& v) {
  Release(k, v, 60.0f, g_ground + 5.0f, "voltou ao chao");
  clash3d::SetActionNow(v.player, 0x8);  // PL_ACT_LAND
}

// Move o ponto de apoio ao longo da parede (lateral > 0 = sentido da tangente (n.y, -n.x)). Numa parede curva ou em
// varios pedacos segue para o pedaco vizinho; na ponta de uma parede sem continuacao, para.
void Slide(Runner& r, float lateral) {
  const float t[2] = {r.wall.n[1], -r.wall.n[0]};
  const float probe[3] = {r.wall.pt[0] + t[0] * lateral + r.wall.n[0] * 40.0f,
                          r.wall.pt[1] + t[1] * lateral + r.wall.n[1] * 40.0f, r.wall.pt[2]};
  Contact c;
  if (!NearestWall(*g_arena, probe, &c, r.wall.n) || c.dist > 120.0f) return;
  if (c.seg == r.wall.seg && (c.along < kEnd || c.along > c.length - kEnd)) {
    // ponta: so aceita se houver outro pedaco logo adiante
    const float ahead[3] = {probe[0] + t[0] * kEnd, probe[1] + t[1] * kEnd, probe[2]};
    Contact next;
    if (!NearestWall(*g_arena, ahead, &next, r.wall.n) || next.seg == r.wall.seg || next.dist > 120.0f) return;
  }
  r.wall = c;
}

void TickRunner(int k, const GrabFighterView* f, int n, bool blocked, uint64_t now) {
  Runner& r = g_run[k];
  const GrabFighterView& v = f[k];
  if (!v.valid) {
    r.on = false;
    MatrixLock(v.player, false);
    return;
  }
  const float dt = std::fmin(static_cast<float>(now - r.last), 50.0f) / 1000.0f;
  r.last = now;
  const int s = fighter::State(v.player);
  if (blocked) return Release(k, v, 70.0f, g_ground + r.h, "cena, supremo ou disputa de jutsus");
  if (Damaged(s)) return Release(k, v, 70.0f, g_ground + r.h, "levou golpe");

  // Intencao do jogador: o proprio jogo traduz o controle (inclusive teclado) em estados.
  float up = 0.0f, side = 0.0f;
  if (r.cpu) {
    const uint64_t t = now - r.since;
    const int target = PromoteTargetOf(k);
    if (r.cpuPlan == 0 && (r.h > 330.0f || t > 900)) r.cpuPlan = 1;
    if (r.cpuPlan == 1 && t > 1700) r.cpuPlan = 2;
    if (r.cpuPlan == 0) up = 1.0f;
    if (r.cpuPlan == 1) {
      side = r.cpuSide;
      if (target >= 0 && target < n && f[target].valid) {  // corre para o lado do alvo
        const float tx = r.wall.n[1], ty = -r.wall.n[0];
        const float rel = (f[target].pos[0] - r.wall.pt[0]) * tx + (f[target].pos[1] - r.wall.pt[1]) * ty;
        side = rel >= 0 ? 1.0f : -1.0f;
      }
    }
    if (r.cpuPlan == 2) return WallAttack(k, f, n, "CPU ataca");
  } else if (XINPUT_GAMEPAD gp{}; v.pad >= 0 && v.pad < 4 && InputPadStatus(v.pad, &gp)) {
    // Controle: analogico relativo a camera; A salta, B ataca (borda do botao).
    const WORD pressed = gp.wButtons & ~r.prevButtons;
    r.prevButtons = gp.wButtons;
    if (pressed & XINPUT_GAMEPAD_A) return WallJump(k, v, "jogador saltou (A)");
    if (pressed & XINPUT_GAMEPAD_B) return WallAttack(k, f, n, "jogador atacou (B)");
    float d[2];
    if (WorldFromStick(gp.sThumbLX, gp.sThumbLY, d)) {
      const float tx = r.wall.n[1], ty = -r.wall.n[0];
      side = d[0] * tx + d[1] * ty;
      up = -(d[0] * r.wall.n[0] + d[1] * r.wall.n[1]);  // empurrar contra a parede = subir; puxar = descer
    }
  } else {
    // Sem controle XInput (teclado): o proprio jogo traduz a entrada em estados.
    if (JumpIntent(s) && !JumpIntent(r.prevState)) return WallJump(k, v, "jogador saltou");
    if (AttackIntent(s) && !AttackIntent(r.prevState)) return WallAttack(k, f, n, "jogador atacou");
    float d[2];
    if (Moving(s) && ReadDir(v.player, d)) {
      const float tx = r.wall.n[1], ty = -r.wall.n[0];
      side = d[0] * tx + d[1] * ty;
      up = -(d[0] * r.wall.n[0] + d[1] * r.wall.n[1]);  // empurrar contra a parede = subir; puxar = descer
    }
  }
  r.prevState = s;
  if (now - r.since > static_cast<uint64_t>(g_maxMs)) return WallJump(k, v, "tempo esgotado");

  const float len = std::hypot(up, side);
  if (len > 0.25f) {
    up /= len;
    side /= len;
    r.h += up * kSpeed * dt;
    Slide(r, side * kSpeed * dt);
    const float tx = r.wall.n[1], ty = -r.wall.n[0];
    r.forward[0] = tx * side;
    r.forward[1] = ty * side;
    r.forward[2] = up;
  }
  const float top = g_arena->segs[r.wall.seg].top;
  if (r.h > top) r.h = top;
  if (r.h < 25.0f) return GroundReturn(k, v);

  const float pos[3] = {r.wall.pt[0] + r.wall.n[0] * kSkin, r.wall.pt[1] + r.wall.n[1] * kSkin, g_ground + r.h};
  WriteBody(v.player, r.forward, r.wall.n, pos);
  ZeroMotion(v.player);
  // Defesa na parede: continua na parede (volta ao neutro). Qualquer outra acao de fora (Combo em Dupla, jutsu pelo
  // teclado, agarrao...) tem prioridade: solta da parede e deixa a outra mecanica seguir.
  if (s == 0x49 || s == 0x4A) {
    if (now >= r.fixAt) {
      r.fixAt = now + 300;
      clash3d::SetActionNow(v.player, 0x1);
      clash3d::PlayAnm(v.player, 77);
    }
  } else if (r.cpu && !Calm(s)) {
    // CPU na parede: o roteiro da mecanica manda; acoes da inteligencia do jogo sao anuladas (golpe recebido ja soltou).
    clash3d::SetActionNow(v.player, 0x1);
    if (fighter::Anm(v.player) != 77) clash3d::PlayAnm(v.player, 77);
  } else if (!Calm(s) && !JumpIntent(s) && !AttackIntent(s)) {
    char why[48];
    std::snprintf(why, sizeof(why), "outra acao 0x%X", s);
    return Release(k, v, 70.0f, g_ground + r.h, why);
  } else if ((s == 0x6 || s == 0x7) && fighter::Anm(v.player) != 77) {
    clash3d::PlayAnm(v.player, 77);
  }
}

void MechanicTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (!g_arena) return;
  if (!g_groundKnown) {
    float lowest = 1e9f;
    for (int k = 0; k < n; ++k)
      if (f[k].valid) lowest = std::fmin(lowest, f[k].pos[2]);
    if (lowest > 1e8f) return;
    g_ground = lowest;
    g_groundKnown = true;
    Log("PAREDE: arena %s, chao %.0f.", g_arena->name, g_ground);
  }
  int clashA = -1, clashB = -1;
  const bool clash = JutsuClashCameraPair(&clashA, &clashB);
  for (int k = 0; k < n && k < 6; ++k) {
    Runner& r = g_run[k];
    const bool blocked = sceneActive || clash || JutsuClashProtects(f[k].player);
    if (r.on) {
      TickRunner(k, f, n, blocked, now);
      continue;
    }
    r.prevState = f[k].valid ? f[k].state : -1;
    if (blocked || !f[k].valid || now < r.cooldownUntil || !Moving(f[k].state)) {
      r.touchSince = 0;
      continue;
    }
    Contact c;
    float d[2];
    const bool cpu = f[k].pad < 0;
    // Encostado (<=70) e indo contra a parede (jogador: empurrando; CPU: mais ou menos para ela). So sobe se a parede
    // SEGURA o lutador: durante 150 ms a distancia nao diminui (numa parede que se atravessa ela cai sem parar).
    if (!NearestWall(*g_arena, f[k].pos, &c) || c.dist > kTouch || !ReadDir(f[k].player, d) ||
        -(d[0] * c.n[0] + d[1] * c.n[1]) < (cpu ? 0.3f : 0.5f)) {
      r.touchSince = 0;
      continue;
    }
    if (!r.touchSince) {
      r.touchSince = now;
      r.touchDist = c.dist;
      continue;
    }
    if (c.dist < r.touchDist - 12.0f) {  // ainda avancando para (ou atraves de) a parede: recomeca a contagem
      r.touchSince = now;
      r.touchDist = c.dist;
      continue;
    }
    if (now - r.touchSince < 150) continue;
    r.touchSince = 0;
    if (cpu) {
      if (static_cast<int>(now % 100) < static_cast<int>(CpuAdaptChance(unsigned(g_cpuChance),f[k].player,cpuai::Action::WallRun))) Enter(k, f[k], c, true, false, now);
      else r.cooldownUntil = now + 3000;
    } else {
      Enter(k, f[k], c, false, false, now);
    }
  }
}

// ---- demonstracao (parede_teste=4): o controle 1 e "segurado" pelo teste; tudo o mais e a mecanica real ----
struct Demo {
  int stage = 0, who = -1, round = 0;
  uint64_t at = 0, traceNext = 0;
  float aim[2]{};
  float mid[2]{};
  int wall = 0, shots = 0;
  bool stick = false;
  short lx = 0, ly = 0;
  WORD buttons = 0;
};
Demo g_demo;
bool g_demoVerify = false;  // parede_teste=7: uma rodada (subir, lado, A) por parede da tabela

// Converte uma direcao do mundo no analogico (relativo a camera).
bool StickFor(const float w[2], short* lx, short* ly) {
  float view[3];
  if (!CameraViewDirection(view)) return false;
  const float l = std::hypot(view[0], view[1]);
  if (!(l > 0.01f)) return false;
  const float fx = view[0] / l, fy = view[1] / l;
  const float rx = fy, ry = -fx;  // direita da camera
  const float sx = w[0] * rx + w[1] * ry, sy = w[0] * fx + w[1] * fy;
  *lx = static_cast<short>(std::fmax(-1.0f, std::fmin(1.0f, sx)) * 32000.0f);
  *ly = static_cast<short>(std::fmax(-1.0f, std::fmin(1.0f, sy)) * 32000.0f);
  return true;
}

void DemoTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (!g_arena || !g_groundKnown) return;
  if (g_demo.stage == 0) {
    if (sceneActive || !g_battleAt || now - g_battleAt < 6000) return;
    for (int k = 0; k < n; ++k)
      if (f[k].valid && f[k].side == 0 && f[k].pad >= 0) {
        g_demo.who = k;
        break;
      }
    if (g_demo.who < 0) return;
    g_demo.stage = 1;
    g_demo.at = now;
  }
  const int k = g_demo.who;
  const GrabFighterView& v = f[k];
  if (g_demo.stage == 1) {
    // Comeco de rodada: J1 800 para dentro do meio da parede; corre de verdade contra ela. Demonstracao: a parede mais
    // comprida; verificacao (parede_teste=7): uma parede por rodada.
    int longest = 0;
    float best = 0.0f;
    for (int i = 0; i < g_arena->count; ++i) {
      const WallSeg& w = g_arena->segs[i];
      const float l = std::hypot(w.bx - w.ax, w.by - w.ay);
      if (l > best) {
        best = l;
        longest = i;
      }
    }
    if (g_demoVerify) longest = g_demo.round;
    const WallSeg& ws = g_arena->segs[longest];
    g_demo.wall = longest;
    // ponto do meio, puxado 300 para o lado do centro da arena (o lado em que se luta)
    float mid[3] = {(ws.ax + ws.bx) * 0.5f, (ws.ay + ws.by) * 0.5f, g_ground};
    const float ml = std::hypot(mid[0], mid[1]);
    if (ml > 1.0f) {
      mid[0] -= mid[0] / ml * 300.0f;
      mid[1] -= mid[1] / ml * 300.0f;
    }
    Contact mc;
    if (!ContactWith(ws, longest, mid, &mc)) return;
    g_demo.aim[0] = -mc.n[0];
    g_demo.aim[1] = -mc.n[1];
    g_demo.mid[0] = mc.pt[0];
    g_demo.mid[1] = mc.pt[1];
    const float start[3] = {mc.pt[0] + mc.n[0] * 800.0f, mc.pt[1] + mc.n[1] * 800.0f, g_ground + 10.0f};
    fighter::SetPos(v.player, start);
    clash3d::SetActionNow(v.player, 0x1);
    g_demo.stage = 2;
    g_demo.at = now;
    Log("PAREDE DEMO rodada %d: J%d correndo para a parede %d (%.0f,%.0f)-(%.0f,%.0f) a partir de (%.0f,%.0f).",
        g_demo.round + 1, v.number, longest, ws.ax, ws.ay, ws.bx, ws.by, start[0], start[1]);
  }
  // Os outros ficam no lado oposto (so no teste), menos o alvo na rodada do ataque.
  const int target = PromoteTargetOf(k);
  for (int o = 0; o < n; ++o) {
    if (o == k || !f[o].valid || (!g_demoVerify && g_demo.round == 1 && o == target && g_demo.stage >= 3)) continue;
    const float a = 0.9f * o;
    const float p[3] = {g_demo.mid[0] - g_demo.aim[0] * 1300.0f + std::cos(a) * 200.0f,
                        g_demo.mid[1] - g_demo.aim[1] * 1300.0f + std::sin(a) * 200.0f, g_ground + 10.0f};
    fighter::SetPos(f[o].player, p);
  }
  const Runner& r = g_run[k];
  const uint64_t t = now - g_demo.at;
  g_demo.buttons = 0;
  g_demo.stick = true;
  if (now >= g_demo.traceNext && g_demo.stage >= 2 && g_demo.stage <= 3) {
    g_demo.traceNext = now + 500;
    Contact c;
    float d[2]{};
    const bool hasC = NearestWall(*g_arena, v.pos, &c);
    const bool hasD = ReadDir(v.player, d);
    Log("PAREDE DEMO TRACE etapa %d +%llums: J%d (%.0f,%.0f,%.0f) estado 0x%X anm %d dir(%.2f,%.2f)%s dist %.0f contra %.2f "
        "analogico (%d,%d) parede %s h %.0f",
        g_demo.stage, static_cast<unsigned long long>(t), v.number, v.pos[0], v.pos[1], v.pos[2], v.state,
        fighter::Anm(v.player), d[0], d[1], hasD ? "" : "?", hasC ? c.dist : -1.0f,
        hasC && hasD ? -(d[0] * c.n[0] + d[1] * c.n[1]) : 0.0f, g_demo.lx, g_demo.ly, r.on ? "SIM" : "nao", r.h);
  }
  if (g_demo.stage == 2) {  // corre ate a parede e continua empurrando: a mecanica real faz subir
    StickFor(g_demo.aim, &g_demo.lx, &g_demo.ly);
    if (r.on) {
      g_demo.stage = 3;
      g_demo.at = now;
      Log("PAREDE DEMO: entrada pela mecanica real (J%d).", v.number);
      if (g_demoVerify)
        Log("PAREDE VERIFICA parede %d: SUBIU (encostou a %.0f da parede em (%.0f,%.0f)).", g_demo.wall, r.wall.dist,
            r.wall.pt[0], r.wall.pt[1]);
      g_demo.shots = 0;
    } else if (t > 6000) {
      Contact c;
      const bool hasC = NearestWall(*g_arena, v.pos, &c);
      Log("PAREDE VERIFICA parede %d: NAO subiu em 6 s; J%d parou em (%.0f,%.0f), parede mais perto a %.0f (pedaco %d).",
          g_demo.wall, v.number, v.pos[0], v.pos[1], hasC ? c.dist : -1.0f, hasC ? c.seg : -1);
      if (g_demoVerify) {
        g_demo.stage = 4;
        g_demo.at = now;
      } else {
        g_demo.stage = 5;
      }
    }
    return;
  }
  if (g_demo.stage == 3) {
    if (!r.on) {
      g_demo.stage = 4;
      g_demo.at = now;
      g_demo.lx = g_demo.ly = 0;
      return;
    }
    // Teste: captura do quadro do jogo (so o jogo) no meio da subida e na corrida de lado.
    if ((g_demo.shots == 0 && t > 600) || (g_demo.shots == 1 && t > 1600)) {
      const std::wstring dir = ModDir() + L"storm6_capturas";
      CreateDirectoryW(dir.c_str(), nullptr);
      wchar_t file[96];
      std::swprintf(file, 96, L"\\parede_%08X_%d_%c.png", g_arena->code, g_demo.wall, g_demo.shots == 0 ? L'a' : L'b');
      FrameCaptureRequest((dir + file).c_str());
      ++g_demo.shots;
    }
    if (t < 900) {  // segue empurrando contra a parede: sobe
      StickFor(g_demo.aim, &g_demo.lx, &g_demo.ly);
    } else if (t < 1900) {  // para o lado: corre pela parede
      const float side[2] = {r.wall.n[1], -r.wall.n[0]};
      StickFor(side, &g_demo.lx, &g_demo.ly);
    } else if (t < 2300) {
      g_demo.lx = g_demo.ly = 0;
    } else {  // rodada 1: salto (A); rodada 2: ataque (B); rodada 3: puxa para longe da parede ate o chao
      g_demo.lx = g_demo.ly = 0;
      if (g_demo.round == 0 || g_demoVerify) g_demo.buttons = ((t / 120) % 2) ? XINPUT_GAMEPAD_A : 0;
      else if (g_demo.round == 1) g_demo.buttons = ((t / 120) % 2) ? XINPUT_GAMEPAD_B : 0;
      else {
        const float back[2] = {r.wall.n[0], r.wall.n[1]};
        StickFor(back, &g_demo.lx, &g_demo.ly);
      }
    }
    return;
  }
  g_demo.lx = g_demo.ly = 0;
  if (g_demo.stage == 4 && t > 2500) {
    if (++g_demo.round >= (g_demoVerify ? std::min(g_arena->count, 10) : 3)) {
      g_demo.stage = 5;
      Log("PAREDE DEMO: fim.");
    } else {
      g_demo.stage = 1;
    }
  }
  if (g_demo.stage == 5) g_demo.stick = false;
}

bool OnWall(uintptr_t player) {
  if (!player) return false;
  for (int k = 0; k < 6; ++k)
    if (g_run[k].on && g_runPlayer[k] == player) return true;
  return false;
}
