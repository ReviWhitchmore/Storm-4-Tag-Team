#pragma once
// Naruto Classico Chronicles: mission PLANS, never engine IDs or live scenes.
// Story catalog is shared, while Original/Evolution keep isolated profiles
// and must validate their respective battle loaders and game asset IDs.
#include <array>
#include <cstddef>
#include <cstdint>

namespace chronicles_classic {
struct Arc {
  const char* code;
  const char* title;
  const char* subtitle;
  int first;
  int count;
};
constexpr std::array<Arc,6> kArcs{{
  {"A01","FORMACAO DA EQUIPE 7","O TESTE DOS SINOS",0,1},
  {"A02","PAIS DAS ONDAS","ZABUZA E HAKU",1,5},
  {"A03","EXAMES CHUNIN","PROVAS E COMBATES",6,12},
  {"A04","INVASAO DE KONOHA","A BATALHA DO TERCEIRO HOKAGE",18,1},
  {"A05","BUSCA POR TSUNADE","OS SANNIN E O REENCONTRO",19,7},
  {"A06","RESGATE DE SASUKE","OS QUATRO DO SOM E O VALE DO FIM",26,14}
}};
struct Mission {
  const char* id;
  const char* title;
  const char* allies;
  const char* enemies;
  const char* arena; // human description ONLY: not an asset ID
  uint8_t teamSize;
  uint8_t enemySize;
  bool alternate;
  bool soundFourDlc;
};
constexpr std::array<Mission,40> kMissions{{
  {"C01","TESTE DOS SINOS","NARUTO / SASUKE / SAKURA","KAKASHI","KONOHA",3,1,false,false},
  {"C02","PRIMEIRO ENCONTRO","KAKASHI","ZABUZA","PAIS DAS ONDAS",1,1,false,false},
  {"C03","PRISAO DE AGUA","NARUTO / SASUKE","ZABUZA","PAIS DAS ONDAS",2,1,false,false},
  {"C04","ESPELHOS DE GELO","NARUTO / SASUKE","HAKU","PONTE",2,1,false,false},
  {"C05","KAKASHI VS ZABUZA","KAKASHI","ZABUZA","PONTE",1,1,false,false},
  {"C06","BATALHA NA PONTE","NARUTO / SASUKE / KAKASHI","ZABUZA / HAKU","PONTE",3,2,true,false},
  {"C07","SASUKE VS ROCK LEE","SASUKE","ROCK LEE","KONOHA",1,1,false,false},
  {"C08","ATAQUE DE OROCHIMARU","NARUTO / SASUKE / SAKURA","OROCHIMARU","FLORESTA",3,1,false,false},
  {"C09","SASUKE VS OROCHIMARU","SASUKE","OROCHIMARU","FLORESTA",1,1,false,false},
  {"C10","SAKURA VS INO","SAKURA","INO","ARENA CHUNIN",1,1,false,false},
  {"C11","NARUTO VS KIBA","NARUTO","KIBA","ARENA CHUNIN",1,1,false,false},
  {"C12","HINATA VS NEJI","HINATA","NEJI","ARENA CHUNIN",1,1,false,false},
  {"C13","ROCK LEE VS GAARA","ROCK LEE","GAARA","ARENA CHUNIN",1,1,false,false},
  {"C14","SHIKAMARU VS TEMARI","SHIKAMARU","TEMARI","ARENA CHUNIN",1,1,false,false},
  {"C15","NARUTO VS NEJI","NARUTO","NEJI","ARENA CHUNIN",1,1,false,false},
  {"C16","SASUKE VS GAARA","SASUKE","GAARA","ARENA CHUNIN",1,1,false,false},
  {"C17","SHINO VS KANKURO","SHINO","KANKURO","FLORESTA",1,1,false,false},
  {"C18","NARUTO VS GAARA","NARUTO","GAARA","FLORESTA",1,1,false,false},
  {"C19","HIRUZEN VS OROCHIMARU","HIRUZEN","OROCHIMARU","TELHADOS DE KONOHA",1,1,false,false},
  {"C20","SASUKE VS ITACHI","SASUKE","ITACHI","KONOHA",1,1,false,false},
  {"C21","JIRAIYA VS AKATSUKI","JIRAIYA","ITACHI / KISAME","HOTEL",1,2,true,false},
  {"C22","NARUTO VS KABUTO","NARUTO","KABUTO","CAMPO ABERTO",1,1,false,false},
  {"C23","TSUNADE VS KABUTO","TSUNADE","KABUTO","CAMPO ABERTO",1,1,false,false},
  {"C24","DOIS SANNIN VS DOIS","JIRAIYA / TSUNADE","OROCHIMARU / KABUTO","CAMPO ABERTO",2,2,true,false},
  {"C25","JIRAIYA VS OROCHIMARU","JIRAIYA","OROCHIMARU","CAMPO ABERTO",1,1,false,false},
  {"C26","NARUTO VS SASUKE","NARUTO","SASUKE","TELHADO DO HOSPITAL",1,1,false,false},
  {"C27","CHOJI VS JIROBO","CHOJI","JIROBO","FLORESTA",1,1,false,true},
  {"C28","NEJI VS KIDOMARU","NEJI","KIDOMARU","FLORESTA",1,1,false,true},
  {"C29","KIBA VS SAKON/UKON","KIBA","SAKON/UKON","FLORESTA",1,1,false,true},
  {"C30","SHIKAMARU VS TAYUYA","SHIKAMARU","TAYUYA","FLORESTA",1,1,false,true},
  {"C31","KANKURO VS SAKON/UKON","KANKURO","SAKON/UKON","FLORESTA",1,1,false,true},
  {"C32","TEMARI VS TAYUYA","TEMARI","TAYUYA","FLORESTA",1,1,false,true},
  {"C33","ROCK LEE VS KIMIMARO","ROCK LEE","KIMIMARO","FLORESTA",1,1,false,false},
  {"C34","GAARA VS KIMIMARO","GAARA","KIMIMARO","FLORESTA",1,1,false,false},
  {"C35","LEE E GAARA VS KIMIMARO","ROCK LEE / GAARA","KIMIMARO","FLORESTA",2,1,true,false},
  {"C36","NARUTO VS KIMIMARO","NARUTO","KIMIMARO","FLORESTA",1,1,false,false},
  {"C37","VALE DO FIM","NARUTO","SASUKE","VALE DO FIM",1,1,false,false},
  {"C38","TRIO VS QUATRO DO SOM","NARUTO / SHIKAMARU / CHOJI","JIROBO / TAYUYA / KIDOMARU","FLORESTA",3,3,true,true},
  {"C39","RESGATE EM EQUIPE","NEJI / KIBA / SHIKAMARU","KIDOMARU / SAKON / TAYUYA","FLORESTA",3,3,true,true},
  {"C40","GRANDE CONFRONTO","NARUTO / LEE / GAARA","SASUKE / KIMIMARO / SAKON","VALE DO FIM",3,3,true,true}
}};
constexpr int ArcCount(){return static_cast<int>(kArcs.size());}
constexpr int MissionCount(){return static_cast<int>(kMissions.size());}
constexpr bool ValidArc(int a){return a>=0&&a<ArcCount();}
constexpr bool ValidMission(int m){return m>=0&&m<MissionCount();}
constexpr bool InArc(int a,int m){
  return ValidArc(a) && m>=kArcs[a].first && m<kArcs[a].first+kArcs[a].count;
}
constexpr int ArcForMission(int m){
  if(!ValidMission(m))return -1;
  for(int a=0;a<ArcCount();++a)if(InArc(a,m))return a;
  return -1;
}
constexpr int Wrap(int pos,int step,int count){
  if(count<=0)return 0;
  const int delta=step%count;
  return ((pos+delta)%count+count)%count;
}
constexpr int NavigateArc(int a,int step){
  return Wrap(ValidArc(a)?a:0,step,ArcCount());
}
constexpr int NavigateMission(int a,int m,int step){
  if(!ValidArc(a))return -1;
  const Arc& arc=kArcs[a];
  return arc.first+Wrap(InArc(a,m)?m-arc.first:0,step,arc.count);
}
struct Balance {
  int allyHealthPct;
  int enemyHealthPct;
  int enemyDamagePct;
};
// First-pass design settings, NOT engine-applied multipliers.
constexpr Balance ProposedBalance(int allies,int enemies){
  return (allies==1&&enemies==2)?Balance{120,75,100}:
         (allies==1&&enemies==3)?Balance{150,60,90}:
         (allies==2&&enemies==1)?Balance{100,175,115}:
         (allies==3&&enemies==1)?Balance{100,230,130}:
         (allies==3&&enemies==2)?Balance{100,140,110}:
         (allies==2&&enemies==3)?Balance{100,85,100}:
         Balance{100,100,100};
}
constexpr bool CanLaunch(const Mission& m,bool assetsVerified,bool loaderVerified){
  // Default false until real roster, stage and native battle loader are tested.
  return assetsVerified && loaderVerified && m.teamSize>=1 && m.teamSize<=3 &&
         m.enemySize>=1 && m.enemySize<=3;
}
} // namespace chronicles_classic
