// Proxy de winmm.dll: cada exportacao salta para a funcao real em System32.
#include "proxy.h"

#include <windows.h>

#include <cstdint>

namespace {
struct ExportInfo {
  const char* name;
  uint16_t ordinal;
};
const ExportInfo kExports[] = {
#include "winmm_names.inc"
};
constexpr size_t kNumExports = sizeof(kExports) / sizeof(kExports[0]);
extern "C" uintptr_t ProxyMissing() { return 0; }
}  // namespace

extern "C" void* g_proxyFn[kNumExports];
void* g_proxyFn[kNumExports];

bool ProxyInit() {
  wchar_t path[MAX_PATH];
  UINT n = GetSystemDirectoryW(path, MAX_PATH);
  if (n == 0 || n > MAX_PATH - 12) return false;
  lstrcatW(path, L"\\winmm.dll");
  HMODULE real = LoadLibraryW(path);
  if (!real) return false;
  for (size_t i = 0; i < kNumExports; ++i) {
    FARPROC p = kExports[i].name ? GetProcAddress(real, kExports[i].name)
                                 : GetProcAddress(real, MAKEINTRESOURCEA(kExports[i].ordinal));
    g_proxyFn[i] = p ? reinterpret_cast<void*>(p) : reinterpret_cast<void*>(&ProxyMissing);
  }
  return true;
}
