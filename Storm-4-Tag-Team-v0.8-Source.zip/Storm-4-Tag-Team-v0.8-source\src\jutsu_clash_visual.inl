// Storm 1-inspired animated power collision (local Storm 1 texture extraction).
// Separate ignition -> looping energy -> advancing winner/dual burst -> aftermath.
// This is a new presentation controller, not a binary copy of Storm 1's engine.
void BuildJutsuClashAnimated(const ClashHud& c, const HudFighter* fighters) {
  using namespace clash_visual;
  const ModImage* warm = LoadModImage(L"storm6_storm1\\xbattle_s-eff01.png");
  const ModImage* cool = LoadModImage(L"storm6_storm1\\xbattle_s-eff03.png");
  const ModImage* flameL = LoadModImage(L"storm6_storm1\\xbattle_s-eff05.png");
  const ModImage* flameR = LoadModImage(L"storm6_storm1\\xbattle_s-eff06.png");
  const ModImage* explosion = LoadModImage(L"storm6_storm1\\xbattle_s-eff07.png");
  const float scale = std::max(0.1f, std::min(g_w / 1600.0f, g_h / 900.0f));
  const AnimationPhase phase = Phase(c.elapsedMs, c.result, c.resultAgeMs);
  const bool live = c.result < 0;
  const float alpha = Opacity(c.result, c.resultAgeMs);
  if (alpha < 0.012f) return;
  const float t = float(c.elapsedMs);
  const float pulse = 0.5f + 0.5f * std::sin(t * 0.022f);
  const float ignition = Ease(float(c.elapsedMs) / float(kIgnitionMs));
  const float rise = live ? (0.28f + 0.72f * ignition) : 1.0f;

  float ax = g_w * 0.24f, bx = g_w * 0.76f, ay = g_h * 0.53f, by = ay;
  if (c.hasPos) {
    const float worldA[3] = {c.posA[0], c.posA[1], c.posA[2] + 105.0f};
    const float worldB[3] = {c.posB[0], c.posB[1], c.posB[2] + 105.0f};
    float sxA = 0, syA = 0, sxB = 0, syB = 0;
    bool backA = false, backB = false;
    if (CameraProject(worldA, g_w / g_h, &sxA, &syA, &backA) &&
        CameraProject(worldB, g_w / g_h, &sxB, &syB, &backB) &&
        !backA && !backB && std::fabs(sxA) < 1.3f && std::fabs(sxB) < 1.3f &&
        std::fabs(syA) < 1.3f && std::fabs(syB) < 1.3f) {
      ax = (sxA * 0.5f + 0.5f) * g_w; ay = (0.5f - syA * 0.5f) * g_h;
      bx = (sxB * 0.5f + 0.5f) * g_w; by = (0.5f - syB * 0.5f) * g_h;
    }
  }
  float worldMx = 0, worldMy = 0;
  const bool worldContact = ProjectClashWorldAnchors(c, &ax, &ay, &bx, &by, &worldMx, &worldMy);
  const bool aLeft = ax <= bx;
  const float lx = aLeft ? ax : bx, ly = aLeft ? ay : by;
  const float rx = aLeft ? bx : ax, ry = aLeft ? by : ay;
  const int lNumber = aLeft ? c.numberA : c.numberB;
  const int rNumber = aLeft ? c.numberB : c.numberA;
  const unsigned lScore = aLeft ? c.scoreA : c.scoreB;
  const unsigned rScore = aLeft ? c.scoreB : c.scoreA;
  const float share = (lScore + rScore) ? float(lScore) / float(lScore + rScore) : 0.5f;
  const float meet = Meeting(share, aLeft, c.result, c.resultAgeMs);
  const float mx = worldContact ? worldMx : lx + (rx - lx) * meet;
  const float my = worldContact ? worldMy : ly + (ry - ly) * meet;
  const float separation = std::hypot(rx - lx, ry - ly);
  const float width = std::clamp(separation * 0.62f, 125.0f * scale, 335.0f * scale) *
                      (0.84f + pulse * 0.20f) * rise;
  const bool leftWins = (c.result == 1) == aLeft;
  const float travel = Ease(float(c.resultAgeMs) / float(kTravelMs));
  const float leftPower = live || c.result == 0 ? 1.0f : leftWins ? (1.0f + 0.38f * travel) : (1.0f - 0.88f * travel);
  const float rightPower = live || c.result == 0 ? 1.0f : !leftWins ? (1.0f + 0.38f * travel) : (1.0f - 0.88f * travel);
  const unsigned frame = Frame4(c.elapsedMs);
  const unsigned fireFrame = Frame8(c.elapsedMs);
  const float igniteShake = std::sin(t * 0.048f) * 5.0f * scale * rise;

  // Cinematic letterbox and shaded arena: the energy remains attached to the projected fighters.
  Rect(0, 0, g_w, g_h, 0.015f, 0.025f, 0.06f, 0.16f * alpha);
  ClashVignette(0.33f, 0.85f * alpha);
  Rect(0, 0, g_w, 45 * scale, 0.005f, 0.009f, 0.022f, 0.96f * alpha);
  Rect(0, g_h - 47 * scale, g_w, 47 * scale, 0.005f, 0.009f, 0.022f, 0.96f * alpha);

  // Repeating Storm 1 energy atlas rows: each of these sprites has 4 frames stacked vertically.
  PlainBeam(lx, ly, mx, my, width * leftPower * 0.74f, kMenuBlue, alpha);
  PlainBeam(rx, ry, mx, my, width * rightPower * 0.74f, kMenuAmber, alpha);
  if (cool && warm) {
    ImageBeam(cool, 0, float(frame) * 192.0f, 330, 192, lx, ly, mx, my,
              width * leftPower * 1.33f, alpha * 0.96f);
    ImageBeam(warm, 0, float(frame) * 192.0f, 330, 192, rx, ry, mx, my,
              width * rightPower * 1.33f, alpha * 0.96f);
  }

  // Two animated source cores; these keep pulsing even when the Storm 4 actors are paused.
  const float sourceSize = (170.0f + 45.0f * pulse) * scale * rise;
  if (explosion) {
    ImagePart(explosion, 0, 0, 192, 192,
              lx - sourceSize * 0.5f, ly - sourceSize * 0.5f, sourceSize, sourceSize,
              alpha * leftPower, false, Rgba{0.48f, 0.78f, 1.0f, 1.0f});
    ImagePart(explosion, 0, 0, 192, 192,
              rx - sourceSize * 0.5f, ry - sourceSize * 0.5f, sourceSize, sourceSize,
              alpha * rightPower, false, Rgba{1.0f, 0.62f, 0.27f, 1.0f});
  }
  if (flameL) ImagePart(flameL, float(fireFrame) * 96, 0, 96, 192,
      lx - 46 * scale, ly - 118 * scale, 92 * scale, 235 * scale, 0.90f * alpha * leftPower);
  if (flameR) ImagePart(flameR, float(fireFrame) * 96, 0, 96, 192,
      rx - 46 * scale, ry - 118 * scale, 92 * scale, 235 * scale, 0.90f * alpha * rightPower);

  // Alternating streaks and spiral arcs: visible travel toward the point of collision, not static beams.
  for (int i = 0; i < 34; ++i) {
    const bool fromLeft = (i % 2) == 0;
    const float startX = fromLeft ? lx : rx, startY = fromLeft ? ly : ry;
    const float endX = mx, endY = my;
    const float speed = (i % 3 == 0 ? 0.00059f : 0.00038f);
    const float along = std::fmod(float(i) * 0.179f + t * speed, 1.0f);
    const float ortho = std::sin(t * 0.011f + float(i) * 3.17f) * width * 0.24f;
    const float dx = endX - startX, dy = endY - startY;
    const float mag = std::max(1.0f, std::hypot(dx, dy));
    const float px = startX + dx * along - dy / mag * ortho;
    const float py = startY + dy * along + dx / mag * ortho;
    const float len = (18.0f + float(i % 5) * 6.0f) * scale;
    const Rgba tone = fromLeft ? Rgba{0.70f, 0.90f, 1.0f, 0.85f * alpha}
                               : Rgba{1.0f, 0.78f, 0.40f, 0.85f * alpha};
    LockStroke(px - dx / mag * len, py - dy / mag * len, px, py, (1.8f + (i % 3)) * scale, tone);
  }
  // The meeting point throws off radial sparks, following the score and the finishing sweep.
  const float core = (140.0f + 46.0f * pulse) * scale * rise;
  if (explosion) ImagePart(explosion, 0, 0, 192, 192,
      mx - core * 0.5f, my - core * 0.5f, core, core, alpha * 0.95f);
  for (int i = 0; i < 22; ++i) {
    const float a = float(i) * 2.39996f + t * 0.00059f;
    const float dist = (39.0f + 45.0f * std::sin(t * 0.009f + i * 1.8f)) * scale * rise;
    const float len = (18.0f + 30.0f * pulse) * scale;
    const float x = mx + std::cos(a) * dist, y = my + std::sin(a) * dist + igniteShake;
    LockStroke(x, y, x + std::cos(a) * len, y + std::sin(a) * len,
               2.2f * scale, Rgba{1.0f, 0.94f, 0.77f, 0.83f * alpha});
  }

  // Storm 1-style opposing energy gauges, tied to real counted button presses.
  const float barW = std::min(g_w * 0.67f, 1010.0f * scale);
  const float barX = (g_w - barW) * 0.5f, barY = g_h * 0.825f;
  const float barH = 19 * scale, barMeet = barX + barW * meet;
  Rect(barX - 6*scale, barY - 6*scale, barW + 12*scale, barH + 12*scale,
       0.02f, 0.035f, 0.07f, 0.94f * alpha);
  Rect(barX, barY, std::max(0.0f, barMeet - barX), barH,
       kMenuBlue.r, kMenuBlue.g, kMenuBlue.b, alpha);
  Rect(barMeet, barY, std::max(0.0f, barX + barW - barMeet), barH,
       kMenuAmber.r, kMenuAmber.g, kMenuAmber.b, alpha);
  Rect(barMeet - 4*scale, barY - 12*scale, 8*scale, barH + 24*scale,
       1.0f, 0.96f, 0.80f, alpha);
  if (flameL) ImagePart(flameL, float(fireFrame) * 96, 0, 96, 192,
      barMeet - 50*scale, barY - 82*scale, 50*scale, 102*scale, alpha);
  if (flameR) ImagePart(flameR, float(fireFrame) * 96, 0, 96, 192,
      barMeet, barY - 82*scale, 50*scale, 102*scale, alpha);

  char line[96];
  const MenuView ui{barX,barY,scale};
  if (live) {
    std::snprintf(line,sizeof(line),"J%d  B / O   %u",lNumber,lScore);
    ui.Label(0, -64, line, 26, kMenuBlue);
    std::snprintf(line,sizeof(line),"%u   B / O  J%d",rScore,rNumber);
    ui.Right(barW / scale, -64, line, 26, kMenuAmber);
    std::snprintf(line,sizeof(line),"JUTSU CLASH  %.1f",float(c.remainingMs)/1000.0f);
    const float w = TextWidth(line,30*scale);
    Text(g_w*0.5f-w*0.5f,g_h*0.15f,line,30*scale,1,1,1,alpha);
  } else {
    const bool drawn = c.result == 0;
    if (phase == AnimationPhase::WinnerAdvance || phase == AnimationPhase::DrawBurst) {
      std::snprintf(line,sizeof(line), drawn ? Lang("CHOQUE FINAL!","FINAL CLASH!") : Lang("J%d DOMINOU O JUTSU!","J%d OVERPOWERS THE JUTSU!"), c.result == 1 ? c.numberA : c.numberB);
    } else {
      std::snprintf(line,sizeof(line), drawn ? Lang("EMPATE! JUTSUS ANULADOS","DRAW! JUTSU CANCELLED") : Lang("J%d VENCEU!","J%d WINS!"), c.result == 1 ? c.numberA : c.numberB);
    }
    const float size = 52*scale, w = TextWidth(line,size);
    Text(g_w*0.5f-w*0.5f,g_h*0.17f,line,size,kMenuGold.r,kMenuGold.g,kMenuGold.b,alpha);
    if (c.resultAgeMs >= 290 && c.resultAgeMs < 1450) {
      const float boomAge = float(c.resultAgeMs) - 290.0f;
      const float boomAlpha = alpha * (1.0f - Ease((boomAge-650.0f)/650.0f));
      const float boomSize = (95.0f + Ease(boomAge/570.0f)*650.0f)*scale;
      const float blastX = drawn ? mx : leftWins ? rx : lx;
      const float blastY = drawn ? my : leftWins ? ry : ly;
      if (explosion) ImagePart(explosion,0,0,192,192,
          blastX-boomSize*0.5f,blastY-boomSize*0.5f,boomSize,boomSize,
          std::max(0.0f,boomAlpha));
      if (c.resultAgeMs < 550)
        Rect(0,0,g_w,g_h,1,1,1,0.42f*(1.0f-Ease(float(c.resultAgeMs)/550.0f)));
    }
  }

  // Character cut-ins are an animated intro over the ongoing power collision.
  if (live && phase == AnimationPhase::Ignition) {
    const float a = 1.0f - Ease((float(c.elapsedMs) - 420.0f) / 260.0f);
    const float slide = Ease(float(c.elapsedMs) / 270.0f);
    const int nums[2] = {lNumber,rNumber};
    for(int side=0;side<2;++side) {
      const char* code = ClashPortraitCode(fighters,nums[side]);
      const float cx = (side==0 ? 0.22f : 0.78f)*g_w +
          (1.0f-slide)*(side==0 ? -0.25f : 0.25f)*g_w;
      const float box = g_h*0.38f;
      if(const auto* pic=code?Portrait(code):nullptr) {
        const float pw=pic->aspect>=1.0f ? box : box*pic->aspect;
        const float ph=pic->aspect>=1.0f ? box/pic->aspect : box;
        Quad(cx-pw*0.5f,g_h*0.36f-ph*0.5f,pw,ph,side==0?0.0f:1.0f,0,
             side==0?1.0f:0.0f,1,1,1,1,a*0.88f,pic->texture.Get());
      }
    }
    const char* title="JUTSU CLASH!";
    const float size=69*scale, w=TextWidth(title,size);
    Text(g_w*0.5f-w*0.5f,g_h*0.27f,title,size,1,0.87f,0.62f,a);
  }
}
