// Contato volumetrico EXPERIMENTAL. Ponto de origem e encontro sao calculados
// em coordenadas do mundo, projetados depois pela camera. Evita colar o sprite
// no quadril/personagem errado com camera em perspectiva.
// Atinge uma aproximacao das maos (nao toca os ossos do modelo).
namespace clash_motion {
struct WorldAnchors {
  float sourceA[3]{};
  float sourceB[3]{};
  float contact[3]{};
};
inline bool MakeWorldAnchors(const float a[3], const float b[3],
                             unsigned scoreA, unsigned scoreB,
                             WorldAnchors* out) {
  if (!out || !a || !b) return false;
  for (int i = 0; i < 3; ++i)
    if (!std::isfinite(a[i]) || !std::isfinite(b[i])) return false;
  const float vx = b[0] - a[0], vy = b[1] - a[1];
  const float dist = std::hypot(vx, vy);
  if (!(dist >= 60.0f) || dist > 20000.0f) return false;
  const float ux = vx / dist, uy = vy / dist;
  const float reach = std::min(55.0f, dist * 0.34f);
  constexpr float handHeight = 77.0f; // provisoria: validar a altura dos ossos de Naruto e Sasuke
  out->sourceA[0] = a[0] + ux * reach;
  out->sourceA[1] = a[1] + uy * reach;
  out->sourceA[2] = a[2] + handHeight;
  out->sourceB[0] = b[0] - ux * reach;
  out->sourceB[1] = b[1] - uy * reach;
  out->sourceB[2] = b[2] + handHeight;
  const float k = ContactFraction(scoreA, scoreB);
  for (int i = 0; i < 3; ++i)
    out->contact[i] = out->sourceA[i] * (1.0f - k) + out->sourceB[i] * k;
  return true;
}
} // namespace clash_motion
