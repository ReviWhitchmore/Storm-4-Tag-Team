#include "grab_defense.h"

#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

#include "addresses.h"
#include "grab_defense_rules.h"
#include "cpu_adapt.h"
#include "log.h"
#include "settings.h"

namespace {
constexpr BYTE kTriggerThreshold = 42;  // mesmo limite do parry (RT/R2)
constexpr uint64_t kFreshPressMs = 100; // aperto que ainda vale para o quadro de logica atual

std::atomic<bool> g_enabled{true};
std::atomic<unsigned> g_windowMs{grabdef::kDefaultWindowMs};
std::atomic<unsigned> g_cpuChance{35};  // % de a CPU escapar quando o agarrao chega na janela

// Entrada (thread do XInput): borda de subida do RT por controle.
std::atomic<bool> g_held[4]{};
std::atomic<uint64_t> g_pressAt[4]{};

// Logica (thread do jogo).
struct Track {
  bool active = false;
  uint64_t startedAt = 0;
  int defender = -1;
  float lastDistance = 0;
  uint64_t lastAt = 0;
  float closing = 0;
  bool decided = false;
  // DIAGNOSTICO: amostras (distancia, tempo ate o contato) durante o agarrao.
  int samples = 0;
  char trace[360]{};
  int traceLen = 0;
  int number = 0;
};
Track g_track[6]{};
uint32_t g_rng = 0x9E3779B9u;
std::atomic<uint64_t> g_feedbackUntil{0};
std::atomic<int> g_feedbackDefender{0}, g_feedbackAttacker{0};
unsigned g_logLines = 0;

uint32_t NextRandom() {
  g_rng ^= g_rng << 13;
  g_rng ^= g_rng >> 17;
  g_rng ^= g_rng << 5;
  return g_rng;
}

// vtable +0x11A8 (FUN_1407D58A0): lutador despertado. Gigantes sao despertares; sem marca propria achada,
// a defesa fica desligada contra qualquer atacante despertado.
bool Awakened(uintptr_t player) {
  __try {
    auto** vtable = *reinterpret_cast<int (***)(uintptr_t)>(player);
    return vtable && vtable[0x11A8 / sizeof(void*)] && vtable[0x11A8 / sizeof(void*)](player) != 0;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return true;  // na duvida, nao interfere
  }
}

bool PushBack(uintptr_t player) {
  __try {
    auto** vtable = *reinterpret_cast<void (***)(uintptr_t, int)>(player);
    auto change = vtable ? vtable[Addr().vtChangeState / sizeof(void*)] : nullptr;
    if (!change) return false;
    change(player, grabdef::kOffsetKnockback);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

void LogLimited(const char* fmt, int a, int b, int c, float d) {
  if (g_logLines >= 120) return;
  ++g_logLines;
  Log(fmt, a, b, c, d);
}
}  // namespace

void GrabDefenseInstall() {
  if (Addr().timestamp != 0x5889906E) {
    g_enabled = false;
    Log("DEFESA DE AGARRAO: disponivel somente no Evolution verificado.");
    return;
  }
  bool enabled = true;
  unsigned window = grabdef::kDefaultWindowMs, cpu = 35;
  const std::wstring file = ModDir() + L"storm6.ini";
  if (FILE* stream = _wfopen(file.c_str(), L"r")) {
    char line[128];
    while (std::fgets(line, sizeof(line), stream)) {
      char key[65]{};
      int value = 0;
      if (std::sscanf(line, "%64[^=]=%d", key, &value) != 2) continue;
      if (!std::strcmp(key, "defesa_agarrao")) enabled = value != 0;
      else if (!std::strcmp(key, "defesa_agarrao_janela_ms") && value >= 80 && value <= 400) window = unsigned(value);
      else if (!std::strcmp(key, "defesa_agarrao_cpu") && value >= 0 && value <= 100) cpu = unsigned(value);
    }
    std::fclose(stream);
  }
  g_enabled = enabled;
  g_windowMs = window;
  g_cpuChance = cpu;
  Log("DEFESA DE AGARRAO: %s janela=%ums, CPU escapa %u%%. Aperte defesa (RT/R2) pouco antes do agarrao.",
      enabled ? "ATIVA" : "desligada (storm6.ini defesa_agarrao=1)", window, cpu);
}

void GrabDefenseObserveGuard(DWORD pad, const XINPUT_STATE* state, bool connected) {
  if (pad >= 4 || !g_enabled.load(std::memory_order_relaxed)) return;
  const bool held = connected && state && state->Gamepad.bRightTrigger >= kTriggerThreshold;
  const bool was = g_held[pad].exchange(held, std::memory_order_relaxed);
  if (held && !was) g_pressAt[pad].store(GetTickCount64(), std::memory_order_release);
}

void GrabDefenseBeginBattle() {
  for (auto& t : g_track) t = {};
  for (auto& p : g_pressAt) p = 0;
  g_feedbackUntil = 0;
  g_logLines = 0;
  g_rng ^= static_cast<uint32_t>(GetTickCount64());
  if (!g_rng) g_rng = 0x9E3779B9u;
}

void GrabDefenseTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (!g_enabled.load(std::memory_order_relaxed) || n < 2 || n > 6) return;
  const unsigned window = g_windowMs.load(std::memory_order_relaxed);
  for (int a = 0; a < n; ++a) {
    Track& t = g_track[a];
    if (!f[a].valid || f[a].state != grabdef::kThrowBegin) {
      if (t.active && g_logLines < 120) {
        ++g_logLines;
        Log("AGARRAO AMOSTRAS J%d (%d quadros, %llu ms, saiu para 0x%X):%s", t.number, t.samples,
            static_cast<unsigned long long>(now - t.startedAt), f[a].state, t.trace);
      }
      t.active = false;
      continue;
    }
    if (!t.active) {
      t = {};
      t.active = true;
      t.startedAt = now;
      t.number = f[a].number;
    }
    // Defensor: o adversario vivo mais perto do agarrao.
    int d = -1;
    float best = 0;
    for (int k = 0; k < n; ++k) {
      if (!f[k].valid || !CpuAdaptEnemy(a,f[a].side,k,f[k].side,Cfg().freeForAll.load(std::memory_order_relaxed))) continue;
      const float dx = f[k].pos[0] - f[a].pos[0], dy = f[k].pos[1] - f[a].pos[1];
      const float dist = std::sqrt(dx * dx + dy * dy);
      if (d < 0 || dist < best) {
        d = k;
        best = dist;
      }
    }
    if (d < 0) continue;
    if (d != t.defender) {
      t.defender = d;
      t.lastAt = 0;
      t.closing = 0;
    }
    if (t.lastAt && now > t.lastAt) {
      const float instant = (t.lastDistance - best) * 1000.0f / float(now - t.lastAt);
      t.closing = t.closing > 0 ? t.closing * 0.5f + instant * 0.5f : instant;
    }
    t.lastDistance = best;
    t.lastAt = now;
    ++t.samples;
    if (t.traceLen < 330)
      t.traceLen += std::snprintf(t.trace + t.traceLen, sizeof(t.trace) - t.traceLen, " %.0f/%d",
                                  best, grabdef::TimeToContactMs(best, t.closing));
    if (t.decided) continue;
    const int ttc = grabdef::TimeToContactMs(best, t.closing);
    const bool allowed = !sceneActive && grabdef::DefenderCanReact(f[d].state) && !Awakened(f[a].player);
    bool escape = false;
    if (f[d].pad >= 0 && f[d].pad < 4) {
      const uint64_t pressed = g_pressAt[f[d].pad].load(std::memory_order_acquire);
      if (!pressed || now < pressed || now - pressed > kFreshPressMs || pressed < t.startedAt) continue;
      g_pressAt[f[d].pad].store(0, std::memory_order_relaxed);  // um aperto, uma tentativa
      if (!allowed) {
        LogLimited("DEFESA DE AGARRAO: J%d apertou contra J%d em estado sem defesa (0x%X, dist %.0f).",
                   f[d].number, f[a].number, f[d].state, best);
        t.decided = true;
        continue;
      }
      t.decided = true;
      if (!grabdef::InWindow(ttc, window)) {
        LogLimited("DEFESA DE AGARRAO: J%d apertou fora da janela contra J%d (faltavam %d ms, dist %.0f).",
                   f[d].number, f[a].number, ttc, best);
        continue;
      }
      escape = true;
    } else {
      // CPU: uma chance quando o agarrao entra na janela.
      if (!allowed || !grabdef::InWindow(ttc, window)) continue;
      t.decided = true;
      const unsigned chance=CpuAdaptChance(g_cpuChance.load(std::memory_order_relaxed),f[d].player,cpuai::Action::GrabDefense);
      escape = chance > 0 && NextRandom() % 100 < chance;
      if (!escape) {
        LogLimited("DEFESA DE AGARRAO: CPU J%d nao escapou do agarrao de J%d (faltavam %d ms, dist %.0f).",
                   f[d].number, f[a].number, ttc, best);
        continue;
      }
    }
    if (!PushBack(f[a].player)) {
      Log("DEFESA DE AGARRAO: falha segura ao empurrar J%d.", f[a].number);
      continue;
    }
    g_feedbackDefender = f[d].number;
    g_feedbackAttacker = f[a].number;
    g_feedbackUntil = now + 900;
    LogLimited("DEFESA DE AGARRAO: J%d escapou do agarrao de J%d (faltavam %d ms, dist %.0f); atacante recuou "
               "(PL_ACT_OFFSET_KNOCKBACK).",
               f[d].number, f[a].number, ttc, best);
  }
}

bool GrabDefenseFeedback(int* defenderNumber, int* attackerNumber) {
  const uint64_t until = g_feedbackUntil.load(std::memory_order_relaxed);
  if (!until || GetTickCount64() > until) return false;
  if (defenderNumber) *defenderNumber = g_feedbackDefender;
  if (attackerNumber) *attackerNumber = g_feedbackAttacker;
  return true;
}
