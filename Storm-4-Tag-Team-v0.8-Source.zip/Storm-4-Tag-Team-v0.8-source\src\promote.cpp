// Fase 1 do 3v3: os 3 membros de cada lado entram como papel 0 (em campo).
//
// FUN_14074DDB8(duel, side, role, slot) cria um membro:
//   - copia a configuracao do lado (0x1AC bytes em 0x141611A8C + side*0x1AC) para a pilha;
//     o bloco do papel R fica em +R*0x3C;
//   - cria o lutador pela fabrica, insere no time com o papel (FUN_14074BA2C) e no
//     sub-objeto membro (player+0xB00, vt+8);
//   - se papel != 0: chama vt+0x1590 (guarda o lutador fora de campo) e zera player+0xCA8.
// Para criar o membro R "em campo" com as configuracoes dele, trocamos os blocos 0 e R
// na tabela global, chamamos a original com papel 0 e desfazemos a troca.

#include "promote.h"

#include <windows.h>
#include <MinHook.h>
#include <intrin.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

#include "census.h"
#include "camera.h"
#include "chronicles.h"
#include "hud.h"
#include "addresses.h"
#include "input.h"
#include "polish_rules.h"
#include "entrance_rules.h"
#include "ffa_release_rules.h"
#include "revolution_lockon_rules.h"
#include "log.h"
#include "settings.h"
#include "parry.h"
#include "grab_defense.h"
#include "perfect_sub.h"
#include "jutsu_clash.h"
#include "dual_combo.h"
#include "wall_run.h"
#include "parry_rules.h"
#include "ult.h"
#include "ultimate_owner_rules.h"

namespace {

#define kRvaCreateInner (Addr().createInner)
#define kRvaSideConfig (Addr().sideConfigBase + 0xC)  // config dos lados + 0xC
constexpr size_t kSideConfigStride = 0x1AC;
constexpr size_t kRoleBlock = 0x3C;
constexpr uintptr_t kTeamOffset = 0x18;
constexpr uintptr_t kTeamStride = 0x68;
constexpr uintptr_t kOnFieldFlag = 0xCA8;
constexpr uintptr_t kMemberGauges = 0x38;

using CreateInner_t = uintptr_t (*)(void* duel, int side, int role, int slot);
CreateInner_t g_orig = nullptr;

struct Tracked {
  std::atomic<void*> team{nullptr};
  int side = -1, origRole = -1, slot = -1;
};
Tracked g_tracked[6];
int g_slotControls[6];
std::atomic<bool> g_promotionReady{false};

bool Enabled() {
  return g_promotionReady.load(std::memory_order_acquire) && Cfg().mode3v3.load(std::memory_order_relaxed);
}

bool IsRosterSlot(int side, int role, int slot) {
  return side >= 0 && side < 2 && role >= 0 && role < 3 && slot == side * 3 + role;
}

// Percorre o std::map do time (MSVC: head em team+8; no: +0 esq, +8 pai, +0x10 dir,
// +0x19 isnil, +0x20 chave, +0x28 membro, +0x30 lutador).
template <typename F>
void ForEachNode(uintptr_t team, F&& fn) {
  uintptr_t head = *reinterpret_cast<uintptr_t*>(team + 8);
  if (!head) return;
  uintptr_t node = *reinterpret_cast<uintptr_t*>(head);  // mais a esquerda
  for (int guard = 0; node != head && guard < 32; ++guard) {
    if (*reinterpret_cast<uint8_t*>(node + 0x19)) break;
    fn(node);
    uintptr_t right = *reinterpret_cast<uintptr_t*>(node + 0x10);
    if (!*reinterpret_cast<uint8_t*>(right + 0x19)) {
      node = right;
      while (!*reinterpret_cast<uint8_t*>(*reinterpret_cast<uintptr_t*>(node) + 0x19))
        node = *reinterpret_cast<uintptr_t*>(node);
    } else {
      uintptr_t parent = *reinterpret_cast<uintptr_t*>(node + 8);
      while (!*reinterpret_cast<uint8_t*>(parent + 0x19) &&
             node == *reinterpret_cast<uintptr_t*>(parent + 0x10)) {
        node = parent;
        parent = *reinterpret_cast<uintptr_t*>(node + 8);
      }
      node = parent;
    }
  }
}

void SwapBlocks(int side, int role) {
  uint8_t* cfg = reinterpret_cast<uint8_t*>(g_base + kRvaSideConfig + side * kSideConfigStride);
  uint8_t tmp[kRoleBlock];
  std::memcpy(tmp, cfg, kRoleBlock);
  std::memcpy(cfg, cfg + role * kRoleBlock, kRoleBlock);
  std::memcpy(cfg + role * kRoleBlock, tmp, kRoleBlock);
}

// Janela de montagem: da criacao do slot 0 ate o primeiro quadro do juiz.
std::atomic<bool> g_setupWindow{false};
std::atomic<unsigned> g_collisionSampleCount{0};
// Dentro da desmontagem da batalha (>0): papeis 1/2 voltam a responder os extras, para o jogo
// limpar e remover cada um; as regras de contexto ficam desligadas (lutadores sendo destruidos).
std::atomic<int> g_teardownDepth{0};
std::atomic<int> g_answers{0};
constexpr int kMaxLoggedSites = 64;
uint32_t g_loggedSites[kMaxLoggedSites];
std::atomic<int> g_numLogged{0};

uintptr_t HookCreateInner(void* duel, int side, int role, int slot) {
  if (!IsRosterSlot(side, role, slot)) return g_orig(duel, side, role, slot);
  const bool promote = role != 0 && Enabled();
  if (slot == 0 && Enabled()) {
    std::fill_n(g_slotControls, 6, kSlotCpu);
    g_setupWindow = true;
    // Discard menu/previous battle collider pointers at the new fighter setup.
    g_collisionSampleCount.store(0, std::memory_order_release);
    g_answers = 0;
    Log("Montagem: janela aberta (buscas por papel 1/2 recebem os extras).");
  }
  if (slot >= 0 && slot < 6) {
    g_tracked[slot].team = reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(duel) + kTeamOffset +
                                                   side * kTeamStride);
    g_tracked[slot].side = side;
    g_tracked[slot].origRole = role;
    g_tracked[slot].slot = slot;
  }
  uintptr_t r;
  if (promote) {
    SwapBlocks(side, role);
    r = g_orig(duel, side, 0, slot);
    SwapBlocks(side, role);
  } else {
    r = g_orig(duel, side, role, slot);
  }
  Log("Criado: lado=%d papel_original=%d slot=%d %s", side, role, slot,
      promote ? "-> EM CAMPO (papel 0)" : "(normal)");
  return r;
}

// ---------------------------------------------------------------- CPU ou jogador por membro
// FUN_14074E4C0(duel, side, role, slot) prepara cada membro na montagem: vt+0xAF0 e, se a marca do
// lado [0x141611A80 + side*0x1AC + 0xC0] diz CPU, vt+0x1340 (cria o "cerebro" de CPU do membro).
// Trocando essa marca so durante a chamada, cada membro pode ser CPU ou jogador.

#define kRvaMemberSetup (Addr().memberSetup)
#define kRvaSideCpuFlag (Addr().sideConfigBase + 0xC0)

using MemberSetup_t = uintptr_t (*)(void* duel, int side, int role, int slot);
MemberSetup_t g_origSetup = nullptr;

uintptr_t HookMemberSetup(void* duel, int side, int role, int slot) {
  if (!Enabled() || !IsRosterSlot(side, role, slot)) return g_origSetup(duel, side, role, slot);
  const int index = side * 3 + role;
  int want = Cfg().slot[index].load();
  int* flag = reinterpret_cast<int*>(g_base + kRvaSideCpuFlag + side * kSideConfigStride);
  const int saved = *flag;
  if (want == kSlotAuto) {
    // O principal Automatico segue o Versus se o seu controle nao foi
    // atribuido a outro lutador presente na luta.
    bool reserved = false;
    if (role == 0 && InputBattleReady()) {
      for (int team = 0; team < 2; ++team) {
        const uintptr_t teamPtr = reinterpret_cast<uintptr_t>(duel) + kTeamOffset + team * kTeamStride;
        ForEachNode(teamPtr, [&](uintptr_t node) {
          const int row = *reinterpret_cast<const int*>(node + 0x20);
          if (row >= 0 && row < 3 && SlotPadIndex(Cfg().slot[team * 3 + row].load()) == side)
            reserved = true;
        });
      }
    }
    if (role != 0 || saved != 0 || reserved) want = kSlotCpu;
    // Contra a CPU, os colegas Automaticos da equipe 1 vao para os controles livres:
    // J2 -> Player 2, J3 -> Player 3.
    if (side == 0 && role != 0 && InputBattleReady()) {
      const auto cpuFlag = [](int team) {
        return *reinterpret_cast<const int*>(g_base + kRvaSideCpuFlag + team * kSideConfigStride);
      };
      bool padTaken = false;
      for (const auto& slot : Cfg().slot) padTaken |= SlotPadIndex(slot.load()) == role;
      if (saved == 0 && cpuFlag(1) != 0 && !padTaken && InputPadStatus(role, nullptr))
        want = kSlotPlayer1 + role;
    }
  } else if (SlotPadIndex(want) >= 0 && !InputBattleReady()) {
    want = role == 0 && SlotPadIndex(want) == side ? kSlotAuto : kSlotCpu;
  }
  // An explicitly assigned extra controller may be unplugged at match setup.
  // Without fallback the pad router feeds zero input forever, making the fighter freeze.
  const int assignedPad = SlotPadIndex(want);
  if (assignedPad >= 0 && InputBattleReady() && !InputPadConnected(assignedPad)) {
    Log("Controle: J%d usava Player %d desconectado; passando para CPU nesta luta.",
        index + 1, assignedPad + 1);
    want = kSlotCpu;
  }
  g_slotControls[index] = want;
  *flag = (want == kSlotCpu) ? 1 : 0;
  uintptr_t r = g_origSetup(duel, side, role, slot);
  *flag = saved;
  const int pad = SlotPadIndex(want);
  if (pad >= 0) Log("Controle: J%d -> Player %d", index + 1, pad + 1);
  else Log("Controle: J%d -> %s", index + 1, want == kSlotCpu ? "CPU" : "Automatico");
  return r;
}

// ---------------------------------------------------------------- tick no jogo
// FUN_14074D248 e o juiz da rodada: roda uma vez por quadro durante a luta, na
// thread do jogo. Usamos como ponto seguro para mexer nos lutadores.
//
// FUN_1407CA2F8 traz um suporte para a arena com estado 0xE4. Usamos
// essa entrada apenas como resgate para extras ainda fora de campo.

#define kRvaJudge (Addr().judge)
#define kVtChangeState (Addr().vtChangeState)
constexpr int kEnterState = 0xE4;
constexpr int kAwakeBeginState = 0x7C; // PL_ACT_AWAKE_BEGIN (Evolution game action enum)
constexpr int kDelayFrames = 180;

using Judge_t = uintptr_t (*)(void* self);
Judge_t g_origJudge = nullptr;
uintptr_t g_battleKey = 0;  // ponteiro do duelo: estavel mesmo quando um lutador e derrotado
int g_frames = 0;
bool g_entered = false;
int g_entranceWave = 0;
int g_entranceWaveElapsed = 0;
int g_awakeningNext = 0;
ULONGLONG g_awakeningLast = 0;

// Lutadores da batalha atual (preenchido no 1o quadro da luta, na thread do jogo).
// Ordem: lado 0 primeiro, depois lado 1; cada lado com 1 a 3 lutadores (equipes podem ser desiguais).
struct Fighter {
  uintptr_t player = 0;
  uintptr_t node = 0;
  uintptr_t team = 0;
  int side = 0;
  int row = 0;  // posicao dentro da equipe (0..2)
  int control = kSlotCpu;
};
Fighter g_fighters[6];
std::atomic<int> g_numFighters{0};
int g_sideCount[2] = {0, 0};
uintptr_t g_team[2] = {0, 0};
std::atomic<uint64_t> g_ctxOverrides{0};
std::atomic<uint64_t> g_ctxQueries{0};
std::atomic<uint64_t> g_ctxTargets{0};
std::atomic<uint64_t> g_ctxCamera{0};
std::atomic<uint64_t> g_ctxScene{0};
// Alvo de cada lutador (indice em g_fighters; 0-2 lado 0, 3-5 lado 1). P1 = indice 0.
std::atomic<int> g_target[6];
uint64_t g_battleId = 0; // updated on each captured fighter roster
// User-visible lock toggle for Revolution mode only; independent per fighter.
// Battle native targeting remains in the engine: never corrupt CPU pointers.
std::atomic<bool> g_revLockOff[6]{};
// Evolution's opponent-leader virtual resolves a side, not a specific fighter.
// Hook this getter to make COM brains consult the selected FFA opponent.
using OpponentGetter_t = uintptr_t (*)(uintptr_t player);
OpponentGetter_t g_originalOpponentGetter = nullptr;
std::atomic<bool> g_ffaOpponentHook{false};
ULONGLONG g_ffaAutoTargetLast = 0;

// Safe, bounded sample of Evolution collision masks. This is observation only;
// collision writes remain native until owner/type categories are verified in battle.
using CollisionMaskSetterFn = void (*)(uintptr_t collider, const void* mask);
CollisionMaskSetterFn g_originalSetCollisionGroup = nullptr;
CollisionMaskSetterFn g_originalSetCollisionTarget = nullptr;
struct CollisionSample {
  uintptr_t collider = 0, owner = 0;
  uint32_t kind = 0;
  uint32_t bits[4]{};
  bool target = false;
};
constexpr unsigned kMaxCollisionSamples = 4096; // rolling window, never stop collecting
SRWLOCK g_ffaSampleLock = SRWLOCK_INIT; // samples can be written from physics/render threads
std::atomic<uint64_t> g_ffaCollisionWriters{0};
std::atomic<uint64_t> g_ffaCollisionMatched{0};
constexpr uint32_t kFfaCollisionDomain = 0x00003F00u; // 6 isolated bits in second mask DWORD
std::atomic<unsigned> g_ffaCollisionPatches{0};
std::atomic<unsigned> g_ffaCollisionConflicts{0};
ULONGLONG g_ffaCollisionCheckAt = 0;
unsigned g_ffaCollisionLastLogged = 0;
ULONGLONG g_ffaCollisionLogAt = 0;
ULONGLONG g_ffaMatrixLogAt = 0;
CollisionSample g_collisionSamples[kMaxCollisionSamples];
// All three research/update loops read the SAME bounded rolling sample list.
// Batch snapshot once instead of acquiring SRWLOCK 4096 times per scan.
// Native collider writes and FfaPatchCollider remain outside the lock.
unsigned FfaSnapshotSamples(CollisionSample* output, unsigned capacity) {
  if(!output || capacity==0)return 0;
  AcquireSRWLockShared(&g_ffaSampleLock);
  const unsigned count=std::min(
      g_collisionSampleCount.load(std::memory_order_relaxed),
      std::min(capacity,kMaxCollisionSamples));
  if(count)std::memcpy(output,g_collisionSamples,count*sizeof(output[0]));
  ReleaseSRWLockShared(&g_ffaSampleLock);
  return count;
}

bool g_ffaCollisionReported = false;

// Evolution 1.09: collider +0xC0 -> owner wrapper, wrapper +0x18 -> fighter.
// +0xD4 is the box kind (2 = fighter hurt body, 4 = fighter offensive volume),
// +0xD8 is a four-dword group mask and +0xE8 is the target mask.
// Use a per-fighter collision bit in an unused DWORD; leave original side bits.
bool FfaPatchCollider(uintptr_t collider, uintptr_t expectedOwner = 0) {
  if (!Cfg().freeForAll.load(std::memory_order_relaxed) || !g_entered || !collider)
    return false;
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (n < 2 || n > 6) return false;
  __try {
    const uint32_t kind = *reinterpret_cast<const uint32_t*>(collider + 0xD4);
    if (kind != 2 && kind != 4) return false;
    const uintptr_t wrapper = *reinterpret_cast<const uintptr_t*>(collider + 0xC0);
    const uintptr_t owner = wrapper ? *reinterpret_cast<const uintptr_t*>(wrapper + 0x18) : 0;
    if (!owner || (expectedOwner && owner != expectedOwner)) return false;
    int fighter = -1;
    for (int k = 0; k < n; ++k)
      if (g_fighters[k].player == owner) {fighter = k;break;}
    if (fighter < 0) return false;
    g_ffaCollisionMatched.fetch_add(1, std::memory_order_relaxed);
    auto* group = reinterpret_cast<uint32_t*>(collider + 0xD8);
    auto* target = reinterpret_cast<uint32_t*>(collider + 0xE8);
    const uint32_t mine = 1u << (8 + fighter);
    const uint32_t others = kFfaCollisionDomain & ~mine;
    // Do not commandeer these bits if another mod or engine already uses them.
    if ((group[1] & kFfaCollisionDomain & ~mine) ||
        (target[1] & kFfaCollisionDomain & ~others)) {
      if (g_ffaCollisionConflicts.fetch_add(1, std::memory_order_relaxed) < 3)
        Log("FFA COLLISION: conflict in second mask; collider=%p kind=%u",
            reinterpret_cast<void*>(collider), kind);
      return false;
    }
    if ((group[1] & mine) && (target[1] & others) == others) return true;
    group[1] |= mine;
    target[1] |= others;
    g_ffaCollisionPatches.fetch_add(1, std::memory_order_relaxed);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

void FfaRefreshCollisionMasks() {
  if (!Cfg().freeForAll.load(std::memory_order_relaxed) || !g_entered ||
      Addr().timestamp != 0x5889906E) return;
  const ULONGLONG now = GetTickCount64();
  if (g_ffaCollisionCheckAt && now - g_ffaCollisionCheckAt < 450) return;
  g_ffaCollisionCheckAt = now;
  static thread_local CollisionSample snapshot[kMaxCollisionSamples];
  const unsigned count=FfaSnapshotSamples(snapshot,kMaxCollisionSamples);
  unsigned updated=0;
  // Process outside SRWLOCK; collision setters can reenter game code.
  for(unsigned i=0;i<count;++i) {
    const CollisionSample& sample=snapshot[i];
    if (!sample.collider || !sample.owner) continue;
    updated += FfaPatchCollider(sample.collider, sample.owner) ? 1 : 0;
  }
  const unsigned total = g_ffaCollisionPatches.load(std::memory_order_relaxed);
  if ((total != g_ffaCollisionLastLogged || g_ffaCollisionConflicts.load() > 0) &&
      (!g_ffaCollisionLogAt || now - g_ffaCollisionLogAt >= 5000)) {
    Log("FFA MASK BETA: registros=%llu janela=%u validos=%u patches=%u conflitos=%u",
        static_cast<unsigned long long>(g_ffaCollisionWriters.load()), count, updated,
        total, g_ffaCollisionConflicts.load());
    g_ffaCollisionLastLogged = total;
    g_ffaCollisionLogAt = now;
  }
}

void FfaRecordMask(uintptr_t collider, bool target) {
  if (!Cfg().freeForAll.load(std::memory_order_relaxed) || !collider) return;
  // A finite list meant that jutsu/projectile colliders created after the
  // first 4096 never received any FFA mask updates. Keep the newest 4096.
  CollisionSample sample{};
  sample.collider = collider;
  __try {
    sample.kind = *reinterpret_cast<const uint32_t*>(collider + 0xD4);
    const uintptr_t wrapper = *reinterpret_cast<const uintptr_t*>(collider + 0xC0);
    sample.owner = wrapper ? *reinterpret_cast<const uintptr_t*>(wrapper + 0x18) : 0;
    std::memcpy(sample.bits, reinterpret_cast<const void*>(collider + (target ? 0xE8 : 0xD8)),
                sizeof(sample.bits));
    sample.target = target;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return;
  }
  AcquireSRWLockExclusive(&g_ffaSampleLock);
  const unsigned index = g_collisionSampleCount.fetch_add(1, std::memory_order_release)
      % kMaxCollisionSamples;
  g_collisionSamples[index] = sample;
  ReleaseSRWLockExclusive(&g_ffaSampleLock);
  g_ffaCollisionWriters.fetch_add(1, std::memory_order_relaxed);
  if (g_entered) FfaPatchCollider(collider, sample.owner);
}

void HookFfaSetCollisionGroup(uintptr_t collider, const void* mask) {
  g_originalSetCollisionGroup(collider, mask);
  FfaRecordMask(collider, false);
}

void HookFfaSetCollisionTarget(uintptr_t collider, const void* mask) {
  g_originalSetCollisionTarget(collider, mask);
  FfaRecordMask(collider, true);
}

void FfaMaskCompatibilityReport() {
  // Observational diagnostic: compatible masks are not proof of real damage.
  if (!g_entered || !Cfg().freeForAll.load(std::memory_order_relaxed) ||
      Addr().timestamp != 0x5889906E) return;
  const ULONGLONG now = GetTickCount64();
  if (g_ffaMatrixLogAt && now - g_ffaMatrixLogAt < 10000) return;
  g_ffaMatrixLogAt = now;

  struct Masks {uint32_t group[4]{}, target[4]{}; bool ready = false;};
  Masks hurt[6], attack[6];
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (n < 2 || n > 6) return;
  static thread_local CollisionSample snapshot[kMaxCollisionSamples];
  const unsigned count=FfaSnapshotSamples(snapshot,kMaxCollisionSamples);
  for(unsigned i=0;i<count;++i) {
    const CollisionSample& sample=snapshot[i];
    if (!sample.owner || !sample.collider || (sample.kind != 2 && sample.kind != 4))
      continue;
    int actor = -1;
    for (int k = 0; k < n; ++k)
      if (g_fighters[k].player == sample.owner) { actor = k; break; }
    if (actor < 0) continue;
    Masks& selected = sample.kind == 4 ? attack[actor] : hurt[actor];
    if (selected.ready) continue;
    __try {
      const uintptr_t wrapper = *reinterpret_cast<const uintptr_t*>(sample.collider + 0xC0);
      if (!wrapper || *reinterpret_cast<const uintptr_t*>(wrapper + 0x18) != sample.owner)
        continue;
      std::memcpy(selected.group, reinterpret_cast<const void*>(sample.collider + 0xD8), 16);
      std::memcpy(selected.target, reinterpret_cast<const void*>(sample.collider + 0xE8), 16);
      selected.ready = true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
  }
  int friends = 0, rivals = 0, seenFriends = 0, seenRivals = 0;
  int readyAttacks = 0, readyHurt = 0;
  for (int k = 0; k < n; ++k) {
    readyAttacks += attack[k].ready ? 1 : 0;
    readyHurt += hurt[k].ready ? 1 : 0;
  }
  for (int i = 0; i < n; ++i) {
    if (!attack[i].ready) continue;
    for (int j = 0; j < n; ++j) {
      if (i == j || !hurt[j].ready) continue;
      bool matchAttack = false, matchReverse = false;
      for (int w = 0; w < 4; ++w) {
        matchAttack |= (attack[i].group[w] & hurt[j].target[w]) != 0;
        matchReverse |= (hurt[j].group[w] & attack[i].target[w]) != 0;
      }
      if (g_fighters[i].side == g_fighters[j].side) {
        ++seenFriends;
        if (matchAttack && matchReverse) ++friends;
      } else {
        ++seenRivals;
        if (matchAttack && matchReverse) ++rivals;
      }
    }
  }
  Log("FFA HIT MATRIX: atk=%d hurt=%d; mesmos times=%d/%d, rivais=%d/%d pares compativeis na mascara. Dano real nao confirmado.",
      readyAttacks, readyHurt, friends, seenFriends, rivals, seenRivals);
}
void FfaLogCollisionSamples() {
  if (g_ffaCollisionReported || !Cfg().freeForAll.load(std::memory_order_relaxed))
    return;
  g_ffaCollisionReported = true;
  static thread_local CollisionSample snapshot[kMaxCollisionSamples];
  const unsigned count=FfaSnapshotSamples(snapshot,kMaxCollisionSamples);
  bool seen[6][2][5]{}; // first five categories for each observed owner and mask type
  int matched=0;
  for(unsigned i=0;i<count;++i) {
    const CollisionSample& s=snapshot[i];
    if (!s.owner) continue;
    for (int k = 0; k < g_numFighters.load(std::memory_order_acquire) && k < 6; ++k) {
      if (s.owner != g_fighters[k].player) continue;
      ++matched;
      const int category = s.kind < 5 ? int(s.kind) : 4;
      if (seen[k][s.target ? 1 : 0][category]) break;
      seen[k][s.target ? 1 : 0][category] = true;
      Log("FFA COLLISION: J%d kind=%u %s mask=%08X:%08X:%08X:%08X",
          g_fighters[k].side * 3 + g_fighters[k].row + 1,
          s.kind, s.target ? "target" : "group",
          s.bits[0], s.bits[1], s.bits[2], s.bits[3]);
      break;
    }
  }
  Log("FFA COLLISION: samples=%u owned_by_fighters=%d; original collision masks unchanged.",
      count, matched);
}
std::atomic<int> g_ffaWinnerSlot{-1}; // independent winner J1..J6, not native side
std::atomic<ULONGLONG> g_ffaWinnerUntil{0};
ULONGLONG g_ffaSoloSince = 0;
int g_ffaSoloCandidate = -1;
bool g_ffaSoloConfirmed = false;
std::atomic<unsigned> g_ffaRosterBits{0};
std::atomic<unsigned> g_ffaKnockedOutBits{0};
ULONGLONG g_ffaDownSince[6]{};
std::atomic<uint64_t> g_ffaNativeResultDeferrals{0};
std::atomic<uint64_t> g_ffaNativeFinalRouted{0};
using JudgeTeamHealthFn = float (*)(uintptr_t team, int nativeKey);
JudgeTeamHealthFn g_origJudgeTeamHealth = nullptr;
bool g_ffaTeamHealthHookInstalled = false;
uint64_t g_ffaEarlyResultSuppressed = 0;
ULONGLONG g_unfinishedBattleSince = 0;
bool g_unfinishedBattleWarned = false;
ULONGLONG g_longSceneSince = 0;
bool g_longSceneWarned = false;

bool FfaAlive(int index) {
  // Called from both the judge and the controller thread. At KO/removal the
  // fighter's node can be freed between these reads; never crash XInput.
  const int count = g_numFighters.load(std::memory_order_acquire);
  if (index < 0 || index >= count || !g_fighters[index].node || !g_fighters[index].player)
    return false;
  __try {
    const float life = *reinterpret_cast<const float*>(g_fighters[index].node + kMemberGauges);
    return std::isfinite(life) && life > 0.0f;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

int FfaCountSurvivors(int* remaining) {
  int live = 0;
  if (remaining) *remaining = -1;
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (n < 3 || n > 6) return 0;
  for (int k = 0; k < n; ++k)
    if (FfaAlive(k)) {
      ++live;
      if (remaining) *remaining = k;
    }
  return live;
}

void FfaUpdateIndividualResult() {
  // This runs before g_origJudge. Once native judge transitions away from
  // combat its post-return callback may never get another usable fighter list.
  if (!g_entered || !Enabled() ||
      !Cfg().freeForAll.load(std::memory_order_relaxed) ||
      Addr().timestamp != 0x5889906E ||
      g_teardownDepth.load(std::memory_order_relaxed) != 0) return;
  const ULONGLONG now = GetTickCount64();
  int survivor = -1;
  const int living = FfaCountSurvivors(&survivor);
  const bool noCinematic = !UltSceneActive();
  // Confirm each KO after 400 ms without life; do not declare an elimination
  // during a cinematic, where actor pointers/health can be transient.
  const int n = g_numFighters.load(std::memory_order_acquire);
  for (int k = 0; k < n && k < 6; ++k) {
    const bool alive = FfaAlive(k);
    if (alive) { g_ffaDownSince[k] = 0; continue; }
    if (!noCinematic) {g_ffaDownSince[k] = 0; continue;}
    if (!g_ffaDownSince[k]) {g_ffaDownSince[k] = now; continue;}
    if (now - g_ffaDownSince[k] < 400) continue;
    const unsigned slot = unsigned(g_fighters[k].side * 3 + g_fighters[k].row);
    if (slot >= 6) continue;
    const unsigned bit = 1u << slot;
    if (!(g_ffaKnockedOutBits.fetch_or(bit, std::memory_order_relaxed) & bit))
      Log("FFA ELIMINACAO: J%u fora da luta, %d lutadores vivos restantes.",
          slot + 1, living);
  }
  // The engine may start a victory cinematic immediately after the final
  // result. Never clear an already confirmed winner during that transition,
  // even if actors temporarily disappear from the health query.
  if (g_ffaSoloConfirmed && (living == 1 &&
      g_ffaWinnerSlot.load(std::memory_order_relaxed) == survivor ||
      !noCinematic)) return;
  if (living != 1 || survivor < 0 || !noCinematic) {
    // A fighter revived before the finish? Retract the provisional verdict.
    if (g_ffaSoloConfirmed && living > 1) {
      Log("FFA RESULTADO: vencedor provisorio cancelado; %d voltaram a viver.", living);
      g_ffaWinnerSlot.store(-1, std::memory_order_relaxed);
      g_ffaWinnerUntil.store(0, std::memory_order_relaxed);
    }
    g_ffaSoloCandidate = -1;
    g_ffaSoloSince = 0;
    g_ffaSoloConfirmed = false;
    return;
  }
  if (g_ffaSoloCandidate != survivor) {
    g_ffaSoloCandidate = survivor;
    g_ffaSoloSince = now;
    g_ffaSoloConfirmed = false;
    return;
  }
  // The last fighter must stay alive for several battle ticks. A
  // cinematic can temporarily hide combat entities; never award on one frame.
  if (!g_ffaSoloConfirmed && now - g_ffaSoloSince >= 400) {
    g_ffaSoloConfirmed = true;
    g_ffaWinnerSlot.store(survivor, std::memory_order_relaxed);
    g_ffaWinnerUntil.store(now + 8000, std::memory_order_relaxed);
    Log("FFA FINAL INDIVIDUAL: J%d confirmado unico sobrevivente. Liberando fim nativo do lado %d.",
        g_fighters[survivor].side * 3 + g_fighters[survivor].row + 1,
        g_fighters[survivor].side);
  }
}

// Evolution native judge at RVA 0x748BC8 queries each side using 0x746A60.
// Calls return to 0x748C5C (native side 0) and 0x748C7D (native side 1).
// Hook ONLY those two call sites: all other team health queries stay native.
// This prevents the side-based judge ending the match when one native team
// dies but there are still at least two individual survivors.
float HookFfaJudgeTeamHealth(uintptr_t team, int nativeKey) {
  const float native = g_origJudgeTeamHealth(team, nativeKey);
  const uintptr_t site = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
  const int side = site == 0x748C5C ? 0 : site == 0x748C7D ? 1 : -1;
  if (side < 0 || !g_ffaTeamHealthHookInstalled ||
      Addr().timestamp != 0x5889906E || !Enabled() ||
      !Cfg().freeForAll.load(std::memory_order_relaxed) ||
      !g_entered || !PromoteBattlePresent() ||
      g_teardownDepth.load(std::memory_order_relaxed) != 0) return native;

  int survivor = -1;
  const int living = FfaCountSurvivors(&survivor);
  if (living >= 2 || (living == 1 && !g_ffaSoloConfirmed)) {
    // Do not change positive native HP. If one original team's aggregate
    // is already zero, keep the judge from issuing a team victory/draw.
    if (std::isfinite(native) && native > 0.0f) return native;
    const uint64_t count = g_ffaNativeResultDeferrals.fetch_add(1, std::memory_order_relaxed);
    if (count < 12)
      Log("FFA JUDGE: lado original %d aparenta cair (nativo %.2f), mas %d individuos ainda presentes. Fim adiado.",
          side, native, living);
    return 1.0f;
  }
  if (living == 1 && g_ffaSoloConfirmed && survivor >= 0 &&
      g_ffaWinnerSlot.load(std::memory_order_relaxed) == survivor) {
    // Translate the independent survivor into the native two-team result
    // only at the moment it is safe for the engine to finish the match.
    const int winnerSide = g_fighters[survivor].side;
    const float adjusted = side == winnerSide
        ? (std::isfinite(native) && native > 0.0f ? native : 1.0f)
        : 0.0f;
    const uint64_t routed = g_ffaNativeFinalRouted.fetch_add(1, std::memory_order_relaxed);
    if (routed < 4)
      Log("FFA JUDGE FINAL: J%d => lado nativo %d, consulta lado %d: HP %.2f -> %.2f",
          g_fighters[survivor].side * 3 + g_fighters[survivor].row + 1,
          winnerSide, side, native, adjusted);
    return adjusted;
  }
  return native;
}

// Vitima do tratamento de acerto que esta rodando nesta thread (ver HookHitHandler).
thread_local uintptr_t t_hitVictim = 0;

uintptr_t HookFfaOpponentGetter(uintptr_t player) {
  if (!g_ffaOpponentHook.load(std::memory_order_acquire) || !PromoteBattleActive())
    return g_originalOpponentGetter(player);
  // Os pontos nativos de 1x1 corrigidos abaixo valem desde o inicio da luta (no Chronicles a entrada 3D
  // pode atrasar ~35 s); o resto continua so depois da entrada.
  const uintptr_t callSite = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
  const bool nativeDuelSite = callSite == 0x78552C || callSite == 0x7CF78B || callSite == 0x7F41A4 ||
                              callSite == 0x7D6F81;
  if (!g_entered && !nativeDuelSite) return g_originalOpponentGetter(player);
  const int fighter = PromoteFighterByPlayer(player);
  if (fighter < 0) return g_originalOpponentGetter(player);
  const int target = g_target[fighter].load(std::memory_order_relaxed);
  if (target == fighter || !FfaAlive(target))
    return g_originalOpponentGetter(player);
  if (Cfg().freeForAll.load(std::memory_order_relaxed))
    return g_fighters[target].player;

  // CAUSA REAL do lider adversario congelado (Evolution): FUN_140796718 (vtable +0xD78) e o "meu adversario"
  // do jogo e devolve sempre o LIDER do outro time (suposicao 1x1). No preparo e nos estados do Supremo
  // (retornos exe+0x7CF78B, exe+0x7F41A4, exe+0x7D6F81) o jogo liga a marca de cena +0x17AC / +0x17A8 e muda
  // o estado desse "adversario": o lider ficava congelado mesmo quando o Supremo era contra outro lutador.
  // Nesses pontos o adversario e o alvo real do lutador.
  if (Addr().timestamp == 0x5889906E && g_fighters[fighter].side != g_fighters[target].side) {
    const uintptr_t site = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
    // FASE 2: ao efetivar um agarrao (FUN_1407854AC, chamada dentro do tratamento de acerto da vitima), o jogo
    // prepara "meu adversario" como vitima (retorno exe+0x78552C). Era o LIDER, nao quem foi agarrado.
    if (site == 0x78552C && t_hitVictim) {
      const int hit = PromoteFighterByPlayer(t_hitVictim);
      if (hit >= 0 && g_fighters[hit].side != g_fighters[fighter].side) {
        static std::atomic<unsigned> grabLogs{0};
        if (grabLogs.fetch_add(1, std::memory_order_relaxed) < 12)
          Log("AGARRAO: vitima do agarrao de J%d e J%d (quem foi pego), nao o lider (exe+0x78552C).",
              g_fighters[fighter].side * 3 + g_fighters[fighter].row + 1,
              g_fighters[hit].side * 3 + g_fighters[hit].row + 1);
        return t_hitVictim;
      }
    }
    if (site == 0x7CF78B || site == 0x7F41A4 || site == 0x7D6F81) {
      static std::atomic<unsigned> logs{0};
      if (logs.fetch_add(1, std::memory_order_relaxed) < 12)
        Log("ULTIMATE: adversario de J%d no Supremo e J%d (alvo real), nao o lider (exe+0x%llX).",
            g_fighters[fighter].side * 3 + g_fighters[fighter].row + 1,
            g_fighters[target].side * 3 + g_fighters[target].row + 1, static_cast<unsigned long long>(site));
      return g_fighters[target].player;
    }
  }

  // Keep native 3v3 targeting intact unless a CPU was left locked on an
  // already defeated enemy leader. Use our living opponent in that case.
  if (SlotPadIndex(g_fighters[fighter].control) >= 0 ||
      g_fighters[fighter].side == g_fighters[target].side)
    return g_originalOpponentGetter(player);
  // Fase 1 (cpu_adversario_real=1 em storm6.ini): a IA nativa da CPU decide pelo "meu adversario", que em 3v3
  // era adivinhado pela pilha e podia nao ser quem ela enfrenta (CPU parada 30-50 s nos testes). Com a opcao,
  // e o alvo real dela (o mesmo do lock-on).
  if (Cfg().cpuRealOpponent.load(std::memory_order_relaxed)) return g_fighters[target].player;
  const uintptr_t nativeOpponent = g_originalOpponentGetter(player);
  const int oldTarget = PromoteFighterByPlayer(nativeOpponent);
  if (oldTarget < 0 || FfaAlive(oldTarget)) return nativeOpponent;
  static std::atomic<unsigned> redirected{0};
  if (redirected.fetch_add(1, std::memory_order_relaxed) < 24)
    Log("COMBAT 0.6.5 CPU: J%d deixou alvo morto J%d e mudou para J%d",
        g_fighters[fighter].side * 3 + g_fighters[fighter].row + 1,
        g_fighters[oldTarget].side * 3 + g_fighters[oldTarget].row + 1,
        g_fighters[target].side * 3 + g_fighters[target].row + 1);
  return g_fighters[target].player;
}


// ---------------------------------------------------------------- posicoes, piso e camera
// Posicao do lutador: player+0x70 (x), +0x74 (y), +0x78 (z) (lida assim por FUN_14079A404,
// o "ponto de mira" do lock-on). O log do jogo confirma o chao em x/y e a altura em z.
constexpr uintptr_t kPosOffset = 0x70;
#define kRvaSetPosition (Addr().setPosition)
constexpr float kBelowFloor = 120.0f;
constexpr ULONGLONG kFloorRecoveryInterval = 1500;
using SetPositionFn = void (*)(void*, const float*);
using ResetMotionFn = void (*)(void*);
SetPositionFn g_setPosition = nullptr;
ResetMotionFn g_resetMotion = nullptr;
float g_pos[6][3];
// Select individual FFA opponents using live fighter positions, not previous
// frame's g_pos (which can be stale after an ultimate or a new battle).
// CPU has target hysteresis; humans keep their selected enemy until it dies.
void FfaUpdateTargets() {
  if (!Cfg().freeForAll.load(std::memory_order_relaxed) || !g_entered ||
      UltSceneActive()) return;
  const ULONGLONG now = GetTickCount64();
  if (g_ffaAutoTargetLast && now - g_ffaAutoTargetLast < 350) return;
  g_ffaAutoTargetLast = now;
  const int count = g_numFighters.load(std::memory_order_acquire);
  if (count < 3 || count > 6) return;
  bool eligible[6]{};
  float position[6][3]{};
  for(int k=0;k<count;++k) {
    if (!FfaAlive(k) || !g_fighters[k].player) continue;
    __try {
      const float* pos=reinterpret_cast<const float*>(g_fighters[k].player+0x70);
      bool valid=true;
      for(int axis=0;axis<3;++axis) {
        position[k][axis]=pos[axis];
        if(!std::isfinite(pos[axis]) || std::fabs(pos[axis])>20000.0f)
          valid=false;
      }
      eligible[k]=valid;
    } __except(EXCEPTION_EXECUTE_HANDLER) {eligible[k]=false;}
  }
  for (int fighter = 0; fighter < count; ++fighter) {
    if(!eligible[fighter])continue;
    const int current=g_target[fighter].load(std::memory_order_relaxed);
    const bool cpu=SlotPadIndex(g_fighters[fighter].control)<0;
    if(!cpu && current>=0 && current<count && current!=fighter &&
       eligible[current])continue;
    const int chosen=FfaStableCpuTarget(position,eligible,count,fighter,current);
    if(chosen>=0 && chosen!=current) {
      g_target[fighter].store(chosen,std::memory_order_relaxed);
      static std::atomic<unsigned> targetChanges{0};
      if(targetChanges.fetch_add(1,std::memory_order_relaxed)<32)
        Log("FFA ALVO ESTAVEL: J%d mudou de J%d para J%d (CPU=%d)",
            fighter+1,current+1,chosen+1,int(cpu));
    }
  }
}
void FfaTrackHealthChanges() {
  static uint64_t battle=0;
  static float last[6]{};
  static bool known[6]{};
  static unsigned reported=0;
  if (!Cfg().freeForAll.load(std::memory_order_relaxed) || !g_entered ||
      UltSceneActive()) return;
  if(battle!=g_battleId) {
    battle=g_battleId;
    std::memset(known,0,sizeof(known));
    reported=0;
  }
  const int count=g_numFighters.load(std::memory_order_acquire);
  if(count<3 || count>6)return;
  for(int i=0;i<count;++i) {
    if(!g_fighters[i].node)continue;
    __try {
      const float hp=*reinterpret_cast<const float*>(g_fighters[i].node+kMemberGauges);
      if(!std::isfinite(hp) || hp<0.0f)continue;
      if(known[i] && last[i]>hp+0.25f && reported<42) {
        const int victim=g_fighters[i].side*3+g_fighters[i].row+1;
        Log("FFA HP OBSERVADO: J%d perdeu %.1f HP (%.1f -> %.1f), atacante nao verificado",
            victim,last[i]-hp,last[i],hp);
        ++reported;
      }
      last[i]=hp;
      known[i]=true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {
      known[i]=false;
    }
  }
  }
void RetargetDefeatedOpponents() {
  // In 3v3 the original per-row target becomes invalid when that rival dies;
  // several native action/AI lookups still consult g_target and can then
  // keep aiming at a KO'd body instead of a living enemy.
  if (Cfg().freeForAll.load(std::memory_order_relaxed) || !g_entered) return;
  const int count = g_numFighters.load(std::memory_order_acquire);
  if (count < 2 || count > 6) return;
  for (int i = 0; i < count; ++i) {
    if (!FfaAlive(i)) continue;
    const int current = g_target[i].load(std::memory_order_relaxed);
    if (current >= 0 && current < count &&
        g_fighters[current].side != g_fighters[i].side && FfaAlive(current))
      continue;
    int closest = -1;
    float distance = 1.0e30f;
    for (int j = 0; j < count; ++j) {
      if (g_fighters[j].side == g_fighters[i].side || !FfaAlive(j)) continue;
      const float dx = g_pos[j][0] - g_pos[i][0];
      const float dy = g_pos[j][1] - g_pos[i][1];
      const float dz = g_pos[j][2] - g_pos[i][2];
      const float candidate = dx * dx + dy * dy + dz * dz;
      if (!std::isfinite(candidate)) continue;
      if (closest < 0 || candidate < distance) {
        closest = j;
        distance = candidate;
      }
    }
    if (closest >= 0 && closest != current) {
      g_target[i].store(closest, std::memory_order_relaxed);
      Log("COMBAT 0.6.5: J%d mudou alvo derrotado para J%d",
          g_fighters[i].side * 3 + g_fighters[i].row + 1,
          g_fighters[closest].side * 3 + g_fighters[closest].row + 1);
    }
  }
}
std::atomic<uint64_t> g_lastJudgeTick{0};
// So o juiz NATIVO (HookJudge). As lutas diretas do Chronicles nao tem juiz nativo: antes a checagem usava
// g_lastJudgeTick, que a propria chamada renovava, e o trabalho do mod rodava so a cada 200 ms (5 vezes por
// segundo): a entrada 3D levava ~35 s e a defesa de agarrao nao via a janela de 0,2 s.
std::atomic<uint64_t> g_lastNativeJudgeTick{0};
std::atomic<uint64_t> g_judgeFrameCount{0};  // native battle heartbeat
HudFighter g_hud[6];
SRWLOCK g_hudLock = SRWLOCK_INIT;  // escrito na thread do jogo, lido pelo HUD (rasgos de 1 quadro sao aceitaveis)
// g_battleId declared near the target roster, before FFA diagnostics.
SRWLOCK g_markerLock = SRWLOCK_INIT;
LockMarker g_markers[4];
int g_markerCount = 0;


float g_spawn[2][3];
bool g_spawnReady = false;
ULONGLONG g_recoverAfter[6];
std::atomic<uint64_t> g_floorRecoveries{0};
// Diagnostic-only movement monitor: never force a standing fighter to move.
float g_lastMovingPos[6][3]{};
ULONGLONG g_lastMovementAt[6]{};
bool g_standstillReported[6]{};
// Lutador vivo preso na origem (0,0) fora do mundo depois de uma cena: desde quando.
ULONGLONG g_voidSince[6]{};
constexpr ULONGLONG kVoidRecoveryDelay = 3000;
constexpr ULONGLONG kVoidRecoveryDelayInScene = 25000;
constexpr int kIdleState = 1;     // estado neutro (+0xCC0) de um lutador parado
ULONGLONG g_lastCinematicAt = 0;  // ultima vez que alguem estava numa cena de Supremo na origem
ULONGLONG g_markedSince[6]{};     // desde quando o lutador esta no campo com marcas de cena e sem cena
bool g_freezeLogged[6]{};         // diagnostico: congelamento ja registrado
ULONGLONG g_liveAt[6]{};          // diagnostico: copia tirada no congelamento, comparada 1 s depois
int g_markPrev[6][7]{};           // diagnostico: ultimo valor das marcas/estado por lutador
// Controle (+CAC) e visibilidade (+CB0) que uma cena nativa tirou do lutador e ainda nao devolveu.
bool g_sceneTookControl[6]{};
std::atomic<bool> g_pausedMotion[6]{}, g_pausedRender[6]{};  // pausado por cena (ganchos de pausa)
bool g_ultLockHooked = false;
std::atomic<bool> g_ultLocked[6]{};  // travado por Supremo (FUN_1407DCB1C) e nao solto (FUN_1407DCBBC)
int g_stateSeen[6]{};             // ultimo estado visto por RestoreAfterScene
ULONGLONG g_stateSince[6]{};      // desde quando o lutador esta nesse estado
bool g_sceneHid[6]{};
int g_prevControl[6]{};
int g_prevShown[6]{};
ULONGLONG g_lastSceneAt = 0;
unsigned g_markLines = 0;         // linhas de MARCAS nesta luta

// Indice (em g_fighters) do lutador na posicao `row` do lado `side`, ou -1.
int FighterAt(int side, int row, int count) {
  for (int k = 0; k < count; ++k)
    if (g_fighters[k].side == side && g_fighters[k].row == row) return k;
  return -1;
}

int CameraFighter() {
  const int count = g_numFighters.load(std::memory_order_acquire);
  if (count < 1 || count > 6) return -1;
  int controlled[4]{};
  for (int pad = 0; pad < 4; ++pad)
    controlled[pad] = PromoteFighterForPad(pad);
  int sides[6]{};
  bool alive[6]{};
  for (int k = 0; k < count; ++k) {
    sides[k] = g_fighters[k].side;
    alive[k] = FfaAlive(k);
  }
  return PolishChooseCameraActor(count, controlled, sides, alive);
}

// Diagnostico: copia do objeto de cada lutador quando ele esta lutando normalmente, para comparar com o
// estado dele preso fora do mundo e achar a marca de cena que desliga a IA.
constexpr size_t kSnapSize = 0x2000;  // cobre as marcas achadas (ate +0x17AC)
uint8_t g_snap[6][kSnapSize];
bool g_snapValid[6]{};
ULONGLONG g_snapAt[6]{};
uint8_t g_liveCopy[6][kSnapSize];

// Diagnostico: o lutador parado ainda se atualiza? Conta os campos que mudaram em 1 s (fora posicao).
void LiveCheck(int k) {
  static uint8_t now[kSnapSize];
  __try {
    std::memcpy(now, reinterpret_cast<const void*>(g_fighters[k].player), kSnapSize);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return;
  }
  char line[700];
  int len = 0, changed = 0;
  for (size_t off = 0x80; off + 4 <= kSnapSize; off += 4) {
    if (off >= 0xD64 && off <= 0xEC8) continue;
    if (std::memcmp(g_liveCopy[k] + off, now + off, 4) == 0) continue;
    ++changed;
    if (len < 620) len += std::snprintf(line + len, sizeof(line) - len, " +%zX", off);
  }
  line[len] = 0;
  Log("VIVO? J%d: %d campos mudaram em 1 s parado (estado 0x%X):%s", g_fighters[k].side * 3 + g_fighters[k].row + 1,
      changed, *reinterpret_cast<const int*>(now + 0xCC0), line);
}

void TakeFighterSnapshot(int k) {
  __try {
    std::memcpy(g_snap[k], reinterpret_cast<const void*>(g_fighters[k].player), kSnapSize);
    g_snapValid[k] = true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    g_snapValid[k] = false;
  }
}

void DiffFighterSnapshot(int k) {
  if (!g_snapValid[k]) {
    Log("DIFF J%d: sem copia de referencia.", g_fighters[k].side * 3 + g_fighters[k].row + 1);
    return;
  }
  static uint8_t now[kSnapSize];
  __try {
    std::memcpy(now, reinterpret_cast<const void*>(g_fighters[k].player), kSnapSize);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return;
  }
  char line[2400];
  int len = std::snprintf(line, sizeof(line), "DIFF J%d (normal -> preso):", g_fighters[k].side * 3 + g_fighters[k].row + 1);
  int shown = 0;
  for (size_t off = 0x80; off + 4 <= kSnapSize && len < 2300; off += 4) {
    int a, b;
    std::memcpy(&a, g_snap[k] + off, 4);
    std::memcpy(&b, now + off, 4);
    if (a == b) continue;
    if (off >= 0xD64 && off <= 0xEC8) continue;  // vetor que oscila sozinho (0/1 por quadro)
    if (off >= 0x60 && off < 0x80) continue;    // posicao
    float fa, fb;
    std::memcpy(&fa, &a, 4);
    std::memcpy(&fb, &b, 4);
    const bool smallInt = a >= -1 && a <= 0x400 && b >= -1 && b <= 0x400;
    // Fator de velocidade/tempo por ator: float que vira 0 ou 1 (ex.: 1.0 -> 0.0 congela o lutador).
    const bool unitFloat = (a == 0x3F800000 || b == 0x3F800000 || a == 0 || b == 0) &&
                           std::isfinite(fa) && std::isfinite(fb) && std::fabs(fa) <= 16.0f &&
                           std::fabs(fb) <= 16.0f && (std::fabs(fa) >= 0.001f || std::fabs(fb) >= 0.001f);
    if (smallInt)
      len += std::snprintf(line + len, sizeof(line) - len, " +%zX:%d>%d", off, a, b);
    else if (unitFloat)
      len += std::snprintf(line + len, sizeof(line) - len, " +%zX:%.3gf>%.3gf", off, fa, fb);
    else
      continue;
    ++shown;
  }
  Log("%s (%d campos)", line, shown);
}

// Leitura protegida de um int de um ator (estado +0xCC0, em campo +0xCA8) para o registro.
int SafeReadInt(uintptr_t base, uintptr_t offset) {
  if (!base) return -1;
  __try {
    return *reinterpret_cast<const int*>(base + offset);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return -1;
  }
}

// Marcas que uma cena de Supremo liga num ator e o jogo so desliga nos atores que ele considera da cena.
// Achadas comparando a memoria do mesmo lutador lutando e preso (iguais em todos os lutadores testados).
// Com elas ligadas o lutador fica sem IA/animacao: parado, congelado ou fora do mundo.
struct SceneMark {
  uintptr_t offset;
  int normal;
};
constexpr SceneMark kSceneMarks[] = {{0xCB0, 1}, {0xCDC, 0}, {0x1068, 1}, {0x10B0, 1}, {0x17AC, 0}};

bool HasSceneMarks(uintptr_t player) {
  for (const SceneMark& mark : kSceneMarks) {
    const int value = SafeReadInt(player, mark.offset);
    if (value != -1 && value != mark.normal) return true;
  }
  return false;
}

int ClearSceneMarks(uintptr_t player) {
  int cleared = 0;
  __try {
    for (const SceneMark& mark : kSceneMarks) {
      int* field = reinterpret_cast<int*>(player + mark.offset);
      if (*field != mark.normal) {
        *field = mark.normal;
        ++cleared;
      }
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  return cleared;
}

// FASE 1 - CAUSA REAL de lutadores parados depois de cenas (Evolution): as cenas nativas percorrem os
// membros 0..2 de um time para DESLIGAR o controle (+CAC=0, FUN_14079772C/codigo da cena) e ESCONDER
// (+CB0=0, FUN_140770D94) quem nao esta na cena, mas no fim religam (FUN_140795CD4) e mostram
// (FUN_140771630) so o "lider" da cena: no jogo original os outros dois membros sao apoios fora de campo.
// Com 6 lutadores em campo, quem nao era o par da cena ficava sem controle (CPU parada em 0x1) ou escondido
// e sem atualizar (parado no meio de um estado). Aqui, quando nenhuma cena esta rodando ha 1 s, quem perdeu
// controle/visibilidade DURANTE uma cena e ainda esta sem, recebe de volta pelas MESMAS funcoes do jogo.
ULONGLONG g_lastNativeSceneAt = 0;     // ultima vez que havia cena na lista do jogo
ULONGLONG g_cineStateSince[6]{};       // desde quando o lutador esta em estado de Supremo sem cena do jogo

void RestoreAfterScene(int n, const int* state, bool cinematic, ULONGLONG now) {
  if (Addr().timestamp != 0x5889906E) return;  // enderecos conferidos so no Evolution
  const bool nativeScene = UltSceneActive();
  if (nativeScene) g_lastNativeSceneAt = now;
  // Estado de Supremo (0x51 vitima, 0x87..0x8F quem faz) so conta como cena enquanto o jogo tem cena na lista
  // (ou ate 3 s depois): um lutador preso em 0x51 depois da cinematica (C39: J5 o resto da luta) fazia o mod
  // achar que a cena nunca acabava e ninguem recebia o controle de volta.
  bool sceneNow = nativeScene || (cinematic && g_lastNativeSceneAt && now - g_lastNativeSceneAt < 3000);
  for (int k = 0; k < n && !sceneNow; ++k)
    if (state[k] == 0x87) sceneNow = true;
  if (sceneNow) g_lastSceneAt = now;
  // Preso em estado de Supremo sem cena do jogo ha 3 s: solta pela funcao nativa (FUN_1407DCBBC) e volta ao
  // estado neutro pelo metodo de troca de estado do proprio lutador.
  for (int k = 0; k < n; ++k) {
    const bool cineState = state[k] == 0x51 || (state[k] >= 0x87 && state[k] <= 0x8F);
    if (!cineState || nativeScene) {
      g_cineStateSince[k] = 0;
      continue;
    }
    if (!g_cineStateSince[k]) g_cineStateSince[k] = now;
    if (now - g_cineStateSince[k] < 3000 || !FfaAlive(k)) continue;
    g_cineStateSince[k] = 0;
    const uintptr_t player = g_fighters[k].player;
    __try {
      reinterpret_cast<void (*)(uintptr_t)>(g_base + 0x7DCBBC)(player);
      auto vtable = *reinterpret_cast<uintptr_t**>(player);
      if (vtable && vtable[kVtChangeState / sizeof(uintptr_t)])
        reinterpret_cast<void (*)(uintptr_t, int)>(vtable[kVtChangeState / sizeof(uintptr_t)])(player, kIdleState);
      Log("CENA: J%d preso no estado de Supremo 0x%X sem cena do jogo; solto e devolvido ao estado neutro.",
          g_fighters[k].side * 3 + g_fighters[k].row + 1, state[k]);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("COMBAT GUARD: falha ao soltar J%d do estado de Supremo.", g_fighters[k].side * 3 + g_fighters[k].row + 1);
    }
  }
  for (int k = 0; k < n; ++k) {
    if (state[k] != g_stateSeen[k] || !g_stateSince[k]) {
      // DIAGNOSTICO (Fase 2): linha do tempo dos estados de agarrao vista de fora (todas as rotas de troca).
      auto grab = [](int s) {
        return s == 0x48 || s == 0x9B || s == 0x9C || (s >= 0x32 && s <= 0x35) || s == 0x38 || s == 0x63 ||
               s == 0x79 || s == 0x7A || (s >= 0x59 && s <= 0x5B);
      };
      static unsigned grabLines = 0;
      if (!g_stateSince[k]) grabLines = 0;
      if ((grab(state[k]) || grab(g_stateSeen[k])) && grabLines < 300) {
        ++grabLines;
        const int tg = g_target[k].load(std::memory_order_relaxed);
        float dist = -1;
        if (tg >= 0 && tg < n) {
          const float dx = g_pos[k][0] - g_pos[tg][0], dy = g_pos[k][1] - g_pos[tg][1];
          dist = std::sqrt(dx * dx + dy * dy);
        }
        Log("AGARRAO: J%d 0x%X -> 0x%X (%llu ms no anterior); alvo J%d estado 0x%X dist %.0f; controle %d",
            g_fighters[k].side * 3 + g_fighters[k].row + 1, g_stateSeen[k], state[k],
            g_stateSince[k] ? static_cast<unsigned long long>(now - g_stateSince[k]) : 0ULL,
            tg >= 0 && tg < n ? g_fighters[tg].side * 3 + g_fighters[tg].row + 1 : 0,
            tg >= 0 && tg < n ? state[tg] : -1, dist, SafeReadInt(g_fighters[k].player, 0xCAC));
      }
      g_stateSeen[k] = state[k];
      g_stateSince[k] = now;
    }
  }
  const bool sceneRecent = sceneNow || (g_lastSceneAt && now - g_lastSceneAt < 500);
  for (int k = 0; k < n; ++k) {
    const int control = SafeReadInt(g_fighters[k].player, 0xCAC);
    const int shown = SafeReadInt(g_fighters[k].player, 0xCB0);
    if (sceneRecent) {
      if (control == 0 && g_prevControl[k] == 1) g_sceneTookControl[k] = true;
      if (shown == 0 && g_prevShown[k] == 1) g_sceneHid[k] = true;
    }
    g_prevControl[k] = control;
    g_prevShown[k] = shown;
  }
  if (sceneNow || !g_lastSceneAt || now - g_lastSceneAt < 1000) return;
  // Fim de luta (alguem sem vida) tem cenas proprias: nao devolver controle ali.
  float life[2]{};
  int members[2]{};
  if (!PromoteSideLife(0, &life[0], &members[0]) || !PromoteSideLife(1, &life[1], &members[1]) ||
      life[0] <= 0.0f || life[1] <= 0.0f)
    return;
  using ActorFn = void (*)(uintptr_t);
  const auto show = reinterpret_cast<ActorFn>(g_base + 0x771630);
  const auto enableControl = reinterpret_cast<ActorFn>(g_base + 0x795CD4);
  // Travado por um Supremo que nao o pegou (acertou outro no caminho): solta pela funcao do jogo.
  if (now - g_lastSceneAt >= 1500 && g_ultLockHooked) {
    for (int k = 0; k < n; ++k) {
      if (!g_ultLocked[k].load(std::memory_order_relaxed)) continue;
      if (now - g_stateSince[k] < 1500) continue;  // ainda trocando de estado: nao esta preso
      const uintptr_t player = g_fighters[k].player;
      if (!FfaAlive(k) || SafeReadInt(player, kOnFieldFlag) != 1) continue;
      __try {
        reinterpret_cast<ActorFn>(g_base + 0x7DCBBC)(player);  // passa pelo gancho: limpa a marca
        Log("CENA: J%d continuava travado por um Supremo que nao o pegou (estado 0x%X); solto pela funcao do jogo.",
            g_fighters[k].side * 3 + g_fighters[k].row + 1, state[k]);
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        Log("COMBAT GUARD: falha ao soltar J%d.", g_fighters[k].side * 3 + g_fighters[k].row + 1);
      }
      g_ultLocked[k].store(false, std::memory_order_relaxed);
    }
  }
  // Pausado por uma cena (FUN_14078FC3C/FC4C) e nunca retomado: retoma pelo metodo do proprio lutador.
  if (now - g_lastSceneAt >= 1500) {
    for (int k = 0; k < n; ++k) {
      const bool motion = g_pausedMotion[k].load(std::memory_order_relaxed);
      const bool render = g_pausedRender[k].load(std::memory_order_relaxed);
      if (!motion && !render) continue;
      if (now - g_stateSince[k] < 1500) continue;  // ainda trocando de estado: nao esta preso
      const uintptr_t player = g_fighters[k].player;
      if (!FfaAlive(k) || SafeReadInt(player, kOnFieldFlag) != 1) continue;
      __try {
        auto** vtable = *reinterpret_cast<ActorFn**>(player);
        if (motion) vtable[0xFF0 / sizeof(void*)](player);
        if (render) vtable[0xFC0 / sizeof(void*)](player);
        Log("CENA: J%d continuava pausado apos a cena (%s%s, estado 0x%X); retomado pelo metodo do jogo.",
            g_fighters[k].side * 3 + g_fighters[k].row + 1, motion ? "movimento" : "",
            render ? (motion ? "+visual" : "visual") : "", state[k]);
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        Log("COMBAT GUARD: falha ao retomar J%d.", g_fighters[k].side * 3 + g_fighters[k].row + 1);
      }
      g_pausedMotion[k].store(false, std::memory_order_relaxed);
      g_pausedRender[k].store(false, std::memory_order_relaxed);
    }
  }
  for (int k = 0; k < n; ++k) {
    // Ja voltou sozinho (o jogo devolveu): nada a fazer.
    if (g_sceneTookControl[k] && SafeReadInt(g_fighters[k].player, 0xCAC) == 1) g_sceneTookControl[k] = false;
    if (g_sceneHid[k] && SafeReadInt(g_fighters[k].player, 0xCB0) == 1) g_sceneHid[k] = false;
    if (!g_sceneTookControl[k] && !g_sceneHid[k]) continue;
    if (now - g_stateSince[k] < 1500) continue;  // ainda trocando de estado: nao esta preso
    const uintptr_t player = g_fighters[k].player;
    const bool hid = g_sceneHid[k], tookControl = g_sceneTookControl[k];
    g_sceneHid[k] = g_sceneTookControl[k] = false;
    if (!FfaAlive(k) || SafeReadInt(player, kOnFieldFlag) != 1) continue;
    __try {
      if (hid && *reinterpret_cast<const int*>(player + 0xCB0) == 0) {
        show(player);
        Log("CENA: J%d continuava escondido apos a cena (estado 0x%X); mostrado pela funcao do jogo.",
            g_fighters[k].side * 3 + g_fighters[k].row + 1, state[k]);
      }
      if (tookControl && *reinterpret_cast<const int*>(player + 0xCAC) == 0) {
        enableControl(player);
        Log("CENA: J%d continuava sem controle apos a cena (estado 0x%X); controle devolvido pela funcao do "
            "jogo (agora %d).",
            g_fighters[k].side * 3 + g_fighters[k].row + 1, state[k],
            *reinterpret_cast<const int*>(player + 0xCAC));
      }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("COMBAT GUARD: falha ao devolver controle/visibilidade de J%d.", g_fighters[k].side * 3 + g_fighters[k].row + 1);
    }
  }
}

void ArenaTick() {
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (n < 2 || n > 6) return;  // stale/corrupt roster must not index past the six slots
  bool valid[6]{};
  for (int k = 0; k < n; ++k) {
    // A KO'd fighter may have an invalid actor position or be removed from
    // the engine. Never let that one pointer block the other five fighters.
    if (!FfaAlive(k)) continue;
    const uintptr_t player = g_fighters[k].player;
    if (!player) continue;
    __try {
      const float* p = reinterpret_cast<const float*>(player + kPosOffset);
      valid[k] = std::isfinite(p[0]) && std::isfinite(p[1]) && std::isfinite(p[2]);
      if (!valid[k]) continue;
      g_pos[k][0] = p[0];
      g_pos[k][1] = p[1];
      g_pos[k][2] = p[2];
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      valid[k] = false;
    }
  }
  const ULONGLONG movementNow = GetTickCount64();
  {
    // JUTSU CLASH: camera de lado nos dois da disputa (vale em qualquer modo de camera, inclusive o nativo).
    int clashA = -1, clashB = -1;
    const bool clashCam = JutsuClashCameraPair(&clashA, &clashB) && clashA >= 0 && clashA < n && clashB >= 0 &&
                          clashB < n && valid[clashA] && valid[clashB];
    if (clashCam) {
      float others[4][3];
      int count = 0;
      for (int k = 0; k < n && count < 4; ++k)
        if (k != clashA && k != clashB && valid[k]) std::memcpy(others[count++], g_pos[k], sizeof(others[0]));
      CameraSetClashBlockers(others, count);
    }
    CameraSetClash(clashCam, clashCam ? g_pos[clashA] : nullptr, clashCam ? g_pos[clashB] : nullptr,
                   clashCam ? JutsuClashCameraStage() : 0);
  }
  // FASE 2: defesa contra agarrao, a cada quadro de logica (inclusive lutas diretas do Chronicles).
  {
    GrabFighterView view[6];
    bool scene = UltSceneActive();
    for (int k = 0; k < n; ++k) {
      view[k].player = g_fighters[k].player;
      view[k].side = g_fighters[k].side;
      view[k].number = g_fighters[k].side * 3 + g_fighters[k].row + 1;
      view[k].state = SafeReadInt(g_fighters[k].player, 0xCC0);
      std::memcpy(view[k].pos, g_pos[k], sizeof(view[k].pos));
      view[k].valid = valid[k] && FfaAlive(k) && SafeReadInt(g_fighters[k].player, kOnFieldFlag) == 1;
      view[k].pad = PromotePadForPlayer(g_fighters[k].player);
      const int st = view[k].state;
      if ((st >= 0x87 && st <= 0x8F) || st == 0x51 || st == 0x4F || st == 0x50) scene = true;
    }
    __try {
      GrabDefenseTick(view, n, scene, movementNow);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("COMBAT GUARD: defesa de agarrao falhou com seguranca neste quadro.");
    }
    __try {
      JutsuClashTick(view, n, scene, movementNow);  // JUTSU CLASH
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("COMBAT GUARD: jutsu clash falhou com seguranca neste quadro.");
    }
    __try {
      DualComboTick(view, n, scene, movementNow);  // COMBO EM DUPLA
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("COMBAT GUARD: combo em dupla falhou com seguranca neste quadro.");
    }
    __try {
      WallRunTick(view, n, scene, movementNow);  // PAREDE (pesquisa)
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("COMBAT GUARD: parede falhou com seguranca neste quadro.");
    }
    __try {
      PerfectSubTick(view, n, scene, movementNow);  // FASE 3
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("COMBAT GUARD: substituicao perfeita falhou com seguranca neste quadro.");
    }
  }
  // Only observe, because stationary CPU fighters and guarding are legitimate.
  if (g_entered && !UltSceneActive()) {
    for (int k = 0; k < n; ++k) {
      if (!valid[k]) continue;
      const float dx = g_pos[k][0] - g_lastMovingPos[k][0];
      const float dy = g_pos[k][1] - g_lastMovingPos[k][1];
      const float dz = g_pos[k][2] - g_lastMovingPos[k][2];
      if (!g_lastMovementAt[k] || dx * dx + dy * dy + dz * dz > 225.0f) {
        std::memcpy(g_lastMovingPos[k], g_pos[k], sizeof(g_pos[k]));
        g_lastMovementAt[k] = movementNow;
        g_standstillReported[k] = false;
      } else if (!g_standstillReported[k] && movementNow - g_lastMovementAt[k] >= 9000 &&
                 *reinterpret_cast<const int*>(g_fighters[k].player + kOnFieldFlag)) {
        g_standstillReported[k] = true;
        Log("COMBAT DIAG: J%d sem deslocamento >9s em (%.0f,%.0f,%.0f). Pode ser espera da CPU.",
            g_fighters[k].side * 3 + g_fighters[k].row + 1,
            g_pos[k][0], g_pos[k][1], g_pos[k][2]);
      }
    }
  } else {
    // Cinematics legitimately keep actors motionless: do not flag them as frozen.
    for (int k = 0; k < n; ++k) {
      if (!valid[k]) continue;
      std::memcpy(g_lastMovingPos[k], g_pos[k], sizeof(g_pos[k]));
      g_lastMovementAt[k] = movementNow;
      g_standstillReported[k] = false;
    }
  }
  const int leaders[] = {FighterAt(0, 0, n), FighterAt(1, 0, n)};
  if (leaders[0] < 0 || leaders[1] < 0) return;
  if (!g_spawnReady) {
    // Never capture a KO'd leader's stale position as the whole team's
    // recovery spawn. Wait for valid coordinates from both active leaders.
    if (!valid[leaders[0]] || !valid[leaders[1]]) return;
    for (int leader : leaders) {
      for (float coord : g_pos[leader])
        if (!std::isfinite(coord) || std::fabs(coord)>20000.0f) return;
    }
    for (int side = 0; side < 2; ++side) std::memcpy(g_spawn[side], g_pos[leaders[side]], sizeof(g_spawn[side]));
    g_spawnReady = true;
    Log("Piso: alturas iniciais dos lideres %.1f / %.1f", g_spawn[0][2], g_spawn[1][2]);
  }
  // Devolucao de controle/visibilidade/pausa depois de cenas: desde o inicio da luta, nao so depois da
  // entrada 3D (no Chronicles um Supremo logo no comeco adiava a entrada por ~35 s).
  if (!g_entered && g_spawnReady) {
    int state[6]{};
    bool cinematic = false;
    for (int k = 0; k < n; ++k) {
      state[k] = SafeReadInt(g_fighters[k].player, 0xCC0);
      if ((state[k] >= 0x88 && state[k] <= 0x8F) || state[k] == 0x51) cinematic = true;
    }
    RestoreAfterScene(n, state, cinematic, GetTickCount64());
  }
  if (g_entered && g_setPosition && g_resetMotion && Cfg().ring.load() && !UltSceneActive()) {
    const ULONGLONG now = GetTickCount64();
    const float spawnFloor = std::min(g_spawn[0][2], g_spawn[1][2]);
    const float z0 = g_pos[leaders[0]][2], z1 = g_pos[leaders[1]][2];
    // Uma queda de um lider nao deve baixar o limite de resgate dos outros.
    const float leaderFloor = std::isfinite(z0) && std::isfinite(z1) ? std::max(z0, z1) : spawnFloor;
    const float floor = leaderFloor >= spawnFloor - kBelowFloor ? std::min(spawnFloor, leaderFloor) : spawnFloor;
    for (int k = 0; k < n; ++k) {
      const Fighter& fighter = g_fighters[k];
      const float height = g_pos[k][2];
      if (!valid[k] || fighter.row == 0 || now < g_recoverAfter[k] ||
          !std::isfinite(height) || height >= floor - kBelowFloor)
        continue;
      if (!*reinterpret_cast<const int*>(fighter.player + kOnFieldFlag)) continue;
      g_recoverAfter[k] = now + kFloorRecoveryInterval;
      void* player = reinterpret_cast<void*>(fighter.player);
      // O proprio jogo limpa a velocidade depois de reposicionar um lutador.
      g_setPosition(player, g_spawn[fighter.side]);
      g_resetMotion(player);
      std::memcpy(g_pos[k], reinterpret_cast<const void*>(fighter.player + kPosOffset), sizeof(g_pos[k]));
      ++g_floorRecoveries;
      Log("Piso: J%d resgatado de Z %.1f para Z %.1f", fighter.side * 3 + fighter.row + 1,
          height, g_pos[k][2]);
    }
  }
  // Depois de um Supremo, o jogo so devolve ao campo os atores da cena nativa. Com 5-6 lutadores, um
  // membro extra (ou ate um lider fora da cena) pode ficar preso em (0,0) fora do mundo, parado/congelado.
  // Durante um Supremo o jogo leva atores para a origem: quem faz (0x88..0x8F), a vitima (0x51) e, quando a
  // vitima e um membro extra, tambem o LIDER adversario (o jogo supoe que a vitima e sempre o lider). No fim
  // so os atores reais voltam; o lider fica na origem, no estado de golpe recebido, sem IA. UltSceneActive()
  // nao e confiavel com 6 lutadores, entao a cena e detectada pelos estados de quem faz e de quem recebe.
  // Resgata quem continuar na origem 3 s depois de nenhuma cena estar acontecendo, ou apos 25 s seguidos.
  if (g_entered && g_setPosition && g_resetMotion && g_spawnReady) {
    const ULONGLONG now = GetTickCount64();
    bool atOrigin[6]{};
    int state[6]{};
    bool cinematic = false;
    for (int k = 0; k < n; ++k) {
      atOrigin[k] = valid[k] && std::fabs(g_pos[k][0]) < 0.5f && std::fabs(g_pos[k][1]) < 0.5f;
      state[k] = SafeReadInt(g_fighters[k].player, 0xCC0);
      // Cena acontecendo: alguem fazendo o Supremo (0x88..0x8F) ou sendo a vitima dele (0x51).
      if ((state[k] >= 0x88 && state[k] <= 0x8F) || state[k] == 0x51) cinematic = true;
    }
    if (cinematic) g_lastCinematicAt = now;
    for (int k = 0; k < n; ++k) {
      if (g_liveAt[k] && now - g_liveAt[k] >= 1000) {
        g_liveAt[k] = 0;
        LiveCheck(k);
      }
      // DIAGNOSTICO (Fase 1): linha do tempo das marcas de cena por lutador.
      const int cur[7] = {state[k], SafeReadInt(g_fighters[k].player, 0xCB0), SafeReadInt(g_fighters[k].player, 0xCDC),
                          SafeReadInt(g_fighters[k].player, 0x1068), SafeReadInt(g_fighters[k].player, 0x10B0),
                          SafeReadInt(g_fighters[k].player, 0x17AC), SafeReadInt(g_fighters[k].player, 0xCAC)};
      if (std::memcmp(cur + 1, g_markPrev[k] + 1, sizeof(int) * 6) != 0 && g_markLines < 400) {
        ++g_markLines;
        Log("MARCAS J%d: CB0 %d>%d CDC %d>%d 1068 %d>%d 10B0 %d>%d 17AC %d>%d CAC %d>%d; estado 0x%X (antes 0x%X) "
            "em (%.0f,%.0f); cena=%d",
            g_fighters[k].side * 3 + g_fighters[k].row + 1, g_markPrev[k][1], cur[1], g_markPrev[k][2], cur[2],
            g_markPrev[k][3], cur[3], g_markPrev[k][4], cur[4], g_markPrev[k][5], cur[5], g_markPrev[k][6], cur[6],
            cur[0], g_markPrev[k][0], g_pos[k][0], g_pos[k][1], cinematic ? 1 : 0);
      }
      std::memcpy(g_markPrev[k], cur, sizeof(cur));
    }
    // Lutador no campo, fora da origem, com as marcas de cena ainda ligadas 3 s depois da ultima cena:
    // ficou congelado no lugar (ex.: J4 parado no estado 0x10). So desfaz as marcas, sem mover.
    if (!cinematic && now - g_lastCinematicAt >= kVoidRecoveryDelay) {
      for (int k = 0; k < n; ++k) {
        // So quem esta sem se deslocar ha 4 s: um golpe normal pode ligar alguma dessas marcas por instantes.
        const bool still = g_lastMovementAt[k] && now - g_lastMovementAt[k] >= 4000;
        // DIAGNOSTICO (Fase 1): lutador parado ha 8 s fora da origem e fora de cena. Registra uma vez por
        // congelamento o estado, o alvo e as marcas, para separar CPU esperando de lutador travado.
        if (valid[k] && !atOrigin[k] && g_lastMovementAt[k] && now - g_lastMovementAt[k] >= 8000) {
          if (!g_freezeLogged[k]) {
            g_freezeLogged[k] = true;
            const int tg = g_target[k].load(std::memory_order_relaxed);
            Log("CONGELADO: J%d parado 8 s no estado 0x%X (anterior 0x%X) em (%.0f,%.0f); alvo J%d estado 0x%X; "
                "marcas %d/%d/%d/%d/%d.",
                g_fighters[k].side * 3 + g_fighters[k].row + 1, state[k],
                SafeReadInt(g_fighters[k].player, 0xCC4), g_pos[k][0], g_pos[k][1],
                tg >= 0 && tg < n ? g_fighters[tg].side * 3 + g_fighters[tg].row + 1 : 0,
                tg >= 0 && tg < n ? state[tg] : -1,
                SafeReadInt(g_fighters[k].player, 0xCB0), SafeReadInt(g_fighters[k].player, 0xCDC),
                SafeReadInt(g_fighters[k].player, 0x1068), SafeReadInt(g_fighters[k].player, 0x10B0),
                SafeReadInt(g_fighters[k].player, 0x17AC));
            DiffFighterSnapshot(k);
            __try {
              std::memcpy(g_liveCopy[k], reinterpret_cast<const void*>(g_fighters[k].player), kSnapSize);
              g_liveAt[k] = now;
            } __except (EXCEPTION_EXECUTE_HANDLER) {
            }
          }
        } else if (!still) {
          g_freezeLogged[k] = false;
        }
        // (Removido: escrever +CB0/+CDC/+10B0 a forca no lutador parado. +CB0 e "visivel" e so a funcao
        // nativa de mostrar o reativa de verdade; com o campo ja em 1 ela nem roda, e o lutador ficava preso.
        // A devolucao certa e feita abaixo por RestoreAfterScene.)
      }
    }
    RestoreAfterScene(n, state, cinematic, now);
    for (int k = 0; k < n; ++k) {
      if (!atOrigin[k]) {
        g_voidSince[k] = 0;
        // Copia de referencia: lutador no campo, parado em estado neutro, sem cena acontecendo.
        // Prefere o estado neutro; se ainda nao houver copia, qualquer estado fora de cena serve.
        // Copia de referencia: lutador se deslocando agora e nenhuma cena nos ultimos 3 s.
        if (valid[k] && !cinematic && now - g_snapAt[k] >= 2000 &&
            ((g_lastMovementAt[k] && now - g_lastMovementAt[k] < 1000 && now - g_lastCinematicAt >= 3000) ||
             !g_snapValid[k])) {
          g_snapAt[k] = now;
          TakeFighterSnapshot(k);
        }
        continue;
      }
      if (!g_voidSince[k]) g_voidSince[k] = now;
      const bool stuckIdle = !cinematic &&
          now - g_lastCinematicAt >= kVoidRecoveryDelay && now - g_voidSince[k] >= kVoidRecoveryDelay;
      const bool stuckLong = now - g_voidSince[k] >= kVoidRecoveryDelayInScene;
      if ((!stuckIdle && !stuckLong) || now < g_recoverAfter[k]) continue;
      g_recoverAfter[k] = now + kFloorRecoveryInterval;
      g_voidSince[k] = 0;
      const Fighter& fighter = g_fighters[k];
      __try {
        const int onField = *reinterpret_cast<const int*>(fighter.player + kOnFieldFlag);
        const int stateBefore = *reinterpret_cast<const int*>(fighter.player + 0xCC0);
        // Nao usar o estado de entrada (0xE4): em teste ele congelou a luta inteira.
        DiffFighterSnapshot(k);
        const int marks = ClearSceneMarks(fighter.player);
        if (marks) Log("RESGATE: J%d %d marcas de cena desfeitas.", fighter.side * 3 + fighter.row + 1, marks);
        // O lider adversario puxado como vitima nativa fica no estado de golpe recebido (ex.: 0x42) na
        // origem. Volta ao estado neutro pelo mesmo metodo de troca de estado do jogo.
        if (stateBefore != kIdleState) {
          auto vtable = *reinterpret_cast<uintptr_t**>(fighter.player);
          if (vtable && vtable[kVtChangeState / sizeof(uintptr_t)])
            reinterpret_cast<void (*)(uintptr_t, int)>(vtable[kVtChangeState / sizeof(uintptr_t)])(
                fighter.player, kIdleState);
        }
        // Ao lado do ponto inicial do time, afastado por fileira para nao empilhar.
        float home[3];
        std::memcpy(home, g_spawn[fighter.side], sizeof(home));
        home[0] += (fighter.row - 1) * 150.0f;
        void* player = reinterpret_cast<void*>(fighter.player);
        g_setPosition(player, home);
        g_resetMotion(player);
        Log("RESGATE: J%d preso fora do mundo (0,0) apos cena; devolvido ao campo (em_campo_antes=%d, estado_antes=0x%X).",
            fighter.side * 3 + fighter.row + 1, onField, stateBefore);
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        Log("COMBAT GUARD: falha ao devolver J%d preso fora do mundo.", fighter.side * 3 + fighter.row + 1);
      }
    }
  }
  if (g_entered && Cfg().camera.load() != kCameraDuel) {
    const int primary = CameraFighter();
    const PolishCameraRoster view = PolishBuildCameraRoster(
        g_pos, valid, n, primary, PromoteTargetOf(primary));
    // The renderer uses dense indices; KO actors are removed from that list.
    CameraSetFighters(view.positions, view.count, view.primary, view.target);
  }
}

void ClearLockMarkers() {
  AcquireSRWLockExclusive(&g_markerLock);
  g_markerCount = 0;
  ReleaseSRWLockExclusive(&g_markerLock);
}

void PublishLockMarkers() {
  LockMarker markers[4];
  int count = 0;
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (n < 1 || n > 6) return;
  bool alive[6]{};
  for (int k = 0; k < n; ++k) alive[k] = FfaAlive(k);
  for (int pad = 0; pad < 4; ++pad) {
    const int controlled = PromoteFighterForPad(pad);
    const int target = PromoteTargetOf(controlled);
    // Hide phantom markers for unplugged pads and KO'd characters/targets.
    if (!PolishShowLock(controlled, target, n, InputPadConnected(pad), alive))
      continue;
    const Fighter& fighter = g_fighters[target];
    markers[count++] = {pad, fighter.side * 3 + fighter.row, g_battleId,
                        {g_pos[target][0], g_pos[target][1], g_pos[target][2]}};
  }
  AcquireSRWLockExclusive(&g_markerLock);
  std::memcpy(g_markers, markers, count * sizeof(markers[0]));
  g_markerCount = count;
  ReleaseSRWLockExclusive(&g_markerLock);
}

void SnapshotHud() {
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (n < 2 || n > 6) return;

  // Read engine memory BEFORE locking: a transient invalid pointer can throw
  // an SEH exception. The caller catches it; never leave the HUD lock held.
  HudFighter sample[6];
  AcquireSRWLockShared(&g_hudLock);
  std::memcpy(sample, g_hud, sizeof(sample)); // also preserves character portraits
  ReleaseSRWLockShared(&g_hudLock);
  for (int k = 0; k < 6; ++k) {
    sample[k].valid = 0;
    if (k >= n || !g_fighters[k].node) continue;
    // A KO/restart can invalidate one fighter's gauge pointer without
    // invalidating the other five. Isolate faults per actor so camera, target
    // markers and every other fighter still get an updated HUD this frame.
    __try {
      const float* rec=reinterpret_cast<const float*>(g_fighters[k].node+kMemberGauges);
      bool good=true;
      for(int j=0;j<6;++j){
        const float v=rec[j];
        good &= std::isfinite(v);
        sample[k].v[j]=good?v:0.0f;
      }
      if(good){
        sample[k].side=g_fighters[k].side;
        sample[k].row=g_fighters[k].row;
        sample[k].valid=1;
      }
    } __except(EXCEPTION_EXECUTE_HANDLER) {
      sample[k].valid=0;
      static std::atomic<unsigned> faults{0};
      if(faults.fetch_add(1,std::memory_order_relaxed)<6)
        Log("HUD GUARD: J%d gauge transiently unavailable; other fighters preserved.",
            g_fighters[k].side*3+g_fighters[k].row+1);
    }
  }
  AcquireSRWLockExclusive(&g_hudLock);
  std::memcpy(g_hud, sample, sizeof(sample));
  ReleaseSRWLockExclusive(&g_hudLock);

  ArenaTick();
  PublishLockMarkers();
}
void ReadPortrait(HudFighter& fighter, int side, int row) {
  fighter.portrait[0] = '\0';
  // O callback GetFaceIconName da HUD nativa chama esta rotina com tipo 0.
  using FaceIconFn = const char* (*)(int, int, int);
  const auto getFaceIcon = reinterpret_cast<FaceIconFn>(g_base + Addr().faceIcon);
  const uint8_t expected[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x6C, 0x24, 0x10};
  if (std::memcmp(reinterpret_cast<const void*>(getFaceIcon), expected, sizeof(expected)) != 0) return;
  const char* name = nullptr;
  __try {
    name = getFaceIcon(side, row, 0);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return;
  }
  if (!name) return;
  size_t length = strnlen_s(name, sizeof(fighter.portrait));
  if (length == 0 || length == sizeof(fighter.portrait)) return;
  for (size_t i = 0; i < length; ++i) {
    const char c = name[i];
    if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_')) return;
  }
  std::memcpy(fighter.portrait, name, length + 1);
  Log("HUD: retrato J%d = %s", side * 3 + row + 1, fighter.portrait);
}

// ---------------------------------------------------------------- papel real no ultimate
// A criacao grava o papel no sub-objeto do membro (player+0xB00, vt+8), e vt+0x10 o devolve. Como os
// extras nascem com papel 0, a leitura de sideConfig + papel*0x3C no codigo do ultimate pegava o bloco
// do lider. So esse ponto ve o papel real: varios outros tratam "papel != 0" como "repasse ao lider",
// e devolver o papel real a eles causa recursao sem fim (FUN_1407D581C no Evolution).
constexpr uintptr_t kMemberOffset = 0xB00;
constexpr size_t kMemberRoleSlot = 0x10 / sizeof(uintptr_t);
using MemberRole_t = int (*)(void*);
MemberRole_t g_origMemberRole = nullptr;
int HookMemberRole(void* member) {
  const int role = g_origMemberRole(member);
  if (!Enabled()) return role;
  const uintptr_t site = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
  if (site != Addr().ultConfigRoleReturn && site != 0x7E655F && site != 0x7E66CB) return role;
  const int k = PromoteFighterByPlayer(reinterpret_cast<uintptr_t>(member) - kMemberOffset);
  if (k < 0) return role;
  if (site == Addr().ultConfigRoleReturn || UltTeamAllyRole(k, site)) {
    const int originalRow = g_fighters[k].row;
    if (site == Addr().ultConfigRoleReturn && role != originalRow) {
      static std::atomic<unsigned> logs{0};
      if (logs.fetch_add(1, std::memory_order_relaxed) < 16)
        Log("ULTIMATE OWNER FIX: exe+0x%llX J%d native=%d original=%d",
            static_cast<unsigned long long>(site),
            g_fighters[k].side * 3 + originalRow + 1, role, originalRow);
    }
    return originalRow;
  }
  return role;
}

// Tratamento de acerto do lutador (vtable +0x1088, Evolution): roda no objeto da VITIMA. Dentro dele o jogo
// pede o atacante como "membro 0 do lado" (exe+0x782C47) e, no Supremo, inicia a cinematica nesse objeto.
// Guardar quem esta sendo atingido permite responder com o atacante real (ver PromoteContext).
using HitHandler_t = uintptr_t (*)(void*, void*, void*, void*);
HitHandler_t g_origHitHandler = nullptr;
void* g_hitHandlerTarget = nullptr;
// (t_hitVictim: declarado antes de HookFfaOpponentGetter)


uintptr_t HookHitHandler(void* self, void* a, void* b, void* c) {
  // JUTSU CLASH: os dois da disputa ficam protegidos. O golpe pendente e descartado como o jogo faz com o golpe
  // mais fraco num choque (FUN_1407EEDBC no receptor +0xFB68, ex.: exe+0x76D93E) e o tratamento nao roda.
  // So quando ha golpe pendente: [+0xFB7C] diferente do "nenhum" (FUN_1405290BC), como o proprio tratamento testa.
  bool pendingHit = false;
  __try {
    pendingHit = *reinterpret_cast<const uint16_t*>(reinterpret_cast<uintptr_t>(self) + 0xFB7C) !=
                 reinterpret_cast<uint16_t (*)()>(g_base + 0x5290BC)();
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  if (pendingHit && JutsuClashProtects(reinterpret_cast<uintptr_t>(self))) {
    __try {
      reinterpret_cast<void (*)(uintptr_t)>(g_base + 0x7EEDBC)(reinterpret_cast<uintptr_t>(self) + 0xFB68);
      return 0;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
  }
  const uintptr_t previous = t_hitVictim;
  t_hitVictim = reinterpret_cast<uintptr_t>(self);
  const uintptr_t r = g_origHitHandler(self, a, b, c);
  t_hitVictim = previous;

  return r;
}

void HookHitHandlerOf(uintptr_t player) {
  if (Addr().timestamp != 0x5889906E || !player) return;
  void* fn = nullptr;
  __try {
    fn = (*reinterpret_cast<void***>(player))[0x1088 / sizeof(void*)];
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return;
  }
  if (!fn || fn == g_hitHandlerTarget) return;
  const uintptr_t rva = reinterpret_cast<uintptr_t>(fn) - g_base;
  if (g_hitHandlerTarget) {
    static bool logged = false;
    if (!logged) {
      logged = true;
      Log("ULTIMATE: um lutador usa outro tratamento de acerto (exe+0x%llX); fica so com a regra antiga.",
          static_cast<unsigned long long>(rva));
    }
    return;
  }
  // So a funcao identificada (contem exe+0x782C47 e exe+0x78380B).
  if (rva < 0x782B88 || rva > 0x782C36) {
    Log("ULTIMATE: tratamento de acerto em exe+0x%llX, fora do esperado; gancho nao instalado.",
        static_cast<unsigned long long>(rva));
    g_hitHandlerTarget = fn;
    return;
  }
  MH_STATUS st = MH_CreateHook(fn, reinterpret_cast<void*>(&HookHitHandler),
                               reinterpret_cast<void**>(&g_origHitHandler));
  if (st == MH_OK) st = MH_EnableHook(fn);
  g_hitHandlerTarget = fn;
  Log("ULTIMATE: tratamento de acerto exe+0x%llX %s.", static_cast<unsigned long long>(rva),
      st == MH_OK ? "monitorado (vitima real conhecida)" : MH_StatusToString(st));
}

// Pausa/retomada nativas dos componentes de um ator (Evolution, vtable do lutador): +0xFF8 FUN_14078FC3C
// pausa a lista +0xF980 (animacao/movimento) e +0xFF0 FUN_14078FD08 retoma; +0xFC8 FUN_14078FC4C /
// +0xFC0 FUN_14078FD50 fazem o mesmo com a lista +0xF7E0. As cenas pausam quem nao esta nelas e no fim so
// retomam o "lider" da cena. Os ganchos so marcam quem ficou pausado; nao mudam nada.
using ActorFn_t = void (*)(uintptr_t);
ActorFn_t g_origPauseMotion = nullptr, g_origResumeMotion = nullptr;
ActorFn_t g_origPauseRender = nullptr, g_origResumeRender = nullptr;
bool g_pauseHooks = false;

int FighterIndexOfPlayer(uintptr_t player) {
  const int n = g_numFighters.load(std::memory_order_acquire);
  for (int k = 0; k < n && k < 6; ++k)
    if (g_fighters[k].player == player) return k;
  return -1;
}
// Golpes comuns (ex.: substituicao) tambem pausam e retomam sozinhos: so conta pausa feita durante uma cena.
void HookPauseMotion(uintptr_t actor) {
  const int k = FighterIndexOfPlayer(actor);
  if (k >= 0) {
    // exe+0x78FC74: pausa feita pelo "esconder" nativo (FUN_14078FC5C, chamado por FUN_140770D94), que o Supremo
    // aplica no alvo um instante ANTES de a cena entrar na lista. A funcao de mostrar nem sempre retoma o
    // movimento (so a parte visual quando vtable +0xC00 responde 1), entao essa pausa tambem e marcada.
    const uintptr_t from = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
    if (UltSceneActive() || UltInSceneStart() || from == 0x78FC74) {
      g_pausedMotion[k].store(true, std::memory_order_relaxed);
    } else {
      static std::atomic<unsigned> logs{0};  // DIAGNOSTICO (Fase 1): quem pausa fora de cena
      if (logs.fetch_add(1, std::memory_order_relaxed) < 30)
        Log("PAUSA fora de cena: J%d (estado 0x%X) chamada de exe+0x%llX.",
            g_fighters[k].side * 3 + g_fighters[k].row + 1, SafeReadInt(actor, 0xCC0),
            static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base));
    }
  }
  g_origPauseMotion(actor);
}
void HookResumeMotion(uintptr_t actor) {
  const int k = FighterIndexOfPlayer(actor);
  if (k >= 0) g_pausedMotion[k].store(false, std::memory_order_relaxed);
  g_origResumeMotion(actor);
}
void HookPauseRender(uintptr_t actor) {
  const int k = FighterIndexOfPlayer(actor);
  const uintptr_t from = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
  if (k >= 0 && (UltSceneActive() || UltInSceneStart() || from == 0x78FC80))
    g_pausedRender[k].store(true, std::memory_order_relaxed);
  g_origPauseRender(actor);
}
void HookResumeRender(uintptr_t actor) {
  const int k = FighterIndexOfPlayer(actor);
  if (k >= 0) g_pausedRender[k].store(false, std::memory_order_relaxed);
  g_origResumeRender(actor);
}

// Trava/solta de Supremo (Evolution): FUN_1407DCB1C(ator, 1) esconde o ator (vtable +0xB78) e as invocacoes;
// FUN_1407DCBBC(ator) solta (vtable +0xB88, FUN_140795BA8: tira a animacao +0xFD90 do modo de Supremo). O
// Supremo trava o alvo mirado ao preparar; se o avanco acerta OUTRO adversario, ninguem solta o alvo mirado,
// que fica parado (ex.: J1 no estado 0x1E por 60 s em C40). Os ganchos so marcam.
using LockFn_t = void (*)(uintptr_t, int);
LockFn_t g_origUltLock = nullptr;
ActorFn_t g_origUltRelease = nullptr;
void HookUltLock(uintptr_t actor, int mode) {
  const int k = FighterIndexOfPlayer(actor);
  if (k >= 0) g_ultLocked[k].store(true, std::memory_order_relaxed);
  g_origUltLock(actor, mode);
}
void HookUltRelease(uintptr_t actor) {
  const int k = FighterIndexOfPlayer(actor);
  if (k >= 0) g_ultLocked[k].store(false, std::memory_order_relaxed);
  g_origUltRelease(actor);
}

void InstallPauseHooks() {
  if (g_pauseHooks || Addr().timestamp != 0x5889906E) return;
  g_pauseHooks = true;
  struct Entry { uintptr_t rva; uint8_t expect[7]; size_t len; void* hook; ActorFn_t* orig; const char* name; };
  const Entry entries[] = {
      {0x78FC3C, {0x48, 0x81, 0xC1, 0x80, 0xF9, 0x00, 0x00}, 7, reinterpret_cast<void*>(&HookPauseMotion), &g_origPauseMotion, "pausa"},
      {0x78FD08, {0x48, 0x89, 0x5C, 0x24, 0x08}, 5, reinterpret_cast<void*>(&HookResumeMotion), &g_origResumeMotion, "retomada"},
      {0x78FC4C, {0x48, 0x81, 0xC1, 0xE0, 0xF7, 0x00, 0x00}, 7, reinterpret_cast<void*>(&HookPauseRender), &g_origPauseRender, "pausa visual"},
      {0x78FD50, {0x48, 0x89, 0x5C, 0x24, 0x08}, 5, reinterpret_cast<void*>(&HookResumeRender), &g_origResumeRender, "retomada visual"},
  };
  int ok = 0;
  for (const Entry& e : entries) {
    void* target = reinterpret_cast<void*>(g_base + e.rva);
    if (std::memcmp(target, e.expect, e.len) != 0) {
      Log("CENA: bytes de %s (exe+0x%llX) diferentes; gancho nao instalado.", e.name,
          static_cast<unsigned long long>(e.rva));
      continue;
    }
    MH_STATUS st = MH_CreateHook(target, e.hook, reinterpret_cast<void**>(e.orig));
    if (st == MH_OK) st = MH_EnableHook(target);
    if (st == MH_OK) ++ok;
    else Log("CENA: gancho de %s falhou: %s", e.name, MH_StatusToString(st));
  }
  Log("CENA: %d de 4 ganchos de pausa/retomada de lutador instalados.", ok);
  // Monitor de trava/solta DESLIGADO: no teste (C39, 10/11 22:39) a luta inteira travou numa cena tipo 3 com ele
  // ligado; sem prova de que foi ele nem de que ajuda, fica desligado ate ser investigado.
  constexpr bool kUltLockMonitor = false;
  if (!kUltLockMonitor) return;
  static const uint8_t kLockBytes[] = {0x40, 0x53, 0x48, 0x83, 0xEC, 0x20, 0x48, 0x8B, 0x01};
  void* lock = reinterpret_cast<void*>(g_base + 0x7DCB1C);
  void* release = reinterpret_cast<void*>(g_base + 0x7DCBBC);
  if (std::memcmp(lock, kLockBytes, sizeof(kLockBytes)) == 0 &&
      std::memcmp(release, kLockBytes, sizeof(kLockBytes)) == 0) {
    MH_STATUS a = MH_CreateHook(lock, reinterpret_cast<void*>(&HookUltLock), reinterpret_cast<void**>(&g_origUltLock));
    if (a == MH_OK) a = MH_EnableHook(lock);
    MH_STATUS b = MH_CreateHook(release, reinterpret_cast<void*>(&HookUltRelease),
                                reinterpret_cast<void**>(&g_origUltRelease));
    if (b == MH_OK) b = MH_EnableHook(release);
    g_ultLockHooked = a == MH_OK && b == MH_OK;
    Log("CENA: trava/solta de Supremo monitoradas (%s / %s).", MH_StatusToString(a), MH_StatusToString(b));
  } else {
    Log("CENA: bytes de trava/solta de Supremo diferentes; nao monitorado.");
  }
}

void PatchMemberRole(uintptr_t player) {
  auto** vtable = *reinterpret_cast<void***>(player + kMemberOffset);
  void** slot = reinterpret_cast<void**>(vtable) + kMemberRoleSlot;
  if (*slot == reinterpret_cast<void*>(&HookMemberRole)) return;
  if (g_origMemberRole && *slot != reinterpret_cast<void*>(g_origMemberRole)) {
    Log("Ultimate: tabela de membro com outra rotina de papel; nao alterada.");
    return;
  }
  DWORD old = 0;
  if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &old)) return;
  g_origMemberRole = reinterpret_cast<MemberRole_t>(*slot);
  *slot = reinterpret_cast<void*>(&HookMemberRole);
  VirtualProtect(slot, sizeof(void*), old, &old);
  Log("Ultimate: papel real ligado (rotina em exe+0x%llX).",
      static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(g_origMemberRole) - g_base));
}

void CaptureFighters(uintptr_t duel) {
  g_numFighters = 0;
  ClearLockMarkers();
  ++g_battleId;
  int n = 0;
  for (int side = 0; side < 2; ++side) {
    uintptr_t team = duel + kTeamOffset + side * kTeamStride;
    g_team[side] = team;
    g_sideCount[side] = 0;
    ForEachNode(team, [&](uintptr_t node) {
      uintptr_t player = *reinterpret_cast<uintptr_t*>(node + 0x30);
      const int row = *reinterpret_cast<const int*>(node + 0x20);
      if (player && n < 6 && row >= 0 && row < 3) {
        g_fighters[n++] = {player, node, team, side, row, g_slotControls[side * 3 + row]};
        ++g_sideCount[side];
      }
    });
  }
  g_spawnReady = false;
  std::memset(g_voidSince, 0, sizeof(g_voidSince));
  g_lastCinematicAt = 0;
  std::memset(g_markedSince, 0, sizeof(g_markedSince));
  std::memset(g_snapValid, 0, sizeof(g_snapValid));
  std::memset(g_snapAt, 0, sizeof(g_snapAt));
  std::memset(g_liveAt, 0, sizeof(g_liveAt));
  std::memset(g_markPrev, 0, sizeof(g_markPrev));
  std::memset(g_sceneTookControl, 0, sizeof(g_sceneTookControl));
  std::memset(g_sceneHid, 0, sizeof(g_sceneHid));
  for (int k = 0; k < 6; ++k) {
    g_stateSeen[k] = -1;
    g_stateSince[k] = 0;
    g_prevControl[k] = g_prevShown[k] = -1;
    g_pausedMotion[k].store(false, std::memory_order_relaxed);
    g_pausedRender[k].store(false, std::memory_order_relaxed);
    g_ultLocked[k].store(false, std::memory_order_relaxed);
  }
  g_lastSceneAt = 0;
  g_lastNativeSceneAt = 0;
  std::memset(g_cineStateSince, 0, sizeof(g_cineStateSince));
  g_markLines = 0;
  g_ffaAutoTargetLast = 0;
  g_ffaCollisionReported = false;
  g_ffaCollisionCheckAt = 0;
  g_ffaCollisionLastLogged = 0;
  g_ffaCollisionLogAt = 0;
  g_ffaMatrixLogAt = 0;
  g_ffaCollisionPatches = 0;
  g_ffaCollisionConflicts = 0;
  g_ffaCollisionWriters = 0;
  g_ffaCollisionMatched = 0;
  g_ffaEarlyResultSuppressed = 0;
  g_ffaWinnerSlot.store(-1, std::memory_order_relaxed);
  g_ffaWinnerUntil.store(0, std::memory_order_relaxed);
  g_ffaSoloSince = 0;
  g_ffaSoloCandidate = -1;
  g_ffaSoloConfirmed = false;
  g_ffaKnockedOutBits.store(0, std::memory_order_relaxed);
  std::memset(g_ffaDownSince, 0, sizeof(g_ffaDownSince));
  unsigned rosterBits = 0;
  for (int i = 0; i < n; ++i) {
    const int slot = g_fighters[i].side * 3 + g_fighters[i].row;
    if (slot >= 0 && slot < 6) rosterBits |= 1u << slot;
  }
  g_ffaRosterBits.store(rosterBits, std::memory_order_release);
  g_ffaNativeResultDeferrals.store(0, std::memory_order_relaxed);
  g_ffaNativeFinalRouted.store(0, std::memory_order_relaxed);
  g_unfinishedBattleSince = 0;
  g_unfinishedBattleWarned = false;
  g_longSceneSince = 0;
  g_longSceneWarned = false;
  g_awakeningNext = 0;
  g_awakeningLast = 0;
  std::memset(g_lastMovementAt, 0, sizeof(g_lastMovementAt));
  std::memset(g_standstillReported, 0, sizeof(g_standstillReported));
  UltBattleReset();
  std::memset(g_recoverAfter, 0, sizeof(g_recoverAfter));
  g_floorRecoveries = 0;
  CameraBeginBattle();
  InputBeginBattle();
  // Alvo inicial: o adversario da mesma posicao; se a outra equipe for menor, reparte entre eles.
  for (int k = 0; k < 6; ++k) {
    g_target[k] = -1;
    g_revLockOff[k].store(false, std::memory_order_relaxed);
  }
  for (int k = 0; k < n; ++k) {
    if (Cfg().freeForAll.load(std::memory_order_relaxed)) {
      g_target[k] = (k + 1) % n; // first opponent, even from same original team
    } else {
      int other = 1 - g_fighters[k].side;
      if (g_sideCount[other] > 0) g_target[k] = FighterAt(other, g_fighters[k].row % g_sideCount[other], n);
    }
  }
  for (int k = 0; k < n; ++k) {
    ReadPortrait(g_hud[k], g_fighters[k].side, g_fighters[k].row);
    PatchMemberRole(g_fighters[k].player);
    HookHitHandlerOf(g_fighters[k].player);
    InstallPauseHooks();
  }
  g_numFighters.store(n, std::memory_order_release);
  ParryBeginBattle();
  GrabDefenseBeginBattle();
  PerfectSubBeginBattle();
  JutsuClashBeginBattle();
  DualComboBeginBattle();
  WallRunBeginBattle();
  Log("Contexto: %d lutadores (%d x %d) registrados para a regra 'meu lado -> eu'.", n, g_sideCount[0],
      g_sideCount[1]);
  if (Cfg().freeForAll.load(std::memory_order_relaxed)) {
    Log("FFA BETA: %d lutadores presentes. Alvos independentes e masks experimentais ativos; dano entre aliados e vencedor individual exigem teste real.", n);
    // Research-only: Evolution's collision manager is at RVA 0x16AAD08.
    // Inspect a few manager fields without changing its geometry or masks.
    if (Addr().timestamp == 0x5889906E) {
      __try {
        const uintptr_t manager = *reinterpret_cast<const uintptr_t*>(g_base + 0x16AAD08);
        Log("FFA COLLISION DIAG: manager=%p", reinterpret_cast<void*>(manager));
        if (manager) {
          const uintptr_t* fields = reinterpret_cast<const uintptr_t*>(manager);
          for (int k = 0; k < 12; ++k)
            Log("FFA COLLISION DIAG: field+0x%X=%p", k * 8,
                reinterpret_cast<void*>(fields[k]));
        }
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        Log("FFA COLLISION DIAG: manager invalid during setup");
      }
    }
  }
}

// Enter actual 3D fighters using the GAME'S native entrance action 0xE4.
// Each team's 2nd member enters on the same wave, followed by the 3rd.
// Do not replay the action for actors already on the stage or after KO.
void EnterExtrasWave(uintptr_t duel, int rank) {
  if(!duel || rank < 1 || rank > 2) return;
  float locations[2][3]{};
  int seen=0;
  for(int side=0;side<2;++side) {
    ForEachNode(duel+kTeamOffset+side*kTeamStride,[&](uintptr_t node) {
      const int key=*reinterpret_cast<const int*>(node+0x20);
      const uintptr_t player=*reinterpret_cast<const uintptr_t*>(node+0x30);
      if(key != rank || !player ||
         *reinterpret_cast<const int*>(player+kOnFieldFlag)) return;
      const float life=*reinterpret_cast<const float*>(node+kMemberGauges);
      if(!std::isfinite(life) || life<=0.0f)return;
      auto vtable=*reinterpret_cast<uintptr_t**>(player);
      if(!vtable || !vtable[kVtChangeState/sizeof(uintptr_t)])return;
      auto changeState=reinterpret_cast<void (*)(uintptr_t,int)>(
          vtable[kVtChangeState/sizeof(uintptr_t)]);
      changeState(player,kEnterState);
      *reinterpret_cast<int*>(player+kOnFieldFlag)=1;
      float position[3]{};
      std::memcpy(position,reinterpret_cast<const void*>(player+kPosOffset),
                  sizeof(position));
      if(seen<2 && std::isfinite(position[0]) && std::isfinite(position[1]) &&
         std::isfinite(position[2]) &&
         std::fabs(position[0])<20000 && std::fabs(position[1])<20000 &&
         std::fabs(position[2])<20000) {
        for(int a=0;a<3;++a)locations[seen][a]=position[a];
        ++seen;
      }
      Log("ENTRADA 3D: J%d/%d lado=%d usando acao nativa 0x%X",
          side*3+key+1,key+1,side,kEnterState);
    });
  }
  if(seen>0)CameraObserveEntrance(locations,seen);
}

void TryAwakenEveryoneAtStart() {
  if (!Cfg().awakenAtStart.load(std::memory_order_relaxed) || !g_entered ||
      !Enabled() || Addr().timestamp != 0x5889906E ||
      !PromoteBattleActive() || UltSceneActive()) return;
  const int count = g_numFighters.load(std::memory_order_acquire);
  if (count < 2 || count > 6 || g_awakeningNext >= count) return;
  const ULONGLONG now = GetTickCount64();
  // Native transformations may change models, animation graphs and scene pointers.
  // Start one fighter at a time on the game's judge thread.
  if (g_awakeningLast && now - g_awakeningLast < 1100) return;
  while (g_awakeningNext < count) {
    const int i = g_awakeningNext++;
    const Fighter& f = g_fighters[i];
    if (!f.player || !f.node) continue;
    const float hp = *reinterpret_cast<const float*>(f.node + kMemberGauges);
    if (!std::isfinite(hp) || hp <= 0 ||
        !*reinterpret_cast<const int*>(f.player + kOnFieldFlag)) continue;
    const auto vtable = *reinterpret_cast<uintptr_t* const*>(f.player);
    if (!vtable || !vtable[Addr().vtChangeState / sizeof(uintptr_t)]) continue;
    auto change = reinterpret_cast<void (*)(uintptr_t, int)>(
        vtable[Addr().vtChangeState / sizeof(uintptr_t)]);
    g_awakeningLast = now;
    Log("Despertar inicial: solicitando estado nativo 0x7C para J%d (%d/%d)",
        f.side * 3 + f.row + 1, g_awakeningNext, count);
    change(f.player, kAwakeBeginState);
    break;
  }
}

// Trabalho do mod a cada quadro de luta. O juiz normal (FUN_14074D248) chama; as lutas do carregador da
// historia (Chronicles) nao passam por ele, entao PromoteForeignJudgeTick chama daqui.
void JudgeWork(uintptr_t duel) {
  if (duel && Enabled()) {
    g_lastJudgeTick.store(GetTickCount64(), std::memory_order_relaxed);
    g_judgeFrameCount.fetch_add(1, std::memory_order_relaxed);
    // Do not identify the match by the first fighter: on KO the native roster may
    // change its first node. Recapturing all six actors mid-match caused resets.
    if (duel != g_battleKey) {
      g_battleKey = duel;
      g_frames = 0;
      g_entered = false;
      g_entranceWave = 0;
      g_entranceWaveElapsed = 0;
      if (g_setupWindow.exchange(false))
        Log("Montagem: janela fechada (%d respostas com extras).", g_answers.load());
      Log("Luta comecou (juiz rodando na thread do jogo).");
      __try {
        CaptureFighters(duel);
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        g_numFighters = 0;
      }
    }
    if (g_numFighters.load(std::memory_order_acquire) >= 2) {
      // Native awakening is attempted only after the promoted fighters have entered.
      __try {
        TryAwakenEveryoneAtStart();
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        Log("Despertar inicial: EXCECAO 0x%08lX; sequencia interrompida", GetExceptionCode());
        g_awakeningNext = 6;
      }
      // One invalid actor pointer must not crash the entire match.
      __try {
        UltTeamTick();
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        Log("COMBAT GUARD: EXCECAO 0x%08lX no processamento do supremo", GetExceptionCode());
        UltBattleReset();
      }
      __try {
        SnapshotHud();
        FfaUpdateTargets();
        RetargetDefeatedOpponents();
        FfaTrackHealthChanges();
        if (g_entered) {
          FfaRefreshCollisionMasks();
          FfaLogCollisionSamples();
          FfaMaskCompatibilityReport();
        }
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        Log("COMBAT GUARD: EXCECAO 0x%08lX ao ler HUD/posicoes e alvos", GetExceptionCode());
      }
    }
    if (!g_entered && g_frames < kDelayFrames) ++g_frames;
    if (!g_entered && g_frames >= kDelayFrames && !UltSceneActive()) {
      g_entered = true;
      g_entranceWave = 1;
      g_entranceWaveElapsed = 0;
      __try {
        EnterExtrasWave(duel,1);
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        Log("Entrada 3D: falha na primeira leva, 0x%08lX",GetExceptionCode());
      }
    }
    if(g_entered && g_entranceWave == 1) {
      ++g_entranceWaveElapsed;
      if(EntranceShouldAdvance(g_entranceWave,g_entranceWaveElapsed,
                               UltSceneActive())) {
        g_entranceWave=2;
        __try {
          EnterExtrasWave(duel,2);
          Log("Entrada 3D: formacao concluida em duas levas.");
        } __except(EXCEPTION_EXECUTE_HANDLER) {
          Log("Entrada 3D: falha na segunda leva, 0x%08lX",GetExceptionCode());
        }
      }
    }
  }
  // Publish the individual winner BEFORE native judge can unload its fighters.
  if (duel && Enabled() && g_entered && Cfg().freeForAll.load(std::memory_order_relaxed))
    FfaUpdateIndividualResult();
}

uintptr_t HookJudge(void* self) {
  g_lastNativeJudgeTick.store(GetTickCount64(), std::memory_order_relaxed);
  uintptr_t duel = *reinterpret_cast<uintptr_t*>(g_base + Addr().duelGlobal);
  JudgeWork(duel);
  uintptr_t result = g_origJudge(self);
  // Read-only result observation. Native +0xBC outcome is documented/tested
  // for Evolution; Original is intentionally excluded until validated.
  if(Addr().timestamp==0x5889906E && self &&
     ChroniclesAssistedMission()>=0 && !Cfg().freeForAll.load()) {
    __try {
      const int nativeOutcome=*reinterpret_cast<const int*>(
        static_cast<const uint8_t*>(self)+0xBC);
      ChroniclesAssistedJudgeTick(nativeOutcome);
    } __except(EXCEPTION_EXECUTE_HANDLER) {
      Log("CHRONICLES ASSISTIDO: resultado nativo indisponivel.");
    }
  }
  // Native GuardHit and action-state hooks enqueue a perfect-guard reaction.
  // Apply on the game's judge thread, never on an XInput worker.
  if(Enabled()) {
    __try {ParryBattleTick();}
    __except(EXCEPTION_EXECUTE_HANDLER) {
      Log("PARRY BETA: native reaction failed safely this frame.");
    }
  }
  // Only a genuine promoted multi-fighter arena uses the FFA result override.
  // Let vanilla 1v1/2v2 outcomes and battle teardown finish natively.
  if (Enabled() && Cfg().freeForAll.load(std::memory_order_relaxed) &&
      g_entered && self && g_teardownDepth.load(std::memory_order_relaxed) == 0 &&
      g_numFighters.load(std::memory_order_acquire) >= 3) {
    __try {
      int alive = 0, survivor = -1;
      const int count = g_numFighters.load(std::memory_order_acquire);
      for (int k = 0; k < count && k < 6; ++k)
        if (FfaAlive(k)) { ++alive; survivor = k; }
      // Evolution judge stores duel outcome at +0xBC; only change battle results.
      int* outcome = reinterpret_cast<int*>(static_cast<uint8_t*>(self) + 0xBC);
      if (alive > 1 && *outcome >= 1 && *outcome <= 3) {
        if (g_ffaEarlyResultSuppressed++ < 6)
          Log("FFA: fim prematuro entre equipes impedido; ainda ha %d lutadores vivos", alive);
        *outcome = 0;
      } else if (alive == 1 && g_ffaSoloConfirmed && survivor >= 0 &&
                 g_ffaWinnerSlot.load(std::memory_order_relaxed) == survivor) {
        // Native result is side-based; do not leave 1 (draw) when a single
        // individual actually won. Avoid finishing on cinematic frame glitches.
        const int wanted = g_fighters[survivor].side == 0 ? 2 : 3;
        if (*outcome != wanted) {
          *outcome = wanted;
          Log("FFA: ultimo sobrevivente J%d, vencedor de lado %d",
              g_fighters[survivor].side * 3 + g_fighters[survivor].row + 1,
              g_fighters[survivor].side);
        }
      }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("FFA: nao foi possivel ler/ajustar resultado da batalha");
    }
  }
  // Read-only end-of-match watchdog, Evolution only. We DO NOT forge a
  // native victory flag or kill a cinematic on a timer.
  if (Enabled() && !Cfg().freeForAll.load(std::memory_order_relaxed) &&
      Addr().timestamp == 0x5889906E && g_entered && self &&
      !g_teardownDepth.load(std::memory_order_relaxed) &&
      g_numFighters.load(std::memory_order_acquire) >= 3) {
    const ULONGLONG now = GetTickCount64();
    if (UltSceneActive()) {
      g_unfinishedBattleSince = 0;
      if (!g_longSceneSince) g_longSceneSince = now;
      if (!g_longSceneWarned && now - g_longSceneSince > 25000) {
        g_longSceneWarned = true;
        Log("COMBAT DIAG: uma cena nativa permanece ativa ha mais de 25 segundos.");
      }
    } else {
      g_longSceneSince = 0;
      g_longSceneWarned = false;
      int living[2] = {};
      const int count = g_numFighters.load(std::memory_order_acquire);
      for (int k = 0; k < count; ++k) {
        if (FfaAlive(k)) ++living[g_fighters[k].side];
      }
      __try {
        const int outcome = *reinterpret_cast<const int*>(static_cast<const uint8_t*>(self) + 0xBC);
        if ((living[0] == 0) != (living[1] == 0) && outcome == 0) {
          if (!g_unfinishedBattleSince) g_unfinishedBattleSince = now;
          if (!g_unfinishedBattleWarned && now - g_unfinishedBattleSince > 5000) {
            g_unfinishedBattleWarned = true;
            Log("COMBAT DIAG: um lado sem lutadores vivos por 5s; vivos=%d x %d, resultado nativo=%d.",
                living[0], living[1], outcome);
          }
        } else {
          g_unfinishedBattleSince = 0;
          g_unfinishedBattleWarned = false;
        }
      } __except (EXCEPTION_EXECUTE_HANDLER) {
        g_unfinishedBattleSince = 0;
      }
    }
  }
  return result;
}

// ---------------------------------------------------------------- desmontagem da batalha
// FUN_14074E434(duel): para cada lado e papel 0..2, chama vt+0xAE0 (limpeza) no membro.
// FUN_14074E04C(duel, side): remove os membros da equipe na ordem dos papeis 0..2.
// Com os extras como papel 0, os papeis 1/2 voltavam vazios: os extras ficavam no mapa ja
// destruidos e o jogo travava ao sair da luta. Aqui a desmontagem volta a ve-los.
#define kRvaTeardownClean (Addr().teardownClean)
#define kRvaTeardownRemove (Addr().teardownRemove)
using TeardownClean_t = uintptr_t (*)(void* duel);
using TeardownRemove_t = uintptr_t (*)(void* duel, int side);
TeardownClean_t g_origClean = nullptr;
TeardownRemove_t g_origRemove = nullptr;

void BeginTeardown(const char* what) {
  if (g_teardownDepth.fetch_add(1) == 0) {
    g_setupWindow = false;
    g_numFighters = 0;  // regras de contexto desligadas: lutadores sendo destruidos
    g_collisionSampleCount.store(0, std::memory_order_relaxed);
    ClearLockMarkers();
    g_battleKey = 0;
    UltBattleReset();
    CameraBeginBattle();
    Log("Desmontagem: %s (extras entregues nos papeis 1/2)", what);
  }
}

uintptr_t HookTeardownClean(void* duel) {
  BeginTeardown("limpeza dos membros");
  uintptr_t r = g_origClean(duel);
  g_teardownDepth.fetch_sub(1);
  return r;
}

uintptr_t HookTeardownRemove(void* duel, int side) {
  BeginTeardown("remocao dos membros");
  uintptr_t r = g_origRemove(duel, side);
  g_teardownDepth.fetch_sub(1);
  return r;
}

bool HookAt(uintptr_t rva, const uint8_t* expect, size_t n, void* detour, void** orig, const char* name) {
  void* target = reinterpret_cast<void*>(g_base + rva);
  if (std::memcmp(target, expect, n) != 0) {
    Log("%s: bytes diferentes do esperado; hook NAO instalado.", name);
    return false;
  }
  MH_STATUS st = MH_CreateHook(target, detour, orig);
  if (st == MH_OK) st = MH_EnableHook(target);
  Log("%s: %s", name, st == MH_OK ? "instalado" : MH_StatusToString(st));
  return st == MH_OK;
}

}  // namespace

bool PromoteInstall() {
  // The getter returns the opponent-side leader; in FFA it must resolve
  // the actual chosen fighter, including someone on the same original side.
  if (Addr().timestamp == 0x5889906E) {
    auto* getOpponent = reinterpret_cast<uint8_t*>(g_base + 0x796718);
    static const uint8_t kOpponentExpected[] = {0x33, 0xC0, 0x39, 0x81, 0x88, 0x0C, 0x00, 0x00};
    if (std::memcmp(getOpponent, kOpponentExpected, sizeof(kOpponentExpected)) == 0) {
      MH_STATUS hs = MH_CreateHook(getOpponent, reinterpret_cast<void*>(&HookFfaOpponentGetter),
          reinterpret_cast<void**>(&g_originalOpponentGetter));
      if (hs == MH_OK) hs = MH_EnableHook(getOpponent);
      if (hs == MH_OK) {
        g_ffaOpponentHook.store(true, std::memory_order_release);
        Log("FFA: virtual do adversario 0x796718 redirecionada para alvo individual.");
      } else {
        Log("FFA: hook de adversario nao instalado: %s", MH_StatusToString(hs));
      }
    } else {
      Log("FFA: assinatura de adversario diferente; hook ignorado.");
    }
  }
  // Collision mask setters in Evolution: group +0xD8, target +0xE8 (4 dwords).
  // Observe only, without bypassing the engine's hit rules.
  if (Addr().timestamp == 0x5889906E) {
    const struct {uintptr_t rva; const uint8_t bytes[3]; CollisionMaskSetterFn* original; void* hook;}
        collisionHooks[] = {
          {0xABC7B0, {0x0F, 0x10, 0x02}, &g_originalSetCollisionGroup,
              reinterpret_cast<void*>(&HookFfaSetCollisionGroup)},
          {0xABC7D0, {0x0F, 0x10, 0x02}, &g_originalSetCollisionTarget,
              reinterpret_cast<void*>(&HookFfaSetCollisionTarget)}
        };
    for (const auto& entry : collisionHooks) {
      void* fn = reinterpret_cast<void*>(g_base + entry.rva);
      if (std::memcmp(fn, entry.bytes, sizeof(entry.bytes)) != 0) {
        Log("FFA collision diagnostics: assinatura incorreta no setter 0x%llX",
            static_cast<unsigned long long>(entry.rva));
        continue;
      }
      MH_STATUS hs = MH_CreateHook(fn, entry.hook, reinterpret_cast<void**>(entry.original));
      if (hs == MH_OK) hs = MH_EnableHook(fn);
      Log("FFA collision diagnostics: setter 0x%llX %s",
          static_cast<unsigned long long>(entry.rva),
          hs == MH_OK ? "monitorado" : MH_StatusToString(hs));
    }
  }
  // A rotina nativa sincroniza a posicao do objeto e suas transformacoes.
  const auto setPosition = reinterpret_cast<SetPositionFn>(g_base + kRvaSetPosition);
  const auto resetMotion = reinterpret_cast<ResetMotionFn>(g_base + Addr().resetMotion);
  static const uint8_t kSetPositionExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x57, 0x48, 0x83, 0xEC, 0x30};
  static const uint8_t kResetMotionExpect[] = {0x40, 0x53, 0x48, 0x83, 0xEC, 0x20, 0x48, 0x8B, 0xD9, 0xE8};
  if (std::memcmp(reinterpret_cast<const void*>(setPosition), kSetPositionExpect, sizeof(kSetPositionExpect)) == 0 &&
      std::memcmp(reinterpret_cast<const void*>(resetMotion), kResetMotionExpect, sizeof(kResetMotionExpect)) == 0) {
    g_setPosition = setPosition;
    g_resetMotion = resetMotion;
    Log("Piso: resgate com reposicionamento e parada de movimento nativos.");
  } else {
    Log("Piso: rotinas de posicao diferentes do esperado; resgate desativado.");
  }

  static const uint8_t kCleanExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x6C, 0x24, 0x10};
  static const uint8_t kRemoveExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x6C, 0x24, 0x10};
  if (!HookAt(kRvaTeardownClean, kCleanExpect, sizeof(kCleanExpect), reinterpret_cast<void*>(&HookTeardownClean),
              reinterpret_cast<void**>(&g_origClean), "Desmontagem (limpeza)") ||
      !HookAt(kRvaTeardownRemove, kRemoveExpect, sizeof(kRemoveExpect), reinterpret_cast<void*>(&HookTeardownRemove),
              reinterpret_cast<void**>(&g_origRemove), "Desmontagem (remocao)"))
    return false;

  void* target = reinterpret_cast<void*>(g_base + kRvaCreateInner);
  static const uint8_t kExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x10, 0x55, 0x56, 0x57};
  if (std::memcmp(target, kExpect, sizeof(kExpect)) != 0) {
    Log("Fase 1: bytes de FUN_14074DDB8 diferentes do esperado; hook NAO instalado.");
    return false;
  }
  MH_STATUS st = MH_CreateHook(target, reinterpret_cast<void*>(&HookCreateInner),
                               reinterpret_cast<void**>(&g_orig));
  if (st == MH_OK) st = MH_EnableHook(target);
  if (st != MH_OK) {
    Log("Fase 1: hook falhou: %s", MH_StatusToString(st));
    return false;
  }
  Log("Fase 1: hook de criacao instalado.");

  void* setup = reinterpret_cast<void*>(g_base + kRvaMemberSetup);
  static const uint8_t kSetupExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x6C, 0x24, 0x10};
  if (std::memcmp(setup, kSetupExpect, sizeof(kSetupExpect)) == 0) {
    MH_STATUS s2 = MH_CreateHook(setup, reinterpret_cast<void*>(&HookMemberSetup),
                                 reinterpret_cast<void**>(&g_origSetup));
    if (s2 == MH_OK) s2 = MH_EnableHook(setup);
    Log("Fase 1: escolha CPU/jogador por membro %s", s2 == MH_OK ? "instalada" : MH_StatusToString(s2));
    if (s2 != MH_OK) return false;
  } else {
    Log("Fase 1: bytes de FUN_14074E4C0 diferentes; escolha CPU/jogador desativada.");
    return false;
  }

  // Only Evolution is mapped and signature-verified. Storm 4 1.09 remains
  // untouched; this does not change any vanilla 3v3 code path.
  if (Addr().timestamp == 0x5889906E) {
    static constexpr uint8_t kJudgeTeamHealthExpect[] =
        {0x48, 0x83, 0xEC, 0x38, 0x0F, 0x29, 0x74, 0x24, 0x20};
    void* nativeHealth = reinterpret_cast<void*>(g_base + 0x746A60);
    if (std::memcmp(nativeHealth, kJudgeTeamHealthExpect,
                    sizeof(kJudgeTeamHealthExpect)) == 0) {
      MH_STATUS sh = MH_CreateHook(nativeHealth,
          reinterpret_cast<void*>(&HookFfaJudgeTeamHealth),
          reinterpret_cast<void**>(&g_origJudgeTeamHealth));
      if (sh == MH_OK) sh = MH_EnableHook(nativeHealth);
      g_ffaTeamHealthHookInstalled = sh == MH_OK;
      Log("FFA juiz individual: hook de verificacao nativa da vida %s",
          sh == MH_OK ? "instalado (2 chamadas Evolution)" : MH_StatusToString(sh));
    } else {
      Log("FFA juiz individual: assinatura inesperada, alteracao de resultado desativada.");
    }
  }
  void* judge = reinterpret_cast<void*>(g_base + kRvaJudge);
  static const uint8_t kJudgeExpect[] = {0x48, 0x8B, 0xC4, 0x48, 0x89, 0x58, 0x08};
  if (std::memcmp(judge, kJudgeExpect, sizeof(kJudgeExpect)) != 0) {
    Log("Fase 1: bytes do juiz diferentes do esperado; entrada dos extras desativada.");
    return false;
  }
  st = MH_CreateHook(judge, reinterpret_cast<void*>(&HookJudge),
                     reinterpret_cast<void**>(&g_origJudge));
  if (st == MH_OK) st = MH_EnableHook(judge);
  Log("Fase 1: tick do juiz %s", st == MH_OK ? "instalado" : MH_StatusToString(st));
  g_promotionReady.store(st == MH_OK, std::memory_order_release);
  return st == MH_OK;
}

void** PromoteAnswer(void* team, int role, uint32_t site) {
  if (role != 1 && role != 2) return nullptr;
  const auto t = reinterpret_cast<uintptr_t>(team);
  for (int side = 0; side < 2; ++side) {
    if (g_team[side] != t) continue;
    if (void** actor = PromoteFighterMember(team, UltTeamActor(side, role, site))) return actor;
    break;
  }
  // Com o juiz parado (menu de pausa, reiniciar), o jogo percorre a equipe pelos papeis 0..2 e nao
  // espera papel vazio: FUN_140681C.. usa o resultado direto e travava com ponteiro nulo.
  const bool paused = g_numFighters.load(std::memory_order_relaxed) >= 2 && !PromoteBattleActive();
  if (!g_setupWindow.load(std::memory_order_relaxed) && g_teardownDepth.load(std::memory_order_relaxed) == 0 && !paused)
    return nullptr;
  void** answer = nullptr;
  __try {
    ForEachNode(reinterpret_cast<uintptr_t>(team), [&](uintptr_t node) {
      if (!answer && *reinterpret_cast<int*>(node + 0x20) == role)
        answer = reinterpret_cast<void**>(node + 0x28);
    });
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return nullptr;
  }
  if (answer) {
    ++g_answers;
    int n = g_numLogged.load();
    bool seen = false;
    for (int i = 0; i < n && i < kMaxLoggedSites; ++i) seen |= g_loggedSites[i] == site;
    if (!seen && n < kMaxLoggedSites) {
      g_loggedSites[n] = site;
      g_numLogged = n + 1;
      Log("Montagem: ponto exe+0x%X pediu papel %d -> extra entregue", site, role);
    }
  }
  return answer;
}

static void** SceneAnswer(uintptr_t t, int n) {
  for (int side = 0; side < 2; ++side) {
    if (g_team[side] != t) continue;
    const int who = UltSceneFighter(side);
    if (who < 0 || who >= n || g_fighters[who].team != t) return nullptr;
    if(CensusDiagnosticsEnabled()) g_ctxScene.fetch_add(1, std::memory_order_relaxed);
    return reinterpret_cast<void**>(g_fighters[who].node + 0x28);
  }
  return nullptr;
}

void** PromoteContext(void* team, int role, const uintptr_t* stack, uint32_t site) {
  int n = g_numFighters.load(std::memory_order_acquire);
  if (n < 2 || n > 6 || g_setupWindow.load(std::memory_order_relaxed)) return nullptr;
  // Os estados do Supremo (exe+0x7D0BE9 / exe+0x7D100D) pedem a vitima por (lado oposto, PAPEL do alvo) com
  // qualquer papel. Com papel 1/2 vinha o extra desse papel (ex.: J6 preso 70 s no estado de vitima 0x51 em
  // C38 quando a vitima real era J4). Para qualquer papel, a resposta e a vitima real da cinematica.
  if (role != 0 && !((site == 0x7D0BE9 || site == 0x7D100D) && Addr().timestamp == 0x5889906E)) return nullptr;
  if(CensusDiagnosticsEnabled()) g_ctxQueries.fetch_add(1, std::memory_order_relaxed);
  uintptr_t t = reinterpret_cast<uintptr_t>(team);
  // CAUSA REAL do Supremo executado pelo lider (Evolution): ao processar um acerto, a vitima pede o
  // atacante como "membro 0 do lado dele" (FUN_1408566BC em exe+0x782C47, FUN_140856690 em exe+0x7836F6)
  // e roda a cinematica (FUN_1407D6C94 -> cena 9) nesse objeto. O jogo so guarda o LADO do atacante.
  // Se esse lado preparou um Supremo (cena 8) agora ha pouco e a vitima dele esta nesta chamada, o
  // atacante e quem preparou.
  // CAUSA REAL do lider adversario preso no Supremo (Evolution): os estados do Supremo (FUN_1407D0Bxx e
  // FUN_1407D0Fxx, retornos exe+0x7D0BE9 / exe+0x7D100D) acham a vitima por (lado oposto, papel do alvo) com
  // FUN_1408566BC e ligam nela a marca de cena +0x17AC. Como os extras tem papel nativo 0, vinha o LIDER, que
  // ficava marcado, puxado para a cinematica e sem IA. Logo apos a cena 9, a resposta e a vitima real dela.
  // CAUSA REAL do lider do time da VITIMA preso depois da cinematica (Evolution): ao criar a cena 9,
  // FUN_1407D6D34 pede FUN_140796A04(alvo) = "lider do lado do alvo" (+0xC88 e o lado do proprio lutador;
  // retornos exe+0x7D6E07 e exe+0x7D6E17) e nele desliga o controle, zera a entrada e poe a animacao (+0xFD90,
  // FUN_1406B0BE8) no modo da cinematica. No 1x1 e a propria vitima; com extras era o LIDER do time dela, que
  // ficava preso (ex.: J4 parado em 0x10 depois de um Supremo em J5/J6). FUN_140796A04 chama o gargalo direto
  // (retorno exe+0x796A2F); o chamador real esta mais acima na pilha. Resposta: a vitima real deste acerto.
  if (site == 0x796A2F && Addr().timestamp == 0x5889906E && t_hitVictim) {
    int hit = -1;
    for (int k = 0; k < n; ++k)
      if (g_fighters[k].player == t_hitVictim) hit = k;
    if (hit >= 0 && g_fighters[hit].team == t) {
      for (int i = 1; i < 32; ++i) {
        const uintptr_t r = stack[i] - g_base;
        if (r != 0x7D6E07 && r != 0x7D6E17) continue;
        static std::atomic<unsigned> logs{0};
        if (logs.fetch_add(1, std::memory_order_relaxed) < 12)
          Log("ULTIMATE: cinematica prepara a vitima J%d, nao o lider do time dela (exe+0x%llX).",
              g_fighters[hit].side * 3 + g_fighters[hit].row + 1, static_cast<unsigned long long>(r));
        return reinterpret_cast<void**>(g_fighters[hit].node + 0x28);
      }
    }
  }
  if ((site == 0x7D0BE9 || site == 0x7D100D) && Addr().timestamp == 0x5889906E) {
    int victimSide = -1, victim = -1;
    if (UltRecentCinematicVictim(&victimSide, &victim, 4000) && t == g_team[victimSide] &&
        victim >= 0 && victim < n && g_fighters[victim].team == t) {
      static std::atomic<unsigned> logs{0};
      if (logs.fetch_add(1, std::memory_order_relaxed) < 6)
        Log("ULTIMATE: vitima da cinematica e J%d, nao o lider (exe+0x%X).",
            g_fighters[victim].side * 3 + g_fighters[victim].row + 1, site);
      return reinterpret_cast<void**>(g_fighters[victim].node + 0x28);
    }
  }
  if (role != 0) return nullptr;  // papel 1/2 so nos estados do Supremo acima
  if ((site == 0x782C4C || site == 0x7836FB) && Addr().timestamp == 0x5889906E) {
    for (int side = 0; side < 2; ++side) {
      if (g_team[side] != t) continue;
      int owner = -1, victim = -1;
      if (!UltPreparedUltimate(side, &owner, &victim) || owner >= n || victim < 0 || victim >= n) break;
      // Vitima real: o objeto cujo tratamento de acerto esta rodando nesta thread; sem ele, a pilha.
      const bool hitVictimKnown = t_hitVictim != 0;
      for (int i = 1; i < 48; ++i) {
        if (hitVictimKnown ? (i > 1 || t_hitVictim != g_fighters[victim].player)
                           : stack[i] != g_fighters[victim].player) continue;
        static std::atomic<unsigned> logs{0};
        if (logs.fetch_add(1, std::memory_order_relaxed) < 24)
          Log("ULTIMATE: acerto do Supremo em J%d atribuido a J%d (quem preparou), nao ao lider (exe+0x%X).",
              g_fighters[victim].side * 3 + g_fighters[victim].row + 1,
              g_fighters[owner].side * 3 + g_fighters[owner].row + 1, site);
        return reinterpret_cast<void**>(g_fighters[owner].node + 0x28);
      }
      // O Supremo acertou OUTRO adversario no caminho (C38: J2 mirou J5 e acertou J6). Se quem preparou
      // ainda esta no avanco do Supremo e a vitima deste acerto e do lado oposto, o atacante e ele.
      if (hitVictimKnown) {
        int hit = -1;
        for (int k = 0; k < n; ++k)
          if (g_fighters[k].player == t_hitVictim) hit = k;
        const int dasher = hit >= 0 ? UltDashAttacker(side, hit) : -1;
        if (dasher >= 0) {
          static std::atomic<unsigned> logs{0};
          if (logs.fetch_add(1, std::memory_order_relaxed) < 24)
            Log("ULTIMATE: acerto do Supremo em J%d no caminho atribuido a J%d (no avanco do Supremo), nao ao "
                "lider (exe+0x%X).",
                g_fighters[hit].side * 3 + g_fighters[hit].row + 1,
                g_fighters[dasher].side * 3 + g_fighters[dasher].row + 1, site);
          return reinterpret_cast<void**>(g_fighters[dasher].node + 0x28);
        }
      }
      break;
    }
  }
  for (int side = 0; side < 2; ++side) {
    if (g_team[side] != t) continue;
    if (void** actor = PromoteFighterMember(team, UltTeamActor(side, role, site))) return actor;
    break;
  }
  // A camera consulta os lideres da arena, independentemente de ponteiros de
  // outros lutadores ainda presentes na pilha.
  if (site == Addr().duelCamLeaderSite - 0x11) return nullptr;
  if (site == Addr().duelCamLeaderSite) {
    if (t != g_team[1] || Cfg().camera.load() != kCameraDuel) return nullptr;
    int tg = g_target[0].load(std::memory_order_relaxed);
    if (tg < 0 || tg >= n || g_fighters[tg].side != 1) return nullptr;
    if(CensusDiagnosticsEnabled()) g_ctxCamera.fetch_add(1, std::memory_order_relaxed);
    return reinterpret_cast<void**>(g_fighters[tg].node + 0x28);
  }
  // O codigo das cenas pergunta pelo lider do lado; lixo antigo na pilha nao pode decidir aqui.
  if (site >= Addr().dirCodeBegin && site < Addr().dirCodeEnd) return SceneAnswer(t, n);
  // A jutsu may put an opponent pointer on the stack before the caster (3v3 and FFA).
  // If that opponent's configured target belongs to the queried team,
  // selecting that target early makes the JUTSU originate from the wrong
  // fighter (often the team leader). Prefer the concrete same-team caster
  // whenever one is available in the saved call context.
  constexpr int kScan = 48;
  int indirectTarget = -1;
  for (int i = 1; i < kScan; ++i) {
    const uintptr_t candidate = stack[i];
    for (int k = 0; k < n; ++k) {
      if (g_fighters[k].player != candidate) continue;
      if (g_fighters[k].team == t) {
        if(CensusDiagnosticsEnabled()) g_ctxOverrides.fetch_add(1, std::memory_order_relaxed);
        if (indirectTarget >= 0) {
          static std::atomic<unsigned> ownerResolvedLogs{0};
          if (ownerResolvedLogs.fetch_add(1, std::memory_order_relaxed) < 20)
            Log("Origem do jutsu/ator: exe+0x%X identificou J%d (evitou alvo indireto J%d)",
                site, g_fighters[k].side * 3 + g_fighters[k].row + 1,
                g_fighters[indirectTarget].side * 3 + g_fighters[indirectTarget].row + 1);
        }
        return reinterpret_cast<void**>(g_fighters[k].node + 0x28);
      }
      const int tg = g_target[k].load(std::memory_order_relaxed);
      if (indirectTarget < 0 && tg >= 0 && tg < n && g_fighters[tg].team == t)
        indirectTarget = tg;
    }

  }
  if (indirectTarget >= 0) {
    if(CensusDiagnosticsEnabled()) g_ctxTargets.fetch_add(1, std::memory_order_relaxed);
    return reinterpret_cast<void**>(g_fighters[indirectTarget].node + 0x28);
  }
  return nullptr;
}

int PromoteLockMarkers(LockMarker out[4]) {
  if (!PromoteBattleActive() || !Cfg().lockon.load()) return 0;
  AcquireSRWLockShared(&g_markerLock);
  const int count = g_markerCount;
  std::memcpy(out, g_markers, count * sizeof(out[0]));
  ReleaseSRWLockShared(&g_markerLock);
  return count;
}

int PromoteFighterSide(int fighter) {
  const int n = g_numFighters.load(std::memory_order_acquire);
  return fighter >= 0 && fighter < n ? g_fighters[fighter].side : -1;
}

int PromoteFighterCount(){
  return g_numFighters.load(std::memory_order_acquire);
}
uintptr_t PromoteFighterPlayer(int fighter){
  const int count=PromoteFighterCount();
  if(fighter<0 || fighter>=count || fighter>=6)return 0;
  return g_fighters[fighter].player;
}
int PromoteParryAttacker(int defender,uint64_t now){
  // This resolver is called ONLY on the native judge thread and only on a
  // confirmed GuardHit event. In crowded 3v3 scenes, never stun a guess.
  const int count=PromoteFighterCount();
  if(count<2 || count>6 || defender<0 || defender>=count ||
     !PromoteBattleActive() || UltSceneActive() ||
     Cfg().freeForAll.load(std::memory_order_relaxed) ||
     !FfaAlive(defender))return -1;
  const Fighter& victim=g_fighters[defender];
  if(!victim.player)return -1;
  int chosen=-1,second=-1;
  float firstDistance=1e9f,secondDistance=1e9f;
  int firstPriority=-1,secondPriority=-1;
  __try {
    const int nativeVictimId=*reinterpret_cast<const int*>(victim.player+0x40);
    const float* vp=reinterpret_cast<const float*>(victim.player+0x70);
    if(!std::isfinite(vp[0])||!std::isfinite(vp[1])||
       !std::isfinite(vp[2]))return -1;
    for(int k=0;k<count;++k) {
      if(k==defender || g_fighters[k].side==victim.side ||
         !FfaAlive(k) || !g_fighters[k].player)continue;
      const uintptr_t actor=g_fighters[k].player;
      const float* p=reinterpret_cast<const float*>(actor+0x70);
      if(!std::isfinite(p[0])||!std::isfinite(p[1])||
         !std::isfinite(p[2]))continue;
      const float dx=p[0]-vp[0],dy=p[1]-vp[1],dz=p[2]-vp[2];
      const float dist=std::sqrt(dx*dx+dy*dy+dz*dz);
      if(!std::isfinite(dist)||dist>190)continue;
      const int targetId=*reinterpret_cast<const int*>(actor+0x8E4);
      const bool nativeTarget=targetId==nativeVictimId;
      const bool attacking=ParryRecentAttack(k,now);
      const int priority=(nativeTarget?2:0)+(attacking?1:0);
      if(priority>firstPriority ||
         (priority==firstPriority&&dist<firstDistance)){
        second=chosen;
        secondDistance=firstDistance;secondPriority=firstPriority;
        chosen=k;firstDistance=dist;firstPriority=priority;
      } else if(priority>secondPriority ||
                (priority==secondPriority&&dist<secondDistance)){
        second=k;secondDistance=dist;secondPriority=priority;
      }
    }
  } __except(EXCEPTION_EXECUTE_HANDLER) {return -1;}
  if(chosen<0)return -1;
  if(second<0)return chosen; // only one viable opponent in reach
  if(firstPriority<3)return -1; // crowded arena requires recent confirmed attacking state
  // A confirmed native target + recent attack outranks an idle fighter.
  if(firstPriority>=3 && secondPriority<3)return chosen;
  // Two likely attackers nearby: never choose a random one.
  if(firstPriority==secondPriority &&
     !parry::UniqueNearbyAttacker(firstDistance,secondDistance,190,65))
    return -1;
  return firstPriority>=2 ? chosen : -1;
}
int PromoteTeamHitVictim(int owner) {

  const int side = PromoteFighterSide(owner);
  if (side < 0) return -1;
  const int targetId = *reinterpret_cast<const int*>(g_fighters[owner].player + 0x8E4);
  const int count = g_numFighters.load(std::memory_order_acquire);
  for (int i = 0; i < count; ++i) {
    if (g_fighters[i].side != side && *reinterpret_cast<const int*>(g_fighters[i].player + 0x40) == targetId)
      return i;
  }
  return -1;
}

void** PromoteFighterMember(void* team, int fighter) {
  if (PromoteFighterSide(fighter) < 0 || g_fighters[fighter].team != reinterpret_cast<uintptr_t>(team))
    return nullptr;
  return reinterpret_cast<void**>(g_fighters[fighter].node + 0x28);
}

int PromoteFullChakraAlly(int owner) {
  if (!PromoteBattleActive() || PromoteFighterSide(owner) < 0 || g_fighters[owner].row != 0) return -1;
  auto ready = [](const Fighter& f) {
    const float* gauges = reinterpret_cast<const float*>(f.node + kMemberGauges);
    return *reinterpret_cast<const int*>(f.player + kOnFieldFlag) &&
           std::isfinite(gauges[0]) && gauges[0] > 0 &&
           std::isfinite(gauges[2]) && std::isfinite(gauges[3]) &&
           gauges[3] > 0 && gauges[2] >= gauges[3];
  };
  const Fighter& leader = g_fighters[owner];
  if (!ready(leader)) return -1;
  const auto* config = reinterpret_cast<const uint8_t*>(
      g_base + kRvaSideConfig + leader.side * kSideConfigStride);
  const int combo = *reinterpret_cast<const int*>(config + 0x24);
  if (combo < 0) return -1;
  const int count = g_numFighters.load(std::memory_order_acquire);
  // A dupla nativa inicia com papeis 0 e 1. O papel 2 nao participa desta animacao.
  if (*reinterpret_cast<const int*>(config + kRoleBlock + 0x24) != combo ||
      *reinterpret_cast<const int*>(config + 2 * kRoleBlock + 0x24) == combo)
    return -1;
  const int ally = FighterAt(leader.side, 1, count);
  return ally >= 0 && ready(g_fighters[ally]) ? ally : -1;
}

bool PromoteTeamSpendChakra75(int owner, int ally) {
  const int count = g_numFighters.load(std::memory_order_acquire);
  if (owner < 0 || ally < 0 || owner >= count || ally >= count || owner == ally ||
      g_fighters[owner].side != g_fighters[ally].side) return false;
  float* chakra[2]{};
  float maxChakra[2]{};
  for (int i = 0; i < 2; ++i) {
    const Fighter& fighter = g_fighters[i == 0 ? owner : ally];
    if (!fighter.node || !fighter.player || !*reinterpret_cast<const int*>(fighter.player + kOnFieldFlag))
      return false;
    auto* gauges = reinterpret_cast<float*>(fighter.node + kMemberGauges);
    if (!std::isfinite(gauges[2]) || !std::isfinite(gauges[3]) ||
        gauges[3] <= 0.0f || gauges[2] < 0.0f) return false;
    chakra[i] = gauges + 2;
    maxChakra[i] = gauges[3];
  }
  // Do not add chakra if the engine has already consumed some.
  // Starting full, each participant is left with one quarter of their maximum.
  const float beforeA = *chakra[0], beforeB = *chakra[1];
  *chakra[0] = std::min(*chakra[0], maxChakra[0] * 0.25f);
  *chakra[1] = std::min(*chakra[1], maxChakra[1] * 0.25f);
  Log("Supremo em equipe: chakra 75%% L%d %.1f->%.1f (max %.1f), L%d %.1f->%.1f (max %.1f)",
      owner + 1, beforeA, *chakra[0], maxChakra[0],
      ally + 1, beforeB, *chakra[1], maxChakra[1]);
  return true;
}

bool PromoteStartTeamUltimate(int owner) {
  // 0x8D is the native team-ultimate state selected by NSUNS4e at 0x7DAFC8.
  // Never use it on other executable versions without re-identifying that state.
  if (Addr().timestamp != 0x5889906E || !PromoteBattleActive() ||
      PromoteFighterSide(owner) < 0 || PromoteFullChakraAlly(owner) < 0) return false;
  const Fighter& fighter = g_fighters[owner];
  if (!fighter.player || !fighter.node || !*reinterpret_cast<int*>(fighter.player + kOnFieldFlag))
    return false;
  auto* vtable = *reinterpret_cast<uintptr_t**>(fighter.player);
  if (!vtable || !vtable[Addr().vtChangeState / sizeof(uintptr_t)]) return false;
  auto changeState = reinterpret_cast<void (*)(uintptr_t, int)>(
      vtable[Addr().vtChangeState / sizeof(uintptr_t)]);
  // Call through the same vtable method and state the executable normally uses.
  changeState(fighter.player, 0x8D);
  return true;
}

void PromoteTeamAllyPosition(int ally, float position[3]) {
  if (PromoteFighterSide(ally) < 0) return;
  std::memcpy(position, reinterpret_cast<const void*>(g_fighters[ally].player + kPosOffset), sizeof(float[3]));
}

void PromoteReturnTeamAlly(int ally, const float position[3]) {
  if (PromoteFighterSide(ally) < 0 || !position) return;
  const auto& fighter = g_fighters[ally];
  if (!fighter.player || !fighter.node) return;
  const int slot = fighter.side * 3 + fighter.row + 1;
  __try {
    const float* gauges = reinterpret_cast<const float*>(fighter.node + kMemberGauges);
    if (!std::isfinite(gauges[0]) || gauges[0] <= 0) return;

    const int onField = *reinterpret_cast<const int*>(fighter.player + kOnFieldFlag);
    float current[3]{};
    std::memcpy(current, reinterpret_cast<const void*>(fighter.player + kPosOffset),
                sizeof(current));
    const float floor = g_spawnReady ? g_spawn[fighter.side][2] : current[2];

    // An ultimate can move a participant to a cinematic-only stage. Never
    // restore a saved position from outside the actual battle arena.
    const bool savedSafe = std::isfinite(position[0]) && std::isfinite(position[1]) &&
        std::isfinite(position[2]) &&
        (!g_spawnReady ||
         (std::fabs(position[0] - g_spawn[fighter.side][0]) < 10000.0f &&
          std::fabs(position[1] - g_spawn[fighter.side][1]) < 10000.0f &&
          position[2] >= floor - kBelowFloor));
    const float* home = savedSafe ? position : (g_spawnReady ? g_spawn[fighter.side] : nullptr);

    if (onField != 0) {
      // The observed bug: native team ultimate left the ally already ON FIELD
      // (log: em_campo_antes=1), but we forced kEnterState again. That may
      // interrupt AI/physics and move the actor below the arena every round.
      // Keep all valid native animations and field flags completely untouched.
      if (g_setPosition && g_resetMotion && home &&
          std::isfinite(current[2]) && std::isfinite(floor) &&
          current[2] < floor - kBelowFloor) {
        g_setPosition(reinterpret_cast<void*>(fighter.player), home);
        g_resetMotion(reinterpret_cast<void*>(fighter.player));
        Log("ULTIMATE RECOVERY: J%d em campo, so posicao abaixo do piso corrigida (Z=%.1f).",
            slot, current[2]);
      } else {
        Log("ULTIMATE RECOVERY: J%d ja estava em campo; sem reentrada nem teleporte.", slot);
      }
      return;
    }

    // Only an ally that really left the native field is allowed to re-enter.
    auto vtable = *reinterpret_cast<uintptr_t**>(fighter.player);
    if (!vtable || !vtable[kVtChangeState / sizeof(uintptr_t)]) return;
    const auto changeState = reinterpret_cast<void (*)(uintptr_t, int)>(
        vtable[kVtChangeState / sizeof(uintptr_t)]);
    changeState(fighter.player, kEnterState);
    *reinterpret_cast<int*>(fighter.player + kOnFieldFlag) = 1;
    if (home && g_setPosition && g_resetMotion) {
      g_setPosition(reinterpret_cast<void*>(fighter.player), home);
      g_resetMotion(reinterpret_cast<void*>(fighter.player));
    }
    Log("ULTIMATE RECOVERY: J%d devolvido ao campo; local salvo valido=%d.",
        slot, int(savedSafe));
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    Log("COMBAT GUARD: falha ao restaurar parceiro de Supremo, J%d.", slot);
  }
}

int PromoteFighterOnStack(const uintptr_t* stack) {
  int n = g_numFighters.load(std::memory_order_acquire);
  if (n < 2) return -1;
  for (int i = 1; i < 48; ++i)
    for (int k = 0; k < n; ++k)
      if (g_fighters[k].player == stack[i]) return k;
  return -1;
}

int PromoteFighterByPlayer(uintptr_t player) {
  int n = g_numFighters.load(std::memory_order_acquire);
  for (int k = 0; k < n; ++k)
    if (g_fighters[k].player == player) return k;
  return -1;
}

int PromotePadForPlayer(uintptr_t player) {
  const int fighter = PromoteFighterByPlayer(player);
  return fighter >= 0 ? SlotPadIndex(g_fighters[fighter].control) : -1;
}

int PromoteFighterForPad(int pad) {
  if (pad < 0) return -1;
  const int count = g_numFighters.load(std::memory_order_acquire);
  for (int i = 0; i < count; ++i) {
    const Fighter& fighter = g_fighters[i];
    if (SlotPadIndex(fighter.control) == pad ||
        (fighter.control == kSlotAuto && fighter.side == pad))
      return i;
  }
  return -1;
}

int PromoteTargetOf(int fighter) {
  int n = g_numFighters.load(std::memory_order_acquire);
  if (fighter < 0 || fighter >= n) return -1;
  if (Cfg().camera.load(std::memory_order_relaxed) == kCameraRevolution &&
      Cfg().lockonStyle.load(std::memory_order_relaxed) == 2 &&
      g_revLockOff[fighter].load(std::memory_order_relaxed))
    return -1;
  int t = g_target[fighter].load();
  return (t >= 0 && t < n) ? t : -1;
}

bool PromoteBattlePresent() {
  return g_numFighters.load() >= 2 && !g_setupWindow.load() && g_teardownDepth.load() == 0;
}

bool PromoteReservesRightStick() {
  return g_setupWindow.load() || PromoteBattlePresent();
}

bool PromoteBattleActive() {
  return PromoteBattlePresent() && GetTickCount64() - g_lastJudgeTick.load(std::memory_order_relaxed) < 500;
}

void PromoteToggleRevolutionLock(int fighter) {
  if (!Cfg().lockon.load(std::memory_order_relaxed) ||
      Cfg().camera.load(std::memory_order_relaxed) != kCameraRevolution ||
      Cfg().lockonStyle.load(std::memory_order_relaxed) != 2 ||
      !PromoteBattleActive()) return;
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (fighter < 0 || fighter >= n || !FfaAlive(fighter)) return;
  const bool nowOff = !g_revLockOff[fighter].load(std::memory_order_relaxed);
  g_revLockOff[fighter].store(nowOff, std::memory_order_relaxed);
  Log("LOCK REVOLUTION: J%d %s (R3)", fighter+1, nowOff?"SEM MIRA":"MIRA ATIVA");
}

void PromoteDirectionalRevolutionTarget(int fighter, float stickX, float stickY) {
  if (!Cfg().lockon.load(std::memory_order_relaxed) ||
      Cfg().camera.load(std::memory_order_relaxed) != kCameraRevolution ||
      Cfg().lockonStyle.load(std::memory_order_relaxed) != 2 ||
      !PromoteBattleActive()) return;
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (fighter < 0 || fighter >= n || n > 6 || !FfaAlive(fighter)) return;
  const float local[3] = {g_pos[fighter][0],g_pos[fighter][1],
                          g_pos[fighter][2]+72.0f};
  const float aspect=HudAspectRatio();
  float ownX=0,ownY=0;
  if (!CameraProject(local,aspect,&ownX,&ownY)) return;
  float projected[6][2]{};
  bool valid[6]{};
  const bool ffa=Cfg().freeForAll.load(std::memory_order_relaxed);
  for(int k=0;k<n;++k) {
    if (k==fighter || !FfaAlive(k) ||
        (!ffa && g_fighters[k].side==g_fighters[fighter].side)) continue;
    const float p[3]={g_pos[k][0],g_pos[k][1],g_pos[k][2]+72.0f};
    bool behind=false;
    if (!CameraProject(p,aspect,&projected[k][0],&projected[k][1],&behind) ||
        behind) continue;
    valid[k]=true;
  }
  const float own[2]={ownX,ownY};
  const int current=g_target[fighter].load(std::memory_order_relaxed);
  const int next=RevolutionDirectionalPick(stickX,stickY,own,projected,valid,n,current);
  if(next>=0) {
    g_target[fighter].store(next,std::memory_order_relaxed);
    g_revLockOff[fighter].store(false,std::memory_order_relaxed);
    Log("LOCK REVOLUTION: J%d selecionou J%d pela direcao do analogico.",
        fighter+1,next+1);
  }
}
void PromoteSetTarget(int fighter, int target) {
  const int n = g_numFighters.load(std::memory_order_acquire);
  if (fighter < 0 || fighter >= n || target < 0 || target >= n || fighter == target || !FfaAlive(target)) return;
  g_target[fighter].store(target, std::memory_order_relaxed);
}
void PromoteCycleTarget(int fighter, int dir) {
  int n = g_numFighters.load();
  if (fighter < 0 || fighter >= n) return;
  if (Cfg().freeForAll.load(std::memory_order_relaxed)) {
    int current = g_target[fighter].load(std::memory_order_relaxed);
    if (current < 0 || current >= n) current = fighter;
    for (int step = 1; step < n; ++step) {
      const int next = (current + dir * step + n * 4) % n;
      if (next != fighter && FfaAlive(next)) {
        g_target[fighter].store(next, std::memory_order_relaxed);
        Log("FFA lock-on: J%d agora mira J%d", fighter + 1, next + 1);
        return;
      }
    }
    return;
  }
  int other = 1 - g_fighters[fighter].side;
  int count = g_sideCount[other];
  if (count < 2) return; // only one enemy; auto-retarget covers its KO
  const int cur = g_target[fighter].load(std::memory_order_relaxed);
  const int row = (cur >= 0 && cur < n && g_fighters[cur].side == other)
      ? g_fighters[cur].row : 0;
  // Never select a defeated fighter just because the right stick was moved.
  for (int step = 1; step <= count; ++step) {
    const int next = FighterAt(other, (row + dir * step + count * 4) % count, n);
    if (next >= 0 && FfaAlive(next)) {
      g_target[fighter].store(next, std::memory_order_relaxed);
      Log("Lock-on: J%d agora mira J%d (vivo)", fighter + 1, next + 1);
      return;
    }
  }
}

bool PromoteHudSnapshot(HudFighter out[6], int* p1Target) {
  if (!PromoteBattleActive() || !out || !p1Target) return false;
  AcquireSRWLockShared(&g_hudLock);
  for (int k = 0; k < 6; ++k) out[k] = g_hud[k];
  ReleaseSRWLockShared(&g_hudLock);
  *p1Target = PromoteTargetOf(CameraFighter());
  return true;
}

void PromoteReport() {
  // Diagnostic only: never force-reset fighters or mutate state on a suspected softlock.
  // The heartbeat is updated from the game's own battle judge thread.
  static uint64_t previousFrame = 0;
  static uint64_t previousBattle = 0;
  static bool warned = false;
  const uint64_t frames = g_judgeFrameCount.load(std::memory_order_relaxed);
  const uint64_t battle = g_battleId;
  const uint64_t last = g_lastJudgeTick.load(std::memory_order_relaxed);
  const uint64_t now = GetTickCount64();
  if (battle != previousBattle) { warned = false; previousBattle = battle; }
  const bool suspect = g_numFighters.load(std::memory_order_relaxed) >= 2 &&
                       last > 0 && now > last + 2500;
  if (suspect && !warned) {
    Log("COMBAT WATCHDOG: judge stalled for %llu ms, fighters=%d, frames=%llu (previous=%llu). Possible softlock.",
        static_cast<unsigned long long>(now - last), g_numFighters.load(),
        static_cast<unsigned long long>(frames), static_cast<unsigned long long>(previousFrame));
    warned = true;
  }
  if (!suspect) warned = false;
  previousFrame = frames;
  if (PromoteBattleActive()) {
    int n = g_numFighters.load();
    char line[640];
    int len = std::snprintf(line, sizeof(line), "Piso: %llu resgates. Posicoes x/y/z:",
                            static_cast<unsigned long long>(g_floorRecoveries.load()));
    for (int k = 0; k < n && len < 560; ++k)
      len += std::snprintf(line + len, sizeof(line) - len, "  J%d(%.0f,%.0f,%.0f e%X c%d a%d)",
                           g_fighters[k].side * 3 + g_fighters[k].row + 1, g_pos[k][0], g_pos[k][1], g_pos[k][2],
                           SafeReadInt(g_fighters[k].player, 0xCC0), SafeReadInt(g_fighters[k].player, kOnFieldFlag),
                           PromoteTargetOf(k) >= 0 ? g_fighters[PromoteTargetOf(k)].side * 3 + g_fighters[PromoteTargetOf(k)].row + 1 : 0);
    Log("%s", line);
    // Ordem e papel nativo (no+0x20) de cada membro na lista do time: mostra se um Supremo trocou o lider.
    __try {
      for (int side = 0; side < 2; ++side) {
        if (!g_team[side]) continue;
        char order[160];
        int olen = std::snprintf(order, sizeof(order), "Time %d (lista nativa):", side);
        ForEachNode(g_team[side], [&](uintptr_t node) {
          const uintptr_t player = *reinterpret_cast<uintptr_t*>(node + 0x30);
          const int k = PromoteFighterByPlayer(player);
          if (olen < 140)
            olen += std::snprintf(order + olen, sizeof(order) - olen, " J%d=papel%d",
                                  k >= 0 ? g_fighters[k].side * 3 + g_fighters[k].row + 1 : 0,
                                  *reinterpret_cast<const int*>(node + 0x20));
        });
        Log("%s", order);
      }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
    for (int k = 0; k < 6; ++k) {
      const HudFighter& h = g_hud[k];
      if (h.valid)
        Log("HUD L%d: %.1f %.1f | %.1f %.1f | %.1f %.1f", k + 1, h.v[0], h.v[1], h.v[2], h.v[3],
            h.v[4], h.v[5]);
    }
  }
  if (g_numFighters.load())
    Log("Contexto: %llu buscas de papel 0; 'eu'=%llu, 'meu alvo'=%llu, camera/interface=%llu, cena=%llu",
        static_cast<unsigned long long>(g_ctxQueries.load()),
        static_cast<unsigned long long>(g_ctxOverrides.load()),
        static_cast<unsigned long long>(g_ctxTargets.load()),
        static_cast<unsigned long long>(g_ctxCamera.load()),
        static_cast<unsigned long long>(g_ctxScene.load()));
  uintptr_t duel = *reinterpret_cast<uintptr_t*>(g_base + Addr().duelGlobal);
  if (!duel) return;
  for (int side = 0; side < 2; ++side) {
    uintptr_t team = duel + kTeamOffset + side * kTeamStride;
    __try {
      int n = 0;
      char line[512];
      int len = std::snprintf(line, sizeof(line), "Time %d:", side);
      ForEachNode(team, [&](uintptr_t node) {
        uintptr_t player = *reinterpret_cast<uintptr_t*>(node + 0x30);
        int key = *reinterpret_cast<int*>(node + 0x20);
        int onField = player ? *reinterpret_cast<int*>(player + kOnFieldFlag) : -1;
        if (len < 440)
          len += std::snprintf(line + len, sizeof(line) - len, "  [chave=%d lutador=%p em_campo=%d]", key,
                           reinterpret_cast<void*>(player), onField);
        ++n;
      });
      if (n) Log("%s", line);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("Time %d: leitura falhou (mapa mudando?)", side);
    }
  }
}


int PromoteFfaWinner() {
  if (!Cfg().freeForAll.load(std::memory_order_relaxed)) return -1;
  const int winner = g_ffaWinnerSlot.load(std::memory_order_relaxed);
  if (winner < 0 || winner >= 6) return -1;
  const ULONGLONG until = g_ffaWinnerUntil.load(std::memory_order_relaxed);
  return PromoteBattleActive() || (until && GetTickCount64() < until) ? winner : -1;
}

bool PromoteFfaEliminationSnapshot(unsigned* roster, unsigned* eliminated) {
  if (!roster || !eliminated || !Cfg().freeForAll.load(std::memory_order_relaxed) ||
      !PromoteBattleActive()) return false;
  *roster = g_ffaRosterBits.load(std::memory_order_acquire);
  *eliminated = g_ffaKnockedOutBits.load(std::memory_order_relaxed);
  return *roster != 0;
}

void PromoteForeignJudgeTick() {
  // So quando o juiz normal nao rodou nos ultimos 200 ms.
  if (GetTickCount64() - g_lastNativeJudgeTick.load(std::memory_order_relaxed) < 200) return;
  JudgeWork(*reinterpret_cast<uintptr_t*>(g_base + Addr().duelGlobal));
}

// ---------------------------------------------------------------- acesso para o balanceamento do Chronicles
bool PromoteFighterVitals(int k, float* life, float* lifeMax, int* side, int* row) {
  if (k < 0 || k >= g_numFighters.load(std::memory_order_acquire)) return false;
  const Fighter& f = g_fighters[k];
  if (!f.node) return false;
  const float* gauges = reinterpret_cast<const float*>(f.node + kMemberGauges);
  *life = gauges[0];
  *lifeMax = gauges[1];
  *side = f.side;
  *row = f.row;
  return std::isfinite(*life) && std::isfinite(*lifeMax);
}

bool PromoteSideLife(int side, float* totalLife, int* members) {
  *totalLife = 0;
  *members = 0;
  if (side < 0 || side > 1) return false;
  const uintptr_t duel = *reinterpret_cast<uintptr_t*>(g_base + Addr().duelGlobal);
  if (!duel) return false;
  __try {
    ForEachNode(duel + kTeamOffset + side * kTeamStride, [&](uintptr_t node) {
      if (!*reinterpret_cast<uintptr_t*>(node + 0x30)) return;
      const float life = *reinterpret_cast<const float*>(node + kMemberGauges);
      if (std::isfinite(life)) {
        *totalLife += life > 0 ? life : 0;
        ++*members;
      }
    });
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
  return *members > 0;
}

void PromoteSetFighterLife(int k, float life) {
  if (k < 0 || k >= g_numFighters.load(std::memory_order_acquire) || !g_fighters[k].node) return;
  *reinterpret_cast<float*>(g_fighters[k].node + kMemberGauges) = life;
}

bool PromoteRequestAwakening(int k) {
  if (k < 0 || k >= g_numFighters.load(std::memory_order_acquire)) return false;
  const Fighter& f = g_fighters[k];
  if (!f.player) return false;
  const auto vtable = *reinterpret_cast<uintptr_t* const*>(f.player);
  if (!vtable || !vtable[Addr().vtChangeState / sizeof(uintptr_t)]) return false;
  reinterpret_cast<void (*)(uintptr_t, int)>(vtable[Addr().vtChangeState / sizeof(uintptr_t)])(f.player, kAwakeBeginState);
  return true;
}
