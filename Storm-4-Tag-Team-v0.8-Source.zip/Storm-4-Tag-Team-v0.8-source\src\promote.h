#pragma once
#include <cstdint>

// Fase 1: cria os papeis 1 e 2 (suportes) como papel 0 (em campo).
// So age se existir storm6_3v3.txt na pasta do jogo.
bool PromoteInstall();
// Grava no log o estado dos lutadores da batalha atual (thread do mod, so leitura).
void PromoteReport();
// Chamado pelo hook da busca central quando nao achou ninguem com o papel pedido.
// Durante a montagem da batalha, devolve o extra que ocupa aquele papel (chave do mapa),
// para que a montagem registre os extras. Retorna nullptr fora da montagem.
void** PromoteAnswer(void* team, int role, uint32_t site);
// Regra "meu lado -> eu": para buscas de papel 0 durante a luta, procura na pilha
// (a partir de `stack`) um dos lutadores da batalha; se ele for do lado pedido,
// devolve o no dele. Retorna nullptr para manter a resposta original.
void** PromoteContext(void* team, int role, const uintptr_t* stack, uint32_t site);
// A luta existe mesmo se o juiz parar de rodar durante uma pausa.
bool PromoteBattlePresent();
bool PromoteReservesRightStick();
// Verdadeiro durante uma luta 3v3 em andamento (juiz rodando).
bool PromoteBattleActive();
int PromotePadForPlayer(uintptr_t player);
int PromoteFighterForPad(int pad);
// Troca o alvo do lutador (0-5) entre os 3 adversarios: dir = +1 direita, -1 esquerda.
void PromoteCycleTarget(int fighter, int dir);
// For camera REVOLUTION + style REVOLUTION: R3 toggles visible targeting,
// right stick selects an alive opponent in the indicated screen direction.
void PromoteToggleRevolutionLock(int fighter);
void PromoteDirectionalRevolutionTarget(int fighter, float stickX, float stickY);

// Valores do registro de cada membro no time (no do mapa + 0x28 + 0x10..0x24), copiados na
// thread do jogo a cada quadro. Lidos pelo HUD em pares: (v0,v1) (v2,v3) (v4,v5).
struct HudFighter {
  float v[6];
  int valid;
  int side;  // 0 = equipe 1 (esquerda), 1 = equipe 2 (direita)
  int row;   // posicao na equipe (0..2)
  char portrait[24];
};
// Copia o ultimo retrato. Retorna false fora da luta 3v3. p1Target = indice (0-5) do alvo do P1.
bool PromoteHudSnapshot(HudFighter out[6], int* p1Target);

// Indice (0-5) do primeiro lutador da batalha encontrado na pilha a partir de `stack`, ou -1.
int PromoteFighterOnStack(const uintptr_t* stack);
// Indice do lutador com este ponteiro de objeto, ou -1.
int PromoteFighterByPlayer(uintptr_t player);
// Alvo atual do lutador (indice) ou -1.
int PromoteTargetOf(int fighter);
// Aponta o alvo do lutador (o "meu adversario" que o mod responde ao jogo). Usado no golpe final da disputa de jutsus
// para o jutsu do vencedor perseguir o perdedor, e nao outro adversario do 3v3.
void PromoteSetTarget(int fighter, int target);
// Alvo do jogador `pad` (0-3), com vaga fixa (0-5) e identificador da batalha.
struct LockMarker {
  int pad;
  int targetSlot;
  uint64_t battleId;
  float position[3];
};
// Copia os marcadores do ultimo quadro do jogo e retorna quantos sao.
int PromoteLockMarkers(LockMarker out[4]);
// Lado (0/1) do lutador ou -1.
int PromoteFighterSide(int fighter);
// Native perfect guard: roster lookup + conservative attacker disambiguation.
int PromoteFighterCount();
uintptr_t PromoteFighterPlayer(int fighter);
int PromoteParryAttacker(int defender,uint64_t now);
// Consultas da tecnica de equipe feitas na thread do combate.
int PromoteFullChakraAlly(int owner);
// Called once after the native team-ultimate attack scene is confirmed.
bool PromoteTeamSpendChakra75(int owner, int ally);
void** PromoteFighterMember(void* team, int fighter);
int PromoteTeamHitVictim(int owner);
void PromoteTeamAllyPosition(int ally, float position[3]);
void PromoteReturnTeamAlly(int ally, const float position[3]);
// Only on battle judge thread: enter Evolution's native team-ultimate start state.
bool PromoteStartTeamUltimate(int owner);
int PromoteFfaWinner(); // J1..J6 winner slot index (0..5), or -1
bool PromoteFfaEliminationSnapshot(unsigned* roster, unsigned* eliminated);
// Lutas que nao passam pelo juiz normal (carregador da historia, Chronicles): roda o trabalho do mod.
void PromoteForeignJudgeTick();
// Balanceamento do Chronicles: vida (0..100) de cada lutador da batalha atual, por indice 0..count-1.
bool PromoteFighterVitals(int fighter, float* life, float* lifeMax, int* side, int* row);
void PromoteSetFighterLife(int fighter, float life);
// Soma da vida (0..100 por membro) e numero de membros do lado, lidos da lista nativa do duelo.
bool PromoteSideLife(int side, float* totalLife, int* members);
// Pede o despertar nativo (estado 0x7C) ao lutador. Falso se nao foi possivel.
bool PromoteRequestAwakening(int fighter);
