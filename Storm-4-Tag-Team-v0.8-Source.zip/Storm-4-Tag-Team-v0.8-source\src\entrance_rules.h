#pragma once
#include <algorithm>
#include <cmath>
// Choreography of Storm 4 native character entry actions.
// Both teams enter the same support rank together, avoiding asymmetric starts.
constexpr int kEntranceWaveGapFrames = 12;
inline bool EntranceShouldAdvance(int currentWave, int framesSinceFirst,
                                  bool nativeSceneActive) {
  return currentWave == 1 && framesSinceFirst >= kEntranceWaveGapFrames &&
         !nativeSceneActive;
}
inline float EntranceCameraBlend(float remainingMilliseconds) {
  if(!std::isfinite(remainingMilliseconds) || remainingMilliseconds <= 0) return 0;
  return 0.24f*std::clamp(remainingMilliseconds/900.0f,0.0f,1.0f);
}
