// Storm 6 - lutadores simultaneos para Naruto Storm 4 (NSUNS4.exe 1.09).
// Fase atual: censo das buscas de membros (so observa, nao muda a partida).

#include <windows.h>
#include <MinHook.h>

#include <cstdarg>
#include <cstdio>
#include <mutex>
#include <share.h>
#include <string>

#include "census.h"
#include "chronicles.h"
#include "scene_probe.h"
#include "cpu_adapt.h"
#include "parry.h"
#include "grab_defense.h"
#include "perfect_sub.h"
#include "jutsu_clash.h"
#include "dual_combo.h"
#include "wall_run.h"
#include "hud.h"
#include "input.h"
#include "ult.h"
#include "camera.h"
#include "addresses.h"
#include "log.h"
#include "promote.h"
#include "settings.h"
#include "proxy/proxy.h"

namespace {
HMODULE g_self = nullptr;
FILE* g_log = nullptr;
std::mutex g_logMutex;

}  // namespace

std::wstring ModDir() {
  wchar_t path[MAX_PATH]{};
  GetModuleFileNameW(g_self, path, MAX_PATH);
  std::wstring s(path);
  return s.substr(0, s.find_last_of(L"\\/") + 1);
}

void Log(const char* fmt, ...) {
  std::lock_guard<std::mutex> lock(g_logMutex);
  if (!g_log) return;
  SYSTEMTIME t;
  GetLocalTime(&t);
  std::fprintf(g_log, "[%02d:%02d:%02d.%03d] [T%05lu] ", t.wHour, t.wMinute, t.wSecond,
               t.wMilliseconds, GetCurrentThreadId());
  va_list args;
  va_start(args, fmt);
  std::vfprintf(g_log, fmt, args);
  va_end(args);
  std::fputc('\n', g_log);
  std::fflush(g_log);
}

namespace {

DWORD WINAPI MainThread(LPVOID) {
  g_log = _wfsopen((ModDir() + L"storm6.log").c_str(), L"w", _SH_DENYNO);
  Log("=== Storm 6 carregado (fase 1: 3v3 em campo + censo) ===");

  g_base = reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
  auto dos = reinterpret_cast<IMAGE_DOS_HEADER*>(g_base);
  auto nt = reinterpret_cast<IMAGE_NT_HEADERS*>(g_base + dos->e_lfanew);
  wchar_t exe[MAX_PATH]{};
  GetModuleFileNameW(nullptr, exe, MAX_PATH);
  Log("Processo: %ls  base=%p  TimeDateStamp=0x%08lX", exe, reinterpret_cast<void*>(g_base),
      nt->FileHeader.TimeDateStamp);
  if (!AddrSelect(nt->FileHeader.TimeDateStamp)) {
    Log("Versao desconhecida (conhecidas: 1.09 0x5EF2F684, Evolution 0x5889906E): nenhum hook instalado.");
    return 0;
  }
  Log("Versao reconhecida: %s", Addr().name);
  if (MH_Initialize() != MH_OK) {
    Log("MH_Initialize falhou");
    return 0;
  }
  SettingsLoad();
  CpuAdaptInstall();
  ParryInstall();
  GrabDefenseInstall();
  PerfectSubInstall();
  JutsuClashInstall();
  DualComboInstall();
  WallRunInstall();
  SceneProbeInstall();
  ChroniclesInstall(); // 0.8 Native mode selector scene probe; no GFX patch.
  const bool census = CensusInstall();
  InputInstallBattle();
  if (census) PromoteInstall();
  CameraInstall();
  HudInstall();
  UltInstall();

  bool inputHooked = false;
  for (unsigned tick = 1;; ++tick) {
    for (int i = 0; i < 50 && !inputHooked; ++i) {  // espera o XInput carregar
      inputHooked = InputTryInstall();
      if (!inputHooked) Sleep(100);
    }
    if (inputHooked) Sleep(5000);
    PromoteReport();
    UltReport();
    if (tick % 2 == 0) CensusDump();
  }
}

}  // namespace

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
  if (reason == DLL_PROCESS_ATTACH) {
    g_self = module;
    DisableThreadLibraryCalls(module);
    if (!ProxyInit()) return FALSE;
    HANDLE t = CreateThread(nullptr, 0, MainThread, nullptr, 0, nullptr);
    if (t) CloseHandle(t);
  }
  return TRUE;
}
