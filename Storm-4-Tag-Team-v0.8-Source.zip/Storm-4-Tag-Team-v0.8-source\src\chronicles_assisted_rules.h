#pragma once
// Read-only verification for an assisted Chronicles match launched by the
// PLAYER through native Free Battle. No engine IDs or fabricated addresses.
// A mission is not credited unless *every* fighter portrait has a validated
// prefix and both side/slot positions match the declared story roster.
#include "chronicles_classic_fighters.h"
#include <cstring>

namespace chronicles_assisted {
struct ObservedFighter {
  int side;
  int row;
  const char* faceCode;
};
inline bool SupportsVerification(int mission) {
  const auto* r=chronicles_classic::Roster(mission);
  if(!r || !chronicles_classic::ValidRoster(mission))return false;
  for(int side=0;side<2;++side) {
    const auto& team=side==0?r->allies:r->enemies;
    for(int slot=0;slot<team.count;++slot) {
      const auto* info=chronicles_classic::Info(team.members[slot]);
      if(!info || !info->portraitHint[0])return false;
    }
  }
  return true;
}
inline bool MatchRoster(int mission,const ObservedFighter* fighters,int count){
  const auto* r=chronicles_classic::Roster(mission);
  if(!r || !fighters || !SupportsVerification(mission))return false;
  if(count!=r->allies.count+r->enemies.count)return false;
  bool seen[2][3]{};
  for(int i=0;i<count;++i) {
    const auto& f=fighters[i];
    if(f.side<0||f.side>1||f.row<0||f.row>2||!f.faceCode)return false;
    const auto& team=f.side==0?r->allies:r->enemies;
    if(f.row>=team.count||seen[f.side][f.row])return false;
    const auto* info=chronicles_classic::Info(team.members[f.row]);
    if(!info || !info->portraitHint[0])return false;
    const size_t n=std::strlen(info->portraitHint);
    if(std::strncmp(f.faceCode,info->portraitHint,n)!=0)return false;
    seen[f.side][f.row]=true;
  }
  for(int side=0;side<2;++side){
    const auto& team=side==0?r->allies:r->enemies;
    for(int row=0;row<team.count;++row)
      if(!seen[side][row])return false;
  }
  return true;
}
inline bool NativeResultIsWin(int result){return result==2;}
inline bool NativeResultIsLoss(int result){return result==3;}
} // namespace chronicles_assisted
