#pragma once
// Instala o HUD de 6 paineis (hook de IDXGISwapChain::Present do Direct3D 11).
bool HudInstall();
// Aspect ratio from current swap-chain backbuffer. Safe for the input/judge
// thread; falls back to 16:9 before the first HUD present.
float HudAspectRatio();
