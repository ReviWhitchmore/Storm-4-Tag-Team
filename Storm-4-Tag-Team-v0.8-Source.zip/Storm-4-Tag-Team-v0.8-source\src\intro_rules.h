#pragma once
#include <algorithm>
#include <cmath>

// An ornamental six-fighter intro displayed while the native round is
// preparing; it never modifies animation or battle state.
struct IntroTimeline {
  bool visible = false;
  float opacity = 0.0f;
  float slide = 0.0f;
};
inline IntroTimeline IntroTransition(int frame, int total=180) {
  IntroTimeline out{};
  if(total<36 || frame<9 || frame>=total-12) return out;
  out.visible=true;
  out.opacity=std::clamp((frame-9)/20.0f,0.0f,1.0f)*
              std::clamp((total-frame-12)/30.0f,0.0f,1.0f);
  out.slide=(1.0f-out.opacity)*28.0f;
  return out;
}
