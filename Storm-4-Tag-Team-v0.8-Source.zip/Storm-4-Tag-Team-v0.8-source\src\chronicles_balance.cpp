// Vida e dano do Chronicles. O jogo guarda a vida de cada lutador em porcentagem (0..100, no+0x38 do membro),
// entao "mais vida" vira "recebe menos dano": a cada quadro, a queda de vida desde o quadro anterior e
// multiplicada por (dano do lado atacante) / (vida do lado que apanha). A barra continua certa em %.
// So vale na luta aberta pelo Chronicles; nada muda no Combate Livre nem na historia original.
#include "chronicles_balance.h"

#include <windows.h>

#include <algorithm>
#include <cmath>

#include "chronicles_classic_bosses.h"
#include "chronicles_classic_fighters.h"
#include "log.h"
#include "promote.h"

namespace {

struct SideRule {
  float health;  // multiplicador de vida
  float damage;  // multiplicador do dano que esse lado causa
};

// Valores iniciais do plano (aliados x inimigos). Lado 0 = aliados, lado 1 = inimigos.
void RulesFor(int allies, int enemies, SideRule rules[2]) {
  rules[0] = {1.0f, 1.0f};
  rules[1] = {1.0f, 1.0f};
  if (allies == 1 && enemies == 2) { rules[0] = {1.20f, 1.0f}; rules[1] = {0.75f, 1.0f}; }
  else if (allies == 1 && enemies == 3) { rules[0] = {1.50f, 1.0f}; rules[1] = {0.60f, 0.90f}; }
  else if (allies == 2 && enemies == 1) { rules[1] = {1.75f, 1.15f}; }
  else if (allies == 3 && enemies == 1) { rules[1] = {2.30f, 1.30f}; }
  else if (allies == 3 && enemies == 2) { rules[1] = {1.40f, 1.10f}; }
  else if (allies == 2 && enemies == 3) { rules[1] = {0.85f, 1.0f}; }
}

int g_mission = -1;
SideRule g_rules[2];
float g_previous[6];
bool g_known[6];
int g_bossPhase = 1;
const chronicles_classic::BossEncounter* g_boss = nullptr;
// Cada fase nova do chefe deixa os golpes dele 10% mais fortes (agressividade).
constexpr float kPhaseDamageStep = 0.10f;

float SideDamage(int side) {
  float damage = g_rules[side].damage;
  if (side == 1 && g_boss) damage *= 1.0f + kPhaseDamageStep * (g_bossPhase - 1);
  return damage;
}

void CheckBossPhase(int k, float life, float lifeMax) {
  if (!g_boss || lifeMax <= 0) return;
  const int percent = static_cast<int>(life * 100.0f / lifeMax + 0.5f);
  const int phase = chronicles_classic::PlannedBossPhase(*g_boss, percent);
  if (phase <= g_bossPhase) return;
  g_bossPhase = phase;
  Log("Chronicles: %s entrou na %s (vida %d%%)", g_boss->name, chronicles_classic::BossPhaseLabel(*g_boss, phase),
      percent);
  // Transformacao: so com a forma que o jogo ja tem (despertar nativo do proprio lutador).
  if (g_boss->requiresSpecialForm && phase == 2)
    Log("Chronicles: despertar do chefe %s", PromoteRequestAwakening(k) ? "pedido" : "indisponivel");
}

}  // namespace

void ChroniclesBalanceBegin(int mission) {
  g_mission = mission;
  const auto* roster = chronicles_classic::Roster(mission);
  if (!roster) {
    g_mission = -1;
    return;
  }
  RulesFor(roster->allies.count, roster->enemies.count, g_rules);
  g_boss = chronicles_classic::BossForMission(mission);
  g_bossPhase = 1;
  std::fill(std::begin(g_known), std::end(g_known), false);
  Log("Chronicles: balanceamento %dv%d: aliados vida %.0f%% dano %.0f%%, inimigos vida %.0f%% dano %.0f%%%s",
      roster->allies.count, roster->enemies.count, g_rules[0].health * 100, g_rules[0].damage * 100,
      g_rules[1].health * 100, g_rules[1].damage * 100, g_boss ? " (chefe)" : "");
}

void ChroniclesBalanceEnd() {
  g_mission = -1;
  g_boss = nullptr;
}

void ChroniclesBalanceTick() {
  if (g_mission < 0) return;
  const int count = std::min(PromoteFighterCount(), 6);
  for (int k = 0; k < count; ++k) {
    float life, lifeMax;
    int side, row;
    if (!PromoteFighterVitals(k, &life, &lifeMax, &side, &row) || side < 0 || side > 1) continue;
    if (!g_known[k]) {
      g_known[k] = true;
      g_previous[k] = life;
      continue;
    }
    const float before = g_previous[k];
    if (life < before && life > 0.0f) {
      // Dano recebido neste quadro, ajustado pelo lado que bateu e pela vida de quem apanhou.
      const float scale = SideDamage(1 - side) / g_rules[side].health;
      float adjusted = before - (before - life) * scale;
      adjusted = std::clamp(adjusted, 0.01f, lifeMax);
      if (std::fabs(adjusted - life) > 0.001f) {
        PromoteSetFighterLife(k, adjusted);
        life = adjusted;
      }
    }
    g_previous[k] = life;
    if (side == 1 && row == 0) CheckBossPhase(k, life, lifeMax);
  }
}