#pragma once
#include <string>

// Pasta onde esta a DLL (a pasta do jogo), terminando em barra.
std::wstring ModDir();
// Grava uma linha com horario e thread em storm6.log (pode ser lido com o jogo aberto).
void Log(const char* fmt, ...);
