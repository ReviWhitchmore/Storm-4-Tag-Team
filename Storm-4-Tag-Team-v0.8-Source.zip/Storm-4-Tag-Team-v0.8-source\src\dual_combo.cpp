#include "dual_combo.h"

#include <windows.h>

#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

#include "addresses.h"
#include "census.h"
#include "cpu_adapt.h"
#include "settings.h"
#include "fighter_motion.h"
#include "input.h"
#include "jutsu_clash.h"
#include "jutsu_clash_3d.h"
#include "log.h"
#include "wall_run.h"
#include "promote.h"

namespace {
std::atomic<bool> g_enabled{false};
std::atomic<bool> g_test{false};
std::atomic<unsigned> g_cpuChance{60};      // % por combo (aliado da CPU)
std::atomic<unsigned> g_cooldownMs{6000};   // por time
std::atomic<unsigned> g_rangeMax{1600};     // aliado ate esta distancia do alvo
uint64_t g_battleAt = 0;
uint32_t g_rng = 0x2545F491u;
uint32_t NextRandom() {
  g_rng ^= g_rng << 13;
  g_rng ^= g_rng >> 17;
  g_rng ^= g_rng << 5;
  return g_rng;
}

// ---- mecanica: estado por lutador e por time
constexpr int kJoinAction = 0xE1;  // PL_ACT_SUP_COMBO_JOIN: o aliado avanca e da o golpe de entrada (S_ATK_INT00/01)
struct Join {
  bool active = false;
  int primary = -1, ally = -1, enemy = -1;
  uint64_t at = 0;
  bool hit = false;
  float enemyLife = 0;
  uint64_t traceNext = 0;
};
Join g_join[2];                  // um combo em dupla por time de cada vez
uint64_t g_cooldownUntil[2]{};
bool g_busy[6]{};                // aliado ja em um combo em dupla
uint64_t g_exitGuardUntil[6]{};  // depois da entrada: o aliado NAO pode fazer a saida de apoio (PL_ACT_SUP_EXIT)
int g_comboRolled[6]{};          // ultimo combo (id) do lutador ja sorteado para a CPU
int g_comboId[6]{};              // conta inicios de combo de cada lutador
int g_prevState[6]{-1, -1, -1, -1, -1, -1};
bool g_bHeld[4]{};
bool g_bPressed[4]{};            // borda de B/Bolinha neste quadro (leitor do jogo)

bool Attacking(int s) { return s == 0x3F || s == 0x40; }
bool ComboHit(int anm) { return (anm >= 192 && anm <= 223) || (anm >= 237 && anm <= 246); }  // ATK01..32, ATK_AIR01..10
bool JoinState(int s) { return s == kJoinAction || s == 0xD9 || s == 0xDA; }

// ---- modo de investigacao: qual acao nativa faz o aliado entrar no combo
constexpr int kJoinCandidates[] = {0xE1, 0xD9, 0x13C};  // SUP_COMBO_JOIN, SUP_FOLLOWATK_BEGIN, GRP_FOLLOW_ATK
struct Probe {
  int stage = 0;  // 0 livre, 1 montado (esperando o combo), 2 aliado mandado
  uint64_t at = 0, next = 0, traceUntil = 0, traceNext = 0;
  int a = -1, ally = -1, enemy = -1;
  int attempt = 0;
  int join = 0;
};
Probe g_probe;

bool Free(int s) { return s == 0x1 || (s >= 0xA && s <= 0x17); }
bool Hurt(int s) { return s >= 0x18 && s <= 0x3C; }

void Trace(const GrabFighterView* f, uint64_t now) {
  auto one = [&](int k, char* out, size_t size) {
    float life = 0, lifeMax = 0;
    int side = -1, row = -1;
    PromoteFighterVitals(k, &life, &lifeMax, &side, &row);
    std::snprintf(out, size, "J%d est 0x%X anm %d pos (%.0f,%.0f,%.0f) vida %.0f", f[k].number,
                  fighter::State(f[k].player), fighter::Anm(f[k].player), f[k].pos[0], f[k].pos[1], f[k].pos[2], life);
  };
  char a[160], b[160], c[160];
  one(g_probe.a, a, sizeof(a));
  one(g_probe.ally, b, sizeof(b));
  one(g_probe.enemy, c, sizeof(c));
  Log("COMBO DUPLA TRACE +%llums: %s | ALIADO %s | INIMIGO %s",
      static_cast<unsigned long long>(now - g_probe.at), a, b, c);
}

void ProbeTick(const GrabFighterView* f, int n, bool scene, uint64_t now) {
  if (g_probe.traceUntil && now < g_probe.traceUntil && now >= g_probe.traceNext) {
    g_probe.traceNext = now + 80;
    Trace(f, now);
  }
  if (g_probe.stage == 0) {
    if (scene || !g_battleAt || now - g_battleAt < 10000 || now < g_probe.next) return;  // depois da entrada dos lutadores
    int a = -1, ally = -1, enemy = -1;
    for (int k = 0; k < n; ++k)
      if (f[k].valid && f[k].side == 0 && Free(f[k].state)) { a = k; break; }
    for (int k = 0; a >= 0 && k < n; ++k)
      if (k != a && f[k].valid && f[k].side == 0 && Free(f[k].state)) { ally = k; break; }
    float best = 1e9f;
    for (int k = 0; a >= 0 && k < n; ++k) {
      if (!f[k].valid || f[k].side != 1 || !Free(f[k].state)) continue;
      const float d = fighter::Distance2D(f[k].pos, f[a].pos);
      if (d < best) { best = d; enemy = k; }
    }
    if (a < 0 || ally < 0 || enemy < 0) return;
    // Montagem SO do teste: inimigo a 140 na frente do J1 (para o combo pegar), aliado a 300 atras e de lado.
    float dx = f[enemy].pos[0] - f[a].pos[0], dy = f[enemy].pos[1] - f[a].pos[1];
    const float len = std::sqrt(dx * dx + dy * dy);
    if (len > 1) { dx /= len; dy /= len; } else { dx = 1; dy = 0; }
    const float pe[3] = {f[a].pos[0] + dx * 140, f[a].pos[1] + dy * 140, f[a].pos[2]};
    const float pa[3] = {f[a].pos[0] - dx * 150 - dy * 260, f[a].pos[1] - dy * 150 + dx * 260, f[a].pos[2]};
    fighter::SetPos(f[enemy].player, pe);
    fighter::SetPos(f[ally].player, pa);
    fighter::FaceToward(f[a].player, pe[0], pe[1]);
    fighter::FaceToward(f[enemy].player, f[a].pos[0], f[a].pos[1]);
    clash3d::SetActionNow(f[enemy].player, 0x1);  // parado na frente (so no teste)
    clash3d::SetActionNow(f[a].player, 0x3F);     // o J1 ja comeca o combo; o controle 1 do teste segue apertando B
    PromoteSetTarget(a, enemy);
    PromoteSetTarget(ally, enemy);
    g_probe.a = a;
    g_probe.ally = ally;
    g_probe.enemy = enemy;
    g_probe.join = kJoinCandidates[g_probe.attempt % 3];
    ++g_probe.attempt;
    g_probe.stage = 1;
    g_probe.at = now;
    g_probe.traceUntil = now + 4000;
    g_probe.traceNext = now;
    Log("COMBO DUPLA TESTE #%d: J%d combina em J%d; aliado J%d vai entrar com a acao 0x%X.", g_probe.attempt,
        f[a].number, f[enemy].number, f[ally].number, g_probe.join);
    return;
  }
  if (g_probe.stage == 1) {
    // Com a mecanica ligada, quem decide a entrada e o mecanismo real (TryJoin); se ele nao fizer em 2,5 s, o TESTE
    // faz a entrada (registrado como forcado) para a demonstracao.
    if (g_enabled.load(std::memory_order_relaxed)) {
      const int side = f[g_probe.a].side;
      if (side >= 0 && side <= 1 && g_join[side].active) {
        Log("COMBO DUPLA TESTE #%d: o mecanismo real fez a entrada.", g_probe.attempt);
        g_probe.stage = 2;
        return;
      }
      if (now - g_probe.at < 2500) return;
      fighter::FaceToward(f[g_probe.ally].player, f[g_probe.enemy].pos[0], f[g_probe.enemy].pos[1]);
      PromoteSetTarget(g_probe.ally, g_probe.enemy);
      const bool ok = clash3d::SetActionNow(f[g_probe.ally].player, 0xE1);
      Log("COMBO DUPLA TESTE #%d: entrada FORCADA pelo teste (aliado J%d 0xE1 %s; J%d 0x%X, alvo 0x%X).",
          g_probe.attempt, f[g_probe.ally].number, ok ? "ok" : "falhou", f[g_probe.a].number,
          fighter::State(f[g_probe.a].player), fighter::State(f[g_probe.enemy].player));
      g_probe.stage = 2;
      return;
    }
    // Investigacao (mecanica desligada): espera o combo e manda o aliado para a acao candidata.
    const int sa = fighter::State(f[g_probe.a].player), se = fighter::State(f[g_probe.enemy].player);
    const bool comboing = (sa == 0x3F || sa == 0x40) && Hurt(se);
    if (comboing || now - g_probe.at > 2500) {
      fighter::FaceToward(f[g_probe.ally].player, f[g_probe.enemy].pos[0], f[g_probe.enemy].pos[1]);
      const bool ok = clash3d::SetActionNow(f[g_probe.ally].player, g_probe.join);
      Log("COMBO DUPLA TESTE #%d: aliado J%d mandado para 0x%X (%s; J%d 0x%X, inimigo 0x%X).", g_probe.attempt,
          f[g_probe.ally].number, g_probe.join, ok ? "ok" : "falhou", f[g_probe.a].number, sa, se);
      g_probe.stage = 2;
    }
    return;
  }
  if (g_probe.stage == 2 && now - g_probe.at > 4200) {
    g_probe.stage = 0;
    g_probe.next = now + 4000;
  }
}
}  // namespace

void DualComboInstall() {
  if (Addr().timestamp != 0x5889906E) {
    Log("COMBO DUPLA: so no Evolution verificado.");
    return;
  }
  bool enabled = false, test = false;
  const std::wstring file = ModDir() + L"storm6.ini";
  if (FILE* stream = _wfopen(file.c_str(), L"r")) {
    char line[128];
    while (std::fgets(line, sizeof(line), stream)) {
      char key[65]{};
      int value = 0;
      if (std::sscanf(line, "%64[^=]=%d", key, &value) != 2) continue;
      if (!std::strcmp(key, "combo_dupla")) enabled = value != 0;
      else if (!std::strcmp(key, "combo_dupla_teste")) test = value != 0;
      else if (!std::strcmp(key, "combo_dupla_cpu") && value >= 0 && value <= 100) g_cpuChance = unsigned(value);
      else if (!std::strcmp(key, "combo_dupla_recarga_ms") && value >= 1000 && value <= 60000) g_cooldownMs = unsigned(value);
      else if (!std::strcmp(key, "combo_dupla_alcance") && value >= 300 && value <= 4000) g_rangeMax = unsigned(value);
    }
    std::fclose(stream);
  }
  g_enabled = enabled;
  g_test = test;
  Log("COMBO DUPLA: %s; CPU %u%% por combo, recarga %u ms por time, alcance %u%s.",
      enabled ? "ATIVO (experimental)" : "desligado (storm6.ini combo_dupla=1)", g_cpuChance.load(), g_cooldownMs.load(),
      g_rangeMax.load(), test ? "; TESTE de investigacao ligado" : "");
}

void DualComboBeginBattle() {
  g_battleAt = GetTickCount64();
  g_probe = {};
  g_join[0] = g_join[1] = {};
  g_cooldownUntil[0] = g_cooldownUntil[1] = 0;
  for (int k = 0; k < 6; ++k) {
    g_busy[k] = false;
    g_exitGuardUntil[k] = 0;
    g_comboRolled[k] = g_comboId[k] = 0;
    g_prevState[k] = -1;
  }
  g_rng ^= static_cast<uint32_t>(GetTickCount64());
  if (!g_rng) g_rng = 0x2545F491u;
}

void ReadButtons() {
  for (int p = 0; p < 4; ++p) {
    uint8_t pad[0x80];
    const bool on = InputPhysicalPad(p, pad);
    uint32_t held = 0;
    std::memcpy(&held, pad + 0x18, sizeof(held));
    const bool down = on && (held & 0x2000) != 0;  // B / Bolinha
    g_bPressed[p] = down && !g_bHeld[p];
    g_bHeld[p] = down;
  }
}

// No jogo original o apoio ataca e SAI do campo (PL_ACT_SUP_EXIT 0xD7 / 0xD8). No 3v3 do mod o aliado e um lutador:
// se ele comecar a sair, volta para o neutro (0x1) e continua na luta.
void GuardExit(const GrabFighterView* f, int n, uint64_t now) {
  for (int k = 0; k < n; ++k) {
    if (!g_exitGuardUntil[k] || now > g_exitGuardUntil[k] || !f[k].valid) continue;
    const int s = fighter::State(f[k].player);
    if (s == 0xD7 || s == 0xD8) {
      clash3d::SetActionNow(f[k].player, 0x1);
      Log("COMBO DUPLA: J%d ia sair do campo como apoio (0x%X); voltou ao combate.", f[k].number, s);
    }
  }
}

void FollowJoin(const GrabFighterView* f, int side, uint64_t now) {
  Join& j = g_join[side];
  if (!j.active) return;
  const int sa = fighter::State(f[j.ally].player), se = fighter::State(f[j.enemy].player);
  float life = 0, lifeMax = 0;
  int s2 = -1, row = -1;
  PromoteFighterVitals(j.enemy, &life, &lifeMax, &s2, &row);
  if (!j.hit && JoinState(sa) && Hurt(se) && life < j.enemyLife) {
    j.hit = true;
    Log("COMBO DUPLA: J%d acertou J%d junto com J%d (vida %.0f -> %.0f).", f[j.ally].number, f[j.enemy].number,
        f[j.primary].number, j.enemyLife, life);
  }
  if (now >= j.traceNext && now - j.at < 1600) {
    j.traceNext = now + 100;
    Log("COMBO DUPLA +%llums: J%d 0x%X anm %d | aliado J%d 0x%X anm %d | alvo J%d 0x%X vida %.0f",
        static_cast<unsigned long long>(now - j.at), f[j.primary].number, fighter::State(f[j.primary].player),
        fighter::Anm(f[j.primary].player), f[j.ally].number, sa, fighter::Anm(f[j.ally].player), f[j.enemy].number, se,
        life);
  }
  // Fim: o aliado saiu da acao de entrada (voltou ao combate normal) ou passou do limite de seguranca (3 s).
  if ((now - j.at > 250 && !JoinState(sa)) || now - j.at > 3000 || !f[j.ally].valid) {
    Log("COMBO DUPLA: J%d terminou a entrada (%s); de volta ao combate (estado 0x%X).", f[j.ally].number,
        j.hit ? "acertou" : "nao acertou", sa);
    if (sa == 0xD7 || sa == 0xD8) {
      clash3d::SetActionNow(f[j.ally].player, 0x1);
      Log("COMBO DUPLA: J%d ia sair do campo como apoio (0x%X); voltou ao combate.", f[j.ally].number, sa);
    }
    g_exitGuardUntil[j.ally] = now + 1500;
    g_busy[j.ally] = false;
    j = {};
  }
}

void TryJoin(const GrabFighterView* f, int n, int p, uint64_t now) {
  if (Cfg().freeForAll.load(std::memory_order_relaxed)) return; // FFA nao tem aliados
  const int side = f[p].side;
  if (side < 0 || side > 1 || g_join[side].active || now < g_cooldownUntil[side]) return;
  const int sp = f[p].state, anm = fighter::Anm(f[p].player);
  if (!Attacking(sp) || !ComboHit(anm)) return;
  const int enemy = PromoteTargetOf(p);
  {
    // DIAGNOSTICO: uma linha por combo, com o motivo de nao haver entrada.
    static int logged[6]{};
    static unsigned lines = 0;
    if (logged[p] != g_comboId[p] && lines < 60) {
      logged[p] = g_comboId[p];
      ++lines;
      int freeAllies = 0;
      for (int k = 0; k < n; ++k)
        if (k != p && f[k].valid && f[k].side == side && !g_busy[k] && Free(f[k].state)) ++freeAllies;
      Log("COMBO DUPLA DIAG: J%d combo anm %d; alvo %d estado 0x%X dist %.0f; aliados livres %d.", f[p].number, anm,
          enemy >= 0 && enemy < n ? f[enemy].number : -1, enemy >= 0 && enemy < n ? f[enemy].state : -1,
          enemy >= 0 && enemy < n ? fighter::Distance2D(f[p].pos, f[enemy].pos) : -1.0f, freeAllies);
    }
  }
  if (enemy < 0 || enemy >= n || !f[enemy].valid || f[enemy].side == side || !Hurt(f[enemy].state)) return;
  if (fighter::Distance2D(f[p].pos, f[enemy].pos) > 400.0f) return;
  int a = -1;
  float best = float(g_rangeMax.load(std::memory_order_relaxed));
  for (int k = 0; k < n; ++k) {
    if (k == p || !f[k].valid || f[k].side != side || g_busy[k] || !Free(f[k].state)) continue;
    if (JutsuClashProtects(f[k].player) || WallRunActive(f[k].player)) continue;  // na disputa ou na parede
    const float d = fighter::Distance2D(f[k].pos, f[enemy].pos);
    if (d < best) { best = d; a = k; }
  }
  if (a < 0) return;
  const int pad = PromotePadForPlayer(f[a].player);
  bool go = false;
  if (pad >= 0 && pad < 4) {
    go = g_bPressed[pad];  // aliado humano: aperta B / Bolinha na janela
  } else if (g_comboRolled[p] != g_comboId[p]) {
    g_comboRolled[p] = g_comboId[p];  // aliado da CPU: sorteio uma vez por combo
    go = NextRandom() % 100 < CpuAdaptChance(g_cpuChance.load(std::memory_order_relaxed),f[a].player,cpuai::Action::DualCombo);
  }
  if (!go) return;
  PromoteSetTarget(a, enemy);
  fighter::FaceToward(f[a].player, f[enemy].pos[0], f[enemy].pos[1]);
  if (!clash3d::SetActionNow(f[a].player, kJoinAction)) return;
  Join& j = g_join[side];
  j = {};
  j.active = true;
  j.primary = p;
  j.ally = a;
  j.enemy = enemy;
  j.at = now;
  j.traceNext = now;
  float life = 0, lifeMax = 0;
  int s2 = -1, row = -1;
  PromoteFighterVitals(enemy, &life, &lifeMax, &s2, &row);
  j.enemyLife = life;
  g_busy[a] = true;
  g_cooldownUntil[side] = now + g_cooldownMs.load(std::memory_order_relaxed);
  Log("COMBO DUPLA: J%d (%s) entra no combo de J%d contra J%d (golpe %d do combo, distancia %.0f).", f[a].number,
      pad >= 0 ? "jogador" : "CPU", f[p].number, f[enemy].number, anm - 191, best);
}

void DualComboTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (n < 2 || n > 6) return;
  if (g_test.load(std::memory_order_relaxed)) {
    ProbeTick(f, n, sceneActive, now);
    if (!g_enabled.load(std::memory_order_relaxed)) return;
  }
  if (!g_enabled.load(std::memory_order_relaxed)) return;
  ReadButtons();
  for (int k = 0; k < n; ++k) {
    const int s = f[k].valid ? f[k].state : -1;
    if (Attacking(s) && !Attacking(g_prevState[k])) ++g_comboId[k];  // novo combo
    g_prevState[k] = s;
  }
  FollowJoin(f, 0, now);
  FollowJoin(f, 1, now);
  GuardExit(f, n, now);
  int pairA = -1, pairB = -1;
  if (sceneActive || JutsuClashCameraPair(&pairA, &pairB)) return;  // Supremo/cena ou disputa de jutsus: nao entra
  for (int p = 0; p < n; ++p)
    if (f[p].valid) TryJoin(f, n, p, now);
}
