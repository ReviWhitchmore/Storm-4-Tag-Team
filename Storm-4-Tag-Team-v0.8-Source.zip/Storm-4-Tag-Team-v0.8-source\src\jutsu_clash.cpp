#include "jutsu_clash.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

#include <MinHook.h>

#include "addresses.h"
#include "census.h"
#include "cpu_adapt.h"
#include "jutsu_clash_3d.h"
#include "jutsu_clash_motion_rules.h"
#include "jutsu_clash_rules.h"
#include "input.h"
#include "log.h"
#include "promote.h"
#include "settings.h"
#include "ult.h"

namespace {
std::atomic<bool> g_enabled{true};
bool g_supported = false;  // Evolution verificado (o menu so liga/desliga onde a disputa existe)
std::atomic<unsigned> g_damagePct{12};
std::atomic<unsigned> g_cpuRate{7};
std::atomic<bool> g_allowDash{false};
std::atomic<bool> g_protect{true};
// Teste visual (jutsu_clash_teste_tela=1): mostra a tela da disputa com placar simulado de 3 a 15 s da luta.
std::atomic<bool> g_testScreen{false};
std::atomic<bool> g_visualV2{true};
std::atomic<bool> g_worldContactPreview{false}; // opcional; desligado por padrao
std::atomic<int> g_style{2};  // jutsu_clash_estilo: 0 Connections, 1 V2, 2 Storm 1
// Duracao da disputa (jutsu_clash_segundos, 3..10). No video do Storm 1 os apertos duram ~4 s; o plano original era 7.
std::atomic<unsigned> g_durationMs{4000};
constexpr uint64_t kIntroCloseA = 450, kIntroCloseB = 900;  // abertura do Storm 1: close de A, depois de B  // referencia de tracks do Storm 1 (sem arquivos distribuidos)
// 3D (motor do Evolution): fundo preto com os personagens visiveis durante a disputa (jutsu_clash_fundo_preto=1).
std::atomic<bool> g_blackBackground{false};  // desligado ate ser visto numa disputa real
uintptr_t g_backgroundOffBy = 0;  // lutador usado para desligar o cenario (religa com o mesmo ou outro da luta)
// Teste (jutsu_clash_teste_forcar=1): a cada 10 s manda dois adversarios soltarem o jutsu juntos (troca de acao
// nativa), para gerar choques reais sem depender da CPU. Tambem registra estado e animacao por 2,5 s.
std::atomic<int> g_forceTest{0};  // 1 = so manda soltar; 2 = aproxima os dois e abre a disputa no meio do jutsu
uint64_t g_lastForce = 0;
uintptr_t g_forceA = 0, g_forceB = 0;  // teste 2: par que vai abrir a disputa
// Animacao 3D durante a disputa (jutsu_clash_anim_modo): 0 = congelado na pose do choque; 1 = alterna entre a fase do
// jutsu do choque e a seguinte (tremor de empurrar); 2 = avanca a animacao quadro a quadro em camera lenta e repete o
// trecho (os dois forcando). Avanco (jutsu_clash_avanco=1): os modelos deslizam para o lado de quem esta perdendo.
std::atomic<int> g_animMode{0};  // 0 ate os modos 1/2 serem vistos numa disputa real
std::atomic<bool> g_slide{false};
struct Pose3D {
  int anmA = -1, anmB = -1;     // animacao de cada um no momento do choque
  float baseA[3]{}, baseB[3]{}; // posicoes no choque (o deslize parte delas)
  uint64_t lastToggle = 0, lastLoop = 0, lastMotion = 0;
  unsigned tick = 0;
  float push = 0.0f;  // deslize atual (suavizado)
  bool alt = false, running = false;
};
Pose3D g_pose;
// Vira o lutador para (tx, ty). Direcao em +0xA8 (x, y) com copias em +0xB4, +0xC0, +0xE4, +0xF0, +0xFC; a matriz do
// modelo em +0x108 usa linha 0 = (-y, -x) e linha 1 = (x, -y) (lido no jogo: os dois de frente tinham esses valores).
// Antes os dois podiam ficar de costas: a disputa abre tambem quando um jutsu acerta por tras quem solta outro jutsu.
void FaceToward(uintptr_t player, float tx, float ty) {
  __try {
    float* base = reinterpret_cast<float*>(player);
    const float px = base[0x70 / 4], py = base[0x74 / 4];
    float dx = tx - px, dy = ty - py;
    const float len = std::sqrt(dx * dx + dy * dy);
    if (!(len > 1.0f)) return;
    dx /= len;
    dy /= len;
    const int dirs[] = {0xA8, 0xB4, 0xC0, 0xE4, 0xF0, 0xFC};
    for (int off : dirs) {
      base[off / 4] = dx;
      base[off / 4 + 1] = dy;
      base[off / 4 + 2] = 0.0f;
    }
    base[0x108 / 4] = -dy;
    base[0x10C / 4] = -dx;
    base[0x118 / 4] = dx;
    base[0x11C / 4] = -dy;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}
void WritePos(uintptr_t player, const float p[3]) {
  __try {
    float* at = reinterpret_cast<float*>(player + 0x70);
    at[0] = p[0];
    at[1] = p[1];
    at[2] = p[2];
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}
uint64_t g_traceUntil = 0, g_traceNext = 0;
uintptr_t g_traceA = 0, g_traceB = 0;
int g_traceNumA = 0, g_traceNumB = 0;
uint64_t g_battleStartedAt = 0;
float g_testPosA[3]{}, g_testPosB[3]{};  // teste de tela: o primeiro de cada lado
bool g_testHasPos = false;
std::atomic<uintptr_t> g_protectA{0}, g_protectB{0};  // jogadores travados na disputa ativa
std::atomic<unsigned> g_discarded{0};

// Entrada (thread do XInput): contador monotono de apertos de B por controle (so a borda conta).
std::atomic<bool> g_bHeld[4]{};
std::atomic<unsigned> g_bCount[4]{};
// Leitor de controle do proprio jogo (8 entradas: 0-3 XInput, 4 teclado, 5.. outros tipos): +0x18 = segurando, bit
// 0x2000 = B / Bolinha (mesmo mapa do XInput; lido no jogo com B simulado). Conta o que o XInput nao ve - controle de
// PlayStation lido direto pelo jogo, teclado. No teste do usuario 08:21 o XInput nao registrou nenhum aperto.
bool g_physHeld[8]{};
unsigned g_physCount[8]{};
unsigned g_physBase[8]{};
void PollPhysicalMash() {
  for (int d = 0; d < 8; ++d) {
    uint8_t pad[0x80];
    const bool on = InputPhysicalPad(d, pad);
    uint32_t held = 0;
    std::memcpy(&held, pad + 0x18, sizeof(held));
    const bool down = on && (held & 0x2000) != 0;
    if (down && !g_physHeld[d]) ++g_physCount[d];
    g_physHeld[d] = down;
  }
}
// Apertos do lado com o controle pad (0-3) desde o inicio da disputa. As entradas 4..7 contam para o primeiro jogador
// humano da disputa (primary).
unsigned PhysicalScore(int pad, int primary) {
  if (pad < 0 || pad > 3) return 0;
  unsigned n = g_physCount[pad] - g_physBase[pad];
  if (pad == primary)
    for (int d = 4; d < 8; ++d) n += g_physCount[d] - g_physBase[d];
  return n;
}

struct Clash {
  clash::Phase phase = clash::Phase::Idle;
  unsigned id = 0;
  int a = -1, b = -1;              // indices dos lutadores na visao
  int numberA = 0, numberB = 0;
  int padA = -1, padB = -1;
  unsigned baseA = 0, baseB = 0;   // contagem de B no inicio (so apertos durante a disputa valem)
  float variationA[7]{}, variationB[7]{};
  uint64_t startedAt = 0;
  unsigned scoreA = 0, scoreB = 0;
  int result = -1;
  int stateA = -1, stateB = -1;  // jutsu de cada um no choque (para o golpe final)
  bool recast = false;           // golpe final com o jutsu solto de novo (espera ate 1,5 s pelo acerto nativo)
  bool loserResumed = false;     // perdedor ja despausado no golpe final (nao retomar duas vezes)
  uint64_t bannerUntil = 0;
  uint64_t resolveAt = 0;
  uint64_t resultAt = 0;
  float posA[3]{}, posB[3]{};
  bool hasPos = false;
  bool testBias = false;  // so no teste forcado: CPU do lado A aperta 1,6x (para o avanco aparecer nas capturas)
};
Clash g_clash;
bool g_forcedRequest = false;
uint64_t g_recentResolvedAt = 0;
uintptr_t g_recentResolvedA = 0, g_recentResolvedB = 0;
unsigned g_nextId = 1;
int g_prev[6]{-1, -1, -1, -1, -1, -1};
SRWLOCK g_hudLock = SRWLOCK_INIT;
ClashHud g_hud;
bool g_hudVisible = false;
uint32_t g_rng = 0x6C8E9CF5u;

uint32_t NextRandom() {
  g_rng ^= g_rng << 13;
  g_rng ^= g_rng >> 17;
  g_rng ^= g_rng << 5;
  return g_rng;
}
float Variation() { return float(NextRandom() % 2001) / 1000.0f - 1.0f; }

// Pausa/retomada nativas do ator (vtable +0xFF8 / +0xFF0): so os dois da disputa ficam travados.
bool CallVirtual(uintptr_t player, size_t offset) {
  __try {
    auto** vtable = *reinterpret_cast<void (***)(uintptr_t)>(player);
    if (!vtable || !vtable[offset / sizeof(void*)]) return false;
    vtable[offset / sizeof(void*)](player);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}
bool ChangeState(uintptr_t player, int state) {
  __try {
    auto** vtable = *reinterpret_cast<void (***)(uintptr_t, int)>(player);
    auto change = vtable ? vtable[Addr().vtChangeState / sizeof(void*)] : nullptr;
    if (!change) return false;
    change(player, state);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}
// Controle durante a disputa, como as cenas do jogo fazem em linha (ex.: exe+0x7D6F5A): +0xCAC = 0 e entrada
// zerada (FUN_1407BB184 em +0x218). Religa com FUN_140795CC4(ator, 1). Sem isso o estado de empurrao acaba
// sozinho (~0,5 s) e a CPU/jogador voltariam a agir no meio da disputa.
void SetControl(uintptr_t player, bool on) {
  __try {
    if (on) {
      reinterpret_cast<void (*)(uintptr_t, int)>(g_base + 0x795CC4)(player, 1);
    } else {
      *reinterpret_cast<int*>(player + 0xCAC) = 0;
      reinterpret_cast<void (*)(uintptr_t)>(g_base + 0x7BB184)(player + 0x218);
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}
bool DamageState(int s) { return s >= 0x18 && s <= 0x3C; }

// 3v3 simultaneo: um Supremo de OUTRA dupla nao cancela a disputa quando os Supremos sao livres (sem cinematica,
// a arena nao congela). Cancela se um dos dois estiver no Supremo (autor ou vitima) ou se os Supremos forem
// cinematicos (ultimates_livres=0).
bool SceneInvolves(const GrabFighterView* f, int a, int b, int n = 6) {
  if (!Cfg().ultFree.load(std::memory_order_relaxed)) return true;
  auto sceneState = [](int s) { return (s >= 0x87 && s <= 0x8F) || s == 0x51 || s == 0x4F || s == 0x50; };
  if (sceneState(f[a].state) || sceneState(f[b].state)) return true;
  int side = -1, victim = -1;
  if (UltRecentCinematicVictim(&side, &victim, 1500) && (victim == a || victim == b)) return true;
  for (int s = 0; s < 2; ++s) {
    int owner = -1, target = -1;
    // So conta o Supremo que AINDA esta acontecendo (quem preparou segue no Supremo, 0x87..0x8F). Antes valia
    // qualquer preparo dos ultimos 8 s e a disputa era cancelada por Supremos que ja tinham acabado.
    if (UltPreparedUltimate(s, &owner, &target) && owner >= 0 && owner < n && f[owner].valid &&
        sceneState(f[owner].state) && (owner == a || owner == b || target == a || target == b))
      return true;
  }
  return false;
}

int CharacterId(uintptr_t player) {
  __try {
    return *reinterpret_cast<const int*>(player + 0xC8C);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return -1;
  }
}

void Damage(int index, int number) {
  float life = 0, lifeMax = 0;
  int side = -1, row = -1;
  if (!PromoteFighterVitals(index, &life, &lifeMax, &side, &row) || lifeMax <= 0) return;
  const float hit = lifeMax * float(g_damagePct.load(std::memory_order_relaxed)) / 100.0f;
  // Nao nocauteia pela disputa: o nocaute nativo nao passa por aqui.
  const float after = life - hit > 1.0f ? life - hit : (life > 1.0f ? 1.0f : life);
  PromoteSetFighterLife(index, after);
  Log("JUTSU CLASH: J%d perdeu %.0f de vida (%.0f -> %.0f).", number, life - after, life, after);
}

void Publish(uint64_t now) {
  if (g_testScreen.load(std::memory_order_relaxed) && g_clash.phase != clash::Phase::Active && g_battleStartedAt &&
      now - g_battleStartedAt >= 3000 && now - g_battleStartedAt < 15000) {
    const uint64_t e = now - g_battleStartedAt - 3000;
    AcquireSRWLockExclusive(&g_hudLock);
    g_hudVisible = true;
    g_hud.visualV2 = g_visualV2.load(std::memory_order_relaxed);
    g_hud.worldContactPreview = g_worldContactPreview.load(std::memory_order_relaxed);
    g_hud.style = g_style.load(std::memory_order_relaxed);
    g_hud.padA = 0;
    g_hud.padB = -1;
    g_hud.numberA = 1;
    g_hud.numberB = 4;
    g_hud.scoreA = unsigned(e / 140);
    g_hud.scoreB = unsigned(e / 165);
    g_hud.remainingMs = e < 7000 ? unsigned(7000 - e) : 0;
    g_hud.result = e < 7000 ? -1 : 1;
    g_hud.elapsedMs = unsigned(e);
    g_hud.resultAgeMs = e < 7000 ? 0 : unsigned(e - 7000);
    g_hud.hasPos = g_testHasPos;
    std::memcpy(g_hud.posA, g_testPosA, sizeof(g_hud.posA));
    std::memcpy(g_hud.posB, g_testPosB, sizeof(g_hud.posB));
    ReleaseSRWLockExclusive(&g_hudLock);
    return;
  }
  AcquireSRWLockExclusive(&g_hudLock);
  g_hudVisible = g_clash.phase == clash::Phase::Active || now < g_clash.bannerUntil;
  g_hud.visualV2 = g_visualV2.load(std::memory_order_relaxed);
  g_hud.worldContactPreview = g_worldContactPreview.load(std::memory_order_relaxed);
  g_hud.style = g_style.load(std::memory_order_relaxed);
  g_hud.cameraIntro = g_style.load(std::memory_order_relaxed) == 2 && g_blackBackground.load(std::memory_order_relaxed);
  g_hud.padA = g_clash.padA;
  g_hud.padB = g_clash.padB;
  g_hud.numberA = g_clash.numberA;
  g_hud.numberB = g_clash.numberB;
  g_hud.scoreA = g_clash.scoreA;
  g_hud.scoreB = g_clash.scoreB;
  const uint64_t elapsed = now > g_clash.startedAt ? now - g_clash.startedAt : 0;
  const uint64_t duration = g_durationMs.load(std::memory_order_relaxed);
  g_hud.remainingMs = g_clash.phase == clash::Phase::Active && elapsed < duration ? unsigned(duration - elapsed) : 0;
  g_hud.result = g_clash.phase == clash::Phase::Active ? -1 : g_clash.result;
  g_hud.elapsedMs = unsigned(elapsed);
  g_hud.resultAgeMs = g_clash.result >= 0 && now > g_clash.resultAt ? unsigned(now - g_clash.resultAt) : 0;
  g_hud.hasPos = g_clash.hasPos;
  std::memcpy(g_hud.posA, g_clash.posA, sizeof(g_hud.posA));
  std::memcpy(g_hud.posB, g_clash.posB, sizeof(g_hud.posB));
  ReleaseSRWLockExclusive(&g_hudLock);
}

void End(const GrabFighterView* f, clash::Phase how, const char* reason) {
  g_protectA = 0;
  g_protectB = 0;
  // Libera o bloqueio das trocas de estado ANTES de retomar os dois atores.
  g_clash.phase = how;
  if (how == clash::Phase::Cancelled) {
    g_recentResolvedAt = GetTickCount64();
    g_recentResolvedA = g_clash.a >= 0 ? f[g_clash.a].player : 0;
    g_recentResolvedB = g_clash.b >= 0 ? f[g_clash.b].player : 0;
  }
  // Retoma os dois sempre (tambem ao cancelar), para ninguem ficar travado.
  if (g_clash.a >= 0) {
    CallVirtual(f[g_clash.a].player, 0xFF0);
    SetControl(f[g_clash.a].player, true);
  }
  if (g_clash.b >= 0) {
    CallVirtual(f[g_clash.b].player, 0xFF0);
    SetControl(f[g_clash.b].player, true);
  }
  if (how == clash::Phase::Cancelled)
    Log("JUTSU CLASH #%u CANCELADO: %s (J%d %u x %u J%d).", g_clash.id, reason, g_clash.numberA, g_clash.scoreA,
        g_clash.scoreB, g_clash.numberB);
}
}  // namespace

void JutsuClashResetIntercept();
void InstallJutsuHitHook();

void JutsuClashInstall() {
  if (Addr().timestamp != 0x5889906E) {
    g_enabled = false;
    Log("JUTSU CLASH: disponivel somente no Evolution verificado.");
    return;
  }
  bool enabled = true, dash = false, protect = true;
  unsigned damage = 12, cpu = 7;
  const std::wstring file = ModDir() + L"storm6.ini";
  if (FILE* stream = _wfopen(file.c_str(), L"r")) {
    char line[128];
    while (std::fgets(line, sizeof(line), stream)) {
      char key[65]{};
      int value = 0;
      if (std::sscanf(line, "%64[^=]=%d", key, &value) != 2) continue;
      if (!std::strcmp(key, "jutsu_clash")) enabled = value != 0;
      else if (!std::strcmp(key, "jutsu_clash_dano") && value >= 0 && value <= 50) damage = unsigned(value);
      else if (!std::strcmp(key, "jutsu_clash_cpu") && value >= 0 && value <= 15) cpu = unsigned(value);
      else if (!std::strcmp(key, "jutsu_clash_teste_investida")) dash = value != 0;
      else if (!std::strcmp(key, "jutsu_clash_protegido")) protect = value != 0;
      else if (!std::strcmp(key, "jutsu_clash_teste_tela")) g_testScreen = value != 0;
      else if (!std::strcmp(key, "jutsu_clash_visual_storm1")) g_visualV2 = value != 0;
      else if (!std::strcmp(key, "jutsu_clash_fundo_preto")) g_blackBackground = value != 0;
      else if (!std::strcmp(key, "jutsu_clash_estilo") && value >= 0 && value <= 2) g_style = value;
      else if (!std::strcmp(key, "jutsu_clash_segundos") && value >= 3 && value <= 10) g_durationMs = unsigned(value) * 1000;
      else if (!std::strcmp(key, "jutsu_clash_teste_forcar") && value >= 0 && value <= 2) g_forceTest = value;
      else if (!std::strcmp(key, "jutsu_clash_anim_modo") && value >= 0 && value <= 4) g_animMode = value;
      else if (!std::strcmp(key, "jutsu_clash_avanco")) g_slide = value != 0;
      else if (!std::strcmp(key, "jutsu_clash_contato_3d_teste")) g_worldContactPreview = value != 0;
    }
    std::fclose(stream);
  }
  g_supported = true;
  Cfg().jutsuClash = enabled;  // mesma chave jutsu_clash do storm6.ini; o menu do mod muda em tempo real
  g_enabled = enabled;
  g_damagePct = damage;
  g_cpuRate = cpu;
  g_allowDash = dash;
  g_protect = protect;
  Log("JUTSU CLASH: %s; %u s apertando B (controle ou teclado); dano %u%%; CPU %u apertos/s%s.",
      enabled ? "ATIVO" : "desligado (storm6.ini jutsu_clash=1)", g_durationMs.load() / 1000, damage, cpu,
      dash ? "; TESTE: choque de investidas tambem abre disputa" : "");
  Log("JUTSU CLASH: apresentacao animada Storm 1 %s (referencia de efeitos locais).",
      g_visualV2.load() ? "habilitada" : "desabilitada");
  InstallJutsuHitHook();
  clash3d::Install();
  if (g_forceTest.load()) Log("JUTSU CLASH: TESTE - choques forcados a cada 10 s (jutsu_clash_teste_forcar=%d).",
                              g_forceTest.load());
  Log("JUTSU CLASH 3D: projecao de contato no mundo %s (teste opt-in).", g_worldContactPreview.load() ? "ativada" : "desativada");
  Log("JUTSU CLASH 3D: animacao na disputa modo %d; avanco dos modelos %s; fundo preto %s.", g_animMode.load(),
      g_slide.load() ? "ligado" : "desligado", g_blackBackground.load() ? "ligado" : "desligado");
}

void JutsuClashObservePad(DWORD pad, const XINPUT_STATE* state, bool connected) {
  if (pad >= 4) return;
  const bool held = connected && state && (state->Gamepad.wButtons & XINPUT_GAMEPAD_B) != 0;
  if (held && !g_bHeld[pad].exchange(true, std::memory_order_relaxed))
    g_bCount[pad].fetch_add(1, std::memory_order_relaxed);
  else if (!held)
    g_bHeld[pad].store(false, std::memory_order_relaxed);
}

void JutsuClashBeginBattle() {
  g_clash = {};
  g_backgroundOffBy = 0;  // cenario novo: nada a religar
  g_lastForce = 0;
  g_traceUntil = 0;
  g_forceA = g_forceB = 0;
  g_pose = {};
  g_recentResolvedAt = 0;
  g_recentResolvedA = g_recentResolvedB = 0;
  g_battleStartedAt = GetTickCount64();
  JutsuClashResetIntercept();
  g_protectA = 0;
  g_protectB = 0;
  for (int& p : g_prev) p = -1;
  g_rng ^= static_cast<uint32_t>(GetTickCount64());
  if (!g_rng) g_rng = 0x6C8E9CF5u;
  AcquireSRWLockExclusive(&g_hudLock);
  g_hudVisible = false;
  ReleaseSRWLockExclusive(&g_hudLock);
}

// ---------------------------------------------------------------- inicio pela rotina de acerto mutuo
// FUN_14076D8xx (acerto mutuo de mesma prioridade) chama a troca de estado nativa para 0x5A no primeiro
// (retorno exe+0x76D926) e logo depois no segundo (retorno exe+0x76D937). Se os dois vinham de jutsu, o mod segura
// as duas trocas: os dois ficam na POSE DO JUTSU (de frente, pois os jutsus estavam apontados um para o outro).
// Se o segundo nao se qualifica, a troca do primeiro e aplicada como o jogo faria.
namespace {
struct Deferred {
  uintptr_t player = 0;
  int state = -1;
  int action = 0;
  void (*original)(uintptr_t, int) = nullptr;
  uint64_t at = 0;
};
Deferred g_first;
struct StartRequest {
  uintptr_t a = 0, b = 0;
  int stateA = -1, stateB = -1;
  int actionA = clash::kOffset, actionB = clash::kOffset;  // -1: o jogo nao empurrou esse lutador
  uint64_t at = 0;
};
StartRequest g_request;
// Acerto sendo tratado agora (thread do jogo, dentro de FUN_140784310): vitima que esta num jutsu e o atacante, que
// tambem esta num jutsu. Assim a disputa abre mesmo quando o jogo so empurra a vitima.
struct HitContext {
  uintptr_t victim = 0, attacker = 0;
  int attackerState = -1;
};
HitContext g_hit;
void ApplyOffset(uintptr_t player, int action);
// Lutadores da luta atual, vistos pelo ultimo JutsuClashTick. So segura um empurrao se o controlador esta rodando
// nesta luta (senao o empurrao segurado nunca seria aplicado) e se os dois sao de lados opostos.
std::atomic<uint64_t> g_tickAt{0};
uintptr_t g_roster[6]{};
int g_rosterSide[6]{};
int g_rosterN = 0;
int RosterSide(uintptr_t player) {
  if (!player || GetTickCount64() - g_tickAt.load(std::memory_order_relaxed) > 250) return -1;
  for (int k = 0; k < g_rosterN; ++k)
    if (g_roster[k] == player) return g_rosterSide[k];
  return -1;
}
int ReadState(uintptr_t player) {
  __try {
    return *reinterpret_cast<const int*>(player + 0xCC0);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return -1;
  }
}
bool Source(int state) {
  return clash::JutsuState(state) || (g_allowDash.load(std::memory_order_relaxed) && state == clash::kChakraDash);
}
void FlushFirst() {
  if (g_first.player && g_first.original) g_first.original(g_first.player, g_first.action);
  g_first = {};
}
}  // namespace

void JutsuClashResetIntercept() {
  g_first = {};
  g_request = {};
}

bool JutsuClashInterceptOffset(uintptr_t player, int action, uintptr_t returnRva, void (*original)(uintptr_t, int)) {
  // O jogo poe os dois em empurrao (0x5A chao / 0x5B ar) por varias rotinas: acerto x acerto (exe+0x76D926/0x76D937),
  // ataque x ataque (exe+0x78EF37/0x78EF45) e golpe recebido x golpe em andamento (exe+0x784A14/0x784A46, o choque de
  // dois jutsus visto no teste do usuario). Generico: qualquer empurrao de quem esta num jutsu fica segurado; se outro
  // lutador tambem entra no empurrao saindo de jutsu na mesma rotina, abre a disputa; senao o empurrao e aplicado no
  // mesmo quadro (JutsuClashTick).
  (void)returnRva;
  if (g_clash.phase == clash::Phase::Active && g_clash.a >= 0 && g_clash.b >= 0 &&
      (player == g_roster[g_clash.a] || player == g_roster[g_clash.b]) &&
      clash::HoldPoseTransition(action)) {
    // Alem do segundo empurrao, impede a volta automatica a PL_ACT_NUT (0x1).
    // Antes, depois de ~1,5 s ambos ficavam em pe, sem jutsu, ate o cronometro acabar.
    static std::atomic<unsigned> held{0};
    if (held.fetch_add(1) < 30)
      Log("JUTSU CLASH #%u: transicao 0x%X bloqueada enquanto a pose do jutsu esta pausada.", g_clash.id, action);
    return true;
  }
  if (action != clash::kOffset && action != clash::kOffsetAir) return false;
  if (g_request.a && (player == g_request.a || player == g_request.b)) {
    // O mesmo choque chega de novo (o outro jutsu tambem acertou): os dois ja estao segurados para a disputa.
    if (player == g_request.b && g_request.actionB < 0) g_request.actionB = action;
    return true;
  }
  if (!g_enabled.load(std::memory_order_relaxed) || g_clash.phase == clash::Phase::Active ||
      g_clash.phase == clash::Phase::Resolving || g_request.a) {
    FlushFirst();
    return false;
  }
  const int state = ReadState(player);
  if (!Source(state)) return false;
  if (RosterSide(player) < 0) {
    FlushFirst();
    return false;
  }
  const uint64_t now = GetTickCount64();
  if (g_hit.victim == player && g_hit.attacker) {
    // Choque de dois jutsus visto pela rotina de acerto: abre a disputa com o atacante, empurrado ou nao pelo jogo.
    FlushFirst();
    g_request = {player, g_hit.attacker, state, g_hit.attackerState, action, -1, now};
    return true;
  }
  if (g_first.player && g_first.player != player && now - g_first.at < 50) {
    g_request = {g_first.player, player, g_first.state, state, g_first.action, action, now};
    g_first = {};
    return true;
  }
  FlushFirst();
  g_first = {player, state, action, original, now};
  return true;  // segura ate o par chegar (mesma rotina) ou ate o proximo quadro
}

// ---------------------------------------------------------------- choque de jutsus de qualquer personagem
// FUN_140784310(vitima, mensagem de acerto) e o tratamento de um golpe que chega em quem esta atacando (mesma funcao
// em todas as vtables de lutador, entrada +0x1048). Ela compara a forca do ataque da vitima (vtable +0x1350 =
// max(+0x13C08, +0x13C0C)) com a do golpe que chega (mensagem +0x74):
//   igual  -> empurrao 0x5A nos dois (retornos exe+0x784A14 / exe+0x784A46) = os jutsus se anulam;
//   maior  -> o golpe que chega e ignorado (exe+0x784A69);  menor -> a vitima leva o golpe.
// Por isso dois jutsus de forca diferente nunca chegavam ao empurrao mutuo e a disputa nao abria. Quando os DOIS
// lutadores estao num jutsu, o mod iguala a forca do golpe que chega so durante esta chamada (e devolve depois): o
// jogo segue o caminho do choque e o gancho da troca de estado abre a disputa. Com a disputa desligada, nada muda.
namespace {
using JutsuHitFn = uintptr_t (*)(uintptr_t, uintptr_t, uintptr_t, uintptr_t);
JutsuHitFn g_origJutsuHit = nullptr;
std::atomic<unsigned> g_levelFixes{0};

void ApplyOffset(uintptr_t player, int action) {
  if (player && action >= 0) ChangeState(player, action);
}

// FUN_1404455DC(_, id): ator pelo id (a mesma busca que a rotina faz com a mensagem +0x10).
uintptr_t FindActor(int id) {
  __try {
    return reinterpret_cast<uintptr_t (*)(uintptr_t, int)>(g_base + 0x4455DC)(0, id);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return 0;
  }
}

unsigned AttackLevel(uintptr_t player) {
  __try {
    auto** vtable = *reinterpret_cast<unsigned (***)(uintptr_t)>(player);
    return vtable && vtable[0x1350 / sizeof(void*)] ? vtable[0x1350 / sizeof(void*)](player) : 0;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return 0;
  }
}

uintptr_t HookJutsuHit(uintptr_t victim, uintptr_t msg, uintptr_t c, uintptr_t d) {
  const bool idle = g_enabled.load(std::memory_order_relaxed) && msg && !g_request.a && !g_hit.victim &&
                    g_clash.phase != clash::Phase::Active && g_clash.phase != clash::Phase::Resolving;
  uint32_t* incoming = nullptr;
  uint32_t saved = 0;
  if (idle && Source(ReadState(victim))) {
    __try {
      const uint32_t level = *reinterpret_cast<const uint32_t*>(msg + 0x74);
      const uintptr_t attacker = level ? FindActor(*reinterpret_cast<const int*>(msg + 0x10)) : 0;
      const int attackerState = attacker && attacker != victim ? ReadState(attacker) : -1;
      const int victimSide = RosterSide(victim), attackerSide = RosterSide(attacker);
      if (Source(attackerState) && victimSide >= 0 && attackerSide >= 0 && victimSide != attackerSide &&
          !clash::RepeatPair(victim, attacker, g_recentResolvedA, g_recentResolvedB,
                             GetTickCount64(), g_recentResolvedAt)) {
        const unsigned own = AttackLevel(victim);
        if (own) {
          g_hit = {victim, attacker, attackerState};
          if (own != level) {
            incoming = reinterpret_cast<uint32_t*>(msg + 0x74);
            saved = level;
            *incoming = own;
            if (g_levelFixes.fetch_add(1) < 20)
              Log("JUTSU CLASH: choque de jutsus de forca diferente (vitima 0x%X forca %u, atacante 0x%X forca %u, "
                  "personagens %d x %d); igualado para abrir a disputa.",
                  ReadState(victim), own, attackerState, level, CharacterId(victim), CharacterId(attacker));
          }
        }
      }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      incoming = nullptr;
      g_hit = {};
    }
  }
  // Golpe final: o jutsu do vencedor acertando o perdedor (que ainda esta na pose do jutsu) vale como MAIS forte,
  // para o jogo dar o golpe de verdade (dano) em vez de empurrar os dois como num choque igual.
  if (!incoming && msg && g_clash.phase == clash::Phase::Resolving && g_clash.a >= 0 && g_clash.b >= 0) {
    const uintptr_t winner = g_roster[g_clash.result == 1 ? g_clash.a : g_clash.b];
    const uintptr_t loser = g_roster[g_clash.result == 1 ? g_clash.b : g_clash.a];
    __try {
      if (victim == loser && FindActor(*reinterpret_cast<const int*>(msg + 0x10)) == winner) {
        const unsigned own = AttackLevel(victim);
        if (own) {
          incoming = reinterpret_cast<uint32_t*>(msg + 0x74);
          saved = *incoming;
          if (saved <= own) *incoming = own + 1;
          else incoming = nullptr;  // ja era mais forte: nada a mudar
        }
      }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      incoming = nullptr;
    }
  }
  const uintptr_t result = g_origJutsuHit(victim, msg, c, d);
  if (incoming) {
    __try {
      *incoming = saved;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
  }
  if (g_hit.victim == victim) g_hit = {};
  return result;
}
}  // namespace

void InstallJutsuHitHook() {
  void* target = reinterpret_cast<void*>(g_base + 0x784310);
  // Assinatura do inicio da funcao (mov rax,rsp; mov [rax+8],rbx; push rbp; push rsi).
  static const uint8_t want[] = {0x48, 0x8B, 0xC4, 0x48, 0x89, 0x58, 0x08, 0x55, 0x56};
  if (std::memcmp(target, want, sizeof(want)) != 0) {
    Log("JUTSU CLASH: rotina de choque de jutsus exe+0x784310 diferente do esperado; so o choque de mesma forca abre.");
    return;
  }
  MH_STATUS st = MH_CreateHook(target, reinterpret_cast<void*>(&HookJutsuHit), reinterpret_cast<void**>(&g_origJutsuHit));
  if (st == MH_OK) st = MH_EnableHook(target);
  Log("JUTSU CLASH: rotina de choque de jutsus exe+0x784310 %s.",
      st == MH_OK ? "monitorada (qualquer personagem, qualquer forca)" : MH_StatusToString(st));
}

int JutsuClashCameraStage() {
  // Abertura no estilo do Storm 1 (so com o fundo/3D ligados e o estilo Storm 1): close de A, close de B, vista de lado.
  if (g_clash.phase != clash::Phase::Active || g_style.load(std::memory_order_relaxed) != 2 ||
      !g_blackBackground.load(std::memory_order_relaxed))
    return 0;
  const uint64_t e = GetTickCount64() - g_clash.startedAt;
  return e < kIntroCloseA ? 1 : e < kIntroCloseB ? 2 : 0;
}

bool JutsuClashCameraPair(int* a, int* b) {
  if (g_clash.phase != clash::Phase::Active && g_clash.phase != clash::Phase::Resolving) return false;
  *a = g_clash.a;
  *b = g_clash.b;
  return true;
}

void JutsuClashTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (n < 2 || n > 6) return;
  {
    // Opcao do menu do mod (F1): vale a partir da proxima colisao; uma disputa em andamento termina normalmente.
    const bool wanted = g_supported && Cfg().jutsuClash.load(std::memory_order_relaxed);
    if (wanted != g_enabled.load(std::memory_order_relaxed)) {
      g_enabled = wanted;
      Log("JUTSU CLASH: %s pelo menu do mod.", wanted ? "LIGADO" : "DESLIGADO");
    }
  }
  for (int k = 0; k < n; ++k) {
    // DIAGNOSTICO: quem entra em jutsu (a entrada em jutsu nao passa pela troca de estado da vtable).
    const int nowState = f[k].valid ? f[k].state : -1;
    if (clash::JutsuState(nowState) && !clash::JutsuState(g_prev[k])) {
      static std::atomic<unsigned> lines{0};
      if (lines.fetch_add(1) < 200) {
        float nearest = 1e9f;
        for (int o = 0; o < n; ++o) {
          if (!f[o].valid || f[o].side == f[k].side) continue;
          const float dx = f[o].pos[0] - f[k].pos[0], dy = f[o].pos[1] - f[k].pos[1];
          nearest = std::min(nearest, std::sqrt(dx * dx + dy * dy));
        }
        Log("JUTSU: J%d entrou em jutsu 0x%X (personagem %d); adversario mais perto a %.0f.", f[k].number, nowState,
            CharacterId(f[k].player), nearest);
      }
    }
    g_prev[k] = nowState;
    g_roster[k] = f[k].valid ? f[k].player : 0;
    g_rosterSide[k] = f[k].side;
  }
  g_rosterN = n;
  g_tickAt.store(now, std::memory_order_relaxed);
  if (g_testScreen.load(std::memory_order_relaxed)) {
    int ta = -1, tb = -1;
    for (int k = 0; k < n; ++k) {
      if (!f[k].valid) continue;
      if (f[k].side == 0 && ta < 0) ta = k;
      if (f[k].side == 1 && tb < 0) tb = k;
    }
    g_testHasPos = ta >= 0 && tb >= 0;
    if (g_testHasPos) {
      std::memcpy(g_testPosA, f[ta].pos, sizeof(g_testPosA));
      std::memcpy(g_testPosB, f[tb].pos, sizeof(g_testPosB));
    }
  }
  if (g_first.player) FlushFirst();  // o par nao veio na mesma rotina: aplica o empurrao do jogo
  // O cenario volta 0,8 s depois do resultado (o golpe final acontece no fundo preto) ou na hora, se a disputa foi
  // cancelada / saiu da luta / comecou uma cena.
  // So a fase da disputa decide: um Supremo de outra dupla (permitido no 3v3) nao religa o cenario; se o Supremo
  // envolver os dois, a disputa e cancelada e o cenario volta por esse caminho.
  // Como no Storm 1: no resultado a imagem volta para a arena (o golpe final acontece no cenario), depois do clarao.
  const bool keepBlack = g_clash.phase == clash::Phase::Active ||
                         (g_clash.resultAt && g_clash.result >= 0 && now - g_clash.resultAt < 220 &&
                          (g_clash.phase == clash::Phase::Resolving || g_clash.phase == clash::Phase::Finished));
  if (g_backgroundOffBy && !keepBlack) {
    // Religa com um lutador valido desta luta (o mesmo, se ainda estiver na luta).
    uintptr_t who = 0;
    for (int k = 0; k < n && !who; ++k)
      if (f[k].valid && f[k].player == g_backgroundOffBy) who = f[k].player;
    for (int k = 0; k < n && !who; ++k)
      if (f[k].valid) who = f[k].player;
    if (who && clash3d::BackgroundDraw(who, true)) Log("JUTSU CLASH 3D: cenario religado.");
    g_backgroundOffBy = 0;
  }
  // DIAGNOSTICO 3D: estado e animacao dos dois do teste/da disputa a cada ~80 ms.
  if (g_traceUntil && now < g_traceUntil && now >= g_traceNext) {
    g_traceNext = now + 80;
    int sa = -1, sb = -1;
    for (int k = 0; k < n; ++k) {
      if (f[k].player == g_traceA) sa = f[k].state;
      if (f[k].player == g_traceB) sb = f[k].state;
    }
    Log("TRACE3D: J%d estado 0x%X anm %d (%.3f) | J%d estado 0x%X anm %d (%.3f)", g_traceNumA, sa,
        clash3d::CurrentAnm(g_traceA), clash3d::AnmValue(g_traceA), g_traceNumB, sb, clash3d::CurrentAnm(g_traceB),
        clash3d::AnmValue(g_traceB));
  }
  // TESTE 2: 0,3 s depois de mandar soltar, se os dois ainda estao no jutsu, abre a disputa ali mesmo.
  if (g_forceA && now - g_lastForce >= 300) {
    int sa = -1, sb = -1;
    for (int k = 0; k < n; ++k) {
      if (f[k].player == g_forceA) sa = f[k].state;
      if (f[k].player == g_forceB) sb = f[k].state;
    }
    if (clash::JutsuState(sa) && clash::JutsuState(sb) && !g_request.a && g_clash.phase != clash::Phase::Active &&
        g_clash.phase != clash::Phase::Resolving) {
      g_request = {g_forceA, g_forceB, sa, sb, -1, -1, now};
      g_forcedRequest = true;
      Log("JUTSU CLASH TESTE: disputa aberta no meio do jutsu (estados 0x%X / 0x%X).", sa, sb);
    } else {
      Log("JUTSU CLASH TESTE: disputa nao aberta (estados 0x%X / 0x%X).", sa, sb);
    }
    g_forceA = g_forceB = 0;
  }
  // TESTE: forca dois adversarios a soltarem o jutsu juntos.
  if (g_forceTest.load(std::memory_order_relaxed) && !sceneActive && g_clash.phase != clash::Phase::Active &&
      g_clash.phase != clash::Phase::Resolving && !g_request.a && g_battleStartedAt &&
      now - g_battleStartedAt > 6000 && now - g_lastForce > 10000) {
    // Livre para o teste: parado, andando, correndo ou num golpe comum (nao em dano, agarrao, jutsu ou cena).
    auto isFree = [](int s) { return s == 0x1 || (s >= 0xA && s <= 0x17) || (s >= 0x3F && s <= 0x43); };
    int ta = -1, tb = -1;
    float best = 1e9f;
    for (int k = 0; k < n; ++k)
      if (f[k].valid && f[k].side == 0 && isFree(f[k].state)) { ta = k; break; }
    for (int k = 0; ta >= 0 && k < n; ++k) {
      if (!f[k].valid || f[k].side != 1 || !isFree(f[k].state)) continue;
      const float dx = f[k].pos[0] - f[ta].pos[0], dy = f[k].pos[1] - f[ta].pos[1], d2 = dx * dx + dy * dy;
      if (d2 < best) { best = d2; tb = k; }
    }
    if (ta >= 0 && tb >= 0) {
      g_lastForce = now;
      if (g_forceTest.load() == 2) {
        // Poe o adversario de frente a 260 (na linha entre os dois) antes de mandar soltar.
        float dx = f[tb].pos[0] - f[ta].pos[0], dy = f[tb].pos[1] - f[ta].pos[1];
        const float len = std::sqrt(dx * dx + dy * dy);
        if (len > 1.0f) {
          dx /= len;
          dy /= len;
        } else {
          dx = 1.0f;
          dy = 0.0f;
        }
        const float nearPos[3] = {f[ta].pos[0] + dx * 260.0f, f[ta].pos[1] + dy * 260.0f, f[ta].pos[2]};
        WritePos(f[tb].player, nearPos);
        FaceToward(f[tb].player, nearPos[0] + dx * 500.0f, nearPos[1] + dy * 500.0f);  // de costas (caso do usuario)
        best = 260.0f * 260.0f;
        g_forceA = f[ta].player;
        g_forceB = f[tb].player;
      }
      const bool okA = clash3d::SetActionNow(f[ta].player, clash::kSkillLand);
      const bool okB = clash3d::SetActionNow(f[tb].player, clash::kSkillLand);
      g_traceA = f[ta].player;
      g_traceB = f[tb].player;
      g_traceNumA = f[ta].number;
      g_traceNumB = f[tb].number;
      g_traceUntil = now + 2500;
      g_traceNext = now;
      Log("JUTSU CLASH TESTE: J%d e J%d mandados soltar jutsu juntos (a %.0f; %s/%s).", f[ta].number, f[tb].number,
          std::sqrt(best), okA ? "ok" : "falhou", okB ? "ok" : "falhou");
    }
  }

  if (g_clash.phase == clash::Phase::Active) {
    const int a = g_clash.a, b = g_clash.b;
    if (!f[a].valid || !f[b].valid) {
      End(f, clash::Phase::Cancelled, "participante fora da luta");
    } else if (sceneActive && SceneInvolves(f, a, b, n)) {
      End(f, clash::Phase::Cancelled, "Supremo envolvendo um dos dois (ou Supremo com cinematica)");
    } else if (DamageState(f[a].state) || DamageState(f[b].state)) {
      End(f, clash::Phase::Cancelled, "participante atingido por outro lutador");
    } else {
      SetControl(f[a].player, false);
      SetControl(f[b].player, false);
      // Le a entrada ANTES de mover os modelos: a energia precisa reagir no mesmo quadro
      // em que o jogador aperta B/Bolinha, inclusive com os atores pausados.
      const uint64_t elapsed = now - g_clash.startedAt;
      InputClashPollRaw(g_clash.padA, g_clash.padB);
      PollPhysicalMash();
      const unsigned rate = g_cpuRate.load(std::memory_order_relaxed);
      const int primary = g_clash.padA >= 0 && (g_clash.padB < 0 || g_clash.padA <= g_clash.padB) ? g_clash.padA
                                                                                               : g_clash.padB;
      g_clash.scoreA = g_clash.padA >= 0
                           ? std::max(g_bCount[g_clash.padA].load() - g_clash.baseA, PhysicalScore(g_clash.padA, primary))
                           : clash::CpuScore(elapsed, CpuAdaptMashRate(float(rate),f[a].player) * (g_clash.testBias ? 1.6f : 1.0f), g_clash.variationA);
      g_clash.scoreB = g_clash.padB >= 0
                           ? std::max(g_bCount[g_clash.padB].load() - g_clash.baseB, PhysicalScore(g_clash.padB, primary))
                           : clash::CpuScore(elapsed, CpuAdaptMashRate(float(rate),f[b].player), g_clash.variationB);
      // ---- animacao 3D dos dois
      const int mode = g_animMode.load(std::memory_order_relaxed);
      if (mode == 4) {
        // Prototipo de esforco corporal: reexecuta o ANM nativo registrado
        // no impacto e deixa o avaliador esqueleto processar poucos quadros,
        // depois pausa sem libertar controle do jogador. Repeticao periodica
        // da pose 3D (bracos/torso), nao apenas translacao de personagem.
        // Se a ANM nao for segura para o personagem, manter pose congelada.
        const uint64_t period = (now - g_clash.startedAt) % 640ULL;
        if (period < 110 && now - g_pose.lastLoop >= 535) {
          g_pose.lastLoop = now;
          const bool okA = g_pose.anmA >= 0 && clash3d::PlayAnm(f[a].player, g_pose.anmA);
          const bool okB = g_pose.anmB >= 0 && clash3d::PlayAnm(f[b].player, g_pose.anmB);
          if (okA && okB && g_pose.tick < 2)
            Log("JUTSU CLASH 3D #%u: loop de esforco esquelético reiniciado (ANM %d / %d).",
                g_clash.id, g_pose.anmA, g_pose.anmB);
          ++g_pose.tick;
        }
        const bool run = period < 160;
        if (run != g_pose.running) {
          CallVirtual(f[a].player, run ? 0xFF0 : 0xFF8);
          CallVirtual(f[b].player, run ? 0xFF0 : 0xFF8);
          g_pose.running = run;
        }
      } else if (mode == 1 && now - g_pose.lastToggle >= 260) {
        // Alterna a pose entre a fase do jutsu do choque e a seguinte (com o ator pausado).
        g_pose.lastToggle = now;
        g_pose.alt = !g_pose.alt;
        if (g_pose.anmA >= 0) clash3d::PlayAnm(f[a].player, g_pose.anmA + (g_pose.alt ? 1 : 0));
        if (g_pose.anmB >= 0) clash3d::PlayAnm(f[b].player, g_pose.anmB + (g_pose.alt ? 1 : 0));
      } else if (mode == 2) {
        // Camera lenta: o ator roda 1 quadro a cada 3 (retoma e pausa de novo); a cada 0,9 s a fase do choque recomeca,
        // antes de o jutsu chegar ao golpe. O bloqueio de trocas de estado continua valendo.
        ++g_pose.tick;
        const bool run = g_pose.tick % 3 == 0;
        if (run != g_pose.running) {
          CallVirtual(f[a].player, run ? 0xFF0 : 0xFF8);
          CallVirtual(f[b].player, run ? 0xFF0 : 0xFF8);
          g_pose.running = run;
        }
        if (now - g_pose.lastLoop >= 900) {
          g_pose.lastLoop = now;
          if (g_pose.anmA >= 0) clash3d::PlayAnm(f[a].player, g_pose.anmA);
          if (g_pose.anmB >= 0) clash3d::PlayAnm(f[b].player, g_pose.anmB);
        }
      }
      // ---- cabo de guerra Ultimate Ninja 5: ambos empurram o choque para o
      // lado perdedor. Inercia por tempo (nao por quadro) e resistencia inicial
      // evitam saltos gigantes quando um jogador aperta B antes do outro.
      std::memcpy(g_clash.posA, f[a].pos, sizeof(g_clash.posA));
      std::memcpy(g_clash.posB, f[b].pos, sizeof(g_clash.posB));
      if (g_slide.load(std::memory_order_relaxed)) {
        const uint64_t dt = g_pose.lastMotion && now >= g_pose.lastMotion ? now - g_pose.lastMotion : 16;
        g_pose.lastMotion = now;
        g_pose.push = clash_motion::Step(g_pose.push,
                                        clash_motion::Target(g_clash.scoreA, g_clash.scoreB), dt);
        float ux = g_pose.baseB[0] - g_pose.baseA[0], uy = g_pose.baseB[1] - g_pose.baseA[1];
        const float len = std::sqrt(ux * ux + uy * uy);
        if (len > 1.0f) {
          ux /= len;
          uy /= len;
          // O choque nao reinicia a tecnica. Uma pequena vibracao das maos
          // deixa o esforco visivel sem descolar os efeitos do contato 3D.
          float shakeA = 0.0f, shakeB = 0.0f;
          if (mode == 3 || mode == 4) {
            const float tt = float(now % 100000);
            shakeA = std::sin(tt * 0.031f) * 3.0f + std::sin(tt * 0.093f) * 1.1f;
            shakeB = std::sin(tt * 0.031f + 2.3f) * 3.0f + std::sin(tt * 0.087f + 1.0f) * 1.1f;
          }
          const float pa[3] = {g_pose.baseA[0] + ux * (g_pose.push + shakeA),
                               g_pose.baseA[1] + uy * (g_pose.push + shakeA), g_pose.baseA[2]};
          const float pb[3] = {g_pose.baseB[0] + ux * (g_pose.push - shakeB),
                               g_pose.baseB[1] + uy * (g_pose.push - shakeB), g_pose.baseB[2]};
          WritePos(f[a].player, pa);
          WritePos(f[b].player, pb);
          // HUD e camera usam AS MESMAS posicoes ja aplicadas aos modelos,
          // sem um quadro de atraso nem o efeito atravessando as maos.
          std::memcpy(g_clash.posA, pa, sizeof(g_clash.posA));
          std::memcpy(g_clash.posB, pb, sizeof(g_clash.posB));
        }
        FaceToward(f[a].player, g_clash.posB[0], g_clash.posB[1]);
        FaceToward(f[b].player, g_clash.posA[0], g_clash.posA[1]);
      }
      g_clash.hasPos = true;
      if (elapsed >= g_durationMs.load(std::memory_order_relaxed)) {
        if (g_pose.running) {
          CallVirtual(f[a].player, 0xFF8);
          CallVirtual(f[b].player, 0xFF8);
          g_pose.running = false;
        }
        g_recentResolvedAt = now;
        g_recentResolvedA = f[a].player;
        g_recentResolvedB = f[b].player;
        if (g_clash.scoreA == 0 && g_clash.scoreB == 0 && (g_clash.padA >= 0 || g_clash.padB >= 0))
          Log("JUTSU CLASH #%u: nenhum aperto B detectado (pads %d,%d). Verificar entrada fisica.",
              g_clash.id, g_clash.padA + 1, g_clash.padB + 1);
        g_protectA = 0;
        g_protectB = 0;
        if (g_discarded.load()) Log("JUTSU CLASH #%u: %u golpes de terceiros descartados durante a disputa.", g_clash.id,
                                    g_discarded.exchange(0));
        g_clash.result = clash::Winner(g_clash.scoreA, g_clash.scoreB);
        g_clash.bannerUntil = now + 2200;
        g_clash.resultAt = now;
        if (g_clash.result == 0) {
          const int both[2] = {a, b};
          for (int k : both) {
            CallVirtual(f[k].player, 0xFF0);
            SetControl(f[k].player, true);
          }
          g_clash.phase = clash::Phase::Finished;
          Damage(a, g_clash.numberA);
          Damage(b, g_clash.numberB);
          ChangeState(f[a].player, clash::kLoserState);
          ChangeState(f[b].player, clash::kLoserState);
          Log("JUTSU CLASH #%u: EMPATE %u x %u; os jutsus explodem e J%d e J%d levam dano.", g_clash.id,
              g_clash.scoreA, g_clash.scoreB, g_clash.numberA, g_clash.numberB);
        } else {
          // O vencedor volta a se mexer NO MEIO do proprio jutsu: o jutsu segue e pode acertar o perdedor de verdade
          // (golpe nativo). O perdedor fica parado, sem protecao, ate 0,4 s esperando esse acerto.
          const int winner = g_clash.result == 1 ? a : b;
          const int loser = winner == a ? b : a;
          if (g_slide.load(std::memory_order_relaxed)) {
            // Finalizacao: o perdedor fica a 140 na frente do vencedor (na linha do choque) antes de o jutsu do
            // vencedor continuar, para o golpe final ser o acerto NATIVO do jogo (animacao de dano real).
            float dx = f[loser].pos[0] - f[winner].pos[0], dy = f[loser].pos[1] - f[winner].pos[1];
            const float len = std::sqrt(dx * dx + dy * dy);
            if (len > 140.0f) {
              dx /= len;
              dy /= len;
              const float to[3] = {f[winner].pos[0] + dx * 140.0f, f[winner].pos[1] + dy * 140.0f, f[loser].pos[2]};
              WritePos(f[loser].player, to);
              Log("JUTSU CLASH 3D #%u: J%d trazido para a frente do jutsu de J%d (%.0f -> 140).", g_clash.id,
                  f[loser].number, f[winner].number, len);
            }
          }
          CallVirtual(f[winner].player, 0xFF0);
          SetControl(f[winner].player, true);
          if (g_slide.load(std::memory_order_relaxed)) {
            // Golpe final como no Storm 1: o vencedor solta o jutsu de novo, a queima-roupa (troca de acao nativa).
            // O jutsu do choque ja passou da fase de acerto depois de 7 s; sem isto o golpe nao alcancava.
            const int jutsu = winner == a ? g_clash.stateA : g_clash.stateB;
            PromoteSetTarget(winner, loser);  // o jutsu (avanco/projetil) persegue o alvo: tem que ser o perdedor
            FaceToward(f[winner].player, f[loser].pos[0], f[loser].pos[1]);
            FaceToward(f[loser].player, f[winner].pos[0], f[winner].pos[1]);
            g_clash.recast = clash::JutsuState(jutsu) && clash3d::SetActionNow(f[winner].player, jutsu);
            if (g_clash.recast) {
              // Ator pausado nao e atingido: o perdedor volta a rodar, sem controle, parado em pe na frente do jutsu.
              CallVirtual(f[loser].player, 0xFF0);
              g_clash.loserResumed = true;
              SetControl(f[loser].player, false);
              clash3d::SetActionNow(f[loser].player, 0x1);
            }
            if (g_clash.recast)
              Log("JUTSU CLASH 3D #%u: J%d solta o jutsu (0x%X) de novo no golpe final.", g_clash.id, f[winner].number,
                  jutsu);
          }
          g_clash.phase = clash::Phase::Resolving;
          g_clash.resolveAt = now;
          Log("JUTSU CLASH #%u: J%d VENCEU %u x %u; o jutsu dele segue contra J%d.", g_clash.id,
              f[winner].number, g_clash.result == 1 ? g_clash.scoreA : g_clash.scoreB,
              g_clash.result == 1 ? g_clash.scoreB : g_clash.scoreA, f[winner == a ? b : a].number);
        }
      }
    }
    Publish(now);
    return;
  }

  if (g_clash.phase == clash::Phase::Resolving) {
    const int winner = g_clash.result == 1 ? g_clash.a : g_clash.b;
    const int loser = winner == g_clash.a ? g_clash.b : g_clash.a;
    // Acerto do jogo: dano comum (0x18..0x3C) ou dano de golpe com cena - jutsu que conecta (0x50 DIRECTION_DMG) ou
    // Supremo (0x51). Antes o 0x50 nao contava: o mod achava que o golpe nao tinha alcancado e cortava a cena do jogo
    // com o dano/empurrao alternativo.
    const int loserState = f[loser].valid ? f[loser].state : -1;
    const bool sceneHit = loserState == 0x50 || loserState == 0x51;
    const bool nativeHit = f[loser].valid && (DamageState(loserState) || sceneHit);
    if (nativeHit || !f[loser].valid || now - g_clash.resolveAt >= (g_clash.recast ? 1500u : 400u) ||
        (sceneActive && SceneInvolves(f, winner, loser, n))) {
      if (f[loser].valid) {
        if (!g_clash.loserResumed) CallVirtual(f[loser].player, 0xFF0);
        if (!sceneHit) SetControl(f[loser].player, true);  // na cena do golpe o jogo devolve o controle no fim
      }
      if (nativeHit) {
        Log("JUTSU CLASH #%u: o jutsu de J%d acertou J%d (golpe do jogo, estado 0x%X).", g_clash.id, f[winner].number,
            f[loser].number, f[loser].state);
      } else if (f[loser].valid) {
        Damage(loser, f[loser].number);
        ChangeState(f[loser].player, clash::kLoserState);
        Log("JUTSU CLASH #%u: o jutsu de J%d nao alcancou; J%d leva o dano da disputa e e empurrado.", g_clash.id,
            f[winner].number, f[loser].number);
      }
      g_clash.phase = clash::Phase::Finished;
    }
    Publish(now);
    return;
  }

  Publish(now);
  if (!g_request.a) return;
  const StartRequest request = g_request;
  g_request = {};
  if (!g_enabled.load(std::memory_order_relaxed) || now - request.at > 200) {
    ApplyOffset(request.a, request.actionA);
    ApplyOffset(request.b, request.actionB);
    return;
  }
  int a = -1, b = -1;
  for (int k = 0; k < n; ++k) {
    if (f[k].player == request.a) a = k;
    if (f[k].player == request.b) b = k;
  }
  if (a < 0 || b < 0 || !f[a].valid || !f[b].valid || f[a].side == f[b].side) {
    // Nao e uma disputa valida: aplica o empurrao que o jogo ia aplicar.
    ApplyOffset(request.a, request.actionA);
    ApplyOffset(request.b, request.actionB);
    return;
  }
  if (sceneActive && SceneInvolves(f, a, b, n)) {
    ApplyOffset(request.a, request.actionA);
    ApplyOffset(request.b, request.actionB);
    Log("JUTSU CLASH: choque J%d x J%d ignorado (Supremo envolvendo um dos dois).", f[a].number, f[b].number);
    return;
  }
  if (clash::RepeatPair(request.a, request.b, g_recentResolvedA, g_recentResolvedB,
                        now, g_recentResolvedAt)) {
    ApplyOffset(request.a, request.actionA);
    ApplyOffset(request.b, request.actionB);
    Log("JUTSU CLASH: segunda colisao do mesmo par suprimida (jutsu ja resolvido).");
    return;
  }
  const float dx = f[a].pos[0] - f[b].pos[0], dy = f[a].pos[1] - f[b].pos[1];
  g_clash = {};
  g_clash.phase = clash::Phase::CollisionDetected;
  g_clash.id = g_nextId++;
  g_clash.a = a;
  g_clash.b = b;
  g_clash.numberA = f[a].number;
  g_clash.numberB = f[b].number;
  g_clash.padA = f[a].pad;
  g_clash.padB = f[b].pad;
  g_clash.stateA = request.stateA;
  g_clash.stateB = request.stateB;
  g_clash.baseA = g_clash.padA >= 0 ? g_bCount[g_clash.padA].load() : 0;
  g_clash.baseB = g_clash.padB >= 0 ? g_bCount[g_clash.padB].load() : 0;
  PollPhysicalMash();  // estado atual (segurando no inicio nao conta como aperto)
  std::memcpy(g_physBase, g_physCount, sizeof(g_physBase));
  for (int s = 0; s < 7; ++s) {
    g_clash.variationA[s] = Variation();
    g_clash.variationB[s] = Variation();
  }
  Log("JUTSU CLASH #%u: colisao J%d (personagem %d, 0x%X) x J%d (personagem %d, 0x%X) a %.0f; %s x %s; os dois "
      "ficam na pose do jutsu.",
      g_clash.id, g_clash.numberA, CharacterId(f[a].player), request.stateA, g_clash.numberB,
      CharacterId(f[b].player), request.stateB, std::sqrt(dx * dx + dy * dy), g_clash.padA >= 0 ? "jogador" : "CPU",
      g_clash.padB >= 0 ? "jogador" : "CPU");
  SetControl(f[a].player, false);
  SetControl(f[b].player, false);
  if (!CallVirtual(f[a].player, 0xFF8) || !CallVirtual(f[b].player, 0xFF8)) {
    End(f, clash::Phase::Cancelled, "nao foi possivel travar os dois");
    return;
  }
  g_clash.phase = clash::Phase::Active;
  g_clash.startedAt = now;
  g_clash.testBias = g_forcedRequest;
  g_forcedRequest = false;
  g_discarded = 0;
  g_pose = {};
  g_pose.anmA = clash3d::CurrentAnm(f[a].player);
  g_pose.anmB = clash3d::CurrentAnm(f[b].player);
  std::memcpy(g_pose.baseA, f[a].pos, sizeof(g_pose.baseA));
  std::memcpy(g_pose.baseB, f[b].pos, sizeof(g_pose.baseB));
  if (g_slide.load(std::memory_order_relaxed)) {
    // Como no Storm 1: os dois frente a frente, com os jutsus encostando (170 entre eles), em volta do ponto medio.
    float ux = g_pose.baseB[0] - g_pose.baseA[0], uy = g_pose.baseB[1] - g_pose.baseA[1];
    const float len = std::sqrt(ux * ux + uy * uy);
    if (len > 175.0f) {
      ux /= len;
      uy /= len;
      const float midX = (g_pose.baseA[0] + g_pose.baseB[0]) * 0.5f, midY = (g_pose.baseA[1] + g_pose.baseB[1]) * 0.5f;
      g_pose.baseA[0] = midX - ux * 85.0f;
      g_pose.baseA[1] = midY - uy * 85.0f;
      g_pose.baseB[0] = midX + ux * 85.0f;
      g_pose.baseB[1] = midY + uy * 85.0f;
      WritePos(f[a].player, g_pose.baseA);
      WritePos(f[b].player, g_pose.baseB);
      Log("JUTSU CLASH 3D #%u: os dois aproximados para o contato (%.0f -> 170).", g_clash.id, len);
    }
    FaceToward(f[a].player, g_pose.baseB[0], g_pose.baseB[1]);
    FaceToward(f[b].player, g_pose.baseA[0], g_pose.baseA[1]);
  }
  g_pose.lastToggle = g_pose.lastLoop = g_pose.lastMotion = now;
  if (g_animMode.load(std::memory_order_relaxed) == 4) g_pose.lastLoop = now - 800;
  Log("JUTSU CLASH 3D #%u: animacao no choque J%d anm %d (%.3f), J%d anm %d (%.3f).", g_clash.id, f[a].number,
      clash3d::CurrentAnm(f[a].player), clash3d::AnmValue(f[a].player), f[b].number, clash3d::CurrentAnm(f[b].player),
      clash3d::AnmValue(f[b].player));
  if (g_blackBackground.load(std::memory_order_relaxed) && clash3d::BackgroundDraw(f[a].player, false)) {
    g_backgroundOffBy = f[a].player;
    Log("JUTSU CLASH 3D #%u: cenario desligado (fundo preto, personagens visiveis).", g_clash.id);
  }
  g_traceA = f[a].player;
  g_traceB = f[b].player;
  g_traceNumA = f[a].number;
  g_traceNumB = f[b].number;
  g_traceUntil = now + 1500;
  g_traceNext = now;
  if (g_protect.load(std::memory_order_relaxed)) {
    g_protectA = f[a].player;
    g_protectB = f[b].player;
  }
  Publish(now);
}

bool JutsuClashProtects(uintptr_t player) {
  if (!player) return false;
  const bool hit = player == g_protectA.load(std::memory_order_acquire) ||
                   player == g_protectB.load(std::memory_order_acquire);
  if (hit) g_discarded.fetch_add(1, std::memory_order_relaxed);
  return hit;
}

bool JutsuClashHud(ClashHud* out) {
  AcquireSRWLockShared(&g_hudLock);
  const bool visible = g_hudVisible;
  if (visible && out) *out = g_hud;
  ReleaseSRWLockShared(&g_hudLock);
  return visible;
}
