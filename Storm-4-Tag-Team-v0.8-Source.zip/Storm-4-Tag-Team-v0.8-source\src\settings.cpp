#include "settings.h"

#include <string>
#include <vector>

#include <windows.h>

#include <cstdio>
#include <cstring>
#include <string>

#include "log.h"

namespace {
Settings g_cfg;
std::wstring Path() { return ModDir() + L"storm6.ini"; }

int ReadSlotControl(int slot, int value) {
  if (value == kSlotPlayer) {
    // Nas configuracoes anteriores so os lideres podiam usar um controle.
    if (slot == 0) return kSlotPlayer1;
    if (slot == 3) return kSlotPlayer2;
    return kSlotCpu;
  }
  return value == kSlotCpu || SlotPadIndex(value) >= 0 ? value : kSlotAuto;
}
}  // namespace

Settings& Cfg() { return g_cfg; }

void SettingsLoad() {
  FILE* f = _wfopen(Path().c_str(), L"r");
  if (!f) {
    // Compatibilidade: antes do menu, o arquivo storm6_3v3.txt ligava o modo.
    std::wstring flag = ModDir() + L"storm6_3v3.txt";
    g_cfg.mode3v3 = GetFileAttributesW(flag.c_str()) != INVALID_FILE_ATTRIBUTES;
    SettingsSave();
  } else {
    char line[128];
    int legacyCamera = kCameraTournament, camera = -1;
    while (std::fgets(line, sizeof(line), f)) {
      char key[64];
      int v;
      if (std::sscanf(line, "%63[^=]=%d", key, &v) != 2) continue;
      if (!std::strcmp(key, "modo3v3")) g_cfg.mode3v3 = v != 0;
      else if (!std::strcmp(key, "free_for_all")) g_cfg.freeForAll = v != 0;
      else if (!std::strcmp(key, "hud")) g_cfg.hud = v != 0;
      else if (!std::strcmp(key, "lockon")) g_cfg.lockon = v != 0;
      else if (!std::strcmp(key, "lockon_estilo")) g_cfg.lockonStyle = v == 2 ? 2 : (v == 0 ? 0 : 1);
      else if (!std::strcmp(key, "camera_grupo")) legacyCamera = v ? kCameraTournament : kCameraDuel;
      else if (!std::strcmp(key, "camera") && v >= kCameraDuel && v <= kCameraRevolution) camera = v;
      else if (!std::strcmp(key, "ringue")) g_cfg.ring = v != 0;
      else if (!std::strcmp(key, "cpu_adversario_real")) g_cfg.cpuRealOpponent = v != 0;
      else if (!std::strcmp(key, "ultimates_livres")) g_cfg.ultFree = v != 0;
      else if (!std::strcmp(key, "despertar_inicio")) g_cfg.awakenAtStart = v != 0;
      else if (!std::strcmp(key, "team_ultimate")) g_cfg.teamUltimate = v != 0;
      else if (!std::strcmp(key, "team_ultimate_button")) g_cfg.teamUltimateButton = v == 1 ? 1 : 0;
      else if (!std::strcmp(key, "selecao_p2")) g_cfg.selectP2 = v != 0;
      else if (!std::strcmp(key, "jutsu_clash")) g_cfg.jutsuClash = v != 0;
      else if (std::strlen(key) == 2 && key[0] == 'J' && key[1] >= '1' && key[1] <= '6') {
        const int slot = key[1] - '1';
        g_cfg.slot[slot] = ReadSlotControl(slot, v);
      }
    }
    g_cfg.camera = camera >= 0 ? camera : legacyCamera;
    std::fclose(f);
    // FFA is a variant of the simultaneous fighter setup, never the vanilla 1v1.
    if (g_cfg.freeForAll.load()) g_cfg.mode3v3 = true;
    bool assigned[4] = {};
    for (auto& slot : g_cfg.slot) {
      const int pad = SlotPadIndex(slot.load());
      if (pad < 0) continue;
      if (assigned[pad]) slot = kSlotCpu;
      assigned[pad] = true;
    }
  }
  Log("Opcoes: modo3v3=%d hud=%d lockon=%d", int(g_cfg.mode3v3), int(g_cfg.hud), int(g_cfg.lockon));
}

// Linhas "chave=valor" do storm6.ini que o menu nao conhece (ex.: jutsu_clash_dano, defesa_agarrao_janela_ms,
// opcoes de teste). Antes o menu reescrevia o arquivo so com as suas chaves e apagava essas linhas.
std::vector<std::string> UnknownLines() {
  static const char* const kKnown[] = {"modo3v3", "hud", "lockon", "camera", "ringue", "free_for_all",
                                       "cpu_adversario_real", "lockon_estilo", "ultimates_livres", "selecao_p2",
                                       "despertar_inicio", "team_ultimate", "team_ultimate_button", "jutsu_clash",
                                       "J1", "J2", "J3", "J4", "J5", "J6"};
  std::vector<std::string> keep;
  FILE* in = _wfopen(Path().c_str(), L"r");
  if (!in) return keep;
  char line[256];
  while (std::fgets(line, sizeof(line), in)) {
    std::string text(line);
    while (!text.empty() && (text.back() == '\n' || text.back() == '\r')) text.pop_back();
    const size_t eq = text.find('=');
    if (text.empty() || text[0] == ';' || eq == std::string::npos || eq == 0) continue;
    const std::string key = text.substr(0, eq);
    bool known = false;
    for (const char* k : kKnown) known = known || key == k;
    if (!known) keep.push_back(text);
  }
  std::fclose(in);
  return keep;
}

void SettingsSave() {
  const std::vector<std::string> extra = UnknownLines();
  FILE* f = _wfopen(Path().c_str(), L"w");
  if (!f) return;
  std::fprintf(f, "; Storm 6 - opcoes (use o menu no jogo: F1 ou SELECT fora da luta)\n");
  std::fprintf(f, "modo3v3=%d\nhud=%d\nlockon=%d\ncamera=%d\nringue=%d\n", int(g_cfg.mode3v3),
               int(g_cfg.hud), int(g_cfg.lockon), g_cfg.camera.load(), int(g_cfg.ring));
  std::fprintf(f, "free_for_all=%d\n", int(g_cfg.freeForAll));
  std::fprintf(f, "cpu_adversario_real=%d\n", int(g_cfg.cpuRealOpponent));
  std::fprintf(f, "lockon_estilo=%d\n", g_cfg.lockonStyle.load());
  std::fprintf(f, "ultimates_livres=%d\nselecao_p2=%d\n", int(g_cfg.ultFree), int(g_cfg.selectP2));
  std::fprintf(f, "despertar_inicio=%d\n", int(g_cfg.awakenAtStart));
  std::fprintf(f, "team_ultimate=%d\nteam_ultimate_button=%d\n", int(g_cfg.teamUltimate), g_cfg.teamUltimateButton.load());
  std::fprintf(f, "jutsu_clash=%d\n", int(g_cfg.jutsuClash));
  std::fprintf(f, "; J1..J6: 0 = automatico, 2 = CPU, 3..6 = Player 1..4\n");
  for (int i = 0; i < 6; ++i) std::fprintf(f, "J%d=%d\n", i + 1, g_cfg.slot[i].load());
  if (!extra.empty()) std::fprintf(f, "; outras opcoes (mantidas pelo menu)\n");
  for (const std::string& line : extra) std::fprintf(f, "%s\n", line.c_str());
  std::fclose(f);
}
