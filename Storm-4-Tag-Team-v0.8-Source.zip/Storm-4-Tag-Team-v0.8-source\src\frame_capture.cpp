#include "frame_capture.h"

#include <windows.h>
#include <d3d11.h>
#include <wincodec.h>
#include <wrl/client.h>

#include <cstdio>
#include <mutex>
#include <string>
#include <vector>

#include "census.h"
#include "log.h"

using Microsoft::WRL::ComPtr;

namespace {
std::mutex g_mutex;
std::wstring g_pending;
unsigned g_frame = 0;

bool SavePng(const std::wstring& path, UINT width, UINT height, const std::vector<uint8_t>& bgra) {
  ComPtr<IWICImagingFactory> factory;
  if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory))))
    return false;
  ComPtr<IWICStream> stream;
  if (FAILED(factory->CreateStream(&stream)) || FAILED(stream->InitializeFromFilename(path.c_str(), GENERIC_WRITE)))
    return false;
  ComPtr<IWICBitmapEncoder> encoder;
  if (FAILED(factory->CreateEncoder(GUID_ContainerFormatPng, nullptr, &encoder)) ||
      FAILED(encoder->Initialize(stream.Get(), WICBitmapEncoderNoCache)))
    return false;
  ComPtr<IWICBitmapFrameEncode> frame;
  if (FAILED(encoder->CreateNewFrame(&frame, nullptr)) || FAILED(frame->Initialize(nullptr)) ||
      FAILED(frame->SetSize(width, height)))
    return false;
  WICPixelFormatGUID format = GUID_WICPixelFormat32bppBGRA;
  if (FAILED(frame->SetPixelFormat(&format))) return false;
  if (FAILED(frame->WritePixels(height, width * 4, static_cast<UINT>(bgra.size()), const_cast<BYTE*>(bgra.data()))))
    return false;
  return SUCCEEDED(frame->Commit()) && SUCCEEDED(encoder->Commit());
}

void Capture(IDXGISwapChain* sc, const std::wstring& path) {
  ComPtr<ID3D11Texture2D> back;
  if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(back.GetAddressOf())))) return;
  ComPtr<ID3D11Device> dev;
  back->GetDevice(&dev);
  ComPtr<ID3D11DeviceContext> ctx;
  dev->GetImmediateContext(&ctx);
  D3D11_TEXTURE2D_DESC desc{};
  back->GetDesc(&desc);
  ComPtr<ID3D11Texture2D> source = back;
  if (desc.SampleDesc.Count > 1) {  // backbuffer com MSAA: resolve antes de copiar
    D3D11_TEXTURE2D_DESC rd = desc;
    rd.SampleDesc.Count = 1;
    rd.SampleDesc.Quality = 0;
    rd.BindFlags = 0;
    rd.MiscFlags = 0;
    ComPtr<ID3D11Texture2D> resolved;
    if (FAILED(dev->CreateTexture2D(&rd, nullptr, &resolved))) return;
    ctx->ResolveSubresource(resolved.Get(), 0, back.Get(), 0, desc.Format);
    source = resolved;
  }
  D3D11_TEXTURE2D_DESC sd = desc;
  sd.SampleDesc.Count = 1;
  sd.SampleDesc.Quality = 0;
  sd.Usage = D3D11_USAGE_STAGING;
  sd.BindFlags = 0;
  sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
  sd.MiscFlags = 0;
  sd.MipLevels = 1;
  sd.ArraySize = 1;
  ComPtr<ID3D11Texture2D> staging;
  if (FAILED(dev->CreateTexture2D(&sd, nullptr, &staging))) return;
  ctx->CopyResource(staging.Get(), source.Get());
  D3D11_MAPPED_SUBRESOURCE map{};
  if (FAILED(ctx->Map(staging.Get(), 0, D3D11_MAP_READ, 0, &map))) return;
  const bool rgba = desc.Format == DXGI_FORMAT_R8G8B8A8_UNORM || desc.Format == DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
  const bool bgra = desc.Format == DXGI_FORMAT_B8G8R8A8_UNORM || desc.Format == DXGI_FORMAT_B8G8R8A8_UNORM_SRGB ||
                    desc.Format == DXGI_FORMAT_B8G8R8X8_UNORM;
  std::vector<uint8_t> pixels;
  if (rgba || bgra) {
    pixels.resize(static_cast<size_t>(desc.Width) * desc.Height * 4);
    for (UINT y = 0; y < desc.Height; ++y) {
      const uint8_t* src = static_cast<const uint8_t*>(map.pData) + static_cast<size_t>(y) * map.RowPitch;
      uint8_t* dst = pixels.data() + static_cast<size_t>(y) * desc.Width * 4;
      for (UINT x = 0; x < desc.Width; ++x) {
        dst[x * 4 + 0] = rgba ? src[x * 4 + 2] : src[x * 4 + 0];
        dst[x * 4 + 1] = src[x * 4 + 1];
        dst[x * 4 + 2] = rgba ? src[x * 4 + 0] : src[x * 4 + 2];
        dst[x * 4 + 3] = 255;
      }
    }
  }
  ctx->Unmap(staging.Get(), 0);
  if (pixels.empty()) {
    Log("CAPTURA: formato do quadro %d nao suportado.", static_cast<int>(desc.Format));
    return;
  }
  const HRESULT co = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
  const bool ok = SavePng(path, desc.Width, desc.Height, pixels);
  if (SUCCEEDED(co)) CoUninitialize();
  char narrow[MAX_PATH]{};
  WideCharToMultiByte(CP_UTF8, 0, path.c_str(), -1, narrow, sizeof(narrow), nullptr, nullptr);
  Log("CAPTURA: quadro do jogo %ux%u %s em %s", desc.Width, desc.Height, ok ? "salvo" : "FALHOU", narrow);
}
}  // namespace

void FrameCaptureRequest(const wchar_t* pngPath) {
  std::lock_guard<std::mutex> lock(g_mutex);
  g_pending = pngPath ? pngPath : L"";
}

void FrameCaptureOnPresent(IDXGISwapChain* sc) {
  // Gatilho por arquivo (para os roteiros de teste), conferido a cada 6 quadros.
  if (++g_frame % 6 == 0) {
    const std::wstring trigger = ModDir() + L"storm6_captura.txt";
    if (FILE* f = _wfopen(trigger.c_str(), L"r")) {
      wchar_t line[MAX_PATH]{};
      const bool got = std::fgetws(line, MAX_PATH, f) != nullptr;
      std::fclose(f);
      _wremove(trigger.c_str());
      if (got) {
        std::wstring path(line);
        while (!path.empty() && (path.back() == L'\n' || path.back() == L'\r' || path.back() == L' ')) path.pop_back();
        if (!path.empty()) FrameCaptureRequest(path.c_str());
      }
    }
  }
  std::wstring path;
  {
    std::lock_guard<std::mutex> lock(g_mutex);
    path.swap(g_pending);
  }
  if (path.empty() || !sc) return;
  Capture(sc, path);
}
