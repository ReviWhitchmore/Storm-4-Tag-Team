#pragma once
#include <cstdint>
#include "grab_defense.h"  // GrabFighterView: visao por quadro dos lutadores

// Fase 3 - Substituicao Perfeita (Evolution). storm6.ini: substituicao_perfeita=1,
// substituicao_perfeita_janela_ms=150. Substituicao que sai ate 0,15 s depois do golpe comecar (estados nativos
// DODGE_TO_WARP_* logo apos PL_ACT_DMG_*) reaparece AO LADO do atacante, sem ataque automatico nem cena.
// Fora da janela, a substituicao do jogo segue igual. A barra de substituicao nao e tocada.
void PerfectSubInstall();
void PerfectSubBeginBattle();
void PerfectSubTick(const GrabFighterView* fighters, int count, bool sceneActive, uint64_t now);
bool PerfectSubFeedback(int* number);
