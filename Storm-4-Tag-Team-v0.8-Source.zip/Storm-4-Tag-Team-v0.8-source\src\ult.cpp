// As cenas do jogo guardam lado e tipo. O mod associa cada entrada da fila
// aos lutadores que o motor usou para iniciar a cena.
#include "ult.h"

#include <windows.h>
#include <MinHook.h>
#include <intrin.h>

#include <atomic>
#include <cstring>

#include "addresses.h"
#include "census.h"
#include "cpu_adapt.h"
#include "jutsu_clash.h"
#include "log.h"
#include "menu.h"
#include "promote.h"
#include "ultimate_owner_rules.h"
#include "settings.h"

namespace {

using CamTrackFn = int (*)(void*);
using AnyDirectionFn = int (*)();
using SceneStartFn = uintptr_t (*)(int side, int type);
using TeamReadyFn = int (*)(void*);
using TeamGaugeFn = float (*)(void*);
CamTrackFn g_origCam = nullptr;
AnyDirectionFn g_origAny = nullptr;
SceneStartFn g_origScene = nullptr;
TeamReadyFn g_origTeamReady = nullptr;
TeamGaugeFn g_origTeamGauge = nullptr;
std::atomic<bool> g_teamHooks{false};
std::atomic<uint64_t> g_teamReadyCalls{0};
std::atomic<uint64_t> g_teamGaugeCalls{0};
// Cross-thread request only; gameplay state is changed on HookJudge's thread.
std::atomic<ULONGLONG> g_teamRequestTick[4] = {};
std::atomic<ULONGLONG> g_teamLastStart[4] = {};
ULONGLONG g_cpuTeamNext[6]{};  // CPU artificial team-ultimate decisions, judge thread
uint32_t g_cpuTeamRng = 0xC30741AFu;
unsigned CpuTeamRoll() {
 g_cpuTeamRng ^= g_cpuTeamRng << 13;
 g_cpuTeamRng ^= g_cpuTeamRng >> 17;
 g_cpuTeamRng ^= g_cpuTeamRng << 5;
 return g_cpuTeamRng;
}
constexpr ULONGLONG kTeamRequestMaxAgeMs = 700;
constexpr ULONGLONG kTeamCooldownMs = 4000;
uintptr_t g_sceneGlobal = 0;
std::atomic<uint64_t> g_freed{0};

constexpr int kMaxScenes = 32; // allow simultaneous scenes from up to six fighters
constexpr int kUltimate = 9;
constexpr int kTeamIntro = 11;
constexpr int kTeamUltimate = 12;

struct SceneNode {
  uintptr_t address;
  int state, type, side;
};

struct SceneActors {
  int side = -1;
  int owner = -1;
  int peer = -1;
};

struct SceneBinding {
  SceneNode node;
  SceneActors actors;
};

thread_local SceneBinding t_scenes[kMaxScenes];
thread_local int t_sceneCount = 0;
thread_local SceneActors t_startingScene;
// The ordinary ultimate starts with scene 8 (accurate RDI caster register).
// Scene 9 then often contains the native leader in RBX. Remember only one
// short-lived pre-ultimate scene per SIDE, never a cross-team global owner.
struct PendingUltimateOwner {
  int owner=-1;
  int victim=-1;
  ULONGLONG started=0;
};
thread_local PendingUltimateOwner t_preUltimateOwner[2]{};
thread_local bool t_inSceneStart = false;
// Ultima cinematica de Supremo (cena 9) criada: quando e o lado da vitima (diagnostico da Fase 1).
std::atomic<ULONGLONG> g_cinematicAt{0};
std::atomic<int> g_cinematicVictimSide{-1};
std::atomic<int> g_cinematicVictim{-1};
// Supremo preparado (cena 8) por lutador: vitima mirada e quando. Escrito na thread do jogo.
struct PreparedByFighter { int victim = -1; ULONGLONG at = 0; };
PreparedByFighter g_preparedBy[6]{};

struct TeamAttempt {
  int side = -1;
  int owner = -1;
  int ally = -1;
  ULONGLONG deadline = 0;
  ULONGLONG attackAt = 0;
  int sceneType = 0;
  bool allyUsed = false;
  bool chakraCharged = false;
  bool prolongedLogged = false;
  float position[3]{};
};
thread_local TeamAttempt t_team;

int HookTeamReady(void* player) {
  const uintptr_t site = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
  // The native team-ultimate override must never run when disabled or in FFA.
  // Otherwise a regular jutsu/attack query can be treated as a team super.
  if (Cfg().teamUltimate.load(std::memory_order_relaxed) &&
      !Cfg().freeForAll.load(std::memory_order_relaxed) &&
      g_teamHooks.load(std::memory_order_acquire) && PromoteBattleActive() &&
      (site == Addr().teamReadyChargeReturn || site == Addr().teamReadyAttackReturn)) {
    const int owner = PromoteFighterByPlayer(reinterpret_cast<uintptr_t>(player));
    if (owner >= 0) {
      const bool ready = t_team.ally < 0 && !UltSceneActive() && PromoteFullChakraAlly(owner) >= 0;
      const uint64_t n = g_teamReadyCalls.fetch_add(1, std::memory_order_relaxed);
      if (n < 5) Log("Team native readiness: caller=%llX owner=%d ready=%d",
                    static_cast<unsigned long long>(site), owner + 1, int(ready));
      return ready;
    }
  }
  return g_origTeamReady(player);
}

float HookTeamGauge(void* player) {
  const uintptr_t site = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
  if (Cfg().teamUltimate.load(std::memory_order_relaxed) &&
      !Cfg().freeForAll.load(std::memory_order_relaxed) &&
      g_teamHooks.load(std::memory_order_acquire) && site == Addr().teamGaugeAttackReturn &&
      PromoteBattleActive()) {
    const int owner = PromoteFighterByPlayer(reinterpret_cast<uintptr_t>(player));
    const int side = PromoteFighterSide(owner);
    if (side >= 0) {
      const int ally = PromoteFullChakraAlly(owner);
      if (ally < 0 || UltSceneActive() || t_team.ally >= 0) return 0.0f;
      t_team = {side, owner, ally, GetTickCount64() + 5000};
      g_teamGaugeCalls.fetch_add(1, std::memory_order_relaxed);
      PromoteTeamAllyPosition(ally, t_team.position);
      Log("Supremo em dupla: L%d e L%d com chakra cheio", owner + 1, ally + 1);
      return 100.0f;
    }
  }
  return g_origTeamGauge(player);
}

int ReadScenes(SceneNode (&out)[kMaxScenes]) {
  if (!g_sceneGlobal) return 0;
  __try {
    const auto manager = *reinterpret_cast<const uintptr_t*>(g_sceneGlobal);
    const auto head = manager ? *reinterpret_cast<const uintptr_t*>(manager + 8) : 0;
    if (!head) return 0;
    int count = 0;
    for (auto node = *reinterpret_cast<const uintptr_t*>(head);
         node && node != head && count < kMaxScenes;
         node = *reinterpret_cast<const uintptr_t*>(node)) {
      out[count++] = {node, *reinterpret_cast<const int*>(node + 0x38),
                      *reinterpret_cast<const int*>(node + 0x3C),
                      *reinterpret_cast<const int*>(node + 0x40)};
    }
    return count;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    static std::atomic<unsigned> readFaults{0};
    if (readFaults.fetch_add(1, std::memory_order_relaxed) < 3)
      Log("COMBAT GUARD: lista de cenas invalida durante transicao.");
    return 0;
  }
}
const SceneBinding* ActiveBinding(bool onlyOne = false, int forSide = -1) {
  if (!t_sceneCount) return nullptr;
  SceneNode list[kMaxScenes];
  const int count = ReadScenes(list);
  if (onlyOne && count != 1) return nullptr;
  const SceneBinding* found = nullptr;
  for (int i = 0; i < count; ++i) {
    const SceneNode& node = list[i];
    if (node.state != 0 || (forSide >= 0 && node.side != forSide)) continue;
    for (int j = 0; j < t_sceneCount; ++j) {
      const SceneNode& tracked = t_scenes[j].node;
      if (tracked.address == node.address && tracked.type == node.type && tracked.side == node.side) {
        // More than one active scene for this side is ambiguous. Return the
        // original game routing rather than bind damage/animation to the wrong actor.
        if (found && found != &t_scenes[j]) return nullptr;
        found = &t_scenes[j];
      }
    }
  }
  return found;
}

bool TeamSceneRunning(int side) {
  SceneNode list[kMaxScenes];
  const int count = ReadScenes(list);
  for (int i = 0; i < count; ++i)
    if (list[i].state == 0 && list[i].side == side &&
        (list[i].type == kTeamIntro || list[i].type == kTeamUltimate))
      return true;
  return false;
}

bool BindNewScene(int side, int type, const SceneActors& actors, const SceneNode* previous, int previousCount) {
  SceneNode list[kMaxScenes];
  const int count = ReadScenes(list);
  int kept = 0;
  for (int i = 0; i < t_sceneCount; ++i) {
    const auto& tracked = t_scenes[i].node;
    for (int j = 0; j < count; ++j) {
      if (list[j].address != tracked.address || list[j].type != tracked.type || list[j].side != tracked.side)
        continue;
      t_scenes[kept++] = t_scenes[i];
      break;
    }
  }
  t_sceneCount = kept;
  if (actors.owner < 0 || t_sceneCount == kMaxScenes) return false;

  const SceneNode* added = nullptr;
  for (int i = 0; i < count; ++i) {
    const SceneNode& node = list[i];
    if (node.side != side || node.type != type) continue;
    bool alreadyPresent = false;
    for (int j = 0; j < previousCount; ++j) alreadyPresent |= previous[j].address == node.address;
    if (alreadyPresent) continue;
    if (added) return false;  // a chamada nao identificou uma unica entrada nova
    added = &node;
  }
  if (!added) return false;
  t_scenes[t_sceneCount++] = {*added, actors};
  Log("Cena: tipo=%d lado=%d, par nativo L%d/L%d", type, side, actors.owner + 1, actors.peer + 1);
  return true;
}

SceneActors ReadActors(int side, int type, const uintptr_t* regs, uintptr_t site) {
  const GameAddrs& addrs = Addr();
  int ownerReg = -1, peerReg = -1;
  if (type == 3 && site == addrs.hitSceneReturn) {
    ownerReg = 0;  // RBX, atingido
    peerReg = 7;   // R15, atacante
  } else if (type == 8 && site == addrs.preUltimateSceneReturn) {
    ownerReg = 1;  // RDI
    peerReg = 0;   // RBX
  } else if (type == kUltimate && site == addrs.ultimateSceneReturn) {
    ownerReg = 0;  // RBX
    peerReg = 1;   // RDI
  } else if ((type == kTeamIntro && site == addrs.teamIntroReturn) ||
             (type == kTeamUltimate && site == addrs.teamSceneReturn)) {
    const int owner = PromoteFighterByPlayer(regs[1]);  // RDI
    if (owner < 0 || t_team.side != side || t_team.owner != owner) return {};
    const int peer = type == kTeamUltimate ? PromoteTeamHitVictim(owner) : PromoteTargetOf(owner);
    if (PromoteFighterSide(peer) != 1 - side) return {};
    t_team.sceneType = type;
    if (type == kTeamUltimate && !t_team.attackAt) t_team.attackAt = GetTickCount64();
    return {side, owner, peer};
  }
  if (ownerReg < 0) return {};
  // All fighters (player and CPU) are identified by their actual game object,
  // not the gamepad that happens to control them. CPU ultimates can have a
  // different victim register context; preserve the caster if unambiguous.
  const int owner = PromoteFighterByPlayer(regs[ownerReg]);
  if (PromoteFighterSide(owner) != side) return {};
  int peer = PromoteFighterByPlayer(regs[peerReg]);
  if (PromoteFighterSide(peer) != 1 - side && (type == kUltimate || type == 8) &&
      !Cfg().freeForAll.load(std::memory_order_relaxed)) {
    const int selected = PromoteTargetOf(owner);
    if (PromoteFighterSide(selected) == 1 - side) peer = selected;
  }
  if (PromoteFighterSide(peer) != 1 - side) return {};
  // Register values may be the native side leader during scene 9, even if
  // a different playable fighter truly started the scene 8. The finalized
  // caller is logged after scene-8 -> scene-9 matching in HookSceneStartImpl.
  return {side, owner, peer};
}

const SceneBinding* FreeUltimate() {
  if (!Cfg().ultFree.load(std::memory_order_relaxed) || !PromoteBattleActive()) return nullptr;
  const auto* scene = ActiveBinding(true);
  return scene && scene->node.type == kUltimate && scene->actors.peer >= 0 ? scene : nullptr;
}

int HookAnyDirection() {
  const int truth = g_origAny();
  if (!truth || t_startingScene.owner >= 0) return truth;
  const auto* stack = static_cast<const uintptr_t*>(_AddressOfReturnAddress());
  const uintptr_t site = *stack - g_base;
  // O gerenciador e os sistemas sem contexto de lutador recebem a resposta real.
  if (site >= Addr().dirCodeBegin && site < Addr().dirCodeEnd) return truth;
  const auto* scene = FreeUltimate();
  if (!scene) return truth;
  const int fighter = PromoteFighterOnStack(stack);
  if (fighter < 0 || fighter == scene->actors.owner || fighter == scene->actors.peer) return truth;
  g_freed.fetch_add(1, std::memory_order_relaxed);
  return 0;
}

int HookCamTrack(void* player) {
  if (PromoteBattleActive()) {
    if (UltSceneActive()) {
      if (FreeUltimate()) return 0;
    } else if (Cfg().camera.load(std::memory_order_relaxed) != kCameraDuel) {
      return 0;
    }
  }
  return g_origCam(player);
}

bool Hook(uintptr_t rva, const uint8_t* expected, size_t size, void* detour, void** original, const char* name) {
  void* target = reinterpret_cast<void*>(g_base + rva);
  if (std::memcmp(target, expected, size) != 0) {
    Log("Cenas: bytes de %s diferentes; hook desativado.", name);
    return false;
  }
  MH_STATUS status = MH_CreateHook(target, detour, original);
  if (status == MH_OK) status = MH_EnableHook(target);
  if (status != MH_OK) Log("Cenas: %s falhou: %s", name, MH_StatusToString(status));
  return status == MH_OK;
}

}  // namespace

extern "C" void SceneStartThunk();

// Estado nativo (+0xCC0) de um lutador, ou -1.
static int FighterState(int fighter) {
  const uintptr_t player = PromoteFighterPlayer(fighter);
  if (!player) return -1;
  __try {
    return *reinterpret_cast<const int*>(player + 0xCC0);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return -1;
  }
}

extern "C" uintptr_t HookSceneStartImpl(int side, int type, const uintptr_t* regs, uintptr_t ret) {
  if (side < 0 || side > 1 || !PromoteBattlePresent()) return g_origScene(side, type);
  SceneActors actors = ReadActors(side, type, regs, ret - g_base);
  const ULONGLONG now=GetTickCount64();
  // DIAGNOSTICO TEMPORARIO: pilha nativa de quem abre as cenas 8 (preparo) e 9 (cinematica) do Supremo,
  // para achar o codigo que roda o Supremo no objeto do lider em vez de no membro que acertou o golpe.
  if (type == 8 || type == kUltimate) {
    static std::atomic<int> traces{0};
    if (traces.fetch_add(1, std::memory_order_relaxed) < 24) {
      void* frames[28]{};
      const USHORT count = RtlCaptureStackBackTrace(0, 28, frames, nullptr);
      char line[600];
      int len = std::snprintf(line, sizeof(line), "ULT PILHA: cena %d lado %d dono=J%d alvo=J%d |", type, side,
                              actors.owner + 1, actors.peer + 1);
      const uintptr_t lo = g_base, hi = g_base + 0x2000000;
      for (USHORT i = 0; i < count && len < 560; ++i) {
        const uintptr_t a = reinterpret_cast<uintptr_t>(frames[i]);
        if (a >= lo && a < hi) len += std::snprintf(line + len, sizeof(line) - len, " %llX",
                                                      static_cast<unsigned long long>(a - g_base));
      }
      Log("%s", line);
    }
  }
  if(type == kUltimate && side>=0 && side<2) {
    const auto& prepared=t_preUltimateOwner[side];
    if(prepared.owner>=0 && now>=prepared.started && PromoteFighterSide(prepared.owner)==side) {
      const bool sameVictim=UltimateSameCasterTransition(side,prepared.owner,prepared.victim,
                                                         side,actors.peer,now-prepared.started,6);
      const int dasher=sameVictim ? -1 : UltDashAttacker(side,actors.peer);
      const int owner=sameVictim ? prepared.owner : dasher;
      if(owner>=0) {
        if(actors.owner!=owner) {
          Log("ULTIMATE OWNER FIX: cena 9 com J%d incorreto; preservado J%d (alvo J%d%s).",
              actors.owner+1,owner+1,actors.peer+1,dasher>=0?", acertado no caminho":"");
        }
        actors.owner=owner;
      }
    }
  }
  SceneNode previous[kMaxScenes];
  const int previousCount = ReadScenes(previous);
  const SceneActors saved = t_startingScene;
  t_startingScene = actors;
  const bool savedInStart = t_inSceneStart;
  t_inSceneStart = true;
  const uintptr_t result = g_origScene(side, type);
  t_inSceneStart = savedInStart;
  t_startingScene = saved;
  const bool created = BindNewScene(side, type, actors, previous, previousCount);
  // Only a scene ACTUALLY added to the native queue is a valid source for
  // an ultimate ownership handoff. Failed/ambiguous pre-scenes are ignored.
  if(type==8 && side>=0 && side<2) {
    t_preUltimateOwner[side] = {};
    if(created && actors.owner>=0 && actors.peer>=0)
      t_preUltimateOwner[side]={actors.owner,actors.peer,now};
    if(created && actors.owner>=0 && actors.owner<6)
      g_preparedBy[actors.owner]={actors.peer,now};
  }
  if(type==kUltimate && side>=0 && side<2)
    t_preUltimateOwner[side] = {}; // never bleed owner into next technique
  if(created && type==kUltimate && side>=0 && side<2) {
    g_cinematicVictimSide.store(1-side, std::memory_order_relaxed);
    g_cinematicVictim.store(actors.peer, std::memory_order_relaxed);
    g_cinematicAt.store(now, std::memory_order_relaxed);
  }
  if(created && (type==8 || type==kUltimate) && actors.owner>=0) {
    int pad=-1;
    for(int i=0;i<4;++i)if(PromoteFighterForPad(i)==actors.owner){pad=i;break;}
    Log("ULTIMATE CASTER: scene=%d side=%d fighter=%d control=%s victim=%d",
        type,side,actors.owner+1,pad<0?"CPU/automatico":"jogador",
        actors.peer+1);
  }
  if (created && type == kTeamUltimate && t_team.owner == actors.owner &&
      t_team.side == side && t_team.ally >= 0 && !t_team.chakraCharged) {
    // Charge only AFTER the native scene has really appeared in the scene queue.
    t_team.chakraCharged = PromoteTeamSpendChakra75(t_team.owner, t_team.ally);
    if (!t_team.chakraCharged)
      Log("Supremo em equipe: impossivel cobrar chakra apos cena criada.");
  }
  return result;
}

bool UltSceneActive() { return g_origAny && g_origAny() != 0; }
bool UltInSceneStart() { return t_inSceneStart; }

int UltSceneFighter(int side) {
  if (t_startingScene.owner >= 0)
    return side == t_startingScene.side ? t_startingScene.owner : t_startingScene.peer;
  const auto* scene = ActiveBinding(false, side);
  if (!scene) return -1;
  return side == scene->actors.side ? scene->actors.owner : scene->actors.peer;
}

bool UltRecentCinematic(int* victimSide, unsigned long long windowMs) {
  const ULONGLONG at = g_cinematicAt.load(std::memory_order_relaxed);
  if (!at || GetTickCount64() - at > windowMs) return false;
  *victimSide = g_cinematicVictimSide.load(std::memory_order_relaxed);
  return *victimSide >= 0;
}

bool UltRecentCinematicVictim(int* victimSide, int* victim, unsigned long long windowMs) {
  if (!UltRecentCinematic(victimSide, windowMs)) return false;
  *victim = g_cinematicVictim.load(std::memory_order_relaxed);
  return *victim >= 0;
}

int UltDashAttacker(int side, int hitVictim) {
  const int count = PromoteFighterCount();
  if (side < 0 || side > 1 || hitVictim < 0 || hitVictim >= count || count < 2 || count > 6) return -1;
  const ULONGLONG now = GetTickCount64();
  float victimPos[3]{};
  bool victimPosOk = false;
  __try {
    std::memcpy(victimPos, reinterpret_cast<const void*>(PromoteFighterPlayer(hitVictim) + 0x70), sizeof(victimPos));
    victimPosOk = true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  int best = -1;
  float bestDist = 3.0e38f;
  for (int k = 0; k < count; ++k) {
    const PreparedByFighter p = g_preparedBy[k];
    if (!p.at || now < p.at) continue;
    if (!UltimateDashHit(side, k, FighterState(k), PromoteFighterSide(k), PromoteFighterSide(hitVictim),
                         now - p.at, count))
      continue;
    if (p.victim == hitVictim) return k;
    float pos[3]{};
    __try {
      std::memcpy(pos, reinterpret_cast<const void*>(PromoteFighterPlayer(k) + 0x70), sizeof(pos));
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      continue;
    }
    const float dx = pos[0] - victimPos[0], dy = pos[1] - victimPos[1];
    const float dist = victimPosOk ? dx * dx + dy * dy : 0.0f;
    if (best < 0 || dist < bestDist) {
      best = k;
      bestDist = dist;
    }
  }
  return best;
}

bool UltPreparedUltimate(int side, int* owner, int* victim) {
  if (side < 0 || side > 1) return false;
  const auto& prepared = t_preUltimateOwner[side];
  if (prepared.owner < 0 || PromoteFighterSide(prepared.owner) != side ||
      GetTickCount64() - prepared.started >= 8000)
    return false;
  *owner = prepared.owner;
  *victim = prepared.victim;
  return true;
}

int UltTeamActor(int side, int role, uintptr_t site) {
  // CAUSA REAL do Supremo com o lider errado (Evolution): quando a vitima processa o acerto do Supremo
  // (FUN_140783xxx, mensagem 0x17), ela pede FUN_140856690(lado do atacante) = membro 0 desse lado, e
  // chama FUN_1407D701C/FUN_1407D6C94 nesse objeto. A cena 9 (cinematica) roda entao no LIDER, mesmo
  // quando quem acertou foi um membro extra. O jogo so guarda o lado do atacante, nao o lutador.
  // Aqui a resposta e quem abriu a cena 8 (preparo do Supremo) nesse lado nos ultimos 8 s.
  // (Resolvido em PromoteContext com UltPreparedUltimate, que tambem confere a vitima na pilha.)
  // Native ordinary ultimate scenes must resolve their own actor even when
  // experimental Team Ultimate is disabled or unsupported (Storm 4 1.09).
  if (site == 0x7D70FF || site == 0x769F38 ||
      site == 0x7DC5BF || site == 0x76EAAC)
    return role == 0 ? UltSceneFighter(side) : -1;
  if (!g_teamHooks.load(std::memory_order_relaxed)) return -1;
  switch (site) {
    case 0x7D20FE: case 0x7D2145:
    case 0x7D22AC: case 0x7D2443: case 0x7D2546:
    case 0x7D261C: case 0x7D266C: case 0x7D2705:
    case 0x7D708B: case 0x7D70CE: case 0x7D716A:
    case 0x76914A: case 0x769440: case 0x769519: case 0x769897:
    case 0x769910: case 0x7699BC: case 0x769A62: case 0x769AA2:
    case 0x769DEB: case 0x769E73: case 0x769F02:
    case 0x768E06: case 0x768E15: case 0x7DD02C: case 0x7DD03C:
      break;
    default:
      return -1;
  }
  if (side != t_team.side) return -1;
  if (!t_team.sceneType && GetTickCount64() >= t_team.deadline) return -1;
  if (role == 0) return t_team.owner;
  if (role != 1) return -1;
  t_team.allyUsed = true;
  return t_team.ally;
}

bool UltTeamAllyRole(int fighter, uintptr_t site) {
  if (!g_teamHooks.load(std::memory_order_relaxed) || (site != 0x7E655F && site != 0x7E66CB)) return false;
  return t_team.allyUsed && t_team.ally == fighter;
}

void UltTeamTick() {
  // Runs on the battle judge thread, not the XInput thread.
  // Discard stale button requests when team techniques are disabled, but keep
  // processing the cleanup of any scene already underway.
  if (!Cfg().teamUltimate.load(std::memory_order_relaxed) ||
      Cfg().freeForAll.load(std::memory_order_relaxed)) {
    for (auto& request : g_teamRequestTick) request.store(0, std::memory_order_relaxed);
  }
  if (Cfg().teamUltimate.load(std::memory_order_relaxed) &&
      !Cfg().freeForAll.load(std::memory_order_relaxed) &&
      Addr().timestamp == 0x5889906E && g_teamHooks.load(std::memory_order_acquire) &&
      PromoteBattleActive() && t_team.ally < 0 && !UltSceneActive()) {
    const ULONGLONG now = GetTickCount64();
    for (int pad = 0; pad < 4; ++pad) {
      const ULONGLONG requested = g_teamRequestTick[pad].exchange(0, std::memory_order_acq_rel);
      if (!requested || now < requested || now - requested > kTeamRequestMaxAgeMs) continue;
      if (g_teamLastStart[pad].load(std::memory_order_relaxed) &&
          now - g_teamLastStart[pad].load(std::memory_order_relaxed) < kTeamCooldownMs) continue;
      const int owner = PromoteFighterForPad(pad);
      const int ally = PromoteFullChakraAlly(owner);
      if (owner < 0 || ally < 0) {
        Log("Supremo em equipe: pad %d bloqueado, dupla ou chakra insuficiente", pad + 1);
        continue;
      }
      const int side = PromoteFighterSide(owner);
      TeamAttempt prepared{};
      prepared.side = side;
      prepared.owner = owner;
      prepared.ally = ally;
      prepared.deadline = now + 5500;
      PromoteTeamAllyPosition(ally, prepared.position);
      t_team = prepared;
      // Backup timeout rolls back team context; no direct gauge manipulation.
      g_teamLastStart[pad] = now;
      Log("Supremo em equipe: P%d chama estado nativo 0x8D para L%d/L%d",
          pad + 1, owner + 1, ally + 1);
      if (!PromoteStartTeamUltimate(owner)) {
        t_team = {};
        Log("Supremo em equipe: jogo rejeitou o inicio para L%d", owner + 1);
      }
      break;
    }
  }
  // CPU escolhe a tecnica conjunta APENAS se o usuario habilitou o teste
  // opt-in (ia_adaptativa=1 e ia_supremo_equipe_cpu=1). Usa o mesmo caminho
  // de cena/limpeza ja validado para controles humanos. Jamais no FFA.
  if (t_team.ally < 0 && CpuAdaptTeamUltimateEnabled() &&
      Cfg().teamUltimate.load(std::memory_order_relaxed) &&
      !Cfg().freeForAll.load(std::memory_order_relaxed) &&
      Addr().timestamp == 0x5889906E &&
      g_teamHooks.load(std::memory_order_acquire) &&
      PromoteBattleActive() && !UltSceneActive()) {
    const ULONGLONG now = GetTickCount64();
    int clashA=-1,clashB=-1;
    if (!JutsuClashCameraPair(&clashA,&clashB)) {
      const int count=std::min(PromoteFighterCount(),6);
      for (int owner=0;owner<count;++owner) {
        const uintptr_t actor=PromoteFighterPlayer(owner);
        if (!actor || PromotePadForPlayer(actor)>=0 || JutsuClashProtects(actor))continue;
        if (g_cpuTeamNext[owner]==0)g_cpuTeamNext[owner]=now+9000+ULONGLONG(owner)*650;
        if (now<g_cpuTeamNext[owner])continue;
        g_cpuTeamNext[owner]=now+11000+ULONGLONG(CpuTeamRoll()%4000);
        const int ally=PromoteFullChakraAlly(owner);
        if (ally<0 || ally==owner || JutsuClashProtects(PromoteFighterPlayer(ally)))continue;
        const unsigned chance=CpuAdaptChance(18,actor,cpuai::Action::TeamUltimate);
        if (CpuTeamRoll()%100>=chance)continue;
        TeamAttempt prepared{};
        prepared.side=PromoteFighterSide(owner);
        prepared.owner=owner;prepared.ally=ally;prepared.deadline=now+5500;
        if (prepared.side<0 || prepared.side>1)continue;
        PromoteTeamAllyPosition(ally,prepared.position);
        t_team=prepared;
        Log("IA ADAPTATIVA: CPU J%d tenta supremo em equipe com J%d.",owner+1,ally+1);
        if (!PromoteStartTeamUltimate(owner)) {
          PromoteReturnTeamAlly(ally,prepared.position);
          t_team={};
          Log("IA ADAPTATIVA: supremo de CPU J%d recusado pelo motor.",owner+1);
        }
        break;
      }
    }
  }
  if (t_team.ally < 0) return;
  const ULONGLONG now = GetTickCount64();
  // A team scene can finish while an unrelated hit/ultimate scene is still queued.
  // Waiting for ALL game scenes caused the second fighter to remain invisible.
  const bool teamEnded = t_team.sceneType == kTeamUltimate &&
      t_team.attackAt && now > t_team.attackAt + 300 && !TeamSceneRunning(t_team.side);
  if (!teamEnded && UltSceneActive()) {
    // Do not forcibly end a legitimate cinematic; report excessively long scenes.
    const ULONGLONG now = GetTickCount64();
    if (!t_team.prolongedLogged && now > t_team.deadline + 12000) {
      t_team.prolongedLogged = true;
      Log("COMBAT DIAG: supremo em equipe L%d/L%d com cena ativa ha muito tempo (tipo=%d)",
          t_team.owner + 1, t_team.ally + 1, t_team.sceneType);
    }
    return;
  }
  if (t_team.sceneType != kTeamUltimate && GetTickCount64() < t_team.deadline) return;
  const TeamAttempt completed = t_team;
  t_team = {};
  if (completed.allyUsed || completed.sceneType == kTeamUltimate || completed.sceneType == kTeamIntro) {
    PromoteReturnTeamAlly(completed.ally, completed.position);
    Log("Supremo em dupla: restaurado L%d apos cena (tipo=%d, papel=%d)", completed.ally + 1, completed.sceneType, int(completed.allyUsed));
  }
}

void UltBattleReset() {
  for (auto& tick : g_teamRequestTick) tick.store(0, std::memory_order_relaxed);
  for (auto& tick : g_teamLastStart) tick.store(0, std::memory_order_relaxed);
  for (auto& ready : g_cpuTeamNext)ready=0;
  g_cpuTeamRng ^= static_cast<uint32_t>(GetTickCount64());
  t_sceneCount = 0;
  t_startingScene = {};
  t_team = {};
  for(auto& pending : t_preUltimateOwner) pending={};
  for(auto& prepared : g_preparedBy) prepared={};
}

bool UltInstall() {
  static const uint8_t kCam[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x74, 0x24, 0x10};
  static const uint8_t kAny[] = {0x48, 0x8B, 0x05};
  static const uint8_t kScene[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x74, 0x24, 0x10, 0x57};
  const auto* code = reinterpret_cast<const uint8_t*>(g_base + Addr().anyDirection);
  if (std::memcmp(code, kAny, sizeof(kAny)) == 0) {
    int32_t displacement;
    std::memcpy(&displacement, code + 3, sizeof(displacement));
    g_sceneGlobal = reinterpret_cast<uintptr_t>(code + 7) + displacement;
  }
  int ok = 0;
  ok += Hook(Addr().anyDirection, kAny, sizeof(kAny), reinterpret_cast<void*>(&HookAnyDirection),
             reinterpret_cast<void**>(&g_origAny), "cena rodando");
  ok += Hook(Addr().sceneStart, kScene, sizeof(kScene), reinterpret_cast<void*>(&SceneStartThunk),
             reinterpret_cast<void**>(&g_origScene), "inicio de cena");
  ok += Hook(Addr().camTrack, kCam, sizeof(kCam), reinterpret_cast<void*>(&HookCamTrack),
             reinterpret_cast<void**>(&g_origCam), "camera da cena");
  Log("Cenas: %d de 3 hooks instalados.", ok);
  if (ok == 3 && Addr().teamReady) {
    static const uint8_t kReady[] = {0x33, 0xC0, 0x83, 0xB9, 0x80, 0x51, 0x01, 0x00, 0x02};
    static const uint8_t kGauge[] = {0x40, 0x53, 0x48, 0x83, 0xEC, 0x20, 0x48, 0x8B, 0x1D};
    const bool ready = Hook(Addr().teamReady, kReady, sizeof(kReady), reinterpret_cast<void*>(&HookTeamReady),
                            reinterpret_cast<void**>(&g_origTeamReady), "chakra da dupla");
    const bool gauge = Hook(Addr().teamGauge, kGauge, sizeof(kGauge), reinterpret_cast<void*>(&HookTeamGauge),
                            reinterpret_cast<void**>(&g_origTeamGauge), "comando em dupla");
    g_teamHooks.store(ready && gauge, std::memory_order_release);
    if (ready && gauge) Log("Supremo em dupla: verificacoes de chakra instaladas.");
  }
  return ok == 3;
}

bool UltTeamButtonPressed(int pad) {
  if (pad < 0 || pad >= 4 || !Cfg().teamUltimate.load(std::memory_order_relaxed) ||
      Cfg().freeForAll.load(std::memory_order_relaxed) ||
      !PromoteBattleActive() || MenuIsOpen()) return false;
  // For unknown game versions do not execute an unverified state.
  if (Addr().timestamp != 0x5889906E || !g_teamHooks.load(std::memory_order_acquire)) {
    Log("Supremo em equipe: atalho nativo disponivel apenas no Evolution com hooks ativos");
    return false;
  }
  g_teamRequestTick[pad].store(GetTickCount64(), std::memory_order_release);
  return true;
}
void UltReport() {
  SceneNode list[kMaxScenes];
  __try {
    const int count = ReadScenes(list);
    for (int i = 0; i < count; ++i)
      Log("Cena na lista: estado=%d tipo=%d lado=%d", list[i].state, list[i].type, list[i].side);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  if (g_teamReadyCalls.load() || g_teamGaugeCalls.load())
    Log("Team native diagnostics: readiness=%llu, gauge accepted=%llu",
        static_cast<unsigned long long>(g_teamReadyCalls.load()),
        static_cast<unsigned long long>(g_teamGaugeCalls.load()));
  if (g_freed.load())
    Log("Ultimates: %llu consultas de lutadores fora do golpe liberadas.",
        static_cast<unsigned long long>(g_freed.load()));
}
