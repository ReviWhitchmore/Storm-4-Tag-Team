#pragma once
#include <cstdint>
#include <cmath>
#include <algorithm>

// Separate, unit-testable quality rules used by input and render hooks.
// They must not depend on the native Storm 4 executable or its structs.
inline bool RuntimePadCacheFresh(uint64_t observedAt,uint64_t now,
                                 uint64_t ageLimit=250) {
  return observedAt!=0 && now>=observedAt && now-observedAt<=ageLimit;
}
struct RuntimeFrameWindow {
  uint64_t start=0,last=0;
  unsigned frames=0,slowFrames=0;
  double totalMs=0.0,maxMs=0.0;
};
struct RuntimeFrameReport {
  bool ready=false;
  double fps=0.0,averageMs=0.0,maxMs=0.0;
  unsigned slowFrames=0,frames=0;
};
inline RuntimeFrameReport RuntimeRecordPresent(RuntimeFrameWindow& window,
                                                uint64_t now,bool inBattle,
                                                uint64_t intervalMs=10000) {
  RuntimeFrameReport report{};
  if(!inBattle) {
    window={};
    return report;
  }
  if(window.start==0 || now<window.last ||
     (window.last && now-window.last>2000)) {
    window={};
    window.start=window.last=now;
    return report;
  }
  const uint64_t step=now-window.last;
  window.last=now;
  if(step<2000) {
    ++window.frames;
    window.totalMs+=double(step);
    window.maxMs=std::max(window.maxMs,double(step));
    if(step>50)++window.slowFrames;
  }
  if(now-window.start<intervalMs || window.frames<4)return report;
  report.ready=true;
  report.frames=window.frames;
  report.slowFrames=window.slowFrames;
  report.averageMs=window.totalMs/window.frames;
  report.maxMs=window.maxMs;
  report.fps=window.totalMs>0?window.frames*1000.0/window.totalMs:0;
  window.start=now;
  window.frames=window.slowFrames=0;
  window.totalMs=window.maxMs=0.0;
  return report;
}
