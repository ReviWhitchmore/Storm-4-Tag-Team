#pragma once
// Enquadramento dos lutadores na camera de duelo.
bool CameraInstall();
void CameraBeginBattle();
// Analogico direito do P1 no modo torneio (-1..1): gira a camera em volta dele.
void CameraSetYawInput(float stick);
void CameraSetFighters(const float positions[][3], int count, int primary, int target);
// JUTSU CLASH: enquanto ativo, a camera fecha nos dois da disputa, de lado (um a esquerda, outro a direita).
// stage (abertura do Storm 1): 1 = close do lutador a, 2 = close do b, 0 = vista de lado. Troca de estagio = corte seco.
void CameraSetClash(bool active, const float a[3], const float b[3], int stage = 0);
// Outros lutadores (3v3) para a camera da disputa escolher o lado sem ninguem na frente.
void CameraSetClashBlockers(const float positions[][3], int count);
// Briefly bias Revolution camera toward the actual arriving 3D fighters.
void CameraObserveEntrance(const float positions[][3], int count);
// Converte um ponto do mundo em coordenadas da tela (-1..1, y para cima) usando a ultima vista da luta.
// Para um ponto atras da camera, behind recebe true e x/y indicam a direcao para uma seta.
// Teste nativo de colisao com o cenario (o mesmo da camera): varre uma esfera de raio radius de from ate from+delta.
// fraction: -1 = caminho livre; 0..1 = fracao do caminho onde bateu. raw (opcional) recebe o resultado bruto (0x108).
// Devolve false se o teste nao estiver disponivel nesta versao ou se a arena ainda nao carregou.
bool CameraStageSweep(const float from[3], const float delta[3], float radius, int mask, float* fraction,
                      void* raw = nullptr);
// Direcao para onde a camera da luta olha (do olho para a mira), da ultima vista. false se a vista estiver velha.
bool CameraViewDirection(float forward[3]);
bool CameraProject(const float world[3], float aspect, float* screenX, float* screenY, bool* behind = nullptr);
