#pragma once
#include <windows.h>
#include <Xinput.h>

// Menu do mod, desenhado pelo HUD. Abre com SELECT/Back (controle 1) ou F1, fora da luta.
enum MenuItem {
  kItem3v3 = 0,
  kItemHud,
  kItemLockon,
  kItemLockStyle,
  kItemCamera,
  kItemRing,
  kItemUlt,
  kItemSelectP2,
  kItemTeamUltimate,
  kItemTeamUltimateButton,
  kItemAwakenStart,
  kItemJutsuClash,
  kItemSlot0,  // J1..J6: kItemSlot0 + i
  kItemClose = kItemSlot0 + 6,
  kItemCount
};

bool MenuIsOpen();
int MenuSelection();
// Chamado pelo hook do XInput a cada leitura do controle 1 (state pode ser nulo se desconectado).
// Le tambem o teclado. Se o menu estiver aberto, zera o controle para o jogo nao reagir.
void MenuInput(XINPUT_STATE* state);
// O jogo nao deve receber controle nem teclado: menu aberto ou fechado ha menos de 250 ms (a mesma tecla/botao que
// fechou o menu nao pode chegar ao menu do jogo que esta atras).
bool MenuBlocksGameInput();
