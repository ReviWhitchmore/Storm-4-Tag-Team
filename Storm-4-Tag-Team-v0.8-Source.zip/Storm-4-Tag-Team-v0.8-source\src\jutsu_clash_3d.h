#pragma once
#include <cstdint>

// Parte 3D da disputa de jutsus: funcoes nativas do motor do Evolution (NSUNS4e.exe, timestamp 0x5889906E).
// Localizadas no nosso proprio executavel comparando com o codigo equivalente do Storm 4 1.09 (referencia publica
// UltimateStormAPI do TheLeonX, so lida). Cada funcao confere a assinatura de bytes antes de ser usada.
namespace clash3d {
void Install();                                  // confere as assinaturas e registra no log
bool SetActionNow(uintptr_t player, int action);  // exe+0x7A97D4: pedido de acao +0xCC8, +0xCDC=1 e aplica
bool PlayAnm(uintptr_t player, int anm);          // exe+0x779804: animacao PL_ANM direto no modelo
bool BackgroundDraw(uintptr_t player, bool on);   // exe+0x7F0B6C liga / exe+0x7F0B20 desliga o desenho do cenario
int CurrentAnm(uintptr_t player);                 // +0x1080 (PL_ANM atual)
float AnmValue(uintptr_t player);                 // +0x1084
}  // namespace clash3d
