// Desenho por cima do jogo (hook de IDXGISwapChain::Present): HUD dos 6 lutadores e menu do mod.
//
// HUD: valores de vida, chakra e substituicao por lutador, e mira por controle.
// Texto: atlas gerado no inicio com a fonte do Windows (GDI), caracteres Latin-1 (32..255).

#include "hud.h"

#include <windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <MinHook.h>
#include <wincodec.h>
#include <wrl/client.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

#include "camera.h"
#include "frame_capture.h"
#include "chronicles.h"
#include "scene_probe.h"
#include "parry.h"
#include "grab_defense.h"
#include "perfect_sub.h"
#include "jutsu_clash.h"
#include "jutsu_clash_motion_rules.h"
#include "jutsu_clash_world_anchors.inl"
#include "jutsu_clash_visual_rules.h"
#include "input.h"
#include "lockon_rules.h"
#include "revolution_lockon_rules.h"
#include "lang.h"
#include "log.h"
#include "menu.h"
#include "promote.h"
#include "settings.h"
#include "runtime_quality_rules.h"

namespace {

using Present_t = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);
Present_t g_origPresent = nullptr;

ID3D11Device* g_dev = nullptr;
ID3D11DeviceContext* g_ctx = nullptr;
ID3D11VertexShader* g_vs = nullptr;
ID3D11PixelShader* g_ps = nullptr;
ID3D11InputLayout* g_layout = nullptr;
ID3D11Buffer* g_vb = nullptr;
ID3D11BlendState* g_blend = nullptr;
ID3D11RasterizerState* g_raster = nullptr;
ID3D11DepthStencilState* g_depth = nullptr;
ID3D11ShaderResourceView* g_fontSrv = nullptr;
ID3D11SamplerState* g_sampler = nullptr;
bool g_failed = false;
constexpr UINT kMaxVerts = 24000;

// Atlas da fonte: 32 colunas x 7 linhas de celulas 32x36 (caracteres 32..255).
constexpr int kAtlasW = 1024, kAtlasH = 256, kCellW = 32, kCellH = 36, kCols = 32;
float g_advance[256];
float g_nameAdvance[256];
ID3D11ShaderResourceView* g_nameSrv = nullptr;
// Pixel branco solido no canto do atlas (para retangulos sem textura).
constexpr float kWhiteU = (kAtlasW - 2) / float(kAtlasW), kWhiteV = (kAtlasH - 2) / float(kAtlasH);

struct Vtx {
  float x, y, u, v;
  float r, g, b, a;
};
std::vector<Vtx> g_verts;
struct DrawBatch {
  UINT first;
  ID3D11ShaderResourceView* texture;
};
std::vector<DrawBatch> g_batches;
float g_w = 1920, g_h = 1080;
std::atomic<float> g_renderAspect{16.0f/9.0f};

using Microsoft::WRL::ComPtr;
ComPtr<IWICImagingFactory> g_images;
struct PortraitImage {
  ComPtr<ID3D11ShaderResourceView> texture;
  float aspect = 1;
};
std::unordered_map<std::string, PortraitImage> g_portraits;

const char kShader[] = R"(
Texture2D t : register(t0);
SamplerState s : register(s0);
struct VI { float2 p : POSITION; float2 uv : TEXCOORD; float4 c : COLOR; };
struct VO { float4 p : SV_POSITION; float2 uv : TEXCOORD; float4 c : COLOR; };
VO vs(VI i) { VO o; o.p = float4(i.p, 0, 1); o.uv = i.uv; o.c = i.c; return o; }
float4 ps(VO i) : SV_TARGET { return t.Sample(s, i.uv) * i.c; }
)";

template <typename T>
void SafeRelease(T*& p) {
  if (p) p->Release();
  p = nullptr;
}

bool BuildAtlas(const wchar_t* face, int height, int weight, float* advance, ID3D11ShaderResourceView** view) {
  HDC dc = CreateCompatibleDC(nullptr);
  BITMAPINFO bi{};
  bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bi.bmiHeader.biWidth = kAtlasW;
  bi.bmiHeader.biHeight = -kAtlasH;
  bi.bmiHeader.biPlanes = 1;
  bi.bmiHeader.biBitCount = 32;
  bi.bmiHeader.biCompression = BI_RGB;
  void* bits = nullptr;
  HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (!bmp) {
    DeleteDC(dc);
    return false;
  }
  HGDIOBJ oldBmp = SelectObject(dc, bmp);
  HFONT font = CreateFontW(-height, 0, 0, 0, weight, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, face);
  HGDIOBJ oldFont = SelectObject(dc, font);
  SetBkMode(dc, TRANSPARENT);
  SetTextColor(dc, RGB(255, 255, 255));
  memset(bits, 0, kAtlasW * kAtlasH * 4);
  for (int c = 32; c < 256; ++c) {
    int i = c - 32, x = (i % kCols) * kCellW, y = (i / kCols) * kCellH;
    wchar_t ch = wchar_t(c);
    SIZE sz{};
    GetTextExtentPoint32W(dc, &ch, 1, &sz);
    advance[c] = float(sz.cx);
    if (c >= 0x7F && c < 0xA0) continue;  // controle: nada a desenhar
    TextOutW(dc, x + 2, y + 2, &ch, 1);
  }
  GdiFlush();
  std::vector<uint32_t> rgba(kAtlasW * kAtlasH);
  auto* src = static_cast<const uint32_t*>(bits);
  for (int i = 0; i < kAtlasW * kAtlasH; ++i) {
    uint32_t p = src[i];
    uint32_t a = (p & 0xFF) > ((p >> 8) & 0xFF) ? (p & 0xFF) : ((p >> 8) & 0xFF);
    if (((p >> 16) & 0xFF) > a) a = (p >> 16) & 0xFF;
    rgba[i] = (a << 24) | 0x00FFFFFF;
  }
  for (int y = kAtlasH - 4; y < kAtlasH; ++y)
    for (int x = kAtlasW - 4; x < kAtlasW; ++x) rgba[y * kAtlasW + x] = 0xFFFFFFFF;
  SelectObject(dc, oldFont);
  SelectObject(dc, oldBmp);
  DeleteObject(font);
  DeleteObject(bmp);
  DeleteDC(dc);

  D3D11_TEXTURE2D_DESC td{};
  td.Width = kAtlasW;
  td.Height = kAtlasH;
  td.MipLevels = 1;
  td.ArraySize = 1;
  td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
  td.SampleDesc.Count = 1;
  td.Usage = D3D11_USAGE_IMMUTABLE;
  td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
  D3D11_SUBRESOURCE_DATA sd{rgba.data(), kAtlasW * 4, 0};
  ID3D11Texture2D* tex = nullptr;
  if (FAILED(g_dev->CreateTexture2D(&td, &sd, &tex))) return false;
  g_dev->CreateShaderResourceView(tex, nullptr, view);
  tex->Release();
  return *view != nullptr;
}

bool BuildFont() {
  if (!BuildAtlas(L"Segoe UI", 26, FW_BOLD, g_advance, &g_fontSrv)) return false;
  // Tracado de pincel para os nomes, como na HUD nativa.
  if (!BuildAtlas(L"Ink Free", 28, FW_BOLD, g_nameAdvance, &g_nameSrv)) return false;
D3D11_SAMPLER_DESC smp{};
  smp.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
  smp.AddressU = smp.AddressV = smp.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
  smp.MaxLOD = D3D11_FLOAT32_MAX;
  g_dev->CreateSamplerState(&smp, &g_sampler);
  return g_fontSrv && g_sampler;
}

bool Init(IDXGISwapChain* sc) {
  if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), reinterpret_cast<void**>(&g_dev)))) return false;
  g_dev->GetImmediateContext(&g_ctx);
  ID3DBlob *vsb = nullptr, *psb = nullptr, *err = nullptr;
  if (FAILED(D3DCompile(kShader, sizeof(kShader), nullptr, nullptr, nullptr, "vs", "vs_4_0", 0, 0, &vsb, &err)) ||
      FAILED(D3DCompile(kShader, sizeof(kShader), nullptr, nullptr, nullptr, "ps", "ps_4_0", 0, 0, &psb, &err))) {
    Log("HUD: falha ao compilar shaders: %s", err ? static_cast<const char*>(err->GetBufferPointer()) : "?");
    SafeRelease(err);
    return false;
  }
  g_dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs);
  g_dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps);
  D3D11_INPUT_ELEMENT_DESC el[] = {
      {"POSITION", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0},
      {"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 8, D3D11_INPUT_PER_VERTEX_DATA, 0},
      {"COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 16, D3D11_INPUT_PER_VERTEX_DATA, 0},
  };
  g_dev->CreateInputLayout(el, 3, vsb->GetBufferPointer(), vsb->GetBufferSize(), &g_layout);
  SafeRelease(vsb);
  SafeRelease(psb);

  D3D11_BUFFER_DESC bd{};
  bd.ByteWidth = kMaxVerts * sizeof(Vtx);
  bd.Usage = D3D11_USAGE_DYNAMIC;
  bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
  bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
  g_dev->CreateBuffer(&bd, nullptr, &g_vb);

  D3D11_BLEND_DESC bl{};
  bl.RenderTarget[0].BlendEnable = TRUE;
  bl.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
  bl.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
  bl.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
  bl.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
  bl.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
  bl.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
  bl.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
  g_dev->CreateBlendState(&bl, &g_blend);

  D3D11_RASTERIZER_DESC rs{};
  rs.FillMode = D3D11_FILL_SOLID;
  rs.CullMode = D3D11_CULL_NONE;
  rs.DepthClipEnable = TRUE;
  g_dev->CreateRasterizerState(&rs, &g_raster);

  D3D11_DEPTH_STENCIL_DESC ds{};
  ds.DepthEnable = FALSE;
  g_dev->CreateDepthStencilState(&ds, &g_depth);

  bool ok = g_vs && g_ps && g_layout && g_vb && g_blend && g_raster && g_depth && BuildFont();
  Log("HUD: inicializado %s", ok ? "OK" : "COM FALHAS");
  return ok;
}

// ------------------------------------------------------------------ primitivas

void Quad(float x, float y, float w, float h, float u0, float v0, float u1, float v1, float r, float g,
          float b, float a, ID3D11ShaderResourceView* texture = nullptr) {
  if (g_verts.size() + 6 > kMaxVerts) return;
  if (!texture) texture = g_fontSrv;
  if (g_batches.empty() || g_batches.back().texture != texture)
    g_batches.push_back({UINT(g_verts.size()), texture});
  float x0 = x / g_w * 2 - 1, x1 = (x + w) / g_w * 2 - 1;
  float y0 = 1 - y / g_h * 2, y1 = 1 - (y + h) / g_h * 2;
  Vtx q[6] = {{x0, y0, u0, v0, r, g, b, a}, {x1, y0, u1, v0, r, g, b, a}, {x0, y1, u0, v1, r, g, b, a},
              {x1, y0, u1, v0, r, g, b, a}, {x1, y1, u1, v1, r, g, b, a}, {x0, y1, u0, v1, r, g, b, a}};
  g_verts.insert(g_verts.end(), q, q + 6);
}

void Rect(float x, float y, float w, float h, float r, float g, float b, float a) {
  Quad(x, y, w, h, kWhiteU, kWhiteV, kWhiteU, kWhiteV, r, g, b, a);
}

void Border(float x, float y, float w, float h, float t, float r, float g, float b) {
  Rect(x - t, y - t, w + 2 * t, t, r, g, b, 1);
  Rect(x - t, y + h, w + 2 * t, t, r, g, b, 1);
  Rect(x - t, y, t, h, r, g, b, 1);
  Rect(x + w, y, t, h, r, g, b, 1);
}

std::wstring Widen(const char* utf8) {
  int n = MultiByteToWideChar(CP_UTF8, 0, utf8, -1, nullptr, 0);
  std::wstring w(n > 0 ? n - 1 : 0, L'\0');
  if (n > 1) MultiByteToWideChar(CP_UTF8, 0, utf8, -1, &w[0], n);
  return w;
}

float TextWidth(const char* utf8, float size, const float* advance = g_advance) {
  float s = size / kCellH, w = 0;
  for (wchar_t c : Widen(utf8)) w += (c < 256 ? advance[c] : advance['?']) * s;
  return w;
}

void Text(float x, float y, const char* utf8, float size, float r, float g, float b, float a = 1,
          ID3D11ShaderResourceView* atlas = nullptr, const float* advance = g_advance) {
  float s = size / kCellH;
  for (wchar_t c : Widen(utf8)) {
    int ch = (c >= 32 && c < 256) ? int(c) : '?';
    int i = ch - 32;
    float u0 = float((i % kCols) * kCellW) / kAtlasW, v0 = float((i / kCols) * kCellH) / kAtlasH;
    float u1 = u0 + float(kCellW) / kAtlasW, v1 = v0 + float(kCellH) / kAtlasH;
    // sombra + letra
    Quad(x + 2 * s, y + 2 * s, kCellW * s, kCellH * s, u0, v0, u1, v1, 0, 0, 0, a * 0.8f, atlas);
    Quad(x, y, kCellW * s, kCellH * s, u0, v0, u1, v1, r, g, b, a, atlas);
    x += advance[ch] * s;
  }
}

float Ratio(float cur, float max) {
  if (!(max > 0.001f)) return 0;
  float v = cur / max;
  return v < 0 ? 0 : (v > 1 ? 1 : v);
}

const PortraitImage* Portrait(const char* code) {
  if (!*code) return nullptr;
  auto [entry, added] = g_portraits.try_emplace(code);
  PortraitImage& result = entry->second;
  if (!added) return result.texture ? &result : nullptr;
  if (!g_images) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                                IID_PPV_ARGS(g_images.GetAddressOf())))) return nullptr;
  }
  const std::wstring path = ModDir() + L"storm6_portraits\\p_" + Widen(code) + L".png";
  ComPtr<IWICBitmapDecoder> decoder;
  ComPtr<IWICBitmapFrameDecode> frame;
  ComPtr<IWICFormatConverter> rgba;
  if (FAILED(g_images->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ,
                                                 WICDecodeMetadataCacheOnLoad, &decoder)) ||
      FAILED(decoder->GetFrame(0, &frame)) || FAILED(g_images->CreateFormatConverter(&rgba)) ||
      FAILED(rgba->Initialize(frame.Get(), GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone,
                              nullptr, 0, WICBitmapPaletteTypeCustom))) {
    Log("HUD: retrato %s indisponivel", code);
    return nullptr;
  }
  UINT w = 0, h = 0;
  if (FAILED(rgba->GetSize(&w, &h)) || !w || !h || w > 1024 || h > 1024) return nullptr;
  std::vector<uint8_t> pixels(w * h * 4);
  if (FAILED(rgba->CopyPixels(nullptr, w * 4, UINT(pixels.size()), pixels.data()))) return nullptr;
  UINT left = w, top = h, right = 0, bottom = 0;
  for (UINT y = 0; y < h; ++y) {
    for (UINT x = 0; x < w; ++x) {
      if (pixels[(y * w + x) * 4 + 3] <= 16) continue;
      left = std::min(left, x);
      top = std::min(top, y);
      right = std::max(right, x + 1);
      bottom = std::max(bottom, y + 1);
    }
  }
  if (left >= right || top >= bottom) return nullptr;
  D3D11_TEXTURE2D_DESC desc{};
  desc.Width = right - left;
  desc.Height = bottom - top;
  desc.MipLevels = desc.ArraySize = desc.SampleDesc.Count = 1;
  desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
  desc.Usage = D3D11_USAGE_IMMUTABLE;
  desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
  D3D11_SUBRESOURCE_DATA image{pixels.data() + (top * w + left) * 4, w * 4, 0};
  ComPtr<ID3D11Texture2D> texture;
  if (SUCCEEDED(g_dev->CreateTexture2D(&desc, &image, &texture)))
    g_dev->CreateShaderResourceView(texture.Get(), nullptr, result.texture.GetAddressOf());
  result.aspect = float(desc.Width) / desc.Height;
  return result.texture ? &result : nullptr;
}

// ------------------------------------------------------------------ HUD

// Paineis no estilo da HUD do jogo, um embaixo do outro. Os lideres usam a HUD nativa, acima destes.
struct Rgba {
  float r, g, b, a;
};

// Quatro cantos em pixels, cada um com sua cor.
void Poly4(const float px[4], const float py[4], const Rgba c[4]) {
  if (g_verts.size() + 6 > kMaxVerts) return;
  if (g_batches.empty() || g_batches.back().texture != g_fontSrv)
    g_batches.push_back({UINT(g_verts.size()), g_fontSrv});
  auto v = [&](int i) {
    return Vtx{px[i] / g_w * 2 - 1, 1 - py[i] / g_h * 2, kWhiteU, kWhiteV, c[i].r, c[i].g, c[i].b, c[i].a};
  };
  const Vtx q[6] = {v(0), v(1), v(3), v(1), v(2), v(3)};
  g_verts.insert(g_verts.end(), q, q + 6);
}

// Sistema de coordenadas de um painel: unidades da HUD nativa em 1920x1080, espelhado no lado direito.
struct PlateSpace {
  bool left;
  float originX, originY, k;
  float X(float u) const { return left ? originX + u * k : g_w - originX - u * k; }
  float Y(float v) const { return originY + v * k; }
};

// Faixa inclinada entre v0 e v1. A inclinacao empurra o topo em `slant` unidades por altura `height`.
void Strip(const PlateSpace& p, float u0, float u1, float v0, float v1, float baseV, float slant, float height,
           Rgba top, Rgba bottom) {
  const float s0 = slant * (baseV + height - v0) / height, s1 = slant * (baseV + height - v1) / height;
  const float px[4] = {p.X(u0 + s0), p.X(u1 + s0), p.X(u1 + s1), p.X(u0 + s1)};
  const float py[4] = {p.Y(v0), p.Y(v0), p.Y(v1), p.Y(v1)};
  const Rgba c[4] = {top, top, bottom, bottom};
  Poly4(px, py, c);
}

void Arc(const PlateSpace& p, float cu, float cv, float r0, float r1, float a0, float a1, Rgba inner, Rgba outer) {
  constexpr int kSegments = 28;
  for (int i = 0; i < kSegments; ++i) {
    const float t0 = a0 + (a1 - a0) * i / kSegments, t1 = a0 + (a1 - a0) * (i + 1) / kSegments;
    const float px[4] = {p.X(cu + std::cos(t0) * r1), p.X(cu + std::cos(t1) * r1), p.X(cu + std::cos(t1) * r0),
                         p.X(cu + std::cos(t0) * r0)};
    const float py[4] = {p.Y(cv + std::sin(t0) * r1), p.Y(cv + std::sin(t1) * r1), p.Y(cv + std::sin(t1) * r0),
                         p.Y(cv + std::sin(t0) * r0)};
    const Rgba c[4] = {outer, outer, inner, inner};
    Poly4(px, py, c);
  }
}

constexpr float kPi = 3.14159265f;

void NativeBar(const PlateSpace& p, float u0, float u1, float v, float h, float ratio, Rgba light, Rgba mid,
               Rgba dark, Rgba empty) {
  constexpr float kSlant = 14.0f;
  const Rgba gold{0.74f, 0.60f, 0.38f, 1}, shadow{0.05f, 0.03f, 0.03f, 0.95f};
  Strip(p, u0 - 3, u1 + 3, v - 3, v + h + 3, v, kSlant, h, shadow, shadow);
  Strip(p, u0 - 1.5f, u1 + 1.5f, v - 1.5f, v + h + 1.5f, v, kSlant, h, gold, gold);
  Strip(p, u0, u1, v, v + h, v, kSlant, h, empty, empty);
  const float end = u0 + (u1 - u0) * ratio;
  if (ratio > 0) {
    Strip(p, u0, end, v, v + h * 0.35f, v, kSlant, h, light, mid);
    Strip(p, u0, end, v + h * 0.35f, v + h, v, kSlant, h, mid, dark);
  }
}

// Nomes dos codigos de retrato conhecidos; o resto mostra a vaga (J2, J5...).
const char* FighterName(const char* code) {
  static const struct {
    const char* code;
    const char* name;
  } kNames[] = {{"nrt", "Naruto"},    {"ssk", "Sasuke"},    {"skr", "Sakura"},    {"kks", "Kakashi"},
                {"gar", "Gaara"},     {"hnt", "Hinata"},    {"mdr", "Madara"},    {"obt", "Obito"},
                {"itc", "Itachi"},    {"tob", "Tobi"},      {"jry", "Jiraiya"},   {"mnt", "Minato"},
                {"hsm", "Hashirama"}, {"tbm", "Tobirama"},  {"ino", "Ino"},       {"sik", "Shikamaru"},
                {"tyo", "Choji"},     {"ten", "Tenten"},    {"nej", "Neji"},      {"roc", "Rock Lee"},
                {"guy", "Guy"},       {"kib", "Kiba"},      {"sin", "Shino"},     {"sai", "Sai"},
                {"ymt", "Yamato"},    {"tsk", "Tsunade"},   {"tmr", "Temari"},    {"knk", "Kankuro"},
                {"mei", "Mei"},       {"kbt", "Kabuto"},    {"orc", "Orochimaru"}, {"brt", "Boruto"},
                {"sld", "Sarada"},    {"mtk", "Mitsuki"},   {"kgy", "Kaguya"},    {"jug", "Jugo"},
                {"sgt", "Suigetsu"},  {"kar", "Karin"},     {"ddr", "Deidara"},   {"sco", "Sasori"},
                {"hdn", "Hidan"}};
  for (const auto& entry : kNames)
    if (!strncmp(code, entry.code, 3)) return entry.name;
  return nullptr;
}

void NativePlate(const HudFighter& f, int slotNumber, const PlateSpace& p) {
  const Rgba clear{0, 0, 0, 0};

  // Brasao atras do rosto e faixa vermelha que some sob as barras.
  Arc(p, 96, 62, 0, 50, 0, 2 * kPi, {0.42f, 0.05f, 0.04f, 0.9f}, {0.30f, 0.06f, 0.05f, 0.45f});
  Arc(p, 96, 62, 50, 56, -2.6f, 1.2f, {0.72f, 0.53f, 0.40f, 0.95f}, {0.47f, 0.31f, 0.24f, 0.9f});
  Arc(p, 96, 62, 34, 39, 1.2f, 4.6f, {0.60f, 0.43f, 0.33f, 0.9f}, {0.36f, 0.22f, 0.17f, 0.85f});
  Arc(p, 44, 62, 0, 12, 0, 2 * kPi, {0.66f, 0.13f, 0.09f, 0.95f}, {0.34f, 0.07f, 0.05f, 0.9f});
  {
    const float px[4] = {p.X(110), p.X(440), p.X(440), p.X(110)};
    const float py[4] = {p.Y(58), p.Y(58), p.Y(112), p.Y(112)};
    const Rgba red{0.50f, 0.06f, 0.05f, 0.9f};
    const Rgba c[4] = {red, clear, clear, red};
    Poly4(px, py, c);
  }
  // Disco escuro do despertar, sob o rosto.
  Arc(p, 100, 124, 0, 18, kPi, 2 * kPi, {0.03f, 0.03f, 0.04f, 0.95f}, {0.08f, 0.08f, 0.09f, 0.95f});

  // Cauda escura com filete dourado sob o fim das barras.
  Strip(p, 456, 717, 97, 114, 97, 8, 17, {0.09f, 0.08f, 0.22f, 0.92f}, {0.05f, 0.05f, 0.14f, 0.92f});
  Strip(p, 456, 717, 95.5f, 97, 95.5f, 2, 1.5f, {0.62f, 0.49f, 0.32f, 1}, {0.62f, 0.49f, 0.32f, 1});

  NativeBar(p, 172, 703, 60, 15, Ratio(f.v[0], f.v[1]), {0.62f, 0.94f, 0.36f, 1}, {0.27f, 0.74f, 0.22f, 1},
            {0.12f, 0.46f, 0.13f, 1}, {0.26f, 0.07f, 0.05f, 1});
  NativeBar(p, 154, 679, 81, 15, Ratio(f.v[2], f.v[3]), {0.67f, 0.87f, 1.0f, 1}, {0.33f, 0.64f, 0.93f, 1},
            {0.16f, 0.37f, 0.72f, 1}, {0.05f, 0.10f, 0.22f, 1});

  // Marca do meio da barra de chakra.
  const float markU = 154 + 525 * 0.40f + 7;
  Arc(p, markU, 88.5f, 0, 11, 0, 2 * kPi, {0.93f, 0.35f, 0.27f, 1}, {0.97f, 0.73f, 0.62f, 1});
  Arc(p, markU, 88.5f, 3.5f, 6.5f, 0.4f, 4.6f, {1, 0.93f, 0.86f, 1}, {1, 0.93f, 0.86f, 1});

  // Rosto sem moldura, por cima do brasao. Do lado direito fica espelhado, como na HUD nativa.
  if (const auto* portrait = Portrait(f.portrait)) {
    constexpr float kBox = 112;
    const float width = portrait->aspect >= 1 ? kBox : kBox * portrait->aspect;
    const float height = portrait->aspect >= 1 ? kBox / portrait->aspect : kBox;
    const float x = p.left ? p.X(100 - width / 2) : p.X(100 + width / 2);
    Quad(x, p.Y(112 - height), width * p.k, height * p.k, p.left ? 0.0f : 1.0f, 0, p.left ? 1.0f : 0.0f, 1, 1, 1, 1,
         1, portrait->texture.Get());
  }

  // Nome no tracado de pincel.
  char tag[8];
  wsprintfA(tag, "J%d", slotNumber);
  const char* name = FighterName(f.portrait);
  if (!name) name = tag;
  const float nameSize = 40 * p.k;
  const float nameW = TextWidth(name, nameSize, g_nameAdvance);
  Text(p.left ? p.X(190) : p.X(190) - nameW, p.Y(12), name, nameSize, 1, 1, 1, 1, g_nameSrv, g_nameAdvance);

  // Pilula com LT e as quatro cargas de substituicao.
  {
    const Rgba back{0.05f, 0.04f, 0.04f, 0.92f};
    Strip(p, 176, 390, 106, 124, 106, 0, 18, back, back);
    Arc(p, 176, 115, 0, 9, kPi * 0.5f, kPi * 1.5f, back, back);
    Arc(p, 390, 115, 0, 9, -kPi * 0.5f, kPi * 0.5f, back, back);
    const float textSize = 20 * p.k;
    const float textW = TextWidth("LT", textSize);
    Text(p.left ? p.X(182) : p.X(182) - textW, p.Y(103), "LT", textSize, 1, 1, 1);
    const int full = int(Ratio(f.v[4], f.v[5]) * 4 + 0.5f);
    for (int pip = 0; pip < 4; ++pip) {
      const float u0 = 226 + pip * 40.0f, u1 = u0 + 36;
      const bool on = pip < full;
      const Rgba edge = on ? Rgba{0.86f, 0.40f, 0.08f, 1} : Rgba{0.20f, 0.13f, 0.08f, 1};
      const Rgba core = on ? Rgba{1.0f, 0.74f, 0.28f, 1} : Rgba{0.30f, 0.20f, 0.12f, 1};
      Strip(p, u0 + 5, u1 - 5, 110, 115, 110, 0, 5, edge, core);
      Strip(p, u0 + 5, u1 - 5, 115, 120, 115, 0, 5, core, edge);
      const float capU0[2] = {u0, u1 - 5}, capU1[2] = {u0 + 5, u1};
      for (int side = 0; side < 2; ++side) {
        const float a = capU0[side], b = capU1[side];
        const float outer = side ? b : a, inner = side ? a : b;
        const float px[4] = {p.X(inner), p.X(inner), p.X(outer), p.X(outer)};
        const float py[4] = {p.Y(110), p.Y(120), p.Y(116), p.Y(114)};
        const Rgba c[4] = {edge, edge, edge, edge};
        Poly4(px, py, c);
      }
    }
  }
}

// Replacement HUD: the six fighter plates are real gauge widgets, not
// leader overlays. The native player-gauge Flash movies are hidden by the
// separate and reversible Scaleform asset override included in the test build.
void SmallSupportPortrait(const PlateSpace& panel, const HudFighter& support,
                          int slot, float centerU, float centerV) {
  const Rgba shadow{0.03f, 0.03f, 0.05f, 0.98f};
  const Rgba border{0.81f, 0.66f, 0.41f, 1};
  const Rgba inner{0.22f, 0.14f, 0.17f, 0.98f};
  Arc(panel, centerU, centerV, 0, 27, 0, 2*kPi, inner, shadow);
  if (const auto* portrait = Portrait(support.portrait)) {
    constexpr float size = 44;
    const float w = portrait->aspect >= 1 ? size : size * portrait->aspect;
    const float h = portrait->aspect >= 1 ? size / portrait->aspect : size;
    const float x = panel.left ? panel.X(centerU - w/2) : panel.X(centerU + w/2);
    Quad(x, panel.Y(centerV - h/2), w * panel.k, h * panel.k,
         panel.left ? 0.0f : 1.0f, 0,
         panel.left ? 1.0f : 0.0f, 1, 1, 1, 1, 1, portrait->texture.Get());
  }
  Arc(panel, centerU, centerV, 24, 28, 0, 2*kPi, border, shadow);
  char label[12];
  std::snprintf(label, sizeof(label), "J%d", slot);
  const float size = 16 * panel.k;
  const float w = TextWidth(label, size);
  Text(panel.left ? panel.X(centerU+14) : panel.X(centerU+14)-w,
       panel.Y(centerV+15), label, size, 1.0f, 0.96f, 0.82f);
}
void BuildPlates(const HudFighter f[6]) {
  const float s = std::min(g_h / 1080.0f, g_w / 1920.0f);
  // Respect the Storm 4 composition: leader and supports form three mirrored
  // rows on each edge, with a generous central gap for the battle timer.
  // Same dimensions and gauges for all six fighters, whether human or CPU.
  constexpr float kPanelScale = 0.83f;
  constexpr float kRowPitch = 130.0f;
  constexpr float kPanelX = 27.0f;
  constexpr float kPanelY = 3.0f;
  for (int row = 0; row < 3; ++row) {
    for (int side = 0; side < 2; ++side) {
      const HudFighter* actor = nullptr;
      for (int k = 0; k < 6; ++k) {
        if (f[k].valid && f[k].side == side && f[k].row == row) {
          actor = &f[k]; break;
        }
      }
      if (!actor) continue;
      const PlateSpace panel{side == 0, kPanelX * s,
                             (kPanelY + kRowPitch * row) * s, kPanelScale * s};
      const int slot = side * 3 + row + 1;
      NativePlate(*actor, slot, panel);
      // The approved Storm 4 reference includes two circular partner icons.
      int shown = 0;
      for (int k = 0; k < 6 && shown < 2; ++k) {
        if (!f[k].valid || f[k].side != side || f[k].row == row) continue;
        const int other = f[k].side * 3 + f[k].row + 1;
        SmallSupportPortrait(panel, f[k], other, 88.0f + shown * 60.0f, 155.0f);
        ++shown;
      }
      // Permanent J1..J6 badge allows CPU and local pad mapping to be read
      // instantly; this does not modify any player controls.
      const Rgba tagFill = side == 0 ? Rgba{0.035f,0.19f,0.39f,1}
                                     : Rgba{0.47f,0.075f,0.075f,1};
      Arc(panel, 35, 100, 0, 23, 0, 2*kPi, tagFill, tagFill);
      Arc(panel, 35, 100, 21, 24, 0, 2*kPi,
          {0.91f,0.73f,0.49f,1}, {0.37f,0.22f,0.13f,1});
      char label[8];
      std::snprintf(label, sizeof(label), "J%d", slot);
      const float font = 21 * panel.k;
      const float width = TextWidth(label, font);
      Text(panel.left ? panel.X(35) - width/2 : panel.X(35) - width/2,
           panel.Y(87), label, font, 1, 1, 1);
    }
  }
}

// A mira usa cantos abertos para manter o lutador visivel, com etiquetas por controle.
constexpr Rgba kLockColors[] = {{1.00f, 0.73f, 0.32f, 1}, {0.36f, 0.79f, 1.00f, 1},
                                {0.77f, 0.61f, 1.00f, 1}, {0.46f, 0.94f, 0.67f, 1}};
constexpr Rgba kLockOutline{0.04f, 0.04f, 0.06f, 0.96f};
constexpr const char* kLockLabels[] = {"P1", "P2", "P3", "P4"};

struct LockGroup {
  // Copy world position into this frame's group, never keep a pointer into another array.
  float position[3]{};
  int pads[4];
  int count = 0;
  ULONGLONG acquired = 0;
};

struct LockAnimation {
  uint64_t battle = 0;
  int slot = -1;
  ULONGLONG acquired = 0;
};
LockAnimation g_lockAnimation[4];

void LockStroke(float x0, float y0, float x1, float y1, float width, Rgba color) {
  const float dx = x1 - x0, dy = y1 - y0;
  const float offset = width * 0.5f / std::hypot(dx, dy);
  const float px[4] = {x0 - dy * offset, x1 - dy * offset, x1 + dy * offset, x0 + dy * offset};
  const float py[4] = {y0 + dx * offset, y1 + dx * offset, y1 - dx * offset, y0 - dx * offset};
  const Rgba colors[4] = {color, color, color, color};
  Poly4(px, py, colors);
}

void DrawLockCorners(float x, float y, float radius, float s, const LockGroup& group, float impact) {
  for (int corner = 0; corner < 4; ++corner) {
    const float dx = (corner & 1) ? radius : -radius;
    const float dy = (corner & 2) ? radius : -radius;
    const float px[] = {x + 0.46f * dx, x + 0.78f * dx, x + dx, x + dx};
    const float py[] = {y + dy, y + dy, y + 0.78f * dy, y + 0.46f * dy};
    const Rgba color = kLockColors[group.pads[corner % group.count]];
    const Rgba accent{color.r + (1 - color.r) * impact, color.g + (1 - color.g) * impact,
                      color.b + (1 - color.b) * impact, 1};
    for (int i = 0; i < 3; ++i) LockStroke(px[i], py[i], px[i + 1], py[i + 1], 5.5f * s, kLockOutline);
    for (int i = 0; i < 3; ++i) LockStroke(px[i], py[i], px[i + 1], py[i + 1], 2.5f * s, accent);
  }
}

void DrawLockBadges(float x, float y, float s, const LockGroup& group) {
  const float w = 28 * s, h = 20 * s, gap = 4 * s;
  const float span = group.count * (w + gap) - gap;
  float left = std::clamp(x - span / 2, 6 * s, g_w - span - 6 * s);
  y = std::clamp(y, 6 * s, g_h - h - 6 * s);
  for (int i = 0; i < group.count; ++i) {
    const int pad = group.pads[i];
    const Rgba color = kLockColors[pad];
    Rect(left, y, w, h, kLockOutline.r, kLockOutline.g, kLockOutline.b, kLockOutline.a);
    Rect(left, y + h - 2 * s, w, 2 * s, color.r, color.g, color.b, 1);
    const char* label = kLockLabels[pad];
    Text(left + (w - TextWidth(label, 16 * s)) / 2, y + 1 * s, label, 16 * s, color.r, color.g, color.b);
    left += w + gap;
  }
}

void DrawLockEdge(float x, float y, float dx, float dy, float s, const LockGroup& group) {
  const float length = std::hypot(dx, dy);
  if (length < 0.0001f || !std::isfinite(length)) return;
  const float nx = dx / length * s, ny = dy / length * s;
  const float px[] = {x - 6 * nx + 9 * ny, x + 7 * nx, x - 6 * nx - 9 * ny};
  const float py[] = {y - 6 * ny - 9 * nx, y + 7 * ny, y - 6 * ny + 9 * nx};
  const Rgba color = kLockColors[group.pads[0]];
  for (int i = 0; i < 2; ++i) LockStroke(px[i], py[i], px[i + 1], py[i + 1], 6 * s, kLockOutline);
  for (int i = 0; i < 2; ++i) LockStroke(px[i], py[i], px[i + 1], py[i + 1], 3 * s, color);
  DrawLockBadges(x, y + (y > g_h * 0.75f ? -36 : 17) * s, s, group);
}

void DrawConnectionsLock(float x, float y, float radius, float s,
                         const LockGroup& group, float impact) {
  // Golden circular ring with open centre, similar to Connections' targeting.
  const Rgba black{0.10f, 0.08f, 0.02f, 0.93f};
  const Rgba gold{1.0f, 0.77f + 0.18f * impact, 0.18f + 0.50f * impact, 0.97f};
  const Rgba orange{1.0f, 0.47f, 0.05f, 0.98f};
  const float r = radius * (1.0f + 0.18f * impact);
  constexpr int segments = 40;
  for (int i = 0; i < segments; ++i) {
    const float a = 6.2831853f * i / segments;
    const float b = 6.2831853f * (i + 1) / segments;
    const float x0 = x + r * std::cos(a), y0 = y + r * std::sin(a);
    const float x1 = x + r * std::cos(b), y1 = y + r * std::sin(b);
    LockStroke(x0, y0, x1, y1, 5.1f * s, black);
    LockStroke(x0, y0, x1, y1, 2.6f * s, gold);
  }
  for (int i = 0; i < 4; ++i) {
    const float a = 1.5707963f * i;
    const float cs = std::cos(a), sn = std::sin(a);
    LockStroke(x + (r - 2 * s) * cs, y + (r - 2 * s) * sn,
               x + (r + 7 * s) * cs, y + (r + 7 * s) * sn, 5 * s, black);
    LockStroke(x + (r - 2 * s) * cs, y + (r - 2 * s) * sn,
               x + (r + 7 * s) * cs, y + (r + 7 * s) * sn, 2.7f * s, orange);
  }
  if (group.count > 1 || group.pads[0] != 0)
    DrawLockBadges(x, y - r - 30 * s, 0.85f * s, group);
}
// Two native-model anchored lock-on styles. Both use the live view matrix,
// not arbitrary offsets in screen space. Off-screen targets have no floating
// edge indicators: the marker exists only at the projected fighter model.
void DrawBodyTarget(float x, float y, float bodySize, float s,
                    const LockGroup& group, float impact) {
  const float radius = std::clamp(bodySize * 0.125f, 12.0f * s, 25.0f * s);
  // Open brackets, a precise center point, and colored pad identification.
  DrawLockCorners(x, y, radius * (1.0f + 0.14f * impact), s, group, impact);
  const Rgba color = kLockColors[group.pads[0]];
  const Rgba inner{color.r, color.g, color.b, 0.95f};
  Arc(PlateSpace{true, x - 3*s, y - 3*s, 1.0f}, 3*s, 3*s, 0, 2.1f*s,
      0, 2*kPi, inner, inner);
  if (group.count > 1 || group.pads[0] != 0)
    DrawLockBadges(x, y - radius - 28*s, 0.88f*s, group);
}
void DrawOverheadArrow(float x, float headY, float s,
                       const LockGroup& group, float impact) {
  const float tip = headY - 5.0f*s;  // arrow POINT, not its center, above head
  const float width = (12.0f + 3.0f*impact)*s;
  const float arrowHeight = (21.0f + 3.0f*impact)*s;
  // Black silhouette, colored filled downward triangle, tiny highlight.
  const float poX[4] = {x-width-3*s, x+width+3*s, x, x};
  const float poY[4] = {tip-arrowHeight-3*s, tip-arrowHeight-3*s,
                        tip+2*s, tip+2*s};
  const Rgba black{0.018f,0.021f,0.035f,0.98f};
  const Rgba bc[4] = {black,black,black,black};
  Poly4(poX,poY,bc);
  const float piX[4] = {x-width, x+width, x, x};
  const float piY[4] = {tip-arrowHeight,tip-arrowHeight,tip,tip};
  const Rgba primary = kLockColors[group.pads[0]];
  const Rgba gold{std::min(1.0f,primary.r+impact*0.2f),
                  std::min(1.0f,primary.g+impact*0.2f),
                  std::min(1.0f,primary.b+impact*0.2f),1};
  const Rgba top{1.0f,0.94f,0.65f,1};
  const Rgba colors[4] = {top,top,gold,gold};
  Poly4(piX,piY,colors);
  // Always label the person controlling the lock (P1, P2, P3, P4).
  DrawLockBadges(x, tip-arrowHeight-29*s, 0.85f*s, group);
}
void DrawRevolutionCursor(float x, float y, float modelHeight, float s,
                          const LockGroup& group, float impact) {
  // Inspired by Revolution's Ninja World Tournament lock-on cursor.
  // Original Direct3D geometry; no Revolution game images or code copied.
  const float radius = std::clamp(modelHeight*0.17f, 17.0f*s, 31.0f*s);
  const Rgba outline{0.025f,0.033f,0.06f,1.0f};
  const Rgba tint = kLockColors[group.pads[0]];
  const Rgba bright{std::min(1.0f,tint.r+0.16f+0.2f*impact),
                    std::min(1.0f,tint.g+0.13f+0.2f*impact),
                    std::min(1.0f,tint.b+0.07f+0.2f*impact),1.0f};
  const float open=radius*(1.0f+0.17f*impact);
  constexpr float tau=6.28318530718f;
  for (int corner=0; corner<4; ++corner) {
    const float a=tau*(corner+0.5f)/4.0f;
    const float cx=std::cos(a), cy=std::sin(a);
    const float tx=-cy, ty=cx;
    const float tipX=x+cx*open, tipY=y+cy*open;
    const float shoulder=open*0.68f;
    const float spread=9.0f*s;
    const float ax=x+cx*shoulder+tx*spread, ay=y+cy*shoulder+ty*spread;
    const float bx=x+cx*shoulder-tx*spread, by=y+cy*shoulder-ty*spread;
    LockStroke(ax,ay,tipX,tipY,5.5f*s,outline);
    LockStroke(bx,by,tipX,tipY,5.5f*s,outline);
    LockStroke(ax,ay,tipX,tipY,2.7f*s,bright);
    LockStroke(bx,by,tipX,tipY,2.7f*s,bright);
  }
  // Tiny central cross keeps exact torso anchoring readable when crowded.
  for (int axis=0;axis<2;++axis) {
    const float dx=axis==0?4.0f*s:0,dy=axis==0?0:4.0f*s;
    LockStroke(x-dx,y-dy,x+dx,y+dy,4.2f*s,outline);
    LockStroke(x-dx,y-dy,x+dx,y+dy,1.8f*s,bright);
  }
  DrawLockBadges(x,y-open-37.0f*s,0.84f*s,group);
}
void BuildLockMarkers() {
  LockMarker markers[4];
  const int count = PromoteLockMarkers(markers);
  if (count <= 0) return;
  const ULONGLONG now = GetTickCount64();
  LockGroup groups[6];
  for (int i = 0; i < count; ++i) {
    const LockMarker& marker = markers[i];
    if (marker.targetSlot < 0 || marker.targetSlot >= 6 ||
        marker.pad < 0 || marker.pad >= 4) continue;
    LockGroup& group = groups[marker.targetSlot];
    if (group.count >= 4) continue;
    std::memcpy(group.position, marker.position, sizeof(group.position));
    group.pads[group.count++] = marker.pad;

    LockAnimation& animation = g_lockAnimation[marker.pad];
    if (animation.battle != marker.battleId || animation.slot != marker.targetSlot)
      animation = {marker.battleId, marker.targetSlot, now};
    group.acquired = std::max(group.acquired, animation.acquired);
  }
  const float s = std::min(g_h/1080.0f,g_w/1920.0f);
  const float aspect = g_w/g_h;
  const int style = Cfg().lockonStyle.load(std::memory_order_relaxed);
  for (const LockGroup& group : groups) {
    if (!group.count) continue;
    const LockOnAnchors actor = LockOnModelAnchors(group.position);
    float nx=0, ny=0; bool behind = false;
    const float* anchor = style == 0 ? actor.crown : actor.torso;
    if (!CameraProject(anchor,aspect,&nx,&ny,&behind)) continue;
    if (style == 2 && RevolutionOffscreen(nx,ny,behind)) {
      // Revolution has an opponent-position cue when target leaves screen.
      float dx=behind?-nx:nx,dy=behind?-ny:ny;
      if (!std::isfinite(dx) || !std::isfinite(dy)) continue;
      if (std::fabs(dx)+std::fabs(dy)<0.01f) dy=-1.0f;
      const float scale=std::max(std::max(std::fabs(dx)/0.87f,
                                          std::fabs(dy)/0.77f),0.01f);
      const float ex=std::clamp(dx/scale,-0.87f,0.87f);
      const float ey=std::clamp(dy/scale,-0.77f,0.77f);
      DrawLockEdge((1.0f+ex)*g_w*0.5f,
                   (1.0f-ey)*g_h*0.5f,dx,-dy,s,group);
      continue;
    }
    if (!LockOnVisible(nx,ny,behind)) continue;
    float baseX=0,baseY=0;
    const bool baseValid=CameraProject(actor.feet,aspect,&baseX,&baseY);
    if (style != 2 && (!baseValid || !std::isfinite(baseY))) continue;
    const float x=(nx+1.0f)*g_w*0.5f;
    const float y=(1.0f-ny)*g_h*0.5f;
    const float height=baseValid && std::isfinite(baseY)
        ? std::fabs(ny-baseY)*g_h*0.5f : 80.0f*s;
    const float fade=1.0f-std::min(now-group.acquired,200ULL)/200.0f;
    const float impact=fade*fade;
    if (style == 2) DrawRevolutionCursor(x,y,height,s,group,impact);
    else if (style == 1) DrawBodyTarget(x,y,height,s,group,impact);
    else DrawOverheadArrow(x,y,s,group,impact);
  }
}
// ------------------------------------------------------------------ menu

// Original geometry and a Naruto-like warm ink/orange + cool chakra palette.
// Nothing is read from or written to the proprietary Scaleform game assets.
constexpr Rgba kMenuInk{0.022f,0.032f,0.055f,0.96f};
constexpr Rgba kMenuPanel{0.065f,0.079f,0.109f,0.99f};
constexpr Rgba kMenuRow{0.084f,0.100f,0.135f,0.98f};
constexpr Rgba kMenuEdge{0.23f,0.30f,0.38f,1};
constexpr Rgba kMenuWhite{1.0f,0.975f,0.93f,1};
constexpr Rgba kMenuMuted{0.68f,0.74f,0.79f,1};
constexpr Rgba kMenuAmber{1.0f,0.53f,0.13f,1};
constexpr Rgba kMenuMint{0.46f,0.96f,0.72f,1};
constexpr Rgba kMenuBlue{0.27f,0.76f,1.0f,1};
constexpr Rgba kMenuRed{1.0f,0.37f,0.31f,1};
constexpr Rgba kMenuGold{1.0f,0.80f,0.32f,1};
constexpr Rgba kMenuDeep{0.025f,0.038f,0.077f,0.98f};

struct MenuView {
  float x, y, s;
  void Fill(float u, float v, float w, float h, Rgba c) const {
    Rect(x + u * s, y + v * s, w * s, h * s, c.r, c.g, c.b, c.a);
  }
  void Label(float u, float v, const char* label, float size, Rgba c = kMenuWhite) const {
    Text(x + u * s, y + v * s, label, size * s, c.r, c.g, c.b, c.a);
  }
  void Right(float u, float v, const char* label, float size, Rgba c) const {
    Label(u - TextWidth(label, size), v, label, size, c);
  }
  void Brush(float u, float v, const char* label, float size,
             Rgba c = kMenuWhite) const {
    Text(x + u*s,y + v*s,label,size*s,c.r,c.g,c.b,c.a,
         g_nameSrv,g_nameAdvance);
  }
  // Original slanted panel geometry inspired by the Storm series'
  // visual rhythm. Built only from existing D3D primitives.
  void Blade(float u,float v,float w,float h,float tilt,
             Rgba top,Rgba bottom) const {
    const float xx[4]={
      x+(u+tilt)*s,x+(u+w+tilt)*s,
      x+(u+w-tilt)*s,x+(u-tilt)*s};
    const float yy[4]={
      y+v*s,y+v*s,y+(v+h)*s,y+(v+h)*s};
    const Rgba cc[4]={top,top,bottom,bottom};
    Poly4(xx,yy,cc);
  }
  void Stroke(float u0,float v0,float u1,float v1,float thickness,
              Rgba c) const {
    LockStroke(x+u0*s,y+v0*s,x+u1*s,y+v1*s,thickness*s,c);
  }
  MenuView At(float u, float v) const { return {x + u * s, y + v * s, s}; }
};

void MenuTag(const MenuView& p, float x, float y, float w, const char* label, Rgba color) {
  p.Blade(x+7,y,w-14,26,7,
          {color.r*0.25f,color.g*0.25f,color.b*0.24f,1},
          {color.r*0.08f,color.g*0.10f,color.b*0.12f,1});
  p.Fill(x+14,y+23,w-28,2,{color.r,color.g,color.b,0.9f});
  p.Label(x + (w - TextWidth(label, 18)) / 2, y + 3, label, 18, color);
}

void MenuSection(const MenuView& p, float w, const char* number, const char* title, const char* caption) {
  p.Fill(0,0,w,566,kMenuPanel);
  p.Fill(0,0,w,70,{0.08f,0.10f,0.15f,1});
  p.Fill(0,0,5,566,{0.10f,0.14f,0.21f,1});
  p.Blade(25,4,83,61,10,
          {0.93f,0.44f,0.10f,1},{0.54f,0.17f,0.09f,1});
  p.Brush(38,15,number,37,kMenuWhite);
  p.Label(128,12,title,28,kMenuWhite);
  p.Label(128,45,caption,15,kMenuMuted);
  p.Fill(0,69,w,3,kMenuGold);
  // Small manga-speed slashes, carefully outside the readable title.
  for(int i=0;i<3;++i)
    p.Stroke(w-62+i*11,6,w-78+i*11,27,2.2f,
             {1.0f,0.67f,0.26f,0.46f});
  p.Fill(0,565,w,1,kMenuEdge);
}

void MenuFocus(const MenuView& p,float x,float y,float w,float h,
               bool focused,Rgba accent) {
  p.Fill(x,y,w,h,focused
         ? Rgba{0.21f,0.19f,0.17f,1} : kMenuRow);
  if(!focused){
    p.Fill(x,y,w,1,{0.20f,0.25f,0.31f,0.48f});
    return;
  }
  const float shimmer=0.75f+0.20f*std::sin(GetTickCount64()*0.008);
  p.Blade(x+9,y+2,14,h-4,6,
          {accent.r,accent.g,accent.b,shimmer},
          {accent.r*0.58f,accent.g*0.58f,accent.b*0.58f,1});
  p.Fill(x+24,y+1,w-24,2,accent);
  p.Fill(x+24,y+h-2,w-24,2,accent);
  p.Fill(x+w-3,y+3,3,h-6,accent);
  p.Stroke(x+w-34,y+7,x+w-49,y+h-7,2,
           {accent.r,accent.g,accent.b,0.55f});
}

void BuildOptionsPanel(const MenuView& p, const Settings& c, int selected) {
  constexpr float w = 462;
  MenuSection(p, w, "01", Lang("Configuração","Settings"), Lang("Ajuste o combate e a câmera","Combat and camera options"));
  const int camera = c.camera.load();
  struct OptionRow {
    const char* label;
    const char* detail;
    const char* value;
    Rgba color;
  };
  const auto toggle = [](const char* label, const char* detail, bool on) {
    return OptionRow{label, detail, on ? Lang("LIGADO","ON") : Lang("DESLIGADO","OFF"), on ? kMenuMint : kMenuMuted};
  };
  const OptionRow rows[] = {
      {Lang("Modo de batalha","Battle mode"), Lang("FFA BETA: seis lutadores, alvo e dano livres","FFA BETA: six fighters, free targets and damage"),
       c.freeForAll.load() ? "FFA BETA" : c.mode3v3.load() ? "3V3" : "VERSUS",
       c.freeForAll.load() ? kMenuAmber : kMenuMint},
      toggle(Lang("HUD de combate","Battle HUD"), Lang("Retratos, vida e chakra","Portraits, health and chakra"), c.hud.load()),
      toggle("Lock-on", camera == kCameraTournament ? Lang("R3 troca o alvo no Torneio","R3 switches target in Tournament") : Lang("Analógico direito troca o alvo","Right stick switches target"),
             c.lockon.load()),
      {Lang("Estilo do lock-on","Lock-on style"), Lang("Corpo, Seta ou Revolution (cursor + indicador)","Body, Arrow or Revolution (cursor + marker)"),
       c.lockonStyle.load() == 2 ? "REVOLUTION" :
        c.lockonStyle.load() == 1 ? Lang("NO CORPO","ON BODY") : Lang("SETA ACIMA","ARROW ABOVE"), kMenuAmber},
      {Lang("Câmera","Camera"), Lang("Enquadramento durante a luta","Framing during the fight"),
       camera == kCameraRevolution ? "REVOLUTION BETA" :
       camera == kCameraConnections ? "CONNECTIONS" :
       camera == kCameraTournament ? Lang("TORNEIO","TOURNAMENT") :
       camera == kCameraGroup ? Lang("TODOS NA TELA","EVERYONE ON SCREEN") : Lang("DUELO","DUEL"), kMenuAmber},
      toggle(Lang("Resgate de piso","Floor rescue"), Lang("Traz de volta extras sob a arena","Brings back extras below the arena"), c.ring.load()),
      toggle(Lang("Ultimates livres","Free ultimates"), Lang("Mantém o combate durante a técnica","The fight goes on during the technique"), c.ultFree.load()),
      toggle(Lang("Seleção com P2","P2 selection"), Lang("Controle 2 ajuda contra a CPU","Controller 2 helps against the CPU"), c.selectP2.load()),
      toggle(Lang("Supremo em equipe (beta)","Team ultimate (beta)"), Lang("L1/LB ou R1/RB; dupla com chakra cheio","L1/LB or R1/RB; pair with full chakra"), c.teamUltimate.load()),
      {Lang("Botao do supremo","Ultimate button"), Lang("L1/LB ou R1/RB","L1/LB or R1/RB"),
       c.teamUltimateButton.load() == 0 ? "L1 / LB" : "R1 / RB", kMenuAmber},
      toggle(Lang("Despertar no inicio","Awaken at start"), Lang("Tenta despertar todos ao entrar","Tries to awaken everyone on entry"), c.awakenAtStart.load()),
      toggle("Jutsu Clash (beta)", Lang("Disputa quando dois jutsus se chocam","Struggle when two jutsu collide"), c.jutsuClash.load()),
  };
  static_assert(sizeof(rows) / sizeof(rows[0]) == kItemSlot0);
  for (int i = 0; i < kItemSlot0; ++i) {
    const auto& row = rows[i];
    const float y = 74 + i * 38.0f;  // 12 linhas cabem no painel (566)
    MenuFocus(p, 13, y, w - 26, 37, selected == i, kMenuAmber);
    p.Label(27, y + 1, row.label, 18);
    p.Label(27, y + 21, row.detail, 14, kMenuMuted);
    MenuTag(p, w - 150, y + 5, 122, row.value, row.color);
  }
  p.Label(18, 536, Lang("As opções são salvas quando você as altera.","Options are saved as you change them."), 18, kMenuMuted);
}

void BuildTeamsPanel(const MenuView& p, const Settings& c, int selected) {
  constexpr float w = 458;
  static const char* const names[] = {"Player 1", "Player 2", "Player 3", "Player 4"};
  MenuSection(p, w, "02", Lang("Equipes","Teams"), Lang("Escolha quem controla cada lutador","Choose who controls each fighter"));
  for (int side = 0; side < 2; ++side) {
    const Rgba accent = side == 0 ? kMenuBlue : kMenuRed;
    const float y = 82 + side * 210.0f;
    p.Fill(13,y,w-26,195,kMenuDeep);
    p.Blade(27,y+5,211,32,9,
            {accent.r*0.50f,accent.g*0.50f,accent.b*0.50f,1},
            {accent.r*0.13f,accent.g*0.13f,accent.b*0.13f,1});
    p.Brush(39,y+7,side==0?Lang("EQUIPE 1 / FOLHA","TEAM 1 / LEAF"):Lang("EQUIPE 2 / RIVAL","TEAM 2 / RIVAL"),26,kMenuWhite);
    p.Fill(13,y+39,w-26,2,accent);
    for (int row = 0; row < 3; ++row) {
      const int slot = side * 3 + row;
      const float yy = y + 45 + row * 46.0f;
      const int control = c.slot[slot].load();
      const int pad = SlotPadIndex(control);
      const Rgba color = pad >= 0 ? kLockColors[pad] : kMenuMuted;
      const char* who = pad >= 0 ? names[pad] : control == kSlotCpu ? "CPU" : Lang("Automático","Auto");
      char tag[8];
      wsprintfA(tag, "J%d", slot + 1);
      MenuFocus(p, 23, yy, w - 46, 39, selected == kItemSlot0 + slot, accent);
      p.Label(36, yy + 6, tag, 23, accent);
      p.Label(88, yy + 8, row == 0 ? Lang("Líder","Leader") : Lang("Aliado","Ally"), 20, kMenuMuted);
      MenuTag(p, w - 154, yy + 6, 116, who, color);
    }
  }
  p.Label(18, 513, Lang("Para jogar em dupla, coloque dois Players na mesma equipe.","To play as a pair, put two Players on the same team."), 17, kMenuMuted);
  p.Label(18, 537, Lang("As vagas valem na próxima luta.","Slots apply to the next fight."), 17, kMenuMuted);
}

// Teste ao vivo de botoes, gatilhos e analogicos dos quatro controles.
void BuildPadPanel(const MenuView& p, const Settings& c) {
  constexpr float w = 420;
  MenuSection(p, w, "03", Lang("Controles","Controllers"), Lang("Pressione os botões para testar","Press buttons to test"));
  int selectedSlot[4] = {-1, -1, -1, -1};
  for (int slot = 0; slot < 6; ++slot) {
    const int pad = SlotPadIndex(c.slot[slot].load());
    if (pad >= 0) selectedSlot[pad] = slot;
  }
  static const struct {
    const char* name;
    WORD mask;
  } buttons[] = {{"A", XINPUT_GAMEPAD_A}, {"B", XINPUT_GAMEPAD_B}, {"X", XINPUT_GAMEPAD_X},
                 {"Y", XINPUT_GAMEPAD_Y}, {"LB", XINPUT_GAMEPAD_LEFT_SHOULDER},
                 {"RB", XINPUT_GAMEPAD_RIGHT_SHOULDER}, {"START", XINPUT_GAMEPAD_START},
                 {"BACK", XINPUT_GAMEPAD_BACK}};

  for (int i = 0; i < 4; ++i) {
    const MenuView card = p.At(13, 82 + i * 116.0f);
    const Rgba accent = kLockColors[i];
    XINPUT_GAMEPAD pad{};
    const bool on = InputPadStatus(i, &pad);
    card.Fill(0,0,w-26,106,kMenuRow);
    card.Blade(16,0,70,32,8,
               on ? Rgba{accent.r*0.36f,accent.g*0.36f,accent.b*0.36f,1}
                  : kMenuEdge,kMenuDeep);
    card.Fill(0,0,4,106,on?accent:kMenuEdge);
    card.Fill(0,104,w-26,2,{accent.r,accent.g,accent.b,0.36f});
    MenuTag(card, 11, 8, 33, kLockLabels[i], accent);
    card.Label(56, 10, on ? Lang("Conectado","Connected") : Lang("Sem conexão","Disconnected"), 20, on ? kMenuMint : kMenuMuted);
    const int slot = selectedSlot[i];
    char who[24];
    std::snprintf(who, sizeof(who), "%s", Lang("Sem vaga manual","No manual slot"));
    if (slot >= 0) wsprintfA(who, Lang("J%d / Equipe %d","J%d / Team %d"), slot + 1, slot / 3 + 1);
    card.Right(w - 38, 12, who, 18, kMenuMuted);

    for (int j = 0; j < 8; ++j) {
      const float x = 11 + j * 47.0f;
      const auto& button = buttons[j];
      const bool down = (pad.wButtons & button.mask) != 0;
      card.Fill(x, 42, 43, 23, down ? accent : kMenuInk);
      card.Label(x + (43 - TextWidth(button.name, 15)) / 2, 45, button.name, 15,
                 down ? kMenuInk : kMenuMuted);
    }
    for (int stick = 0; stick < 2; ++stick) {
      const float x = 11 + stick * 64.0f;
      const float dx = (stick ? pad.sThumbRX : pad.sThumbLX) * (9.0f / 32768.0f);
      const float dy = (stick ? pad.sThumbRY : pad.sThumbLY) * (9.0f / 32768.0f);
      card.Label(x, 77, stick ? "R" : "L", 16, kMenuMuted);
      card.Fill(x + 17, 73, 25, 25, kMenuInk);
      card.Fill(x + 17, 85, 25, 1, kMenuEdge);
      card.Fill(x + 29, 73, 1, 25, kMenuEdge);
      card.Fill(x + 27.5f + dx, 83.5f - dy, 4, 4, on ? accent : kMenuEdge);
    }
    for (int trigger = 0; trigger < 2; ++trigger) {
      const float x = 137 + trigger * 122.0f;
      const float value = (trigger ? pad.bRightTrigger : pad.bLeftTrigger) / 255.0f;
      card.Label(x, 77, trigger ? "RT" : "LT", 16, kMenuMuted);
      card.Fill(x + 27, 82, 87, 7, kMenuInk);
      card.Fill(x + 27, 82, 87 * value, 7, accent);
    }
  }
}

#include "menu_storm4_preview.inl"

void BuildMenu() {
  if (Storm4MenuPreviewEnabled()) { BuildStorm4MenuPreview(); return; }
  constexpr float w=1440,h=802;
  const float s=std::min(g_w/1520.0f,g_h/886.0f);
  const MenuView p{(g_w-w*s)/2,(g_h-h*s)/2,s};
  const Settings& c=Cfg();
  const int selected=MenuSelection();

  // Full-screen matte and original, painterly ninja scroll geometry.
  Rect(0,0,g_w,g_h,0.014f,0.018f,0.031f,0.84f);
  p.Fill(-7,5,w+14,h+6,{0.010f,0.015f,0.029f,0.85f});
  p.Fill(0,0,w,h,kMenuInk);
  p.Fill(0,0,w,120,{0.071f,0.084f,0.117f,1});
  p.Blade(30,0,566,120,35,
          {0.69f,0.24f,0.07f,1},{0.26f,0.10f,0.07f,1});
  p.Blade(37,0,535,117,34,
          {0.32f,0.13f,0.06f,0.74f},{0.06f,0.06f,0.09f,0.85f});
  p.Fill(0,0,w,4,kMenuGold);
  p.Fill(0,118,w,2,kMenuAmber);
  for(int i=0;i<9;++i){
    const float x=692+i*25.0f;
    p.Stroke(x,8,x-48,111,4.8f,
             {0.99f,0.59f,0.21f,0.18f});
  }
  // Sharp six-fighter insignia: a lightweight original icon.
  p.Blade(48,28,82,76,17,kMenuGold,kMenuAmber);
  p.Blade(50,34,78,65,15,kMenuDeep,kMenuDeep);
  p.Brush(75,42,"6",58,kMenuWhite);
  for(int i=0;i<6;++i){
    const float x=179+i*22.0f;
    p.Stroke(x,87,x+11,108,3,kMenuGold);
  }
  p.Label(166,15,"NINJA BATTLE SYSTEM",18,kMenuGold);
  p.Brush(161,36,"STORM 4 TAG TEAM",49,kMenuWhite);
  p.Label(350,92,"LOCAL CO-OP  /  SIMULTANEOUS COMBAT",17,kMenuWhite);
  p.Label(45,122,"Made for Revi Whitchmore",17,kMenuGold);
  p.Right(w-33,22,Lang("MODO DE BATALHA","BATTLE MODE"),18,kMenuMuted);
  p.Right(w-33,53,c.freeForAll.load()?Lang("FFA / TESTE","FFA / TEST"):
          c.mode3v3.load()?Lang("3 CONTRA 3","3 VS 3"):Lang("VERSUS PADRAO","STANDARD VERSUS"),37,kMenuGold);

  BuildOptionsPanel(p.At(24,142),c,selected);
  BuildTeamsPanel(p.At(504,142),c,selected);
  BuildPadPanel(p.At(980,142),c);
  p.Blade(31,716,w-62,7,7,kMenuGold,kMenuAmber);
  p.Fill(22,739,w-44,47,{0.06f,0.075f,0.11f,1});
  p.Label(40,750,Lang("DPAD / SETAS","DPAD / ARROWS"),18,kMenuGold);
  p.Label(169,750,Lang("NAVEGAR","NAVIGATE"),17,kMenuWhite);
  p.Label(304,750,"A / ENTER  < > ",18,kMenuGold);
  p.Label(480,750,Lang("ALTERAR","CHANGE"),17,kMenuWhite);
  p.Label(602,750,"B / ESC / SELECT",18,kMenuGold);
  p.Label(787,750,Lang("VOLTAR","BACK"),17,kMenuWhite);
  MenuFocus(p,w-199,742,171,37,selected==kItemClose,kMenuAmber);
  p.Brush(w-152,748,Lang("FECHAR","CLOSE"),24,kMenuWhite);
}
void BuildFfaProgress(unsigned roster, unsigned eliminated) {
  if (!roster) return;
  const float s = std::min(g_w / 1600.0f, g_h / 1080.0f);
  const MenuView p{g_w * 0.5f - 255 * s, 167 * s, s};
  int total = 0, remaining = 0;
  for (int k = 0; k < 6; ++k) {
    const unsigned bit = 1u << k;
    if (roster & bit) {
      ++total;
      if (!(eliminated & bit)) ++remaining;
    }
  }
  p.Fill(0, 0, 510, 43, kMenuInk);
  p.Fill(0, 0, 4, 43, kMenuAmber);
  char text[128];
  int used = std::snprintf(text, sizeof(text), Lang("FFA  |  VIVOS: %d/%d","FFA  |  ALIVE: %d/%d"), remaining, total);
  if (eliminated && used > 0 && used < int(sizeof(text)) - 16) {
    used += std::snprintf(text + used, sizeof(text) - used, Lang("  |  FORA:","  |  OUT:"));
    for (int k = 0; k < 6 && used < int(sizeof(text)) - 8; ++k)
      if (eliminated & (1u << k))
        used += std::snprintf(text + used, sizeof(text) - used, " J%d", k + 1);
  }
  p.Label(17, 9, text, 19, kMenuAmber);
}
void BuildFfaWinner(int fighter) {
  if (fighter < 0) return;
  const float s = std::min(g_w / 1600.0f, g_h / 1080.0f);
  const MenuView p{g_w / 2.0f - 245 * s, 94 * s, s};
  p.Fill(0, 0, 490, 54, kMenuInk);
  p.Fill(0, 0, 5, 54, kMenuAmber);
  char msg[80];
  std::snprintf(msg, sizeof(msg), Lang("FFA / VENCEDOR INDIVIDUAL: J%d","FFA / SOLO WINNER: J%d"), fighter + 1);
  p.Label(22, 10, msg, 24, kMenuAmber);
}
void BuildHint() {
  const float s = std::min(g_h / 1080.0f, g_w / 1600.0f);
  const MenuView p{g_w - 452 * s, g_h - 55 * s, s};
  p.Fill(0, 0, 420, 34, kMenuInk);
  p.Fill(0, 0, 3, 34, kMenuAmber);
  p.Label(11, 6, Cfg().freeForAll.load() ? "STORM 4 TAG TEAM / FFA BETA" : Cfg().mode3v3.load() ? "STORM 4 TAG TEAM / 3V3" : "STORM 4 TAG TEAM / VERSUS", 17, kMenuAmber);
  p.Right(409, 7, "F1 / SELECT", 18, kMenuWhite);
}

// ------------------------------------------------------------------ quadro

// Assinatura discreta de autoria, desenhada apenas sobre menus.
// Posicao abaixo do teaser Chronicles, sem interferir com opcoes ou luta.
void BuildReviWatermark() {
  // O Storm 4 pode usar um framebuffer maior do que a area de tela
  // (ex.: 1920x1080 numa area fisica de 1536x864).
  // Nessa situacao ancora a assinatura dentro da regiao visivel.
  const float visibleW = std::min(g_w,
    static_cast<float>(GetSystemMetrics(SM_CXSCREEN)));
  const float visibleH = std::min(g_h,
    static_cast<float>(GetSystemMetrics(SM_CYSCREEN)));
  const float s = std::min(visibleW / 1600.0f, visibleH / 900.0f);
  const MenuView w{visibleW - 306.0f*s, visibleH - 35.0f*s, s};

  // Base suave, sombra e ouro transparente, estilo visual do Storm 4.
  w.Fill(0, 0, 294, 32, {0.018f, 0.025f, 0.042f, 0.29f});
  w.Fill(0, 29, 294, 1, {1.0f, 0.70f, 0.27f, 0.35f});
  w.Right(279, 7, "Revi Whitchmore", 21,
          {0.0f, 0.0f, 0.0f, 0.34f});
  const MenuView foreground=w.At(-1,-1);
  foreground.Right(279, 7, "Revi Whitchmore", 21,
                   {1.0f, 0.92f, 0.72f, 0.66f});
}

void BuildChroniclesModeEntry() {
  if (Storm4MenuPreviewEnabled()) { BuildStorm4ChroniclesPreview(); return; }
  const float s=std::min(g_w/1600.0f,g_h/900.0f);
  const bool open=ChroniclesChapterScreenOpen();
  if(!open){
    const MenuView teaser{g_w-638*s,g_h-132*s,s};
    teaser.Blade(19,4,576,96,22,
                 {0.81f,0.35f,0.075f,0.97f},
                 {0.18f,0.07f,0.06f,0.95f});
    teaser.Blade(25,10,551,85,20,kMenuDeep,kMenuInk);
    teaser.Brush(50,14,"CHRONICLES",37,kMenuWhite);
    teaser.Label(52,58,Lang("Y / F6  -  NARUTO CLASSICO","Y / F6  -  CLASSIC NARUTO"),19,kMenuGold);
    return;
  }
  const bool missions=ChroniclesMissionListOpen();
  const bool detail=ChroniclesMissionDetailOpen();
  Rect(0,0,g_w,g_h,0.010f,0.019f,0.034f,0.70f);
  constexpr float w=900,h=660;
  const MenuView c{(g_w-w*s)/2,(g_h-h*s)/2,s};
  c.Fill(-9,7,w+18,h+4,{0.006f,0.01f,0.016f,0.84f});
  c.Fill(0,0,w,h,kMenuInk);
  c.Fill(0,0,w,132,{0.076f,0.096f,0.14f,1});
  c.Blade(25,0,520,128,33,
          {0.75f,0.29f,0.075f,1},
          {0.20f,0.065f,0.055f,1});
  c.Blade(32,0,486,121,31,
          {0.34f,0.14f,0.065f,0.77f},
          {0.06f,0.05f,0.08f,1});
  c.Fill(0,0,w,4,kMenuGold);
  c.Fill(0,125,w,3,kMenuGold);
  c.Label(42,15,Lang("NARUTO CLASSICO  /  CHRONICLES V0.8","CLASSIC NARUTO  /  CHRONICLES V0.8"),19,kMenuGold);
  c.Brush(41,37,"CHRONICLES MODE",48,kMenuWhite);
  c.Label(42,92,ChroniclesCampaignLabel(),19,kMenuWhite);
  c.Right(w-35,32,detail?Lang("DETALHES","DETAILS"):missions?Lang("MISSOES","MISSIONS"):Lang("ARCOS","ARCS"),20,kMenuMuted);
  c.Right(w-35,65,ChroniclesEditionLabel(),15,kMenuGold);
  for(int i=0;i<8;++i){
    const float x=543+i*31.0f;
    c.Stroke(x,13,x-56,120,4,{0.93f,0.45f,0.12f,0.16f});
  }
  const int arc=ChroniclesChapterSelection();
  if(detail){
    const int mission=ChroniclesMissionSelection();
    c.Label(38,147,ChroniclesMissionTitle(mission),26,kMenuGold);
    c.Right(w-38,149,ChroniclesMissionTeams(mission),24,kMenuGold);
    char stageInfo[180];
    std::snprintf(stageInfo,sizeof(stageInfo),Lang("ARENA: %s    |    DIFICULDADE: %s","ARENA: %s    |    DIFFICULTY: %s"),
                  ChroniclesMissionArena(mission),
                  ChroniclesMissionDifficulty(mission));
    c.Label(38,180,stageInfo,17,kMenuMuted);
    c.Label(38,211,Lang("LUTADORES ALIADOS (VAGAS)","ALLIED FIGHTERS (SLOTS)"),17,kMenuGold);
    c.Label(468,211,Lang("LUTADORES INIMIGOS (VAGAS)","ENEMY FIGHTERS (SLOTS)"),17,kMenuGold);
    for(int slot=0;slot<3;++slot){
      char ally[110],enemy[110];
      std::snprintf(ally,sizeof(ally),"A%d  %s",slot+1,
                    ChroniclesFighterInSlot(mission,0,slot));
      std::snprintf(enemy,sizeof(enemy),Lang("I%d  %s","E%d  %s"),slot+1,
                    ChroniclesFighterInSlot(mission,1,slot));
      c.Label(38,239+slot*24.0f,ally,19,kMenuWhite);
      c.Label(468,239+slot*24.0f,enemy,19,kMenuWhite);
    }
    if(ChroniclesRosterDlcNeeded(mission))
      c.Right(w-38,315,Lang("ELENCO DLC SOM NECESSARIO","SOUND FOUR DLC ROSTER REQUIRED"),15,kMenuGold);
    else
      c.Right(w-38,315,Lang("ESCALACAO PLANEJADA / IDS PENDENTES","PLANNED LINEUP / IDS PENDING"),15,kMenuMuted);
    c.Label(38,328,Lang("OBJETIVO PLANEJADO","PLANNED OBJECTIVE"),17,kMenuGold);
    c.Label(38,350,ChroniclesMissionObjective(mission),20,kMenuWhite);
    c.Label(38,379,Lang("REGRA DA MISSAO","MISSION RULE"),17,kMenuGold);
    c.Label(38,402,ChroniclesMissionSpecial(mission),18,kMenuWhite);
    c.Label(38,432,Lang("ESTILO DE IA PREVISTO","PLANNED AI STYLE"),17,kMenuGold);
    c.Label(38,453,ChroniclesMissionAI(mission),18,kMenuWhite);
    c.Label(38,479,"BONUS: ",17,kMenuGold);
    c.Label(126,479,ChroniclesMissionBonus(mission),17,kMenuWhite);
    char balance[190];
    std::snprintf(balance,sizeof(balance),
      Lang("BALANCEAMENTO PREVISTO: HP ALIADO %d%% / HP INIMIGO %d%% / DANO INIMIGO %d%%","PLANNED BALANCE: ALLY HP %d%% / ENEMY HP %d%% / ENEMY DAMAGE %d%%"),
      ChroniclesMissionAllyHealth(mission),
      ChroniclesMissionEnemyHealth(mission),
      ChroniclesMissionEnemyDamage(mission));
    c.Label(38,507,balance,15,kMenuMuted);
    if(ChroniclesMissionIsBoss(mission)){
      char boss[160];
      std::snprintf(boss,sizeof(boss),Lang("BOSS: %s  /  %d FASES (AINDA PLANEJADAS)","BOSS: %s  /  %d PHASES (STILL PLANNED)"),
        ChroniclesMissionBossName(mission),ChroniclesMissionBossPhases(mission));
      c.Label(38,537,boss,17,kMenuGold);
    }
  }else if(missions){
    const int first=ChroniclesArcMissionFirst(arc);
    const int count=ChroniclesArcMissionCount(arc);
    const int focus=ChroniclesMissionSelection();
    const int page=((focus-first)/6);
    char heading[120];
    std::snprintf(heading,sizeof(heading),Lang("ARCO %02d  /  %s","ARC %02d  /  %s"),arc+1,
                  ChroniclesChapterTitle(arc));
    c.Label(38,146,heading,22,kMenuGold);
    char range[50];
    std::snprintf(range,sizeof(range),"%d-%d / %d",page*6+1,
                  std::min(count,page*6+6),count);
    c.Right(w-39,150,range,17,kMenuMuted);
    for(int row=0;row<6;++row){
      const int i=first+page*6+row;
      if(i>=first+count)break;
      const float y=179+row*57.0f;
      const bool selected=(i==focus);
      MenuFocus(c,38,y,w-76,51,selected,kMenuGold);
      c.Brush(54,y+9,ChroniclesMissionId(i),28,kMenuWhite);
      c.Label(143,y+9,ChroniclesMissionTitle(i),22,
              selected?kMenuWhite:kMenuMuted);
      c.Right(w-63,y+11,ChroniclesMissionTeams(i),21,kMenuGold);
      c.Label(144,y+32,ChroniclesMissionStatus(i),14,kMenuMuted);
    }
  }else{
    c.Label(38,146,Lang("ESCOLHA O ARCO DA HISTORIA","CHOOSE A STORY ARC"),22,kMenuGold);
    c.Right(w-39,150,Lang("40 MISSOES PLANEJADAS","40 PLANNED MISSIONS"),16,kMenuMuted);
    const int focus=ChroniclesChapterSelection();
    for(int i=0;i<ChroniclesArcCount();++i){
      const float y=179+i*57.0f;
      const bool selected=i==focus;
      MenuFocus(c,38,y,w-76,51,selected,kMenuGold);
      char number[12];
      std::snprintf(number,sizeof(number),"%02d",i+1);
      c.Brush(58,y+10,number,30,kMenuWhite);
      c.Label(144,y+7,ChroniclesChapterTitle(i),23,
              selected?kMenuWhite:kMenuMuted);
      c.Label(145,y+34,ChroniclesChapterSubtitle(i),14,kMenuMuted);
      char count[24];
      std::snprintf(count,sizeof(count),ChroniclesArcMissionCount(i)==1?Lang("%d MISSAO","%d MISSION"):Lang("%d MISSOES","%d MISSIONS"),ChroniclesArcMissionCount(i));
      c.Right(w-60,y+16,count,18,kMenuGold);
    }
  }
  c.Fill(29,580,w-58,2,kMenuGold);
  if(ChroniclesMissionNotReady())
    c.Label(39,592,Lang("CARREGAMENTO DE BATALHA NAO IMPLEMENTADO","BATTLE LOADING NOT IMPLEMENTED"),19,kMenuGold);
  else if(detail)
    c.Label(39,592,Lang("A / F9: PREPARAR DESAFIO NO COMBATE LIVRE","A / F9: PREPARE CHALLENGE IN FREE BATTLE"),18,kMenuWhite);
  else
    c.Label(39,592,Lang("DPAD / F7-F8: NAVEGAR    A / F9: ABRIR","DPAD / F7-F8: NAVIGATE    A / F9: OPEN"),18,kMenuWhite);
  c.Label(39,622,Lang("B / F10: VOLTAR      Y / F6: FECHAR","B / F10: BACK      Y / F6: CLOSE"),17,kMenuMuted);
  c.Right(w-39,624,detail?Lang("FICHA DA MISSAO","MISSION CARD"):missions?Lang("LISTA DE MISSOES","MISSION LIST"):Lang("LISTA DE ARCOS","ARC LIST"),16,kMenuGold);
  c.Fill(0,h-3,w,3,kMenuAmber);
}
void BuildAssistedMissionBanner(){
  const int mission=ChroniclesAssistedMission();
  if(mission<0 || mission>=40)return;
  const int state=ChroniclesAssistedState();
  const bool inBattle=PromoteBattleActive();
  const float scale=std::min(g_w/1600.0f,g_h/900.0f);
  constexpr float w=840,h=69;
  const MenuView b{(g_w-w*scale)/2,g_h-(h+25)*scale,scale};
  b.Fill(0,0,w,h,{0.025f,0.035f,0.065f,0.93f});
  b.Fill(0,0,6,h,kMenuGold);
  char title[175];
  std::snprintf(title,sizeof(title),"%s  /  %s  [%s]",
                ChroniclesMissionId(mission),ChroniclesMissionTitle(mission),
                ChroniclesMissionTeams(mission));
  b.Label(17,10,title,20,kMenuWhite);
  const char* message=
    state==3?Lang("VITORIA CONFIRMADA / PROGRESSO SALVO","VICTORY CONFIRMED / PROGRESS SAVED"):
    state==4?Lang("DERROTA - PREPARE NOVAMENTE NO CHRONICLES","DEFEAT - SET IT UP AGAIN IN CHRONICLES"):
    state==2?Lang("COMBATE RECONHECIDO / BOA LUTA!","BATTLE RECOGNIZED / GOOD LUCK!"):
    inBattle?Lang("ESCALACAO NAO VALIDADA PARA ESTA MISSAO","LINEUP NOT VALID FOR THIS MISSION"):
    Lang("ABRA COMBATE LIVRE E SELECIONE OS PERSONAGENS DESTA MISSAO","OPEN FREE BATTLE AND PICK THIS MISSION'S CHARACTERS");
  b.Label(17,40,message,16,kMenuGold);
}
// Fim de missao do Chronicles (luta direta): faixa de vitoria/derrota no centro da tela.
void BuildChroniclesResult(int result,int mission,unsigned elapsed){
  const float s=std::min(g_w/1600.0f,g_h/900.0f);
  const float fade=std::min(1.0f,elapsed/400.0f);
  Rect(0,g_h*0.36f,g_w,g_h*0.28f,0.01f,0.015f,0.03f,0.72f*fade);
  constexpr float w=900,h=210;
  const MenuView v{(g_w-w*s)/2,g_h*0.5f-h*s/2,s};
  const Rgba accent=result==1?kMenuGold:Rgba{0.86f,0.27f,0.22f,1};
  v.Fill(0,0,w,4,accent);
  v.Fill(0,h-4,w,4,accent);
  v.Brush(60,18,result==1?Lang("VITORIA!","VICTORY!"):Lang("DERROTA","DEFEAT"),70,accent);
  char line[200];
  std::snprintf(line,sizeof(line),"%s  /  %s",ChroniclesMissionId(mission),ChroniclesMissionTitle(mission));
  v.Label(64,112,line,24,kMenuWhite);
  v.Label(64,152,result==1?Lang("MISSAO CONCLUIDA - PROGRESSO SALVO","MISSION COMPLETE - PROGRESS SAVED"):Lang("TENTE NOVAMENTE NO MENU CHRONICLES","TRY AGAIN FROM THE CHRONICLES MENU"),
          20,result==1?kMenuGold:kMenuMuted);
}
void BuildPerfectParry(int defender,int attacker) {
  const float s=std::min(g_w/1600.0f,g_h/900.0f);
  const MenuView p{g_w*0.5f-238*s,g_h*0.23f,s};
  p.Fill(0,0,476,83,kMenuInk);
  p.Fill(0,0,5,83,kMenuAmber);
  p.Label(39,9,"PERFECT PARRY!",36,kMenuAmber);
  char detail[100];
  std::snprintf(detail,sizeof(detail),Lang("J%d DEFENDEU  |  J%d ATORDOADO","J%d PARRIED  |  J%d STUNNED"),
                defender+1,attacker+1);
  p.Label(39,53,detail,19,kMenuWhite);
}
void BuildGrabEscape(int defender,int attacker) {
  const float s=std::min(g_w/1600.0f,g_h/900.0f);
  const MenuView p{g_w*0.5f-238*s,g_h*0.33f,s};
  p.Fill(0,0,476,83,kMenuInk);
  p.Fill(0,0,5,83,kMenuAmber);
  p.Label(39,9,Lang("ESCAPOU DO AGARRAO!","GRAB ESCAPE!"),32,kMenuAmber);
  char detail[100];
  std::snprintf(detail,sizeof(detail),Lang("J%d ESCAPOU  |  J%d RECUOU","J%d ESCAPED  |  J%d PUSHED BACK"),defender,attacker);
  p.Label(39,53,detail,19,kMenuWhite);
}
void BuildPerfectSubstitution(int number) {
  const float s=std::min(g_w/1600.0f,g_h/900.0f);
  const MenuView p{g_w*0.5f-238*s,g_h*0.43f,s};
  p.Fill(0,0,476,83,kMenuInk);
  p.Fill(0,0,5,83,kMenuAmber);
  p.Label(39,9,Lang("SUBSTITUICAO PERFEITA!","PERFECT SUBSTITUTION!"),30,kMenuAmber);
  char detail[100];
  std::snprintf(detail,sizeof(detail),Lang("J%d AO LADO DO ATACANTE","J%d NEXT TO THE ATTACKER"),number);
  p.Label(39,53,detail,19,kMenuWhite);
}
// ------------------------------------------------------------------ imagens locais (arte do Storm 1 do usuario)
// Imagens geradas por tools/extrair_clash_storm1.js a partir do Storm 1 instalado (pasta storm6_storm1). Nada do
// Storm 1 vai junto com o mod; sem a pasta, a disputa usa a tela desenhada pelo mod.
struct ModImage {
  ComPtr<ID3D11ShaderResourceView> srv;
  UINT w = 0, h = 0;
};
std::unordered_map<std::wstring, ModImage> g_modImages;

const ModImage* LoadModImage(const wchar_t* relative) {
  auto [entry, added] = g_modImages.try_emplace(relative);
  ModImage& image = entry->second;
  if (!added) return image.srv ? &image : nullptr;
  if (!g_images) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                                IID_PPV_ARGS(g_images.GetAddressOf())))) return nullptr;
  }
  const std::wstring path = ModDir() + relative;
  ComPtr<IWICBitmapDecoder> decoder;
  ComPtr<IWICBitmapFrameDecode> frame;
  ComPtr<IWICFormatConverter> rgba;
  if (FAILED(g_images->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnLoad,
                                                 &decoder)) ||
      FAILED(decoder->GetFrame(0, &frame)) || FAILED(g_images->CreateFormatConverter(&rgba)) ||
      FAILED(rgba->Initialize(frame.Get(), GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0,
                              WICBitmapPaletteTypeCustom)))
    return nullptr;
  UINT w = 0, h = 0;
  if (FAILED(rgba->GetSize(&w, &h)) || !w || !h || w > 2048 || h > 2048) return nullptr;
  std::vector<uint8_t> pixels(size_t(w) * h * 4);
  if (FAILED(rgba->CopyPixels(nullptr, w * 4, UINT(pixels.size()), pixels.data()))) return nullptr;
  D3D11_TEXTURE2D_DESC desc{};
  desc.Width = w;
  desc.Height = h;
  desc.MipLevels = desc.ArraySize = desc.SampleDesc.Count = 1;
  desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
  desc.Usage = D3D11_USAGE_IMMUTABLE;
  desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
  D3D11_SUBRESOURCE_DATA init{pixels.data(), w * 4, 0};
  ComPtr<ID3D11Texture2D> texture;
  if (SUCCEEDED(g_dev->CreateTexture2D(&desc, &init, &texture)))
    g_dev->CreateShaderResourceView(texture.Get(), nullptr, image.srv.GetAddressOf());
  image.w = w;
  image.h = h;
  if (image.srv) Log("HUD: imagem local %ls carregada (%ux%u).", relative, w, h);
  return image.srv ? &image : nullptr;
}

// Pedaco de uma imagem (em pixels da imagem) desenhado num retangulo da tela; flip espelha na horizontal.
void ImagePart(const ModImage* img, float sx, float sy, float sw, float sh, float x, float y, float w, float h,
               float alpha = 1.0f, bool flip = false, Rgba tint = Rgba{1, 1, 1, 1}) {
  if (!img) return;
  float u0 = sx / img->w, u1 = (sx + sw) / img->w;
  const float v0 = sy / img->h, v1 = (sy + sh) / img->h;
  if (flip) std::swap(u0, u1);
  Quad(x, y, w, h, u0, v0, u1, v1, tint.r, tint.g, tint.b, tint.a * alpha, img->srv.Get());
}

// Textura num quadrilatero qualquer (cantos em volta: 0, 1, 2, 3).
void TexPoly4(ID3D11ShaderResourceView* tex, const float px[4], const float py[4], const float u[4], const float v[4],
              Rgba c) {
  if (!tex || g_verts.size() + 6 > kMaxVerts) return;
  if (g_batches.empty() || g_batches.back().texture != tex) g_batches.push_back({UINT(g_verts.size()), tex});
  auto vx = [&](int i) { return Vtx{px[i] / g_w * 2 - 1, 1 - py[i] / g_h * 2, u[i], v[i], c.r, c.g, c.b, c.a}; };
  const Vtx q[6] = {vx(0), vx(1), vx(3), vx(1), vx(2), vx(3)};
  g_verts.insert(g_verts.end(), q, q + 6);
}

// Faixa de imagem de (x0,y0) ate (x1,y1), espessura w: o comeco do recorte fica em (x0,y0) e o fim em (x1,y1).
void ImageBeam(const ModImage* img, float sx, float sy, float sw, float sh, float x0, float y0, float x1, float y1,
               float w, float alpha) {
  if (!img) return;
  const float dx = x1 - x0, dy = y1 - y0, len = std::hypot(dx, dy);
  if (len < 1) return;
  const float nx = -dy / len * w * 0.5f, ny = dx / len * w * 0.5f;
  const float px[4] = {x0 + nx, x1 + nx, x1 - nx, x0 - nx};
  const float py[4] = {y0 + ny, y1 + ny, y1 - ny, y0 - ny};
  const float ua = sx / img->w, ub = (sx + sw) / img->w, va = sy / img->h, vb = (sy + sh) / img->h;
  const float u[4] = {ua, ub, ub, ua}, v[4] = {va, va, vb, vb};
  TexPoly4(img->srv.Get(), px, py, u, v, Rgba{1, 1, 1, alpha});
}

// Feixe sem imagem: cor por fora, nucleo claro no meio.
// Brilho em degrade (forte no eixo, transparente nas bordas). Antes eram faixas retas de cor solida, que no jogo
// apareciam como dois retangulos azul e laranja entre os lutadores.
void PlainBeam(float x0, float y0, float x1, float y1, float w, Rgba tone, float alpha) {
  const float dx = x1 - x0, dy = y1 - y0, len = std::hypot(dx, dy);
  if (len < 1.0f) return;
  const float nx = -dy / len, ny = dx / len;
  auto band = [&](float half, Rgba c, float a) {
    const Rgba mid{c.r, c.g, c.b, a}, edge{c.r, c.g, c.b, 0.0f};
    for (int side = -1; side <= 1; side += 2) {
      const float ox = nx * half * side, oy = ny * half * side;
      const float px[4] = {x0, x1, x1 + ox, x0 + ox}, py[4] = {y0, y1, y1 + oy, y0 + oy};
      const Rgba k[4] = {mid, mid, edge, edge};
      Poly4(px, py, k);
    }
  };
  band(w * 0.50f, tone, 0.42f * alpha);
  band(w * 0.24f, tone, 0.65f * alpha);
  band(w * 0.09f, Rgba{1, 1, 1, 1}, 0.85f * alpha);
}

// Bordas escuras (o centro, onde estao os dois e o choque, fica claro), como o fundo preto da disputa do Connections.
void ClashVignette(float depth, float alpha) {
  const float W = g_w, H = g_h, dx = W * depth, dy = H * depth;
  const Rgba d{0.0f, 0.0f, 0.03f, alpha}, c{0.0f, 0.0f, 0.03f, 0.0f};
  { const float px[4] = {0, W, W - dx, dx}, py[4] = {0, 0, dy, dy}; const Rgba k[4] = {d, d, c, c}; Poly4(px, py, k); }
  { const float px[4] = {dx, W - dx, W, 0}, py[4] = {H - dy, H - dy, H, H}; const Rgba k[4] = {c, c, d, d}; Poly4(px, py, k); }
  { const float px[4] = {0, dx, dx, 0}, py[4] = {0, dy, H - dy, H}; const Rgba k[4] = {d, c, c, d}; Poly4(px, py, k); }
  { const float px[4] = {W - dx, W, W, W - dx}, py[4] = {dy, 0, H, H - dy}; const Rgba k[4] = {c, d, d, c}; Poly4(px, py, k); }
}

const char* ClashPortraitCode(const HudFighter* f, int number) {
  if (!f || number < 1 || number > 6) return nullptr;
  const int side = (number - 1) / 3, row = (number - 1) % 3;
  for (int k = 0; k < 6; ++k)
    if (f[k].portrait[0] && f[k].side == side && f[k].row == row) return f[k].portrait;
  return nullptr;
}

#include "jutsu_clash_world_projection.inl"
#include "jutsu_clash_visual.inl"
#include "jutsu_clash_storm1.inl"

// Disputa de jutsus no estilo do Storm Connections (video de referencia do usuario):
//  1) abertura de ~0,9 s em tela dividida (rosto de cada lutador, azul x laranja, "JUTSU CLASH!");
//  2) disputa: bordas escuras com riscos de velocidade saindo do choque, a energia de cada um saindo DO LUTADOR
//     (posicao projetada na tela) ate o ponto de encontro, que anda conforme o placar, explosao e raios no encontro,
//     avisos "B / MASH" dos lados e a barra fina embaixo;
//  3) resultado: clarao, explosao no perdedor (ou no meio, no empate) e "J1 VENCEU!".
// Usa as imagens do Storm 1 do usuario (storm6_storm1) quando existem; sem elas, feixes desenhados pelo mod.
void BuildJutsuClash(const ClashHud& c, const HudFighter* fighters) {
  if (c.style == 2 && LoadModImage(L"storm6_storm1\\xbattle_sousai.png")) { BuildJutsuClashStorm1Look(c); return; }
  if (c.style == 1 || (c.style == 2 && c.visualV2)) { BuildJutsuClashAnimated(c, fighters); return; }
  const ModImage* orange = LoadModImage(L"storm6_storm1\\xbattle_s-eff01.png");
  const ModImage* blue = LoadModImage(L"storm6_storm1\\xbattle_s-eff03.png");
  const ModImage* burst = LoadModImage(L"storm6_storm1\\xbattle_s-eff07.png");
  const ModImage* fireOrange = LoadModImage(L"storm6_storm1\\xbattle_s-eff05.png");
  const ModImage* fireBlue = LoadModImage(L"storm6_storm1\\xbattle_s-eff06.png");
  const float s = std::min(g_w / 1600.0f, g_h / 900.0f);
  const unsigned t = unsigned(GetTickCount64() % 100000);
  const float pulse = 0.5f + 0.5f * std::sin(t * 0.02f);
  const bool live = c.result < 0;
  uint32_t seed = 0x9E3779B9u ^ (t / 50);
  auto rnd = [&seed]() { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; return (seed % 10000) / 10000.0f; };

  // Onde estao os dois na tela (altura do peito/maos).
  float ax = g_w * 0.33f, ay = g_h * 0.50f, bx = g_w * 0.67f, by = g_h * 0.50f;
  if (c.hasPos) {
    const float aspect = g_w / g_h;
    const float wa[3] = {c.posA[0], c.posA[1], c.posA[2] + 100.0f}, wb[3] = {c.posB[0], c.posB[1], c.posB[2] + 100.0f};
    float sxa, sya, sxb, syb;
    bool behindA = false, behindB = false;
    if (CameraProject(wa, aspect, &sxa, &sya, &behindA) && CameraProject(wb, aspect, &sxb, &syb, &behindB) &&
        !behindA && !behindB && std::fabs(sxa) < 1.4f && std::fabs(sxb) < 1.4f && std::fabs(sya) < 1.4f &&
        std::fabs(syb) < 1.4f) {
      ax = (sxa * 0.5f + 0.5f) * g_w;
      ay = (0.5f - sya * 0.5f) * g_h;
      bx = (sxb * 0.5f + 0.5f) * g_w;
      by = (0.5f - syb * 0.5f) * g_h;
    }
  }
  const bool aLeft = ax <= bx;
  const float lx = aLeft ? ax : bx, ly = aLeft ? ay : by, rx = aLeft ? bx : ax, ry = aLeft ? by : ay;
  const int numL = aLeft ? c.numberA : c.numberB, numR = aLeft ? c.numberB : c.numberA;
  const unsigned scoreL = aLeft ? c.scoreA : c.scoreB, scoreR = aLeft ? c.scoreB : c.scoreA;
  const unsigned total = scoreL + scoreR;
  const float shareL = std::clamp(total ? float(scoreL) / float(total) : 0.5f, 0.18f, 0.82f);
  // Tremor da imagem (os dois jutsus se empurrando).
  const float jx = std::sin(t * 0.071f) * 3.0f * s, jy = std::cos(t * 0.093f) * 3.0f * s;
  const float mx = lx + (rx - lx) * shareL + jx, my = ly + (ry - ly) * shareL + jy;
  const float dist = std::hypot(rx - lx, ry - ly);
  char line[96];

  // ---- 2) disputa e 3) resultado
  const float fadeOut = live ? 1.0f : std::clamp(1.0f - (float(c.resultAgeMs) - 500.0f) / 700.0f, 0.0f, 1.0f);
  if (fadeOut > 0) {
    Rect(0, 0, g_w, g_h, 0.0f, 0.0f, 0.03f, 0.22f * fadeOut);
    ClashVignette(0.36f, 0.97f * fadeOut);
    for (int i = 0; i < 46; ++i) {
      const float ang = rnd() * 6.2832f;
      const float inner = (0.36f + 0.20f * rnd()) * g_h, outer = g_w * 1.1f;
      LockStroke(mx + std::cos(ang) * inner, my + std::sin(ang) * inner, mx + std::cos(ang) * outer,
                 my + std::sin(ang) * outer, (1.5f + 4.0f * rnd()) * s, Rgba{1, 1, 1, (0.18f + 0.35f * rnd()) * fadeOut});
    }
  }
  if (live) {
    const float beamW = std::clamp(dist * 0.75f, 170.0f * s, 400.0f * s) * (0.92f + 0.16f * pulse);
    const int frame = int(t / 70) % 4;  // energias do Storm 1: 4 quadros empilhados de 768x192, chama na metade esquerda
    // Brilho por baixo (o feixe aparece mesmo longo e fino) e a imagem animada do Storm 1 por cima.
    PlainBeam(lx + jx, ly + jy, mx, my, beamW * 0.62f, kMenuBlue, 0.8f);
    PlainBeam(rx + jx, ry + jy, mx, my, beamW * 0.62f, kMenuAmber, 0.8f);
    if (blue && orange) {
      ImageBeam(blue, 0, frame * 192.0f, 330, 192, lx + jx, ly + jy, mx + 50 * s, my, beamW * 1.25f, 1.0f);
      ImageBeam(orange, 0, frame * 192.0f, 330, 192, rx + jx, ry + jy, mx - 50 * s, my, beamW * 1.25f, 1.0f);
    }
    // Energia concentrada na mao de cada um (como o Rasengan / Chidori no video).
    const float hs = beamW * (0.95f + 0.2f * pulse);
    if (burst) {
      ImagePart(burst, 0, 0, 192, 192, lx + jx - hs * 0.5f, ly + jy - hs * 0.5f, hs, hs, 0.9f, false,
                Rgba{0.55f, 0.82f, 1.0f, 1});
      ImagePart(burst, 0, 0, 192, 192, rx + jx - hs * 0.5f, ry + jy - hs * 0.5f, hs, hs, 0.9f, true,
                Rgba{1.0f, 0.70f, 0.35f, 1});
    } else {
      Rect(lx + jx - hs * 0.2f, ly + jy - hs * 0.2f, hs * 0.4f, hs * 0.4f, kMenuBlue.r, kMenuBlue.g, kMenuBlue.b, 0.7f);
      Rect(rx + jx - hs * 0.2f, ry + jy - hs * 0.2f, hs * 0.4f, hs * 0.4f, kMenuAmber.r, kMenuAmber.g, kMenuAmber.b, 0.7f);
    }
    // Encontro: explosao pulsando, nucleo branco e raios.
    const float bs = (300 + 120 * pulse) * s;
    if (burst) ImagePart(burst, 0, 0, 192, 192, mx - bs * 0.5f, my - bs * 0.5f, bs, bs, 0.95f);
    Rect(mx - 9 * s, my - 26 * s, 18 * s, 52 * s, 1, 1, 1, 0.85f);
    for (int i = 0; i < 16; ++i) {
      const float ang = rnd() * 6.2832f, len = (70 + 150 * rnd()) * s;
      float x0 = mx, y0 = my;
      for (int k = 0; k < 3; ++k) {  // raio quebrado em 3 pedacos
        const float a = ang + (rnd() - 0.5f) * 0.9f, step = len / 3.0f;
        const float x1 = x0 + std::cos(a) * step, y1 = y0 + std::sin(a) * step;
        LockStroke(x0, y0, x1, y1, (3.5f - k) * s, Rgba{0.85f, 0.95f, 1.0f, 0.9f});
        x0 = x1;
        y0 = y1;
      }
    }
    // Avisos de apertar de cada lado (bloco com raios, "B", "MASH").
    const int numbers[2] = {numL, numR};
    for (int side = 0; side < 2; ++side) {
      const float px = side == 0 ? g_w * 0.13f : g_w * 0.87f, py = g_h * 0.50f;
      const Rgba tone = side == 0 ? kMenuBlue : kMenuAmber;
      for (int i = 0; i < 14; ++i) {
        const float ang = rnd() * 6.2832f, len = (60 + 70 * rnd()) * s * (0.8f + 0.4f * pulse);
        LockStroke(px, py, px + std::cos(ang) * len, py + std::sin(ang) * len, (2 + 3 * rnd()) * s, Rgba{1, 1, 1, 0.8f});
      }
      const float tile = (66 + 10 * pulse) * s;
      Rect(px - tile * 0.5f - 4 * s, py - tile * 0.5f - 4 * s, tile + 8 * s, tile + 8 * s, 0.92f, 0.92f, 0.92f, 0.97f);
      Rect(px - tile * 0.5f, py - tile * 0.5f, tile, tile, 0.10f, 0.10f, 0.12f, 0.98f);
      const MenuView box{px, py, s};
      box.Label(-14, -30, "B", 46, tone);
      box.Label(-26, 46, "MASH", 20, kMenuWhite);
      std::snprintf(line, sizeof(line), "J%d", numbers[side]);
      box.Label(-14, 70, line, 22, tone);
    }
  } else {
    // Resultado: clarao e explosao no perdedor (empate: no meio).
    const float age = float(c.resultAgeMs);
    if (age < 300) Rect(0, 0, g_w, g_h, 1, 1, 1, 0.85f * (1.0f - age / 300.0f));
    float ex = mx, ey = my;
    if (c.result == 1) { ex = bx; ey = by; }
    if (c.result == 2) { ex = ax; ey = ay; }
    if (age < 1100) {
      const float grow = std::min(1.0f, age / 350.0f), es = (180 + 420 * grow) * s;
      const float alpha = age < 600 ? 1.0f : 1.0f - (age - 600) / 500.0f;
      if (burst) ImagePart(burst, 0, 0, 192, 192, ex - es * 0.5f, ey - es * 0.5f, es, es, alpha);
      else Rect(ex - es * 0.25f, ey - es * 0.25f, es * 0.5f, es * 0.5f, 1, 0.95f, 0.8f, 0.6f * alpha);
    }
  }

  // Barra fina embaixo (cabo de guerra), como no video: azul a esquerda, laranja a direita, chama no encontro.
  if (fadeOut > 0 || !live) {
    const float barW = std::min(g_w * 0.62f, 1000 * s), barH = 10 * s, x0 = g_w * 0.5f - barW * 0.5f, y0 = g_h * 0.80f;
    const float meet = x0 + barW * (total ? float(scoreL) / float(total) : 0.5f);
    Rect(x0 - 3 * s, y0 - 3 * s, barW + 6 * s, barH + 6 * s, 0.02f, 0.03f, 0.06f, 0.9f);
    Rect(x0, y0, meet - x0, barH, kMenuBlue.r, kMenuBlue.g, kMenuBlue.b, 0.95f);
    Rect(x0, y0 + barH * 0.35f, meet - x0, barH * 0.3f, 1, 1, 1, 0.6f);
    Rect(meet, y0, x0 + barW - meet, barH, kMenuAmber.r, kMenuAmber.g, kMenuAmber.b, 0.95f);
    Rect(meet, y0 + barH * 0.35f, x0 + barW - meet, barH * 0.3f, 1, 0.95f, 0.8f, 0.6f);
    const int fireFrame = int(t / 60) % 8;
    if (fireBlue) ImagePart(fireBlue, fireFrame * 96.0f, 0, 96, 192, meet - 34 * s, y0 - 52 * s, 34 * s, 68 * s, 0.95f);
    if (fireOrange) ImagePart(fireOrange, fireFrame * 96.0f, 0, 96, 192, meet, y0 - 52 * s, 34 * s, 68 * s, 0.95f);
    Rect(meet - 3 * s, y0 - 8 * s, 6 * s, barH + 16 * s, 1, 1, 1, 0.95f);
    const MenuView bar{x0, y0, s};
    if (live) {
      bar.Label(barW / s * 0.5f - 72, -36, "JUTSU CLASH", 24, kMenuWhite);
      std::snprintf(line, sizeof(line), "%.1f", c.remainingMs / 1000.0f);
      bar.Right(barW / s, -34, line, 22, kMenuGold);
    } else if (c.result == 0) {
      bar.Label(barW / s * 0.5f - 64, -38, Lang("EMPATE!","DRAW!"), 30, kMenuGold);
    } else {
      std::snprintf(line, sizeof(line), Lang("J%d VENCEU!","J%d WINS!"), c.result == 1 ? c.numberA : c.numberB);
      bar.Label(barW / s * 0.5f - 86, -40, line, 32, kMenuGold);
    }
    std::snprintf(line, sizeof(line), "J%d  %u", numL, scoreL);
    bar.Label(0, barH / s + 6, line, 22, kMenuBlue);
    std::snprintf(line, sizeof(line), "%u  J%d", scoreR, numR);
    bar.Right(barW / s, barH / s + 6, line, 22, kMenuAmber);
  }
  if (!live) {
    const char* big = c.result == 0 ? Lang("EMPATE! OS JUTSUS EXPLODEM","DRAW! THE JUTSU EXPLODE") : nullptr;
    if (!big) {
      std::snprintf(line, sizeof(line), Lang("J%d VENCEU!","J%d WINS!"), c.result == 1 ? c.numberA : c.numberB);
      big = line;
    }
    const float size = 64 * s, w = TextWidth(big, size);
    const float a = std::clamp(2.0f - float(c.resultAgeMs) / 1100.0f, 0.0f, 1.0f);
    Text(g_w * 0.5f - w * 0.5f, g_h * 0.22f, big, size, kMenuGold.r, kMenuGold.g, kMenuGold.b, a);
    return;
  }

  // ---- 1) abertura em tela dividida
  if (c.elapsedMs >= 900) return;
  const float e = float(c.elapsedMs);
  const float slide = std::min(1.0f, e / 250.0f), fade = e < 700 ? 1.0f : 1.0f - (e - 700) / 200.0f;
  const float W = g_w, H = g_h, topX = W * 0.53f, botX = W * 0.47f;
  {
    const float px[4] = {0, topX, botX, 0}, py[4] = {0, 0, H, H};
    const Rgba k[4] = {{0.05f, 0.18f, 0.42f, 0.97f * fade}, {0.10f, 0.30f, 0.62f, 0.97f * fade},
                       {0.02f, 0.07f, 0.20f, 0.97f * fade}, {0.01f, 0.03f, 0.12f, 0.97f * fade}};
    Poly4(px, py, k);
  }
  {
    const float px[4] = {topX, W, W, botX}, py[4] = {0, 0, H, H};
    const Rgba k[4] = {{0.62f, 0.22f, 0.04f, 0.97f * fade}, {0.40f, 0.10f, 0.02f, 0.97f * fade},
                       {0.18f, 0.04f, 0.01f, 0.97f * fade}, {0.35f, 0.10f, 0.02f, 0.97f * fade}};
    Poly4(px, py, k);
  }
  // Riscos horizontais correndo em cada metade.
  for (int i = 0; i < 26; ++i) {
    const float y = rnd() * H, len = (0.10f + 0.25f * rnd()) * W, off = std::fmod(e * 1.6f + rnd() * W, W * 0.5f);
    const float xL = W * 0.45f - off, xR = W * 0.55f + off;
    LockStroke(xL - len, y, xL, y, (1.5f + 3 * rnd()) * s, Rgba{0.7f, 0.85f, 1.0f, 0.35f * fade});
    LockStroke(xR, y, xR + len, y, (1.5f + 3 * rnd()) * s, Rgba{1.0f, 0.8f, 0.55f, 0.35f * fade});
  }
  // Rostos: o da esquerda entra pela esquerda, o da direita pela direita (espelhado, olhando para o centro).
  const int numbers[2] = {numL, numR};
  for (int side = 0; side < 2; ++side) {
    const char* code = ClashPortraitCode(fighters, numbers[side]);
    const float cx = side == 0 ? W * 0.25f - (1 - slide) * W * 0.4f : W * 0.75f + (1 - slide) * W * 0.4f;
    if (const auto* portrait = code ? Portrait(code) : nullptr) {
      const float box = H * 0.62f;
      const float pw = portrait->aspect >= 1 ? box : box * portrait->aspect;
      const float ph = portrait->aspect >= 1 ? box / portrait->aspect : box;
      Quad(cx - pw * 0.5f, H * 0.47f - ph * 0.5f, pw, ph, side == 0 ? 0.0f : 1.0f, 0, side == 0 ? 1.0f : 0.0f, 1, 1, 1,
           1, fade, portrait->texture.Get());
    }
    const char* name = code ? FighterName(code) : nullptr;
    std::snprintf(line, sizeof(line), "J%d", numbers[side]);
    if (!name) name = line;
    const float size = 58 * s, nw = TextWidth(name, size, g_nameAdvance);
    const Rgba tone = side == 0 ? kMenuBlue : kMenuAmber;
    Text(cx - nw * 0.5f, H * 0.80f, name, size, tone.r, tone.g, tone.b, fade, g_nameSrv, g_nameAdvance);
  }
  LockStroke(topX, 0, botX, H, 12 * s, Rgba{1, 1, 1, fade});
  if (e > 220) {
    const float pop = std::min(1.0f, (e - 220) / 120.0f);
    const float size = (96 - 24 * pop) * s, tw = TextWidth("JUTSU CLASH!", size);
    Text(W * 0.5f - tw * 0.5f, H * 0.08f, "JUTSU CLASH!", size, kMenuGold.r, kMenuGold.g, kMenuGold.b, fade);
  }
}
void Draw(IDXGISwapChain* sc) {


  HudFighter f[6];
  int target = -1;
  bool battle = PromoteHudSnapshot(f, &target);
  bool plates = battle && Cfg().hud.load();
  bool markers = battle && Cfg().lockon.load();
  bool menu = MenuIsOpen();
  bool hint = !PromoteBattleActive();
  const bool chroniclesInMenu=ChroniclesNativeModeVisible() && !MenuIsOpen();
  // Faixa do modo assistido (abrir pelo Combate Livre): nao vale para a luta direta do Chronicles.
  const bool assistedBanner=ChroniclesAssistedMission()>=0 && !SceneProbeMissionFight() &&
                            !menu && !ChroniclesChapterScreenOpen();
  int chrMission=-1;
  unsigned chrElapsed=0;
  const int chrResult=SceneProbeMissionResult(&chrMission,&chrElapsed);
  int parryDefender=-1,parryAttacker=-1;
  const bool parryFlash=ParryFeedback(&parryDefender,&parryAttacker);
  int grabDefender=0,grabAttacker=0;
  const bool grabFlash=GrabDefenseFeedback(&grabDefender,&grabAttacker);
  int subNumber=0;
  const bool subFlash=PerfectSubFeedback(&subNumber);
  ClashHud clashHud;
  const bool clashShown=JutsuClashHud(&clashHud);
  const int ffaWinner = PromoteFfaWinner();
  unsigned ffaRoster = 0, ffaEliminated = 0;
  const bool ffaProgress = battle &&
      PromoteFfaEliminationSnapshot(&ffaRoster, &ffaEliminated);
  if (!plates && !markers && !menu && !hint && !chroniclesInMenu &&
      !assistedBanner && ffaWinner < 0 && !parryFlash && !grabFlash && !subFlash && !clashShown && !chrResult) return;
  if (!g_dev && !g_failed && !Init(sc)) g_failed = true;
  if (g_failed) return;

  ID3D11Texture2D* back = nullptr;
  if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&back)))) return;
  D3D11_TEXTURE2D_DESC td;
  back->GetDesc(&td);
  g_w = float(td.Width);
  g_h = float(td.Height);
  if(td.Width>0 && td.Height>0)
    g_renderAspect.store(float(td.Width)/float(td.Height),
                         std::memory_order_relaxed);
  ID3D11RenderTargetView* rtv = nullptr;
  g_dev->CreateRenderTargetView(back, nullptr, &rtv);
  back->Release();
  if (!rtv) return;

  g_verts.clear();
  g_batches.clear();
  if (plates) BuildPlates(f);
  if (markers) BuildLockMarkers();
  if (ffaProgress) BuildFfaProgress(ffaRoster, ffaEliminated);
  if (ffaWinner >= 0) BuildFfaWinner(ffaWinner);
  if (parryFlash) BuildPerfectParry(parryDefender,parryAttacker);
  if (grabFlash) BuildGrabEscape(grabDefender,grabAttacker);
  if (subFlash) BuildPerfectSubstitution(subNumber);
  if (clashShown) BuildJutsuClash(clashHud, battle ? f : nullptr);
  if (menu) BuildMenu();
  else if (chroniclesInMenu) BuildChroniclesModeEntry();
  else if (hint) BuildHint();
  if (assistedBanner) BuildAssistedMissionBanner();
  if (chrResult) BuildChroniclesResult(chrResult,chrMission,chrElapsed);
  // Revi Whitchmore: marca d'agua exclusiva dos menus.
  // Nunca desenhar durante combate ou fora das telas de configuracao.
  if (menu || chroniclesInMenu) BuildReviWatermark();
  D3D11_MAPPED_SUBRESOURCE m;
  if (g_verts.empty() || FAILED(g_ctx->Map(g_vb, 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) {
    rtv->Release();
    return;
  }
  memcpy(m.pData, g_verts.data(), g_verts.size() * sizeof(Vtx));
  g_ctx->Unmap(g_vb, 0);

  ID3D11RenderTargetView* oldRtv = nullptr;
  ID3D11DepthStencilView* oldDsv = nullptr;
  g_ctx->OMGetRenderTargets(1, &oldRtv, &oldDsv);
  UINT nvp = 1;
  D3D11_VIEWPORT oldVp{};
  g_ctx->RSGetViewports(&nvp, &oldVp);
  ID3D11BlendState* oldBlend = nullptr;
  FLOAT oldFactor[4];
  UINT oldMask;
  g_ctx->OMGetBlendState(&oldBlend, oldFactor, &oldMask);
  ID3D11RasterizerState* oldRs = nullptr;
  g_ctx->RSGetState(&oldRs);
  ID3D11DepthStencilState* oldDs = nullptr;
  UINT oldRef;
  g_ctx->OMGetDepthStencilState(&oldDs, &oldRef);
  ID3D11InputLayout* oldLayout = nullptr;
  g_ctx->IAGetInputLayout(&oldLayout);
  D3D11_PRIMITIVE_TOPOLOGY oldTopo;
  g_ctx->IAGetPrimitiveTopology(&oldTopo);
  ID3D11Buffer* oldVb = nullptr;
  UINT oldStride, oldOffset;
  g_ctx->IAGetVertexBuffers(0, 1, &oldVb, &oldStride, &oldOffset);
  ID3D11VertexShader* oldVs = nullptr;
  g_ctx->VSGetShader(&oldVs, nullptr, nullptr);
  ID3D11PixelShader* oldPs = nullptr;
  g_ctx->PSGetShader(&oldPs, nullptr, nullptr);
  ID3D11ShaderResourceView* oldSrv = nullptr;
  g_ctx->PSGetShaderResources(0, 1, &oldSrv);
  ID3D11SamplerState* oldSmp = nullptr;
  g_ctx->PSGetSamplers(0, 1, &oldSmp);

  D3D11_VIEWPORT vp{0, 0, g_w, g_h, 0, 1};
  g_ctx->OMSetRenderTargets(1, &rtv, nullptr);
  g_ctx->RSSetViewports(1, &vp);
  FLOAT bf[4] = {0, 0, 0, 0};
  g_ctx->OMSetBlendState(g_blend, bf, 0xFFFFFFFF);
  g_ctx->RSSetState(g_raster);
  g_ctx->OMSetDepthStencilState(g_depth, 0);
  g_ctx->IASetInputLayout(g_layout);
  g_ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
  UINT stride = sizeof(Vtx), offset = 0;
  g_ctx->IASetVertexBuffers(0, 1, &g_vb, &stride, &offset);
  g_ctx->VSSetShader(g_vs, nullptr, 0);
  g_ctx->PSSetShader(g_ps, nullptr, 0);
  g_ctx->PSSetSamplers(0, 1, &g_sampler);
  for (size_t i = 0; i < g_batches.size(); ++i) {
    const DrawBatch& batch = g_batches[i];
    const UINT end = i + 1 < g_batches.size() ? g_batches[i + 1].first : UINT(g_verts.size());
    g_ctx->PSSetShaderResources(0, 1, &batch.texture);
    g_ctx->Draw(end - batch.first, batch.first);
  }

  g_ctx->OMSetRenderTargets(1, &oldRtv, oldDsv);
  g_ctx->RSSetViewports(1, &oldVp);
  g_ctx->OMSetBlendState(oldBlend, oldFactor, oldMask);
  g_ctx->RSSetState(oldRs);
  g_ctx->OMSetDepthStencilState(oldDs, oldRef);
  g_ctx->IASetInputLayout(oldLayout);
  g_ctx->IASetPrimitiveTopology(oldTopo);
  g_ctx->IASetVertexBuffers(0, 1, &oldVb, &oldStride, &oldOffset);
  g_ctx->VSSetShader(oldVs, nullptr, 0);
  g_ctx->PSSetShader(oldPs, nullptr, 0);
  g_ctx->PSSetShaderResources(0, 1, &oldSrv);
  g_ctx->PSSetSamplers(0, 1, &oldSmp);
  SafeRelease(oldRtv);
  SafeRelease(oldDsv);
  SafeRelease(oldBlend);
  SafeRelease(oldRs);
  SafeRelease(oldDs);
  SafeRelease(oldLayout);
  SafeRelease(oldVb);
  SafeRelease(oldVs);
  SafeRelease(oldPs);
  SafeRelease(oldSrv);
  SafeRelease(oldSmp);
  rtv->Release();
}

// Tiny one-line 10-second quality telemetry in active combat. This logs
// PRESENT intervals, not synthetic benchmark speed and not the actual GPU
// draw cost. Does not force an FPS cap or write any file per frame.
HRESULT STDMETHODCALLTYPE HookPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
  // Keyboard fallback on the game's real mode-select screen only.
  ChroniclesKeyboardInput();
  static RuntimeFrameWindow window;
  const ULONGLONG now=GetTickCount64();
  const RuntimeFrameReport report=
      RuntimeRecordPresent(window,now,PromoteBattleActive());
  if(report.ready)
    Log("PERF v0.7: present=%.1f FPS, media=%.2fms, pior=%.0fms, quadros>50ms=%u/%u (10s combate).",
        report.fps,report.averageMs,report.maxMs,report.slowFrames,report.frames);
  Draw(sc);
  FrameCaptureOnPresent(sc);  // capturas de teste: so o quadro do jogo
  return g_origPresent(sc,sync,flags);
}

}  // namespace

float HudAspectRatio() {
  const float aspect=g_renderAspect.load(std::memory_order_relaxed);
  return std::isfinite(aspect) && aspect>=0.5f && aspect<=4.0f
      ?aspect:16.0f/9.0f;
}

bool HudInstall() {
  HWND wnd = CreateWindowExW(0, L"STATIC", L"storm6", WS_OVERLAPPEDWINDOW, 0, 0, 64, 64, nullptr,
                             nullptr, GetModuleHandleW(nullptr), nullptr);
  if (!wnd) return false;
  DXGI_SWAP_CHAIN_DESC sd{};
  sd.BufferCount = 1;
  sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
  sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
  sd.OutputWindow = wnd;
  sd.SampleDesc.Count = 1;
  sd.Windowed = TRUE;
  IDXGISwapChain* sc = nullptr;
  ID3D11Device* dev = nullptr;
  ID3D11DeviceContext* ctx = nullptr;
  HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
                                             D3D11_SDK_VERSION, &sd, &sc, &dev, nullptr, &ctx);
  void* present = nullptr;
  if (SUCCEEDED(hr)) present = (*reinterpret_cast<void***>(sc))[8];
  SafeRelease(sc);
  SafeRelease(ctx);
  SafeRelease(dev);
  DestroyWindow(wnd);
  if (!present) {
    Log("HUD: nao achei Present (hr=0x%08lX)", hr);
    return false;
  }
  MH_STATUS st = MH_CreateHook(present, reinterpret_cast<void*>(&HookPresent),
                               reinterpret_cast<void**>(&g_origPresent));
  if (st == MH_OK) st = MH_EnableHook(present);
  Log("HUD: hook de Present %s", st == MH_OK ? "instalado" : MH_StatusToString(st));
  return st == MH_OK;
}

