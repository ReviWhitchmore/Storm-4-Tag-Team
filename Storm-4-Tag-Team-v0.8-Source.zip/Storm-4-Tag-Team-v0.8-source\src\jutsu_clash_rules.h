#pragma once
#include <cstdint>

// Jutsu Clash - regras puras (sem memoria do jogo), testadas em tools/jutsu_clash_tests.cpp.
// Gatilho no Storm 4 (Evolution): a rotina de acerto mutuo (~FUN_14076D8xx) poe os dois lutadores em
// PL_ACT_OFFSET_KNOCKBACK (0x5A) quando se acertam no mesmo instante com a mesma prioridade. Se os dois vinham
// de um jutsu (PL_ACT_SKILL_LAND 0x4D / SKILL_AIR 0x4E), os jutsus colidiram: comeca a disputa.
namespace clash {
enum class Phase { Idle, CollisionDetected, Active, Resolving, Finished, Cancelled };

constexpr uint64_t kDurationMs = 7000;  // exatamente 7 s
constexpr int kSkillLand = 0x4D, kSkillAir = 0x4E;
constexpr int kOffsetPre = 0x59, kOffset = 0x5A, kOffsetAir = 0x5B;
constexpr int kChakraDash = 0x10;
// Perdedor: empurrao nativo PL_ACT_OFFSET_KNOCKBACK (recua ~0,5 s e volta sozinho). PL_ACT_DMG_SMASH_SIDE (0x1C)
// foi testado e NAO serve: sem os dados de um golpe real o lutador ficou 10 s parado nele.
constexpr int kLoserState = 0x5A;
constexpr int kWinnerState = 0x1;  // PL_ACT_NUT: vencedor livre para agir na hora
// Enquanto os dois jutsus estao pausados na colisao, o jogo continua tentando
// encerrar a animacao e voltar a 0x1. Segurar tambem esta troca preserva a pose.
// Estados de dano e de cinematica continuam livres (cancelamento seguro no Tick).
inline bool HoldPoseTransition(int action) {
  return action == kWinnerState || action == kOffsetPre || action == kOffset || action == kOffsetAir;
}

// Jutsus de qualquer personagem (tabela PL_ACT_*): SKILL_LAND/AIR (0x4D/0x4E), WALLBATTLE_SKILL (0x66),
// NORMAL_SPTYPE_SPSKILL (0x98), especiais de marionete/tipo (0xF0, 0xF5, 0xF6, 0xF8..0xFB).
inline bool JutsuState(int s) {
  return s == kSkillLand || s == kSkillAir || s == 0x66 || s == 0x98 || s == 0xF0 || s == 0xF5 || s == 0xF6 ||
         (s >= 0xF8 && s <= 0xFB);
}
inline bool OffsetState(int s) { return s == kOffsetPre || s == kOffset || s == kOffsetAir; }

// Os dois entraram no empurrao mutuo agora; vinham de jutsu (ou de investida de chakra no modo de teste).
inline bool CollisionStart(int prevA, int nowA, int prevB, int nowB, bool allowDash) {
  auto source = [allowDash](int s) { return JutsuState(s) || (allowDash && s == kChakraDash); };
  return OffsetState(nowA) && OffsetState(nowB) && !OffsetState(prevA) && !OffsetState(prevB) &&
         source(prevA) && source(prevB);
}

// Se um mesmo par acabar de disputar, o segundo acerto do mesmo jutsu nao
// deve abrir uma nova disputa. Nao bloqueia pares independentes no 3v3.
inline bool RepeatPair(uintptr_t a, uintptr_t b, uintptr_t lastA, uintptr_t lastB,
                       uint64_t now, uint64_t endedAt, uint64_t cooldownMs = 1700) {
  return a && b && lastA && lastB && now >= endedAt && now - endedAt < cooldownMs &&
         ((a == lastA && b == lastB) || (a == lastB && b == lastA));
}

// Contador de apertos: so a borda (soltou -> apertou) vale; segurar nao pontua.
struct Presses {
  bool held = false;
  unsigned count = 0;
  void Sample(bool pressed) {
    if (pressed && !held) ++count;
    held = pressed;
  }
};

// Resultado: 1 = A vence, 2 = B vence, 0 = empate.
inline int Winner(unsigned scoreA, unsigned scoreB) { return scoreA > scoreB ? 1 : scoreB > scoreA ? 2 : 0; }

// Fatia da barra (0..1) do lado A; 0,5 com 0 x 0.
inline float BarShare(unsigned scoreA, unsigned scoreB) {
  const unsigned total = scoreA + scoreB;
  return total ? float(scoreA) / float(total) : 0.5f;
}

// Pontos da CPU ate o instante `elapsedMs`: ritmo base (apertos/s) com variacao controlada por segundo.
// `variation[i]` em [-1,1] (sorteado no inicio), amplitude 25%. Sempre cresce com o tempo.
inline unsigned CpuScore(uint64_t elapsedMs, float pressesPerSecond, const float variation[7]) {
  float score = 0;
  for (int second = 0; second < 7; ++second) {
    const uint64_t start = uint64_t(second) * 1000;
    if (elapsedMs <= start) break;
    const uint64_t span = elapsedMs - start < 1000 ? elapsedMs - start : 1000;
    const float rate = pressesPerSecond * (1.0f + 0.25f * variation[second]);
    score += rate * float(span) / 1000.0f;
  }
  return score > 0 ? unsigned(score) : 0;
}
}  // namespace clash
