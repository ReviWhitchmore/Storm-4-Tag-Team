#pragma once
#include <algorithm>
#include <cstdint>

namespace clash_visual {
// Storm 1 uses separate animation tracks for start, loop and ending (renda/effects).
// These timings are original to this mod; they do not claim to be Storm 1's native timings.
enum class AnimationPhase { Ignition, Loop, WinnerAdvance, DrawBurst, Aftermath };
constexpr unsigned kIgnitionMs = 680;
constexpr unsigned kTravelMs = 550;
constexpr unsigned kImpactMs = 1550;

inline float Clamp01(float x) { return std::clamp(x, 0.0f, 1.0f); }
inline float Ease(float x) { x = Clamp01(x); return x * x * (3.0f - 2.0f * x); }
inline AnimationPhase Phase(unsigned elapsed, int result, unsigned age) {
  if (result < 0) return elapsed < kIgnitionMs ? AnimationPhase::Ignition : AnimationPhase::Loop;
  if (result == 0) return age < kTravelMs ? AnimationPhase::DrawBurst : AnimationPhase::Aftermath;
  return age < kTravelMs ? AnimationPhase::WinnerAdvance : AnimationPhase::Aftermath;
}
// Left score share: a stronger left jutsu pushes the meeting point right.
// Result 1 or 2 is relative to the original A/B participant order.
inline float Meeting(float leftShare, bool leftIsA, int result, unsigned age) {
  leftShare = std::clamp(leftShare, 0.12f, 0.88f);
  if (result == 0) return leftShare + (0.5f - leftShare) * Ease(float(age) / float(kTravelMs));
  if (result < 0) return leftShare;
  const bool leftWon = (result == 1) == leftIsA;
  const float target = leftWon ? 0.98f : 0.02f;
  return leftShare + (target - leftShare) * Ease(float(age) / float(kTravelMs));
}
inline float Opacity(int result, unsigned age) {
  if (result < 0 || age < kTravelMs) return 1.0f;
  return 1.0f - Ease(float(age - kTravelMs) / float(kImpactMs));
}
inline unsigned Frame4(unsigned ms) { return (ms / 85u) % 4u; }
inline unsigned Frame8(unsigned ms) { return (ms / 75u) % 8u; }
} // namespace clash_visual
