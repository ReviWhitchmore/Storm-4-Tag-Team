#pragma once
#include <cmath>
#include <cstdint>

// Fase 3 - Substituicao Perfeita. Regras puras (sem memoria do jogo), testadas em tools/perfect_sub_tests.cpp.
// Estados (tabela PL_ACT_* do NSUNS4e.exe): 0x6D..0x71 DODGE_TO_WARP_* (some) e 0x72..0x78 DODGE_WARP_*
// (reaparece). No Storm 4 a substituicao so sai DURANTE o dano recebido; "perfeita" = sair logo no comeco
// do dano, dentro da janela (0,15 s no inicio, ajustavel).
namespace perfectsub {
constexpr unsigned kDefaultWindowMs = 150;
constexpr float kLateralDistance = 150.0f;   // distancia do atacante, de lado
constexpr float kBoundsMargin = 60.0f;       // folga sobre a area ja ocupada pelos lutadores

inline bool DamageState(int s) { return s >= 0x18 && s <= 0x3C; }       // PL_ACT_DMG_* (inclui guardbreak)
inline bool SubOutState(int s) { return s >= 0x6D && s <= 0x71; }       // DODGE_TO_WARP_*
inline bool SubInState(int s) { return s >= 0x72 && s <= 0x78; }        // DODGE_WARP_*
inline bool AttackState(int s) {
  return (s >= 0x3F && s <= 0x42) || (s >= 0x4D && s <= 0x4F) || s == 0x10 || s == 0x13 || s == 0x48 ||
         s == 0x96 || s == 0x9B;
}

inline bool Perfect(uint64_t damageStartedAt, uint64_t substitutedAt, unsigned windowMs) {
  return damageStartedAt && substitutedAt >= damageStartedAt && substitutedAt - damageStartedAt <= windowMs;
}

// Ponto ao lado do atacante: perpendicular a linha defensor->atacante, do lado mais perto de `prefer`
// (onde o jogo colocaria o lutador). Falha (false) se o ponto sair da area segura: raio maximo entre o
// atacante e `prefer` em relacao ao centro da arena, mais uma folga. Assim nunca vai mais longe que lugares
// onde o jogo ja colocou alguem (sem atravessar parede nem sair do mapa).
inline bool LateralSpot(const float attacker[3], const float defenderBefore[3], const float prefer[3],
                        float out[3]) {
  float vx = attacker[0] - defenderBefore[0], vy = attacker[1] - defenderBefore[1];
  float len = std::sqrt(vx * vx + vy * vy);
  if (!(len > 1.0f)) {
    vx = 1.0f;
    vy = 0.0f;
    len = 1.0f;
  }
  vx /= len;
  vy /= len;
  const float px = -vy, py = vx;
  const float a[2] = {attacker[0] + px * kLateralDistance, attacker[1] + py * kLateralDistance};
  const float b[2] = {attacker[0] - px * kLateralDistance, attacker[1] - py * kLateralDistance};
  auto d2 = [](const float* p, const float* q) { return (p[0] - q[0]) * (p[0] - q[0]) + (p[1] - q[1]) * (p[1] - q[1]); };
  const float* first = d2(a, prefer) <= d2(b, prefer) ? a : b;
  const float* second = first == a ? b : a;
  const float limit = std::fmax(std::sqrt(attacker[0] * attacker[0] + attacker[1] * attacker[1]),
                                std::sqrt(prefer[0] * prefer[0] + prefer[1] * prefer[1])) + kBoundsMargin;
  const float* candidates[2] = {first, second};
  for (const float* c : candidates) {
    if (std::sqrt(c[0] * c[0] + c[1] * c[1]) <= limit) {
      out[0] = c[0];
      out[1] = c[1];
      out[2] = attacker[2];
      return true;
    }
  }
  return false;
}
}  // namespace perfectsub
