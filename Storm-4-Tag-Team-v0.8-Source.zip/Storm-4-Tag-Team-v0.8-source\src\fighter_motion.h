#pragma once
#include <cstdint>

// Leitura e escrita basicas de um lutador do Storm 4 Evolution (offsets lidos no jogo, ver README rodadas 5 e 7):
// posicao +0x70 (x, y, z); estado PL_ACT +0xCC0; animacao PL_ANM +0x1080; direcao +0xA8 (x, y) com copias em
// +0xB4/+0xC0/+0xE4/+0xF0/+0xFC e a matriz do modelo em +0x108. Tudo protegido contra ponteiro invalido.
namespace fighter {
int State(uintptr_t player);
int Anm(uintptr_t player);
bool Pos(uintptr_t player, float out[3]);
void SetPos(uintptr_t player, const float p[3]);
void FaceToward(uintptr_t player, float tx, float ty);
float Distance2D(const float a[3], const float b[3]);
}  // namespace fighter
