#include "wall_run.h"

#include <windows.h>
#include <Xinput.h>
#include <MinHook.h>

#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

#include "addresses.h"
#include "camera.h"
#include "census.h"
#include "cpu_adapt.h"
#include "fighter_motion.h"
#include "frame_capture.h"
#include "jutsu_clash_3d.h"
#include "input.h"
#include "jutsu_clash.h"
#include "log.h"
#include "promote.h"

namespace {
std::atomic<int> g_test{0};
uint64_t g_battleAt = 0;

// ---- leitura e escrita do corpo do lutador (Evolution) ----
// Matriz do modelo em +0x108: linhas (X.x, Y.x, Z.x, pos.x), (X.y, Y.y, Z.y, pos.y), (X.z, Y.z, Z.z, pos.z), onde
// X/Y/Z sao os eixos locais no mundo. De pe, olhando para d: X = (-dy, dx, 0), Y = -d, Z = (0, 0, 1).
// O desenho do modelo recebe a matriz por exe+0x5594CC(objetoDeDesenho, matriz); interceptamos essa rotina e, para
// um lutador inclinado, trocamos a matriz pela nossa (qualquer caminho do jogo que monte o desenho passa por ali).
using SetDrawMatrixFn = void (*)(uintptr_t draw, const float* matrix);
SetDrawMatrixFn g_origSetDrawMatrix = nullptr;
std::atomic<uintptr_t> g_tiltDraw[6]{};
float g_tiltMatrix[6][16]{};  // 4x4: a rotina de desenho le as 4 linhas (a 4a do jogo e 0,0,0,1)
std::atomic<unsigned> g_tiltSwaps{0};

void HookSetDrawMatrix(uintptr_t draw, const float* matrix) {
  if (draw)
    for (int k = 0; k < 6; ++k)
      if (g_tiltDraw[k].load(std::memory_order_relaxed) == draw) {
        matrix = g_tiltMatrix[k];
        g_tiltSwaps.fetch_add(1, std::memory_order_relaxed);
        break;
      }
  g_origSetDrawMatrix(draw, matrix);
}

uintptr_t DrawOf(uintptr_t player) {
  __try {
    return *reinterpret_cast<const uintptr_t*>(player + 0x208);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return 0;
  }
}

void ClearTilt(uintptr_t player) {
  const uintptr_t draw = DrawOf(player);
  for (auto& d : g_tiltDraw) {
    uintptr_t expected = draw;
    if (draw) d.compare_exchange_strong(expected, 0);
  }
}

void WriteBody(uintptr_t player, const float forward[3], const float up[3], const float pos[3]) {
  // Y = -frente, Z = cima, X = Y x Z
  const float Y[3] = {-forward[0], -forward[1], -forward[2]};
  const float* Z = up;
  const float X[3] = {Y[1] * Z[2] - Y[2] * Z[1], Y[2] * Z[0] - Y[0] * Z[2], Y[0] * Z[1] - Y[1] * Z[0]};
  __try {
    float* m = reinterpret_cast<float*>(player + 0x108);
    for (int r = 0; r < 3; ++r) {
      m[r * 4 + 0] = X[r];
      m[r * 4 + 1] = Y[r];
      m[r * 4 + 2] = Z[r];
      m[r * 4 + 3] = pos[r];
    }
    float* p = reinterpret_cast<float*>(player + 0x70);
    p[0] = pos[0];
    p[1] = pos[1];
    p[2] = pos[2];
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return;
  }
  // Desenho: registra a matriz para o gancho e aplica ja neste quadro.
  const uintptr_t draw = DrawOf(player);
  if (!draw || !g_origSetDrawMatrix) return;
  int slot = -1;
  for (int k = 0; k < 6; ++k)
    if (g_tiltDraw[k].load(std::memory_order_relaxed) == draw) slot = k;
  for (int k = 0; k < 6 && slot < 0; ++k)
    if (!g_tiltDraw[k].load(std::memory_order_relaxed)) slot = k;
  if (slot < 0) return;
  std::memcpy(g_tiltMatrix[slot], reinterpret_cast<const void*>(player + 0x108), sizeof(g_tiltMatrix[slot]));
  g_tiltDraw[slot].store(draw, std::memory_order_relaxed);
  __try {
    g_origSetDrawMatrix(draw, g_tiltMatrix[slot]);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}

void ReadMatrix(uintptr_t player, float out[12]) {
  __try {
    std::memcpy(out, reinterpret_cast<const void*>(player + 0x108), 12 * sizeof(float));
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    std::memset(out, 0, 12 * sizeof(float));
  }
}

void ZeroMotion(uintptr_t player) {
  __try {
    float* v = reinterpret_cast<float*>(player + 0x148);
    v[0] = v[1] = v[2] = 0.0f;  // +0x148 velocidade
    v[3] = 0.0f;                // +0x154 velocidade para frente
    v[5] = 0.0f;                // +0x15C velocidade vertical
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}

// Trava nativa da matriz do corpo: com +0x210 != 0 a rotina de desenho do lutador (exe+0x786844) nao remonta a
// matriz em pe a partir da direcao; so copia +0x108 para o objeto de desenho. exe+0x75DF04 trava, exe+0x75E56C solta.
void ClearTilt(uintptr_t player);
bool MatrixLock(uintptr_t player, bool lock) {
  if (!lock) ClearTilt(player);
  static const uint8_t kLock[] = {0xC7, 0x81, 0x10, 0x02, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0xC3};
  static const uint8_t kUnlock[] = {0x83, 0xA1, 0x10, 0x02, 0x00, 0x00, 0x00, 0xC3};
  const auto* fn = reinterpret_cast<const uint8_t*>(g_base + (lock ? 0x75DF04 : 0x75E56C));
  if (std::memcmp(fn, lock ? kLock : kUnlock, lock ? sizeof(kLock) : sizeof(kUnlock)) != 0) return false;
  __try {
    reinterpret_cast<void (*)(uintptr_t)>(const_cast<uint8_t*>(fn))(player);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

float ReadF(uintptr_t player, int off) {
  __try {
    return *reinterpret_cast<const float*>(player + off);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return NAN;
  }
}

// Raio horizontal contra o cenario; devolve a distancia ate a batida ou -1.
float Ray(const float from[3], const float dir[3], float length, int mask, void* raw = nullptr) {
  const float delta[3] = {dir[0] * length, dir[1] * length, dir[2] * length};
  float fraction = -1.0f;
  if (!CameraStageSweep(from, delta, 8.0f, mask, &fraction, raw)) return -2.0f;
  if (fraction < 0.0f || fraction > 1.0f) return -1.0f;
  return fraction * length;
}

bool StickFor(const float w[2], short* lx, short* ly);

uint32_t CurrentArenaCode() {
  __try {
    return *reinterpret_cast<const uint32_t*>(g_base + 0x15FED38);  // codigo da arena da luta atual
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return 0;
  }
}

// ---- mapa da arena (parede_teste=2): raios do centro e limite da area de luta ----
struct MapProbe {
  int stage = 0;
  int who = -1;
  int leg = -1;
  uint64_t at = 0, next = 0, traceNext = 0;
  uint64_t crashLog[6]{};
  float ground = 0.0f;
  float lastStop[3]{};
  bool stick = false;
  short stickX = 0, stickY = 0;
  float runDir[2]{1, 0};
  uint64_t shotAt = 0;
};
MapProbe g_map;

void MapRays(float ground) {
  const float heights[] = {60.0f, 300.0f, 900.0f};
  const int masks[] = {4, -1};
  for (float h : heights)
    for (int mask : masks) {
      const float origin[3] = {0.0f, 0.0f, ground + h};
      char line[900];
      int used = std::snprintf(line, sizeof(line), "PAREDE MAPA h%.0f m%d:", h, mask);
      for (int i = 0; i < 72; ++i) {
        const float a = 6.2831853f * (i + 0.5f) / 72.0f;  // nunca exatamente num eixo
        const float dir[3] = {std::cos(a), std::sin(a), 0.0f};
        const float d = Ray(origin, dir, 8000.0f, mask);
        used += std::snprintf(line + used, sizeof(line) - used, " %.0f", d);
      }
      Log("%s", line);
    }
}

void MapTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (g_map.stage == 0) {
    if (sceneActive || !g_battleAt || now - g_battleAt < 8000) return;
    for (int k = 0; k < n; ++k)
      if (f[k].valid && f[k].side == 0) {
        g_map.who = k;
        break;
      }
    if (g_map.who < 0) return;
    g_map.ground = f[g_map.who].pos[2];
    char where[400];
    int used = std::snprintf(where, sizeof(where), "PAREDE MAPA: chao %.0f, lutadores", g_map.ground);
    for (int k = 0; k < n; ++k)
      if (f[k].valid)
        used += std::snprintf(where + used, sizeof(where) - used, " J%d(%.0f,%.0f,%.0f)", f[k].number, f[k].pos[0],
                              f[k].pos[1], f[k].pos[2]);
    Log("%s", where);
    MapRays(g_map.ground);
    g_map.stage = 1;
    g_map.next = now;
    return;
  }
  if (g_map.stage < 1 || g_map.stage > 3) return;
  const uintptr_t pl = f[g_map.who].player;
  // Os outros lutadores ficam presos longe (do lado oposto a corrida) para nao atrapalhar a medicao.
  for (int k = 0; k < n; ++k) {
    if (k == g_map.who || !f[k].valid) continue;
    const float a = 0.25f * k;
    const float farPos[3] = {-g_map.runDir[0] * 1300.0f + std::cos(a) * 200.0f,
                             -g_map.runDir[1] * 1300.0f + std::sin(a) * 200.0f, g_map.ground + 20.0f};
    fighter::SetPos(f[k].player, farPos);
  }
  // Batidas na borda (DMG_CRASH_WALL 0x2C) de qualquer lutador: e onde o jogo acha que ha parede.
  for (int k = 0; k < n; ++k)
    if (f[k].valid && f[k].state == 0x2C && now >= g_map.crashLog[k]) {
      g_map.crashLog[k] = now + 1000;
      Log("PAREDE BATIDA NA BORDA: J%d em (%.0f,%.0f,%.0f) r=%.0f", f[k].number, f[k].pos[0], f[k].pos[1], f[k].pos[2],
          std::hypot(f[k].pos[0], f[k].pos[1]));
    }
  if (g_map.stage == 1) {
    // Corrida ate o limite: 8 pernas de 5 s, analogico do controle 1 em 8 direcoes (relativas a camera).
    if (now >= g_map.next) {
      if (g_map.leg >= 0 && !g_map.shotAt) {
        // fim da perna: captura o quadro do jogo com o J1 parado onde travou; 250 ms depois segue
        const std::wstring dir = ModDir() + L"storm6_capturas";
        CreateDirectoryW(dir.c_str(), nullptr);
        const uint32_t code = CurrentArenaCode();
        wchar_t file[64];
        std::swprintf(file, 64, L"\\mapa_%08X_%02d.png", code, g_map.leg);
        FrameCaptureRequest((dir + file).c_str());
        g_map.stick = false;
        g_map.shotAt = now;
        g_map.next = now + 250;
        return;
      }
      g_map.shotAt = 0;
      if (g_map.leg >= 0) {
        float p[3]{};
        fighter::Pos(pl, p);
        if (std::hypot(p[0], p[1]) > std::hypot(g_map.lastStop[0], g_map.lastStop[1])) {  // a corrida mais longa
          g_map.lastStop[0] = p[0];
          g_map.lastStop[1] = p[1];
          g_map.lastStop[2] = p[2];
        }
        Log("PAREDE LIMITE perna %d: parou em (%.0f,%.0f,%.0f) r=%.0f angulo %.0f estado 0x%X", g_map.leg, p[0], p[1], p[2],
            std::hypot(p[0], p[1]), std::atan2(p[1], p[0]) * 57.2958f, fighter::State(pl));
      }
      ++g_map.leg;
      if (g_map.leg >= 12) {
        g_map.stage = 2;
        g_map.stick = false;
        g_map.at = now;
        Log("PAREDE MAPA: corridas terminadas; teste do corpo inclinado na borda.");
        return;
      }
      const float c[3] = {0.0f, 0.0f, g_map.ground + 20.0f};
      fighter::SetPos(pl, c);
      clash3d::SetActionNow(pl, 0x1);
      // pernas em direcoes do MUNDO (0 = +x): o analogico e recalculado a cada quadro pela camera
      const float wa = g_map.leg * 30.0f / 57.2958f;  // 12 direcoes do mundo, a cada 30 graus
      g_map.runDir[0] = std::cos(wa);
      g_map.runDir[1] = std::sin(wa);
      StickFor(g_map.runDir, &g_map.stickX, &g_map.stickY);
      g_map.stick = true;
      g_map.next = now + 4500;
      g_map.traceNext = now + 300;
      return;
    }
    StickFor(g_map.runDir, &g_map.stickX, &g_map.stickY);
    if (now >= g_map.traceNext) {
      g_map.traceNext = now + 500;
      float p[3]{};
      fighter::Pos(pl, p);
      Log("PAREDE CORRIDA perna %d: (%.0f,%.0f,%.0f) r=%.0f estado 0x%X anm %d", g_map.leg, p[0], p[1], p[2],
          std::hypot(p[0], p[1]), fighter::State(pl), fighter::Anm(pl));
    }
    return;
  }
  // Corpo inclinado na ultima borda: 0-1,5 s estado 0x1 + RUN1; 1,5-3 s estado 0x64; depois solta (FALL).
  const uint64_t t = now - g_map.at;
  float out[2] = {g_map.lastStop[0], g_map.lastStop[1]};
  const float r = std::hypot(out[0], out[1]);
  if (!(r > 100.0f)) {
    g_map.stage = 4;
    return;
  }
  const float N[3] = {-out[0] / r, -out[1] / r, 0.0f};  // da borda para o centro
  if (now >= g_map.traceNext && t < 4500) {
    g_map.traceNext = now + 100;
    float p[3]{}, m[12]{};
    fighter::Pos(pl, p);
    ReadMatrix(pl, m);
    Log("PAREDE INCLINADO +%llums: estado 0x%X anm %d pos (%.0f,%.0f,%.0f) Z(%.2f,%.2f,%.2f) Y(%.2f,%.2f,%.2f) vz %.2f",
        static_cast<unsigned long long>(t), fighter::State(pl), fighter::Anm(pl), p[0], p[1], p[2], m[2], m[6], m[10],
        m[1], m[5], m[9], ReadF(pl, 0x15C));
  }
  if (t < 3000) {
    if (g_map.stage == 2 && t < 50) {
      clash3d::SetActionNow(pl, 0x1);
      Log("PAREDE INCLINADO: RUN1 %s.", clash3d::PlayAnm(pl, 77) ? "ok" : "falhou");
    }
    if (g_map.stage == 2 && t >= 1500) {
      g_map.stage = 3;
      Log("PAREDE INCLINADO: agora no estado 0x64 (%s).", clash3d::SetActionNow(pl, 0x64) ? "ok" : "falhou");
    }
    const float pos[3] = {g_map.lastStop[0], g_map.lastStop[1], g_map.ground + 150.0f + t * 0.1f};
    const float up[3] = {0.0f, 0.0f, 1.0f};
    WriteBody(pl, up, N, pos);
    ZeroMotion(pl);
    return;
  }
  if (g_map.stage != 4) {
    g_map.stage = 4;
    const float off[3] = {g_map.lastStop[0] + N[0] * 80.0f, g_map.lastStop[1] + N[1] * 80.0f, g_map.ground + 450.0f};
    fighter::SetPos(pl, off);
    fighter::FaceToward(pl, off[0] + N[0] * 100.0f, off[1] + N[1] * 100.0f);
    Log("PAREDE INCLINADO: solto (FALL %s).", clash3d::SetActionNow(pl, 0x6) ? "ok" : "falhou");
  }
}

// ---- onde esta a parede de verdade (parede_teste=3) ----
struct SpotProbe {
  int stage = 0, who = -1, step = -1;
  uint64_t at = 0, next = 0, traceNext = 0;
  float ground = 0.0f, angle = 0.0f;
};
SpotProbe g_spot;

void SpotTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (g_spot.stage == 0) {
    if (sceneActive || !g_battleAt || now - g_battleAt < 8000) return;
    for (int k = 0; k < n; ++k)
      if (f[k].valid && f[k].side == 0) {
        g_spot.who = k;
        break;
      }
    if (g_spot.who < 0) return;
    float view[3]{};
    g_spot.angle = CameraViewDirection(view) ? std::atan2(view[1], view[0]) : 0.3f;
    g_spot.ground = f[g_spot.who].pos[2];
    g_spot.stage = 1;
    g_spot.next = now;
    Log("PAREDE ONDE: angulo da camera %.0f graus; J%d sera colocado no fundo da vista.", g_spot.angle * 57.2958f,
        f[g_spot.who].number);
    return;
  }
  if (g_spot.stage > 2) return;
  const uintptr_t pl = f[g_spot.who].player;
  for (int k = 0; k < n; ++k) {
    if (k == g_spot.who || !f[k].valid) continue;
    const float a = g_spot.angle + 3.14159f + 0.3f * k;
    const float farPos[3] = {std::cos(a) * 900.0f, std::sin(a) * 900.0f, g_spot.ground + 20.0f};
    fighter::SetPos(f[k].player, farPos);
  }
  static const float kRadii[] = {2200.0f, 2600.0f, 3000.0f, 3300.0f, 3600.0f, 3900.0f};
  const float c = std::cos(g_spot.angle), s = std::sin(g_spot.angle);
  const float N[3] = {-c, -s, 0.0f};  // da parede para o centro
  if (g_spot.stage == 1) {
    if (now >= g_spot.next) {
      ++g_spot.step;
      if (g_spot.step >= 6) {
        // Solta fora do circulo, em pe, e pula para o centro: o jogo puxa de volta para dentro do limite?
        MatrixLock(pl, false);
        const float p[3] = {c * 3000.0f, s * 3000.0f, g_spot.ground + 10.0f};
        fighter::SetPos(pl, p);
        fighter::FaceToward(pl, 0.0f, 0.0f);
        g_spot.stage = 2;
        g_spot.at = now;
        Log("PAREDE ONDE: J%d solto em r=3000 e pulando para o centro (JMP_F 0x5 %s).", f[g_spot.who].number,
            clash3d::SetActionNow(pl, 0x5) ? "ok" : "falhou");
        return;
      }
      const bool locked = MatrixLock(pl, true);
      clash3d::SetActionNow(pl, 0x1);
      clash3d::PlayAnm(pl, 77);
      Log("PAREDE ONDE: J%d inclinado em r=%.0f (trava %s).", f[g_spot.who].number, kRadii[g_spot.step],
          locked ? "ok" : "FALHOU");
      g_spot.next = now + 1600;
    }
    const float R = kRadii[g_spot.step];
    const float pos[3] = {c * R, s * R, g_spot.ground + 220.0f};
    const float up[3] = {0.0f, 0.0f, 1.0f};
    WriteBody(pl, up, N, pos);
    ZeroMotion(pl);
    if (fighter::Anm(pl) != 77) clash3d::PlayAnm(pl, 77);
    return;
  }
  // stage 2: rastro do pulo de volta
  if (now >= g_spot.traceNext) {
    g_spot.traceNext = now + 150;
    float p[3]{};
    fighter::Pos(pl, p);
    Log("PAREDE VOLTA +%llums: (%.0f,%.0f,%.0f) r=%.0f estado 0x%X", static_cast<unsigned long long>(now - g_spot.at), p[0],
        p[1], p[2], std::hypot(p[0], p[1]), fighter::State(pl));
  }
  if (now - g_spot.at > 3000) g_spot.stage = 3;
}

// ---- teste de investigacao (parede_teste=1) ----
struct Probe {
  int stage = 0;
  int who = -1;
  uint64_t at = 0, traceNext = 0;
  float ground = 0.0f;
  float wall[3]{};    // ponto da parede
  float normal[3]{};  // normal da parede (para fora)
  float wallTop = 0.0f;
};
Probe g_probe;

bool ScanWalls(const float pos[3], Probe& probe) {
  const float origin[3] = {pos[0], pos[1], pos[2] + 100.0f};
  constexpr int kDirs = 32;
  constexpr float kLen = 3000.0f;
  float best = 1e9f, bestAngle = 0.0f;
  char line[512];
  int used = std::snprintf(line, sizeof(line), "PAREDE RAIOS (mascara 4, de %.0f,%.0f,%.0f):", origin[0], origin[1],
                           origin[2]);
  for (int i = 0; i < kDirs; ++i) {
    const float a = 6.2831853f * i / kDirs;
    const float dir[3] = {std::cos(a), std::sin(a), 0.0f};
    const float d = Ray(origin, dir, kLen, 4);
    used += std::snprintf(line + used, sizeof(line) - used, " %d:%.0f", i * 360 / kDirs, d);
    if (d >= 0.0f && d < best) {
      best = d;
      bestAngle = a;
    }
  }
  Log("%s", line);
  // Outras mascaras na direcao mais proxima (para saber quem bloqueia o lutador e quem bloqueia a camera).
  {
    const float dir[3] = {std::cos(bestAngle), std::sin(bestAngle), 0.0f};
    Log("PAREDE MASCARAS no angulo %.0f: m1 %.0f m2 %.0f m4 %.0f m8 %.0f m16 %.0f m-1 %.0f", bestAngle * 57.2958f,
        Ray(origin, dir, kLen, 1), Ray(origin, dir, kLen, 2), Ray(origin, dir, kLen, 4), Ray(origin, dir, kLen, 8),
        Ray(origin, dir, kLen, 16), Ray(origin, dir, kLen, -1));
  }
  if (best > 2500.0f) {
    Log("PAREDE: nenhuma parede ao alcance (mascara 4).");
    return false;
  }
  // Normal por dois raios vizinhos (+-4 graus): tangente = P2 - P1.
  float P[2][3];
  for (int s = 0; s < 2; ++s) {
    const float a = bestAngle + (s ? 0.07f : -0.07f);
    const float dir[3] = {std::cos(a), std::sin(a), 0.0f};
    const float d = Ray(origin, dir, kLen, 4);
    if (d < 0.0f) {
      Log("PAREDE: raio vizinho nao bateu; normal indefinida.");
      return false;
    }
    for (int k = 0; k < 3; ++k) P[s][k] = origin[k] + dir[k] * d;
  }
  float tx = P[1][0] - P[0][0], ty = P[1][1] - P[0][1];
  const float tl = std::hypot(tx, ty);
  if (!(tl > 0.5f)) return false;
  tx /= tl;
  ty /= tl;
  float nx = ty, ny = -tx;
  const float cdir[3] = {std::cos(bestAngle), std::sin(bestAngle), 0.0f};
  if (nx * cdir[0] + ny * cdir[1] > 0.0f) {  // a normal aponta para o lutador (contra o raio)
    nx = -nx;
    ny = -ny;
  }
  alignas(16) uint8_t raw[0x108]{};
  const float d = Ray(origin, cdir, kLen, 4, raw);
  for (int k = 0; k < 3; ++k) probe.wall[k] = origin[k] + cdir[k] * d;
  probe.wall[2] = pos[2];
  probe.normal[0] = nx;
  probe.normal[1] = ny;
  probe.normal[2] = 0.0f;
  probe.ground = pos[2];
  Log("PAREDE MAIS PROXIMA: %.0f a %.0f graus, ponto (%.0f,%.0f), normal (%.2f,%.2f)", d, bestAngle * 57.2958f,
      probe.wall[0], probe.wall[1], nx, ny);
  const float* f = reinterpret_cast<const float*>(raw);
  for (int row = 0; row < 4; ++row)
    Log("PAREDE RESULTADO +%02X: %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f", row * 32, f[row * 8 + 0], f[row * 8 + 1],
        f[row * 8 + 2], f[row * 8 + 3], f[row * 8 + 4], f[row * 8 + 5], f[row * 8 + 6], f[row * 8 + 7]);
  // Altura da parede: raios contra ela em varias alturas.
  probe.wallTop = 0.0f;
  char hl[256];
  int hu = std::snprintf(hl, sizeof(hl), "PAREDE ALTURA:");
  const float heights[] = {30.0f, 150.0f, 300.0f, 500.0f, 800.0f, 1200.0f, 1800.0f, 2500.0f};
  for (float h : heights) {
    const float from[3] = {probe.wall[0] + nx * 120.0f, probe.wall[1] + ny * 120.0f, pos[2] + h};
    const float into[3] = {-nx, -ny, 0.0f};
    const float hit = Ray(from, into, 300.0f, 4);
    hu += std::snprintf(hl + hu, sizeof(hl) - hu, " %.0f:%.0f", h, hit);
    if (hit >= 0.0f) probe.wallTop = h;
  }
  Log("%s (topo medido %.0f)", hl, probe.wallTop);
  return true;
}

void ProbeTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (g_probe.stage == 0) {
    if (sceneActive || !g_battleAt || now - g_battleAt < 8000) return;
    int who = -1;
    for (int k = 0; k < n; ++k)
      if (f[k].valid && f[k].side == 0) {
        who = k;
        break;
      }
    if (who < 0) return;
    g_probe.who = who;
    g_probe.at = now;
    g_probe.stage = ScanWalls(f[who].pos, g_probe) ? 1 : 9;
    Log("PAREDE TESTE: J%d, gravidade +158 = %.3f, escala +200 = %.3f", f[who].number, ReadF(f[who].player, 0x158),
        ReadF(f[who].player, 0x200));
    return;
  }
  if (g_probe.stage == 9) return;
  const int k = g_probe.who;
  const uintptr_t pl = f[k].player;
  const uint64_t t = now - g_probe.at;
  const float* N = g_probe.normal;

  // Rastro do que o JOGO deixou (antes de a gente escrever neste quadro).
  if (now >= g_probe.traceNext && t < 11000) {
    g_probe.traceNext = now + 100;
    float p[3]{}, m[12]{};
    fighter::Pos(pl, p);
    ReadMatrix(pl, m);
    Log("PAREDE TRACE +%llums etapa %d: estado 0x%X anm %d pos (%.0f,%.0f,%.0f) X(%.2f,%.2f,%.2f) Y(%.2f,%.2f,%.2f) "
        "Z(%.2f,%.2f,%.2f) T(%.0f,%.0f,%.0f) vz %.2f",
        static_cast<unsigned long long>(t), g_probe.stage, fighter::State(pl), fighter::Anm(pl), p[0], p[1], p[2],
        m[0], m[4], m[8], m[1], m[5], m[9], m[2], m[6], m[10], m[3], m[7], m[11], ReadF(pl, 0x15C));
  }

  if (g_probe.stage == 1 && t > 1000) {
    // Leva o lutador para perto da parede, de frente para ela.
    const float p[3] = {g_probe.wall[0] + N[0] * 200.0f, g_probe.wall[1] + N[1] * 200.0f, g_probe.ground};
    fighter::SetPos(pl, p);
    fighter::FaceToward(pl, g_probe.wall[0], g_probe.wall[1]);
    clash3d::SetActionNow(pl, 0x1);
    g_probe.stage = 2;
    Log("PAREDE TESTE: J%d na frente da parede (%.0f,%.0f).", f[k].number, p[0], p[1]);
    return;
  }
  if (g_probe.stage == 2 && t > 2000) {
    g_probe.stage = 3;
    Log("PAREDE TESTE: subindo (corpo inclinado, posicao por quadro). PlayAnm RUN1 %s.",
        clash3d::PlayAnm(pl, 77) ? "ok" : "falhou");
  }
  if (g_probe.stage == 3) {
    const float climb = std::fmin((t - 2000) * 0.25f, std::fmax(0.0f, (g_probe.wallTop > 0 ? g_probe.wallTop : 400.0f) - 120.0f));
    const float pos[3] = {g_probe.wall[0] + N[0] * 6.0f, g_probe.wall[1] + N[1] * 6.0f, g_probe.ground + 40.0f + climb};
    const float forward[3] = {0.0f, 0.0f, 1.0f};
    WriteBody(pl, forward, N, pos);
    ZeroMotion(pl);
    if (t > 4500 && t < 4600 && fighter::Anm(pl) != 77) clash3d::PlayAnm(pl, 77);
    if (t > 6000) {
      g_probe.stage = 4;
      Log("PAREDE TESTE: correndo de lado na parede.");
    }
    return;
  }
  if (g_probe.stage == 4) {
    // Lado: a frente e a tangente da parede.
    const float tangent[3] = {-N[1], N[0], 0.0f};
    const float run = (t - 6000) * 0.3f;
    const float height = std::fmax(60.0f, std::fmin(g_probe.wallTop > 0 ? g_probe.wallTop - 150.0f : 250.0f, 250.0f));
    const float pos[3] = {g_probe.wall[0] + N[0] * 6.0f + tangent[0] * run, g_probe.wall[1] + N[1] * 6.0f + tangent[1] * run,
                          g_probe.ground + height};
    WriteBody(pl, tangent, N, pos);
    ZeroMotion(pl);
    if (t > 8000) {
      // Pulo para fora: solta longe da parede e deixa o jogo cair e aterrissar.
      g_probe.stage = 5;
      const float off[3] = {pos[0] + N[0] * 80.0f, pos[1] + N[1] * 80.0f, pos[2]};
      fighter::SetPos(pl, off);
      fighter::FaceToward(pl, off[0] + N[0] * 100.0f, off[1] + N[1] * 100.0f);
      Log("PAREDE TESTE: soltando da parede (FALL 0x6 %s).", clash3d::SetActionNow(pl, 0x6) ? "ok" : "falhou");
    }
    return;
  }
  if (g_probe.stage == 5 && t > 11000) {
    g_probe.stage = 9;
    Log("PAREDE TESTE: fim.");
  }
}
#include "wall_run_mechanic.inl"

// ---- teste visual da rotacao (parede_teste=6): em pe, de cabeca para baixo, deitado ----
struct PoseProbe {
  int stage = 0, who = -1, last = -1;
  uint64_t at = 0, traceNext = 0;
  float base[3]{};
};
PoseProbe g_pose;

void PoseTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (g_pose.stage == 0) {
    if (sceneActive || !g_battleAt || now - g_battleAt < 6000) return;
    for (int k = 0; k < n; ++k)
      if (f[k].valid && f[k].side == 0 && f[k].pad >= 0) {
        g_pose.who = k;
        break;
      }
    if (g_pose.who < 0) return;
    g_pose.base[0] = f[g_pose.who].pos[0];
    g_pose.base[1] = f[g_pose.who].pos[1];
    g_pose.base[2] = f[g_pose.who].pos[2] + 250.0f;
    g_pose.stage = 1;
    g_pose.at = now;
    Log("PAREDE POSE: J%d travado em (%.0f,%.0f,%.0f) (trava %s).", f[g_pose.who].number, g_pose.base[0], g_pose.base[1],
        g_pose.base[2], MatrixLock(f[g_pose.who].player, true) ? "ok" : "FALHOU");
    Log("PAREDE POSE: 4a linha da matriz (+0x138) = %.3f %.3f %.3f %.3f", ReadF(f[g_pose.who].player, 0x138),
        ReadF(f[g_pose.who].player, 0x13C), ReadF(f[g_pose.who].player, 0x140), ReadF(f[g_pose.who].player, 0x144));
  }
  if (g_pose.stage != 1) return;
  const uintptr_t pl = f[g_pose.who].player;
  for (int o = 0; o < n; ++o) {  // os outros longe (so no teste)
    if (o == g_pose.who || !f[o].valid) continue;
    const float farPos[3] = {g_pose.base[0] + 380.0f + 90.0f * o, g_pose.base[1] + 60.0f * o, g_pose.base[2] - 250.0f};
    fighter::SetPos(f[o].player, farPos);
  }
  if (now >= g_pose.traceNext) {
    g_pose.traceNext = now + 500;
    float sx = 0, sy = 0;
    CameraProject(g_pose.base, 16.0f / 9.0f, &sx, &sy);
    Log("PAREDE POSE: J1 na tela (%.2f,%.2f) estado 0x%X", sx, sy, fighter::State(pl));
  }
  const uint64_t t = now - g_pose.at;
  const int phase = static_cast<int>(t / 1500);
  if (phase >= 3) {
    MatrixLock(pl, false);
    g_pose.stage = 2;
    Log("PAREDE POSE: fim.");
    return;
  }
  if (phase != g_pose.last) {
    g_pose.last = phase;
    Log("PAREDE POSE: trocas da matriz de desenho ate agora %u.", g_tiltSwaps.load());
    Log("PAREDE POSE: fase %d (%s).", phase, phase == 0 ? "em pe, olhando +x" : phase == 1 ? "de cabeca para baixo" : "deitado, cabeca para +x");
  }
  const float fwdUp[3] = {1, 0, 0}, upUp[3] = {0, 0, 1};
  const float fwdDown[3] = {1, 0, 0}, upDown[3] = {0, 0, -1};
  const float fwdLie[3] = {0, 0, 1}, upLie[3] = {1, 0, 0};
  const float* F = phase == 0 ? fwdUp : phase == 1 ? fwdDown : fwdLie;
  const float* U = phase == 0 ? upUp : phase == 1 ? upDown : upLie;
  WriteBody(pl, F, U, g_pose.base);
  ZeroMotion(pl);
  if (fighter::Anm(pl) != 77) clash3d::PlayAnm(pl, 77);
}

// ---- luta na parede NATIVA (parede_teste=5): arenas com paredes de cenario (SI43B, SI51A) ----
struct NativeProbe {
  int stage = 0, who = -1;
  uint64_t at = 0, traceNext = 0;
  int seen[6]{};
};
NativeProbe g_native;

void NativeTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  for (int k = 0; k < n && k < 6; ++k) {
    const int s = f[k].valid ? f[k].state : -1;
    if (s >= 0x64 && s <= 0x66 && g_native.seen[k] != s) {
      g_native.seen[k] = s;
      Log("PAREDE NATIVA: J%d entrou no estado 0x%X sozinho em (%.0f,%.0f,%.0f) anm %d", f[k].number, s, f[k].pos[0],
          f[k].pos[1], f[k].pos[2], fighter::Anm(f[k].player));
    } else if (!(s >= 0x64 && s <= 0x66)) {
      g_native.seen[k] = 0;
    }
  }
  if (g_native.stage == 0) {
    if (sceneActive || !g_battleAt || now - g_battleAt < 6000) return;
    for (int k = 0; k < n; ++k)
      if (f[k].valid && f[k].side == 0 && f[k].pad >= 0) {
        g_native.who = k;
        break;
      }
    if (g_native.who < 0) return;
    uint32_t code = 0;
    __try {
      code = *reinterpret_cast<const uint32_t*>(g_base + 0x15FED38);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
    char where[400];
    int used = std::snprintf(where, sizeof(where), "PAREDE NATIVA: arena 0x%08X, lutadores", code);
    for (int k = 0; k < n; ++k)
      if (f[k].valid)
        used += std::snprintf(where + used, sizeof(where) - used, " J%d(%.0f,%.0f,%.0f)", f[k].number, f[k].pos[0],
                              f[k].pos[1], f[k].pos[2]);
    Log("%s", where);
    float view[3]{1, 0, 0};
    CameraViewDirection(view);
    const float l = std::hypot(view[0], view[1]);
    g_demo.aim[0] = l > 0.01f ? view[0] / l : 1.0f;
    g_demo.aim[1] = l > 0.01f ? view[1] / l : 0.0f;
    g_native.stage = 1;
    g_native.at = now;
  }
  if (g_native.stage > 2) return;
  const GrabFighterView& v = f[g_native.who];
  const uint64_t t = now - g_native.at;
  if (now >= g_native.traceNext) {
    g_native.traceNext = now + 150;
    Log("PAREDE NATIVA TRACE etapa %d +%llums: J%d estado 0x%X anm %d pos (%.0f,%.0f,%.0f)", g_native.stage,
        static_cast<unsigned long long>(t), v.number, fighter::State(v.player), fighter::Anm(v.player), v.pos[0], v.pos[1],
        v.pos[2]);
  }
  if (g_native.stage == 1) {  // corre de verdade contra a borda (no fundo da vista)
    g_demo.stick = true;
    g_demo.buttons = 0;
    StickFor(g_demo.aim, &g_demo.lx, &g_demo.ly);
    if (t > 5000) {
      g_demo.stick = false;
      g_native.stage = 2;
      g_native.at = now;
      Log("PAREDE NATIVA: J%d mandado para WALLBATTLE_IN 0x64 (%s).", v.number,
          clash3d::SetActionNow(v.player, 0x64) ? "ok" : "falhou");
    }
    return;
  }
  if (g_native.stage == 2 && t > 5000) {
    g_native.stage = 3;
    Log("PAREDE NATIVA: fim.");
  }
}
}  // namespace

void WallRunInstall() {
  if (Addr().timestamp != 0x5889906E) return;
  int test = 0, enabled = 0, cpu = 35, maxMs = 3500;
  const std::wstring file = ModDir() + L"storm6.ini";
  if (FILE* stream = _wfopen(file.c_str(), L"r")) {
    char line[128];
    while (std::fgets(line, sizeof(line), stream)) {
      char key[65]{};
      int value = 0;
      if (std::sscanf(line, "%64[^=]=%d", key, &value) != 2) continue;
      if (!std::strcmp(key, "parede_teste")) test = value;
      if (!std::strcmp(key, "parede")) enabled = value;
      if (!std::strcmp(key, "parede_cpu")) cpu = value;
      if (!std::strcmp(key, "parede_tempo_ms")) maxMs = value;
    }
    std::fclose(stream);
  }
  g_test = test;
  g_enabled = enabled != 0 || test == 4 || test == 7;
  g_demoVerify = test == 7;
  static const uint8_t kSetDraw[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x6C, 0x24, 0x10, 0x48, 0x89, 0x74, 0x24, 0x18};
  void* target = reinterpret_cast<void*>(g_base + 0x5594CC);
  if ((g_enabled.load() || test) && std::memcmp(target, kSetDraw, sizeof(kSetDraw)) == 0) {
    MH_STATUS st = MH_CreateHook(target, reinterpret_cast<void*>(&HookSetDrawMatrix),
                                 reinterpret_cast<void**>(&g_origSetDrawMatrix));
    if (st == MH_OK) st = MH_EnableHook(target);
    Log("PAREDE: gancho da matriz de desenho %s.", st == MH_OK ? "instalado" : MH_StatusToString(st));
    if (st != MH_OK) g_origSetDrawMatrix = nullptr;
  }
  g_cpuChance = cpu < 0 ? 0 : cpu > 100 ? 100 : cpu;
  g_maxMs = maxMs < 800 ? 800 : maxMs > 10000 ? 10000 : maxMs;
  Log("PAREDE: %s (CPU %d%%, ate %d ms na parede)%s.", g_enabled.load() ? "ligada nas arenas verificadas" : "desligada",
      g_cpuChance, g_maxMs, test == 4 ? "; TESTE: demonstracao com o controle 1" : test ? "; TESTE de investigacao" : "");
}

void WallRunBeginBattle() {
  g_battleAt = GetTickCount64();
  g_probe = {};
  g_map = {};
  g_spot = {};
  g_demo = {};
  g_native = {};
  g_pose = {};
  for (auto& r : g_run) r = {};
  g_groundKnown = false;
  g_arena = nullptr;
  if (!g_enabled.load(std::memory_order_relaxed)) return;
  uint32_t code = 0;
  __try {
    code = *reinterpret_cast<const uint32_t*>(g_base + 0x15FED38);  // codigo da arena da luta atual
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  g_arena = FindArena(code);
  Log("PAREDE: arena 0x%08X %s.", code, g_arena ? "verificada: corrida na parede liberada" : "fora da lista: sem corrida na parede");
}

bool WallRunActive(uintptr_t player) { return OnWall(player); }

bool WallRunTestInput(short* lx, short* ly, WORD* buttons) {
  const int test = g_test.load(std::memory_order_relaxed);
  if (test == 2 && g_map.stick) {
    *lx = g_map.stickX;
    *ly = g_map.stickY;
    *buttons = 0;
    return true;
  }
  if ((test == 4 || test == 5 || test == 7) && g_demo.stick) {
    *lx = g_demo.lx;
    *ly = g_demo.ly;
    *buttons = g_demo.buttons;
    return true;
  }
  return false;
}

void WallRunTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (n < 2) return;
  const int test = g_test.load(std::memory_order_relaxed);
  if (g_enabled.load(std::memory_order_relaxed)) MechanicTick(f, n, sceneActive, now);
  if (test == 6) PoseTick(f, n, sceneActive, now);
  else if (test == 5) NativeTick(f, n, sceneActive, now);
  else if (test == 4 || test == 7) DemoTick(f, n, sceneActive, now);
  else if (test == 3) SpotTick(f, n, sceneActive, now);
  else if (test == 2) MapTick(f, n, sceneActive, now);
  else if (test == 1) ProbeTick(f, n, sceneActive, now);
}
