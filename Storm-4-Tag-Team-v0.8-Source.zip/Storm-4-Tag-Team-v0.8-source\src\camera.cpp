// A camera de duelo calcula olho/alvo e os entrega a FUN_140AC8590, que monta a orientacao.
// Interceptamos so a chamada de FUN_1407428A4 (duelo normal), antes do jogo aplicar a camera.
#include "camera.h"

#include <windows.h>
#include <MinHook.h>
#include <intrin.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <mutex>

#include "census.h"
#include "addresses.h"
#include "log.h"
#include "promote.h"
#include "settings.h"
#include "revolution_camera_rules.h"
#include "entrance_rules.h"
#include "trailer_cam.h"
#include "ult.h"

namespace {

#define kRvaSetView (Addr().setView)
#define kRvaDuelViewReturn (Addr().duelViewReturn)
constexpr int kMaxFighters = 6;
constexpr float kFighterCenterHeight = 65.0f;
constexpr float kMinDistance = 900.0f;
constexpr float kMaxGroupDistance = 8000.0f;
// Perto fica baixa como no 1 contra 1; quando abre, sobe para passar por cima do cenario.
constexpr float kLowPitchSin = 0.28f;
constexpr float kHighPitchSin = 0.62f;
constexpr float kLowPitchDistance = 1200.0f;
constexpr float kHighPitchDistance = 4000.0f;
// Gira para deixar a maior distancia entre os lutadores na horizontal da tela.
constexpr float kMaxTurnSpeed = 0.7f;
constexpr float kMinSpread = 22500.0f;
constexpr float kMinElongation = 0.25f;
constexpr float kIgnoreBeyond = 20000.0f;
// Vista ampla e levemente inclinada, como no torneio de Connections.
constexpr float kTournamentDistance = 1900.0f;
constexpr float kTournamentAimHeight = 85.0f;
constexpr float kTournamentSlope = 0.4f;
constexpr float kTournamentDeadZone = 0.1f;
constexpr float kTournamentTurnPerSecond = 819.0f / 65536.0f * 6.2831853f * 60.0f;
constexpr float kTournamentFollow = 6.0f;
// A camera de duelo guarda o campo de visao vertical, em graus, em camera+0x2C (padrao 45).
constexpr uintptr_t kCameraFov = 0x2C;
constexpr float kDefaultFov = 45.0f;
constexpr float kAspect = 16.0f / 9.0f;
constexpr float kFitMargin = 0.75f;  // folga para a HUD e para as bordas
constexpr ULONGLONG kViewFreshMs = 250;
constexpr float kDegToRad = 3.14159265f / 180.0f;
constexpr float kFighterPadding = 90.0f;
// Elevated, wide, auto-framing camera patterned after the Connections tournament video.
constexpr float kConnectionsMinDistance = 1700.0f;
constexpr float kConnectionsLowPitch = 0.48f;
constexpr float kConnectionsHighPitch = 0.76f;
constexpr float kConnectionsFitMargin = 0.68f;
constexpr float kConnectionsFollowRate = 5.5f;
constexpr float kConnectionsReturnRate = 1.8f;

using SetViewFn = void (*)(void*, const float*, const float*, const float*);
SetViewFn g_original = nullptr;

struct CameraSweep {
  float origin[3];
  float radius;
  float displacement[3];
};
static_assert(sizeof(CameraSweep) == 0x1C);

using SweepInitFn = void* (*)(void*);
using SweepFn = float (*)(void*, const CameraSweep*, void*, int);
SweepInitFn g_sweepInit = nullptr;
SweepFn g_sweep = nullptr;

std::mutex g_cameraMutex;
float g_positions[kMaxFighters][3];
int g_count = 0;
int g_primary = 0;
int g_target = -1;
ULONGLONG g_lastView = 0;
float g_back[2];
float g_aim[3];
float g_distance = 0;
float g_revolutionSlope = 0.36f;
float g_entranceCenter[3]{};
ULONGLONG g_entranceExpires = 0;
float g_clearFraction = 1.0f;
ULONGLONG g_sweepTick = 0;
bool g_sweepReported = false;
// Ultima vista entregue ao jogo durante a luta, para projetar marcadores na tela.
float g_viewEye[3], g_viewAim[3], g_viewUp[3] = {0, 0, 1};
float g_viewFov = kDefaultFov;
ULONGLONG g_viewTick = 0;
std::atomic<float> g_yawStick{0};

float ReadFov(const void* camera) {
  const float fov = *reinterpret_cast<const float*>(static_cast<const uint8_t*>(camera) + kCameraFov);
  return std::isfinite(fov) && fov > 5.0f && fov < 120.0f ? fov : kDefaultFov;
}

void RememberView(const float* eye, const float* aim, const float* up, float fov) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  std::memcpy(g_viewEye, eye, sizeof(g_viewEye));
  std::memcpy(g_viewAim, aim, sizeof(g_viewAim));
  std::memcpy(g_viewUp, up, sizeof(g_viewUp));
  g_viewFov = fov;
  g_viewTick = GetTickCount64();
}

// Gira g_back em direcao a perpendicular do eixo mais longo do grupo, como a camera de duelo faz
// com a linha entre os dois lutadores. Sem inverter o lado de onde a camera olha.
void TurnTowardGroup(float elapsed) {
  float meanX = 0, meanY = 0;
  for (int i = 0; i < g_count; ++i) {
    meanX += g_positions[i][0];
    meanY += g_positions[i][1];
  }
  meanX /= g_count;
  meanY /= g_count;
  float xx = 0, yy = 0, xy = 0;
  for (int i = 0; i < g_count; ++i) {
    const float dx = g_positions[i][0] - meanX, dy = g_positions[i][1] - meanY;
    xx += dx * dx;
    yy += dy * dy;
    xy += dx * dy;
  }
  const float total = xx + yy;
  if (total / g_count < kMinSpread) return;
  const float elongation = std::hypot(xx - yy, 2.0f * xy) / total;
  if (elongation < kMinElongation) return;
  const float axis = 0.5f * std::atan2(2.0f * xy, xx - yy);
  float wantX = -std::sin(axis), wantY = std::cos(axis);
  if (wantX * g_back[0] + wantY * g_back[1] < 0) {
    wantX = -wantX;
    wantY = -wantY;
  }
  const float cross = g_back[0] * wantY - g_back[1] * wantX;
  const float dot = g_back[0] * wantX + g_back[1] * wantY;
  const float limit = kMaxTurnSpeed * elongation * elapsed;
  const float turn = std::clamp(std::atan2(cross, dot), -limit, limit);
  const float c = std::cos(turn), s = std::sin(turn);
  const float x = g_back[0] * c - g_back[1] * s;
  const float y = g_back[0] * s + g_back[1] * c;
  const float length = std::hypot(x, y);
  g_back[0] = x / length;
  g_back[1] = y / length;
}

// Centro do retangulo que contem todos, medido nos eixos da propria camera.
void GroupCenter(float center[3]) {
  const float rightX = g_back[1], rightY = -g_back[0];
  float acrossLo = 0, acrossHi = 0, alongLo = 0, alongHi = 0, zLo = 0, zHi = 0;
  for (int i = 0; i < g_count; ++i) {
    const float* p = g_positions[i];
    const float across = p[0] * rightX + p[1] * rightY;
    const float along = p[0] * g_back[0] + p[1] * g_back[1];
    acrossLo = i ? std::min(acrossLo, across) : across;
    acrossHi = i ? std::max(acrossHi, across) : across;
    alongLo = i ? std::min(alongLo, along) : along;
    alongHi = i ? std::max(alongHi, along) : along;
    zLo = i ? std::min(zLo, p[2]) : p[2];
    zHi = i ? std::max(zHi, p[2]) : p[2];
  }
  const float midAcross = (acrossLo + acrossHi) * 0.5f, midAlong = (alongLo + alongHi) * 0.5f;
  center[0] = rightX * midAcross + g_back[0] * midAlong;
  center[1] = rightY * midAcross + g_back[1] * midAlong;
  center[2] = (zLo + zHi) * 0.5f + kFighterCenterHeight;
}

// O analogico direito mantem o giro do modo torneio. Trocar de alvo so desloca a mira.
bool TournamentView(const float* nativeEye, const float* nativeAim, float eye[3], float aim[3]) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  if (g_count < 1 || g_primary < 0 || g_primary >= g_count) return false;
  const float* player = g_positions[g_primary];
  for (int axis = 0; axis < 3; ++axis)
    if (!std::isfinite(player[axis]) || std::fabs(player[axis]) > kIgnoreBeyond) return false;
  const ULONGLONG now = GetTickCount64();
  const bool starting = !g_lastView;
  const float elapsed = std::min(now - g_lastView, 100ULL) / 1000.0f;
  float wanted[3] = {player[0], player[1], player[2] + kTournamentAimHeight};
  float distance = kTournamentDistance;
  if (g_target >= 0 && g_target < g_count) {
    const float* opponent = g_positions[g_target];
    const float dx = opponent[0] - player[0], dy = opponent[1] - player[1];
    const float separation = std::hypot(dx, dy);
    if (separation > 1.0f && separation < kIgnoreBeyond) {
      const float weight = std::min(0.25f, 300.0f / separation);
      wanted[0] += dx * weight;
      wanted[1] += dy * weight;
      distance += std::clamp((separation - 500.0f) * 0.22f, 0.0f, 350.0f);
    }
  }
  if (starting) {
    const float dx = nativeEye[0] - nativeAim[0], dy = nativeEye[1] - nativeAim[1];
    const float length = std::hypot(dx, dy);
    if (!(length > 1.0f) || !std::isfinite(length)) return false;
    g_back[0] = dx / length;
    g_back[1] = dy / length;
    std::memcpy(g_aim, wanted, sizeof(g_aim));
    g_distance = distance;
    Log("Camera: torneio ativa, seguindo o lutador %d, distancia %.1f", g_primary + 1, g_distance);
  } else {
    const float stick = g_yawStick.load(std::memory_order_relaxed);
    if (std::fabs(stick) > kTournamentDeadZone) {
      const float turn = -stick * kTournamentTurnPerSecond * elapsed;
      const float c = std::cos(turn), s = std::sin(turn);
      const float x = g_back[0] * c - g_back[1] * s, y = g_back[0] * s + g_back[1] * c;
      const float length = std::hypot(x, y);
      g_back[0] = x / length;
      g_back[1] = y / length;
    }
    const float follow = 1.0f - std::exp(-kTournamentFollow * elapsed);
    for (int axis = 0; axis < 3; ++axis) g_aim[axis] += (wanted[axis] - g_aim[axis]) * follow;
    g_distance += (distance - g_distance) * (1.0f - std::exp(-3.0f * elapsed));
  }
  std::memcpy(aim, g_aim, sizeof(g_aim));
  eye[0] = aim[0] + g_back[0] * g_distance;
  eye[1] = aim[1] + g_back[1] * g_distance;
  eye[2] = aim[2] + g_distance * kTournamentSlope;
  g_lastView = now;
  return true;
}

// Independent Revolution-like camera for six simultaneous fighters.
// Only active if explicitly chosen in F1; original games remain untouched.
// 3D target-follow camera with smooth 1.25 rad/s turns and recovery from
// native introductory / ultimate cinematics. No actual player state modified.
bool RevolutionView(const float* nativeEye,const float* nativeAim,
                    float eye[3],float aim[3]) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  if(!nativeEye || !nativeAim || g_count<1 ||
     g_primary<0 || g_primary>=g_count)return false;
  const ULONGLONG now=GetTickCount64();
  const bool starting=!g_lastView || now<g_lastView || now-g_lastView>1200;
  const float dt=starting?0.0f:std::min(now-g_lastView,100ULL)*0.001f;
  float nativeBack[2]={nativeEye[0]-nativeAim[0],
                        nativeEye[1]-nativeAim[1]};
  const float nativeLength=std::hypot(nativeBack[0],nativeBack[1]);
  if(!std::isfinite(nativeLength) || nativeLength<1.0f)return false;
  float fallback[2]={nativeBack[0]/nativeLength,nativeBack[1]/nativeLength};
  if(!starting){
    fallback[0]=g_back[0];
    fallback[1]=g_back[1];
  }
  const float* target=(g_target>=0 && g_target<g_count && g_target!=g_primary)
      ?g_positions[g_target]:nullptr;
  RevolutionCameraGoal goal;
  if(!RevolutionBuildCameraGoal(g_positions[g_primary],target,fallback,&goal))
    return false;
  if(g_entranceExpires > now && g_entranceExpires-now <= 900ULL) {
    const float weight=EntranceCameraBlend(float(g_entranceExpires-now));
    for(int i=0;i<3;++i)
      goal.focus[i]+=(g_entranceCenter[i]-goal.focus[i])*weight;
    goal.distance=std::max(goal.distance,2100.0f);
  }
  if(starting) {
    // The first image after an introduction/ultimate begins at the game's
    // current view, then eases into the target framing. No camera snap.
    g_back[0]=fallback[0];
    g_back[1]=fallback[1];
    for(int i=0;i<3;++i) {
      if(!std::isfinite(nativeAim[i]) || !std::isfinite(nativeEye[i]))
        return false;
      g_aim[i]=nativeAim[i];
    }
    g_distance=std::clamp(nativeLength,1000.0f,5400.0f);
    g_revolutionSlope=std::clamp((nativeEye[2]-nativeAim[2])/nativeLength,
                                 0.22f,0.58f);
    Log("Camera REVOLUTION: retoma vista nativa sem salto; %d lutadores.",g_count);
  } else {
    if(goal.trackingOpponent) {
      RevolutionTurnToward(g_back,goal.backward,dt,1.25f);
    }
    const float follow=RevolutionEase(dt,4.2f);
    for(int i=0;i<3;++i)g_aim[i]+=(goal.focus[i]-g_aim[i])*follow;
    const float zoomRate=goal.distance>g_distance?3.8f:1.7f;
    g_distance+=(goal.distance-g_distance)*RevolutionEase(dt,zoomRate);
    const float wantedSlope=std::clamp(0.33f+
         (goal.distance-1700.0f)/3700.0f*0.13f,0.33f,0.46f);
    g_revolutionSlope+=(wantedSlope-g_revolutionSlope)*RevolutionEase(dt,2.7f);
  }
  std::memcpy(aim,g_aim,sizeof(g_aim));
  eye[0]=aim[0]+g_back[0]*g_distance;
  eye[1]=aim[1]+g_back[1]*g_distance;
  eye[2]=aim[2]+g_revolutionSlope*g_distance;
  g_lastView=now;
  return true;
}
bool GroupView(const float* nativeEye, const float* nativeAim, float fov, float eye[3], float aim[3],
               bool connections = false) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  if (g_count < 2) return false;
  for (int i = 0; i < g_count; ++i)
    for (int axis = 0; axis < 3; ++axis)
      if (!std::isfinite(g_positions[i][axis]) || std::fabs(g_positions[i][axis]) > kIgnoreBeyond) return false;

  float center[3];
  const ULONGLONG now = GetTickCount64();
  const bool starting = !g_lastView;
  const float elapsed = std::min(now - g_lastView, 100ULL) / 1000.0f;
  if (starting) {
    const float dx = nativeEye[0] - nativeAim[0], dy = nativeEye[1] - nativeAim[1];
    const float length = std::hypot(dx, dy);
    if (!(length > 1.0f) || !std::isfinite(length)) return false;
    g_back[0] = dx / length;
    g_back[1] = dy / length;
    GroupCenter(center);
    std::memcpy(g_aim, center, sizeof(g_aim));
  } else {
    TurnTowardGroup(elapsed);
    GroupCenter(center);
    const float follow = 1.0f - std::exp(-(connections ? kConnectionsFollowRate : 8.0f) * elapsed);
    for (int axis = 0; axis < 3; ++axis) g_aim[axis] += (center[axis] - g_aim[axis]) * follow;
  }

  const float rise = std::clamp((g_distance - kLowPitchDistance) / (kHighPitchDistance - kLowPitchDistance), 0.0f, 1.0f);
  const float pitchSin = connections
      ? kConnectionsLowPitch + (kConnectionsHighPitch - kConnectionsLowPitch) * rise
      : kLowPitchSin + (kHighPitchSin - kLowPitchSin) * rise;
  const float pitchCos = std::sqrt(1.0f - pitchSin * pitchSin);
  const float halfHeight = std::tan(fov * 0.5f * kDegToRad) *
      (connections ? kConnectionsFitMargin : kFitMargin);
  float required = connections ? kConnectionsMinDistance : kMinDistance;
  for (int i = 0; i < g_count; ++i) {
    const float dx = g_positions[i][0] - g_aim[0];
    const float dy = g_positions[i][1] - g_aim[1];
    const float along = dx * g_back[0] + dy * g_back[1];
    const float across = std::fabs(dx * g_back[1] - dy * g_back[0]);
    // Calcula a distancia que enquadra o pe e a cabeca na perspectiva inclinada.
    for (float height : {0.0f, 2.0f * kFighterCenterHeight}) {
      const float dz = g_positions[i][2] + height - g_aim[2];
      const float towardEye = along * pitchCos + dz * pitchSin;
      const float up = std::fabs(dz * pitchCos - along * pitchSin);
      const float widthFit = (across + kFighterPadding) / (halfHeight * kAspect);
      const float heightFit = (up + kFighterPadding) / halfHeight;
      required = std::max(required, towardEye + std::max(widthFit, heightFit));
    }
  }
  required = std::min(required, kMaxGroupDistance);
  // Abre logo para manter todos visiveis; fecha devagar.
  if (starting || required >= g_distance) g_distance = required;
  else g_distance += (required - g_distance) *
      (1.0f - std::exp(-(connections ? kConnectionsReturnRate : 1.5f) * elapsed));

  std::memcpy(aim, g_aim, sizeof(g_aim));
  eye[0] = aim[0] + g_back[0] * g_distance * pitchCos;
  eye[1] = aim[1] + g_back[1] * g_distance * pitchCos;
  eye[2] = aim[2] + g_distance * pitchSin;
  g_lastView = now;
  if (starting)
    Log("Camera: %s ativa (%d lutadores), distancia %.1f",
        connections ? "Connections" : "grupo", g_count, g_distance);
  return true;
}

bool KeepCameraInsideStage(float eye[3], const float aim[3]) {
  if (!g_sweep) return false;
  const auto stage = *reinterpret_cast<uintptr_t*>(g_base + Addr().cameraStage);
  if (!stage) return true;
  void* collection = *reinterpret_cast<void**>(stage + 0x8);
  if (!collection) return true;

  // A camera nativa varre uma esfera de raio 25 com a mascara 4.
  const CameraSweep path{{aim[0], aim[1], aim[2]}, 25.0f,
                         {eye[0] - aim[0], eye[1] - aim[1], eye[2] - aim[2]}};
  alignas(16) uint8_t results[0x108];
  g_sweepInit(results);
  const float hit = g_sweep(results, &path, collection, 4);
  if (!std::isfinite(hit) || hit < -1.0f || hit > 1.0f) return false;

  const float distance = std::hypot(path.displacement[0], path.displacement[1], path.displacement[2]);
  if (distance < 1.0f) return false;
  const float clear = hit < 0.0f ? 1.0f : std::max(0.0f, hit - 15.0f / distance);
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  const ULONGLONG now = GetTickCount64();
  const float elapsed = std::min(now - g_sweepTick, 100ULL) / 1000.0f;
  if (!g_sweepTick || clear <= g_clearFraction) g_clearFraction = clear;
  else g_clearFraction += (clear - g_clearFraction) * (1.0f - std::exp(-5.0f * elapsed));
  g_sweepTick = now;
  if (hit >= 0.0f && !g_sweepReported) {
    Log("Camera: barreira do cenario detectada (%.2f)", hit);
    g_sweepReported = true;
  }
  // Se a mira estiver colada na geometria, deixa o jogo manter sua vista de duelo.
  if (distance * g_clearFraction < 120.0f) return false;
  for (int i = 0; i < 3; ++i) eye[i] = aim[i] + path.displacement[i] * g_clearFraction;
  return true;
}

// ---------------------------------------------------------------- camera da disputa de jutsus
bool g_clashCam = false;          // protegido por g_cameraMutex
std::atomic<int> g_clashStage{0};  // abertura do Storm 1 (close de a / de b)
int g_clashLastStage = -1;
float g_clashBlockers[4][3]{};  // outros lutadores (3v3): a vista de lado escolhe o lado sem ninguem na frente
int g_clashBlockerCount = 0;
float g_clashSide = 0.0f;       // lado escolhido no inicio da disputa (+1/-1); 0 = ainda nao escolhido

// Distancia (no chao) de p ate o segmento a-b.
float SegmentDistance2D(const float p[3], const float a[3], const float b[3]) {
  const float vx = b[0] - a[0], vy = b[1] - a[1], wx = p[0] - a[0], wy = p[1] - a[1];
  const float vv = vx * vx + vy * vy;
  const float t = vv > 1.0f ? std::clamp((wx * vx + wy * vy) / vv, 0.0f, 1.0f) : 0.0f;
  return std::hypot(wx - vx * t, wy - vy * t);
}
float g_clashA[3]{}, g_clashB[3]{};
float g_clashEye[3]{}, g_clashAim[3]{};
ULONGLONG g_clashLast = 0;

bool ClashView(const float* nativeEye, const float* nativeAim, float eye[3], float aim[3]) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  if (!g_clashCam) {
    g_clashLast = 0;
    g_clashLastStage = -1;
    g_clashSide = 0.0f;
    return false;
  }
  for (int i = 0; i < 3; ++i)
    if (!std::isfinite(g_clashA[i]) || !std::isfinite(g_clashB[i])) return false;
  const float mid[3] = {(g_clashA[0] + g_clashB[0]) * 0.5f, (g_clashA[1] + g_clashB[1]) * 0.5f,
                        (g_clashA[2] + g_clashB[2]) * 0.5f + kFighterCenterHeight};
  float dx = g_clashB[0] - g_clashA[0], dy = g_clashB[1] - g_clashA[1];
  float len = std::hypot(dx, dy);
  if (!(len > 1.0f)) {
    dx = 1.0f;
    dy = 0.0f;
    len = 1.0f;
  }
  // Lado da camera: perpendicular a linha entre os dois. Escolhido uma vez no inicio da disputa: o lado onde a camera
  // ja estava, a menos que um terceiro lutador (3v3) esteja entre a camera e o choque e o outro lado esteja livre.
  float px = -dy / len, py = dx / len;
  if (g_clashSide == 0.0f) {
    float side = (nativeEye[0] - mid[0]) * px + (nativeEye[1] - mid[1]) * py < 0 ? -1.0f : 1.0f;
    auto blocked = [&](float sgn) {
      const float d = std::clamp(len * 0.75f + 190.0f, 300.0f, 700.0f);
      const float eye[3] = {mid[0] + px * sgn * d, mid[1] + py * sgn * d, mid[2]};
      int count = 0;
      for (int i = 0; i < g_clashBlockerCount; ++i)
        if (SegmentDistance2D(g_clashBlockers[i], eye, mid) < 120.0f) ++count;
      return count;
    };
    if (blocked(side) > blocked(-side)) side = -side;
    g_clashSide = side;
  }
  px *= g_clashSide;
  py *= g_clashSide;
  // Como no Storm 1: de lado, bem perto e na altura das maos - os dois ocupam a tela e os jutsus se encontram no meio.
  const float distance = std::clamp(len * 0.75f + 190.0f, 300.0f, 700.0f);
  float wantEye[3] = {mid[0] + px * distance, mid[1] + py * distance, mid[2] + 30.0f};
  float wantAim[3] = {mid[0], mid[1], mid[2]};
  const int stage = g_clashStage.load(std::memory_order_relaxed);
  if (stage == 1 || stage == 2) {
    // Close de frente do lutador (como os cortes do Storm 1): a camera fica entre os dois, perto de quem aparece,
    // um pouco para o lado da vista de lado, olhando o rosto e a mao com o jutsu.
    const float* who = stage == 1 ? g_clashA : g_clashB;
    const float toward = stage == 1 ? 1.0f : -1.0f;  // direcao para o outro lutador
    const float ux = dx / len * toward, uy = dy / len * toward;
    // Tres quartos de frente: de lado e um pouco a frente (nao na linha do adversario, que pode estar a ~110).
    wantEye[0] = who[0] + ux * 70.0f + px * 150.0f;
    wantEye[1] = who[1] + uy * 70.0f + py * 150.0f;
    wantEye[2] = who[2] + 95.0f;
    wantAim[0] = who[0] + ux * 25.0f;
    wantAim[1] = who[1] + uy * 25.0f;
    wantAim[2] = who[2] + 80.0f;
  }
  const ULONGLONG now = GetTickCount64();
  if (stage != g_clashLastStage) {
    // Corte seco entre os closes e a vista de lado (sem varrer a arena).
    std::memcpy(g_clashEye, wantEye, sizeof(g_clashEye));
    std::memcpy(g_clashAim, wantAim, sizeof(g_clashAim));
    g_clashLastStage = stage;
    g_clashLast = now;
  }
  if (!g_clashLast) {
    std::memcpy(g_clashEye, nativeEye, sizeof(g_clashEye));
    std::memcpy(g_clashAim, nativeAim, sizeof(g_clashAim));
  }
  const float dt = g_clashLast ? std::min(now - g_clashLast, 100ULL) / 1000.0f : 0.0f;
  const float follow = 1.0f - std::exp(-6.0f * dt);
  for (int i = 0; i < 3; ++i) {
    g_clashEye[i] += (wantEye[i] - g_clashEye[i]) * follow;
    g_clashAim[i] += (wantAim[i] - g_clashAim[i]) * follow;
  }
  g_clashLast = now;
  std::memcpy(eye, g_clashEye, sizeof(g_clashEye));
  std::memcpy(aim, g_clashAim, sizeof(g_clashAim));
  // Tremor leve da camera enquanto os jutsus se empurram (nao acumula: so na vista entregue ao jogo).
  const float t = float(now % 100000) * 0.001f;
  const float shake[3] = {std::sin(t * 61.0f) * 3.0f, std::cos(t * 53.0f) * 3.0f, std::sin(t * 71.0f) * 2.5f};
  for (int i = 0; i < 3; ++i) {
    eye[i] += shake[i];
    aim[i] += shake[i] * 0.6f;
  }
  return true;
}

void SetClashInternal(bool active, const float a[3], const float b[3]) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  const bool was = g_clashCam;
  g_clashCam = active && a && b;
  if (g_clashCam) {
    std::memcpy(g_clashA, a, sizeof(g_clashA));
    std::memcpy(g_clashB, b, sizeof(g_clashB));
  }
  // Ao sair da disputa a camera normal reinicia a partir da vista atual (sem salto).
  if (was && !g_clashCam) g_lastView = 0;
}

void HookSetView(void* camera, const float* eye, const float* aim, const float* up) {
  const int mode = Cfg().camera.load(std::memory_order_relaxed);
  const bool duelView = reinterpret_cast<uintptr_t>(_ReturnAddress()) == g_base + kRvaDuelViewReturn;
  static std::atomic<int> previousMode{-1};
  const int oldMode = previousMode.exchange(mode, std::memory_order_relaxed);
  if (oldMode >= 0 && oldMode != mode) CameraBeginBattle();
  const float fov = duelView ? ReadFov(camera) : kDefaultFov;
  // During native introductions, team scenes and ultimates the game owns its
  // own cinematic camera. Reinitialize only the Revolution mode afterward.
  const bool revScene = mode == kCameraRevolution &&
      (!PromoteBattleActive() || UltSceneActive());
  // Edge-trigger scene resets; do not reinitialize on every camera call.
  static std::atomic<bool> wasRevScene{false};
  const bool previousScene=wasRevScene.exchange(revScene,std::memory_order_relaxed);
  if(revScene && !previousScene){
    std::lock_guard<std::mutex> lock(g_cameraMutex);
    g_lastView=0;
  }
  if (duelView && PromoteBattlePresent()) {
    float clashEye[3], clashAim[3];
    if (ClashView(eye, aim, clashEye, clashAim) && KeepCameraInsideStage(clashEye, clashAim)) {
      const float worldUp[] = {0, 0, 1};
      RememberView(clashEye, clashAim, worldUp, fov);
      g_original(camera, clashEye, clashAim, worldUp);
      return;
    }
  }
  // Camera de trailer (camera_trailer no ini, so para filmar); cenas e Supremos continuam com a camera do jogo.
  if (duelView && mode != kCameraDuel && TrailerCamEnabled() && PromoteBattleActive() && !UltSceneActive()) {
    float positions[kMaxFighters][3];
    int count, primary, target;
    {
      std::lock_guard<std::mutex> lock(g_cameraMutex);
      count = g_count;
      primary = g_primary;
      target = g_target;
      std::memcpy(positions, g_positions, sizeof(positions));
    }
    float trailerEye[3], trailerAim[3];
    if (TrailerCamView(positions, count, primary, target, trailerEye, trailerAim) &&
        KeepCameraInsideStage(trailerEye, trailerAim)) {
      const float worldUp[] = {0, 0, 1};
      RememberView(trailerEye, trailerAim, worldUp, fov);
      g_original(camera, trailerEye, trailerAim, worldUp);
      return;
    }
  }
  if (duelView && mode != kCameraDuel && PromoteBattlePresent() && !revScene) {
    float groupEye[3], groupAim[3];
    const bool built = mode == kCameraTournament ? TournamentView(eye, aim, groupEye, groupAim)
        : mode == kCameraRevolution ? RevolutionView(eye, aim, groupEye, groupAim)
        : GroupView(eye, aim, fov, groupEye, groupAim, mode == kCameraConnections);
    if (built && KeepCameraInsideStage(groupEye, groupAim)) {
      const float worldUp[] = {0, 0, 1};
      RememberView(groupEye, groupAim, worldUp, fov);
      g_original(camera, groupEye, groupAim, worldUp);
      return;
    }
  }
  if (duelView) {
    RememberView(eye, aim, up, fov);
  } else if (PromoteBattleActive()) {
    // Outra camera do jogo assumiu durante a luta: registra de onde veio, uma vez por ponto.
    static std::atomic<uintptr_t> seen[24];
    const uintptr_t from = reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base;
    for (auto& slot : seen) {
      uintptr_t value = slot.load(std::memory_order_relaxed);
      if (value == from) break;
      if (!value && slot.compare_exchange_strong(value, from)) {
        Log("Camera: outra vista na luta, chamada de exe+0x%llX", static_cast<unsigned long long>(from));
        break;
      }
    }
  }
  g_original(camera, eye, aim, up);
}

}  // namespace

bool CameraInstall() {
  TrailerCamLoad();
  void* target = reinterpret_cast<void*>(g_base + kRvaSetView);
  const uint8_t* callSite = reinterpret_cast<const uint8_t*>(g_base + kRvaDuelViewReturn - 5);
  static const uint8_t kExpected[] = {0x48, 0x8B, 0xC4, 0x48, 0x89, 0x58, 0x08, 0x48, 0x89, 0x70, 0x10};
  // A chamada da camera de duelo precisa apontar para FUN_SetView (o deslocamento muda por versao).
  int32_t rel;
  std::memcpy(&rel, callSite + 1, 4);
  bool callOk = callSite[0] == 0xE8 && g_base + kRvaDuelViewReturn + rel == g_base + kRvaSetView;
  if (std::memcmp(target, kExpected, sizeof(kExpected)) != 0 || !callOk) {
    Log("Camera: bytes da camera de duelo diferentes; enquadramento de grupo indisponivel.");
    return false;
  }
  const auto* sweep = reinterpret_cast<const uint8_t*>(g_base + Addr().cameraSweep);
  const auto* sweepInit = reinterpret_cast<const uint8_t*>(g_base + Addr().cameraSweepInit);
  const uint8_t expectedSweep[] = {0x48, 0x83, 0xEC, 0x38, 0x83, 0x64, 0x24, 0x2C, 0x00, 0x48, 0x8D, 0x05};
  const uint8_t expectedInit[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x74, 0x24, 0x10, 0x57};
  if (std::memcmp(sweep, expectedSweep, sizeof(expectedSweep)) == 0 &&
      std::memcmp(sweepInit, expectedInit, sizeof(expectedInit)) == 0) {
    g_sweepInit = reinterpret_cast<SweepInitFn>(sweepInit);
    g_sweep = reinterpret_cast<SweepFn>(sweep);
    Log("Camera: teste nativo de colisao disponivel.");
  } else {
    Log("Camera: bytes da colisao diferentes; usando a vista nativa.");
  }
  MH_STATUS status = MH_CreateHook(target, reinterpret_cast<void*>(&HookSetView),
                                   reinterpret_cast<void**>(&g_original));
  if (status == MH_OK) status = MH_EnableHook(target);
  Log("Camera: enquadramento de grupo %s", status == MH_OK ? "instalado" : MH_StatusToString(status));
  return status == MH_OK;
}

bool CameraStageSweep(const float from[3], const float delta[3], float radius, int mask, float* fraction, void* raw) {
  if (!g_sweep || !g_sweepInit || !fraction) return false;
  __try {
    const auto stage = *reinterpret_cast<uintptr_t*>(g_base + Addr().cameraStage);
    if (!stage) return false;
    void* collection = *reinterpret_cast<void**>(stage + 0x8);
    if (!collection) return false;
    const CameraSweep path{{from[0], from[1], from[2]}, radius, {delta[0], delta[1], delta[2]}};
    alignas(16) uint8_t results[0x108];
    g_sweepInit(results);
    const float hit = g_sweep(results, &path, collection, mask);
    if (!std::isfinite(hit)) return false;
    *fraction = hit;
    if (raw) std::memcpy(raw, results, sizeof(results));
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

bool CameraViewDirection(float forward[3]) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  if (!g_viewTick || GetTickCount64() - g_viewTick > kViewFreshMs) return false;
  for (int i = 0; i < 3; ++i) forward[i] = g_viewAim[i] - g_viewEye[i];
  return std::isfinite(forward[0]) && std::isfinite(forward[1]) && std::isfinite(forward[2]);
}

void CameraSetYawInput(float stick) { g_yawStick.store(stick, std::memory_order_relaxed); }

bool CameraProject(const float world[3], float aspect, float* screenX, float* screenY, bool* behind) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  if (!g_viewTick || GetTickCount64() - g_viewTick > kViewFreshMs ||
      !std::isfinite(aspect) || aspect <= 0.0f) return false;
  float f[3], r[3], u[3], d[3];
  for (int i = 0; i < 3; ++i) {
    f[i] = g_viewAim[i] - g_viewEye[i];
    d[i] = world[i] - g_viewEye[i];
  }
  const auto normalize = [](float v[3]) {
    const float length = std::sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (!(length > 0.0001f)) return false;
    for (int i = 0; i < 3; ++i) v[i] /= length;
    return true;
  };
  if (!normalize(f)) return false;
  r[0] = f[1] * g_viewUp[2] - f[2] * g_viewUp[1];
  r[1] = f[2] * g_viewUp[0] - f[0] * g_viewUp[2];
  r[2] = f[0] * g_viewUp[1] - f[1] * g_viewUp[0];
  if (!normalize(r)) return false;
  u[0] = r[1] * f[2] - r[2] * f[1];
  u[1] = r[2] * f[0] - r[0] * f[2];
  u[2] = r[0] * f[1] - r[1] * f[0];
  const float depth = d[0] * f[0] + d[1] * f[1] + d[2] * f[2];
  if (!std::isfinite(depth) || (depth < 1.0f && !behind)) return false;
  if (behind) *behind = depth < 1.0f;
  const float projectionDepth = std::max(1.0f, std::fabs(depth));
  const float halfHeight = std::tan(g_viewFov * 0.5f * kDegToRad);
  *screenX = (d[0] * r[0] + d[1] * r[1] + d[2] * r[2]) / (projectionDepth * halfHeight * aspect);
  *screenY = (d[0] * u[0] + d[1] * u[1] + d[2] * u[2]) / (projectionDepth * halfHeight);
  if (depth < 1.0f && std::fabs(*screenX) + std::fabs(*screenY) < 0.01f) *screenY = -1.0f;
  return std::isfinite(*screenX) && std::isfinite(*screenY);
}

void CameraBeginBattle() {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  g_viewTick = 0;
  g_count = 0;
  g_lastView = 0;
  g_distance = 0;
  g_revolutionSlope = 0.36f;
  g_entranceExpires = 0;
  g_clearFraction = 1.0f;
  g_sweepTick = 0;
  g_sweepReported = false;
  TrailerCamReset();
}

void CameraObserveEntrance(const float positions[][3],int count) {
  if(!positions || count<1 || count>2 ||
     Cfg().camera.load(std::memory_order_relaxed)!=kCameraRevolution)return;
  float center[3]{};
  for(int k=0;k<count;++k)
    for(int a=0;a<3;++a) {
      if(!std::isfinite(positions[k][a]) ||
         std::fabs(positions[k][a])>20000.0f)return;
      center[a]+=positions[k][a]/count;
    }
  center[2]+=85.0f;
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  std::memcpy(g_entranceCenter,center,sizeof(center));
  g_entranceExpires=GetTickCount64()+900;
}
void CameraSetClashBlockers(const float positions[][3], int count) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  g_clashBlockerCount = positions ? std::clamp(count, 0, 4) : 0;
  for (int i = 0; i < g_clashBlockerCount; ++i) std::memcpy(g_clashBlockers[i], positions[i], sizeof(g_clashBlockers[i]));
}
void CameraSetClash(bool active, const float a[3], const float b[3], int stage) {
  SetClashInternal(active, a, b);
  g_clashStage.store(active ? stage : 0, std::memory_order_relaxed);
}
void CameraSetFighters(const float positions[][3], int count, int primary, int target) {
  std::lock_guard<std::mutex> lock(g_cameraMutex);
  if (!positions || count < 1 || count > kMaxFighters || primary < 0 || primary >= count) {
    g_count = 0;
    return;
  }
  g_count = count;
  g_primary = primary;
  g_target = target >= 0 && target < count ? target : -1;
  std::memcpy(g_positions, positions, count * sizeof(g_positions[0]));
}
