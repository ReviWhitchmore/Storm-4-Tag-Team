#include "cpu_adapt.h"
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <windows.h>
#include "census.h"
#include "log.h"
namespace {
std::atomic<bool> g_enabled{false};
std::atomic<int> g_level{1};
std::atomic<unsigned> g_parryCpu{25};
std::atomic<bool> g_teamUltCpu{false};
int CharacterId(uintptr_t player) {
  __try {
    const int id=player?*reinterpret_cast<const int*>(player+0xC8C):-1;
    return id>=0&&id<=1024?id:-1;
  } __except(EXCEPTION_EXECUTE_HANDLER) {return -1;}
}
} // namespace
void CpuAdaptInstall() {
  bool on=false;bool team=false;int level=1;unsigned parry=25;
  const std::wstring ini=ModDir()+L"storm6.ini";
  if(FILE* file=_wfopen(ini.c_str(),L"r")){
    char line[128];
    while(std::fgets(line,sizeof(line),file)){
      char key[65]{};int value=0;
      if(std::sscanf(line,"%64[^=]=%d",key,&value)!=2)continue;
      if(!std::strcmp(key,"ia_adaptativa"))on=value!=0;
      else if(!std::strcmp(key,"ia_supremo_equipe_cpu"))team=value!=0;
      else if(!std::strcmp(key,"ia_nivel")&&value>=0&&value<=3)level=value;
      else if(!std::strcmp(key,"ia_parry_cpu")&&value>=0&&value<=100)parry=unsigned(value);
    }
    std::fclose(file);
  }
  g_enabled=on;g_level=level;g_parryCpu=parry;g_teamUltCpu=team;
  Log("IA ADAPTATIVA: %s, nivel %d, parry CPU base %u%%; nativa preservada.",
      on?"ATIVADA":"desligada (ini ia_adaptativa=1)",level,parry);
}
bool CpuAdaptEnabled(){return g_enabled.load(std::memory_order_relaxed);}
unsigned CpuAdaptChance(unsigned base,uintptr_t player,cpuai::Action action,bool danger) {
  if(!CpuAdaptEnabled())return base;
  return cpuai::Chance(base,CharacterId(player),action,g_level.load(std::memory_order_relaxed),danger);
}
float CpuAdaptMashRate(float base,uintptr_t player){
  if(!CpuAdaptEnabled())return base;
  return cpuai::MashRate(base,CharacterId(player),g_level.load(std::memory_order_relaxed));
}
unsigned CpuAdaptParryBaseChance(){return CpuAdaptEnabled()?g_parryCpu.load(std::memory_order_relaxed):0u;}
bool CpuAdaptTeamUltimateEnabled(){return CpuAdaptEnabled()&&g_teamUltCpu.load(std::memory_order_relaxed);}
bool CpuAdaptEnemy(int fighterA,int sideA,int fighterB,int sideB,bool ffa){
  return cpuai::Enemy(fighterA,sideA,fighterB,sideB,ffa);
}
