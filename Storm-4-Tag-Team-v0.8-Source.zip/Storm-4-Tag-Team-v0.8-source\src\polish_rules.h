#pragma once
// Pure rules used by both the game bridge and offline regression tests.
// No engine pointers, XInput calls or mutable global state in these helpers.
inline int PolishChooseCameraActor(int count, const int forPad[4],
                                   const int side[6], const bool alive[6]) {
  if (!forPad || !side || !alive || count < 1 || count > 6) return -1;
  const int p1 = forPad[0];
  if (p1 >= 0 && p1 < count && alive[p1]) return p1;
  if (p1 >= 0 && p1 < count)
    for (int i = 0; i < count; ++i)
      if (side[i] == side[p1] && alive[i]) return i;
  for (int pad = 1; pad < 4; ++pad) {
    const int candidate = forPad[pad];
    if (candidate >= 0 && candidate < count && alive[candidate])
      return candidate;
  }
  for (int i = 0; i < count; ++i)
    if (alive[i]) return i;
  return -1;
}
struct PolishCameraRoster {
  float positions[6][3]{};
  int original[6]{};
  int count = 0;
  int primary = -1;
  int target = -1;
};

inline PolishCameraRoster PolishBuildCameraRoster(const float positions[6][3],
                                                const bool alive[6], int count,
                                                int preferred, int selectedTarget) {
  PolishCameraRoster result{};
  if (!positions || !alive || count < 1 || count > 6) return result;
  for (int i = 0; i < count; ++i) {
    if (!alive[i]) continue;
    const int index = result.count++;
    result.original[index] = i;
    for (int axis = 0; axis < 3; ++axis)
      result.positions[index][axis] = positions[i][axis];
    if (i == preferred) result.primary = index;
    if (i == selectedTarget) result.target = index;
  }
  // If P1 lost, the camera can still follow another living actor (CPU or P2).
  if (result.count && result.primary < 0) result.primary = 0;
  if (result.target == result.primary) result.target = -1;
  return result;
}

inline bool PolishShowLock(int fighter, int target, int count,
                          bool controllerConnected, const bool alive[6]) {
  return alive && controllerConnected && fighter >= 0 && fighter < count &&
         target >= 0 && target < count && target != fighter &&
         count <= 6 && alive[fighter] && alive[target];
}
