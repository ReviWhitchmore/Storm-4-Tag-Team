#pragma once
#include <cstdint>
#include <windows.h>
#include <Xinput.h>
#include "grab_defense.h"  // GrabFighterView: visao por quadro dos lutadores

// Jutsu Clash (Evolution). storm6.ini: jutsu_clash=1, jutsu_clash_dano=12 (% da vida maxima),
// jutsu_clash_cpu=7 (apertos por segundo da CPU), jutsu_clash_teste_investida=0 (1 = choque de investidas de
// chakra tambem abre a disputa, so para testar). Dois jutsus que se chocam (os dois lutadores saem de
// PL_ACT_SKILL_* direto para o empurrao mutuo PL_ACT_OFFSET_KNOCKBACK) abrem uma disputa de 7 s apertando B.
// Os dois ficam travados (pausa nativa do ator); o resto da arena continua lutando.
struct ClashHud {
  int numberA = 0, numberB = 0;  // J1..J6
  unsigned scoreA = 0, scoreB = 0;
  unsigned remainingMs = 0;
  int result = -1;  // -1 em andamento, 0 empate, 1 A venceu, 2 B venceu
  unsigned elapsedMs = 0;     // desde o inicio da disputa (abertura em tela dividida nos primeiros ~0,9 s)
  unsigned resultAgeMs = 0;   // desde o resultado (clarao e explosao)
  bool hasPos = false;        // posicoes no mundo dos dois (para desenhar a energia entre eles)
  int style = 2;              // 0 = Connections (Claude), 1 = V2 (Codex), 2 = Storm 1 (jutsu_clash_estilo)
  int padA = -1, padB = -1;   // controle de cada lado (-1 = CPU): 1P / 2P / COM na barra do Storm 1
  bool cameraIntro = false;   // abertura do Storm 1 com closes de camera (0,9 s antes da vista de lado)
  bool visualV2 = true;       // inicio / energia em loop / avanco do vencedor / explosao
  bool worldContactPreview = false; // TESTE: ancora das energias em coordenadas 3D
  float posA[3]{}, posB[3]{};
};

void JutsuClashInstall();
void JutsuClashObservePad(DWORD pad, const XINPUT_STATE* state, bool connected);
void JutsuClashBeginBattle();
void JutsuClashTick(const GrabFighterView* fighters, int count, bool sceneActive, uint64_t now);
bool JutsuClashHud(ClashHud* out);
// O lutador esta numa disputa ativa e protegida (golpes de terceiros sao descartados). jutsu_clash_protegido=1.
bool JutsuClashProtects(uintptr_t player);
// Gancho da troca de estado nativa (thread do jogo): true = nao aplicar a troca (os dois ficam na pose do jutsu).
bool JutsuClashInterceptOffset(uintptr_t player, int action, uintptr_t returnRva, void (*original)(uintptr_t, int));
// Indices dos dois da disputa (ativa ou resolvendo), para a camera fechar neles.
bool JutsuClashCameraPair(int* a, int* b);
// Abertura do Storm 1: 1 = close do lutador A, 2 = close do B, 0 = vista de lado da disputa.
int JutsuClashCameraStage();
