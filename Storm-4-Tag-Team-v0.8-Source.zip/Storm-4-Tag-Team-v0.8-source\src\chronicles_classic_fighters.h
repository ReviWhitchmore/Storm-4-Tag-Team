#pragma once
// Typed character assignments for all Naruto Classic Chronicles encounters.
// IMPORTANT: these are STORY ROSTER KEYS, not engine character IDs.
// Never pass these enums, indexes, or portrait labels to Storm 4 native APIs.
#include "chronicles_classic.h"
#include <array>
#include <cstdint>

namespace chronicles_classic {
enum class Fighter : uint8_t {
  Empty=0, Naruto, Sasuke, Sakura, Kakashi, Zabuza, Haku, RockLee,
  Orochimaru, Ino, Kiba, Hinata, Neji, Gaara, Shikamaru, Temari,
  Shino, Kankuro, Hiruzen, Itachi, Kisame, Kabuto, Tsunade, Jiraiya,
  Choji, Jirobo, Kidomaru, SakonUkon, Tayuya, Kimimaro, Count
};
enum class FighterStyle : uint8_t { Classic, Default, SoundFourDlc };
struct FighterInfo {
  const char* display;
  const char* portraitHint; // HUD hints from the mod, NOT engine identifiers
  FighterStyle preferredStyle;
};
constexpr std::array<FighterInfo,static_cast<int>(Fighter::Count)> kFighterInfo{{
  {"---","",FighterStyle::Default},
  {"NARUTO","nrt",FighterStyle::Classic},
  {"SASUKE","ssk",FighterStyle::Classic},
  {"SAKURA","skr",FighterStyle::Classic},
  {"KAKASHI","kks",FighterStyle::Default},
  {"ZABUZA","",FighterStyle::Default},
  {"HAKU","",FighterStyle::Default},
  {"ROCK LEE","roc",FighterStyle::Classic},
  {"OROCHIMARU","orc",FighterStyle::Default},
  {"INO","ino",FighterStyle::Classic},
  {"KIBA","kib",FighterStyle::Classic},
  {"HINATA","hnt",FighterStyle::Classic},
  {"NEJI","nej",FighterStyle::Classic},
  {"GAARA","gar",FighterStyle::Classic},
  {"SHIKAMARU","sik",FighterStyle::Classic},
  {"TEMARI","tmr",FighterStyle::Classic},
  {"SHINO","sin",FighterStyle::Classic},
  {"KANKURO","knk",FighterStyle::Classic},
  {"HIRUZEN","",FighterStyle::Default},
  {"ITACHI","itc",FighterStyle::Default},
  {"KISAME","",FighterStyle::Default},
  {"KABUTO","kbt",FighterStyle::Default},
  {"TSUNADE","tsk",FighterStyle::Default},
  {"JIRAIYA","jry",FighterStyle::Default},
  {"CHOJI","tyo",FighterStyle::Classic},
  {"JIROBO","",FighterStyle::SoundFourDlc},
  {"KIDOMARU","",FighterStyle::SoundFourDlc},
  {"SAKON / UKON","",FighterStyle::SoundFourDlc},
  {"TAYUYA","",FighterStyle::SoundFourDlc},
  {"KIMIMARO","",FighterStyle::Default}
}};
constexpr bool ValidFighter(Fighter f) {
  return f>Fighter::Empty && f<Fighter::Count;
}
constexpr const FighterInfo* Info(Fighter f) {
  return ValidFighter(f)?&kFighterInfo[static_cast<int>(f)]:nullptr;
}
struct BattleTeam {
  std::array<Fighter,3> members;
  uint8_t count;
};
struct BattleRoster {
  BattleTeam allies; // side 0; player 1 unless controlled by CPU
  BattleTeam enemies; // side 1; CPU opponent
};
constexpr Fighter X=Fighter::Empty;
constexpr BattleTeam Team(Fighter a,Fighter b=X,Fighter c=X) {
  return {{a,b,c},static_cast<uint8_t>(1+int(b!=X)+int(c!=X))};
}
using F=Fighter;
constexpr std::array<BattleRoster,40> kBattleRosters{{
  // A01 - Formation
  {Team(F::Naruto,F::Sasuke,F::Sakura),Team(F::Kakashi)},        // C01
  // A02 - Land of Waves
  {Team(F::Kakashi),Team(F::Zabuza)},                           // C02
  {Team(F::Naruto,F::Sasuke),Team(F::Zabuza)},                  // C03
  {Team(F::Naruto,F::Sasuke),Team(F::Haku)},                    // C04
  {Team(F::Kakashi),Team(F::Zabuza)},                           // C05
  {Team(F::Naruto,F::Sasuke,F::Kakashi),Team(F::Zabuza,F::Haku)}, // C06
  // A03 - Chunin exams
  {Team(F::Sasuke),Team(F::RockLee)},                          // C07
  {Team(F::Naruto,F::Sasuke,F::Sakura),Team(F::Orochimaru)},     // C08
  {Team(F::Sasuke),Team(F::Orochimaru)},                        // C09
  {Team(F::Sakura),Team(F::Ino)},                              // C10
  {Team(F::Naruto),Team(F::Kiba)},                             // C11
  {Team(F::Hinata),Team(F::Neji)},                             // C12
  {Team(F::RockLee),Team(F::Gaara)},                           // C13
  {Team(F::Shikamaru),Team(F::Temari)},                        // C14
  {Team(F::Naruto),Team(F::Neji)},                             // C15
  {Team(F::Sasuke),Team(F::Gaara)},                            // C16
  {Team(F::Shino),Team(F::Kankuro)},                           // C17
  {Team(F::Naruto),Team(F::Gaara)},                            // C18
  // A04 - Konoha invasion
  {Team(F::Hiruzen),Team(F::Orochimaru)},                      // C19
  // A05 - Search for Tsunade
  {Team(F::Sasuke),Team(F::Itachi)},                           // C20
  {Team(F::Jiraiya),Team(F::Itachi,F::Kisame)},                 // C21
  {Team(F::Naruto),Team(F::Kabuto)},                           // C22
  {Team(F::Tsunade),Team(F::Kabuto)},                          // C23
  {Team(F::Jiraiya,F::Tsunade),Team(F::Orochimaru,F::Kabuto)},  // C24
  {Team(F::Jiraiya),Team(F::Orochimaru)},                      // C25
  {Team(F::Naruto),Team(F::Sasuke)},                           // C26
  // A06 - Sasuke retrieval
  {Team(F::Choji),Team(F::Jirobo)},                            // C27
  {Team(F::Neji),Team(F::Kidomaru)},                           // C28
  {Team(F::Kiba),Team(F::SakonUkon)},                          // C29
  {Team(F::Shikamaru),Team(F::Tayuya)},                        // C30
  {Team(F::Kankuro),Team(F::SakonUkon)},                       // C31
  {Team(F::Temari),Team(F::Tayuya)},                           // C32
  {Team(F::RockLee),Team(F::Kimimaro)},                        // C33
  {Team(F::Gaara),Team(F::Kimimaro)},                          // C34
  {Team(F::RockLee,F::Gaara),Team(F::Kimimaro)},                // C35
  {Team(F::Naruto),Team(F::Kimimaro)},                         // C36
  {Team(F::Naruto),Team(F::Sasuke)},                           // C37
  {Team(F::Naruto,F::Shikamaru,F::Choji),
   Team(F::Jirobo,F::Tayuya,F::Kidomaru)},                    // C38
  {Team(F::Neji,F::Kiba,F::Shikamaru),
   Team(F::Kidomaru,F::SakonUkon,F::Tayuya)},                 // C39
  {Team(F::Naruto,F::RockLee,F::Gaara),
   Team(F::Sasuke,F::Kimimaro,F::SakonUkon)}                  // C40
}};
constexpr const BattleRoster* Roster(int mission){
  return ValidMission(mission)?&kBattleRosters[mission]:nullptr;
}
constexpr bool TeamValid(const BattleTeam& team){
  if(team.count<1 || team.count>3)return false;
  for(int slot=0;slot<3;++slot){
    const bool occupied=slot<team.count;
    if(occupied!=ValidFighter(team.members[slot]))return false;
  }
  return true;
}
constexpr bool ValidRoster(int mission) {
  const auto* roster=Roster(mission);
  return roster && TeamValid(roster->allies) && TeamValid(roster->enemies) &&
     roster->allies.count==kMissions[mission].teamSize &&
     roster->enemies.count==kMissions[mission].enemySize;
}
constexpr bool TeamNeedsSoundFour(const BattleTeam& team){
  for(int i=0;i<team.count;++i) {
    const auto* info=Info(team.members[i]);
    if(info && info->preferredStyle==FighterStyle::SoundFourDlc)return true;
  }
  return false;
}
constexpr bool RosterNeedsSoundFour(int mission){
  const auto* roster=Roster(mission);
  return roster && (TeamNeedsSoundFour(roster->allies) ||
                    TeamNeedsSoundFour(roster->enemies));
}
} // namespace chronicles_classic
