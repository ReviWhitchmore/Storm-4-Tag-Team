#pragma once
// Original geometry and easing for a Revolution-like 6-fighter camera.
// No native Storm Revolution binary, assets or code are embedded.
#include <algorithm>
#include <cmath>
struct RevolutionCameraGoal {
  float focus[3]{};
  float backward[2]{};
  float distance = 1700.0f;
  bool trackingOpponent = false;
};
inline float RevolutionEase(float seconds, float rate) {
  if (!std::isfinite(seconds) || !std::isfinite(rate) ||
      seconds <= 0.0f || rate <= 0.0f) return 0.0f;
  return 1.0f - std::exp(-rate * std::min(seconds, 0.1f));
}
inline bool RevolutionTurnToward(float backward[2],const float desired[2],
                                  float dt,float radiansPerSecond) {
  if(!backward || !desired || !std::isfinite(dt) || dt < 0.0f ||
     !std::isfinite(radiansPerSecond) || radiansPerSecond < 0.0f)
    return false;
  const float currentNorm=std::hypot(backward[0],backward[1]);
  const float goalNorm=std::hypot(desired[0],desired[1]);
  if(!(currentNorm>0.0001f) || !(goalNorm>0.0001f) ||
     !std::isfinite(currentNorm) || !std::isfinite(goalNorm))return false;
  const float x=backward[0]/currentNorm,y=backward[1]/currentNorm;
  const float gx=desired[0]/goalNorm,gy=desired[1]/goalNorm;
  const float radians=std::atan2(x*gy-y*gx,x*gx+y*gy);
  const float step=std::clamp(radians,-radiansPerSecond*dt,radiansPerSecond*dt);
  backward[0]=x*std::cos(step)-y*std::sin(step);
  backward[1]=x*std::sin(step)+y*std::cos(step);
  return true;
}
inline bool RevolutionBuildCameraGoal(const float player[3],const float* opponent,
                                     const float fallbackBack[2],RevolutionCameraGoal* out) {
  if(!player || !fallbackBack || !out)return false;
  for(int axis=0;axis<3;++axis)
    if(!std::isfinite(player[axis]) || std::fabs(player[axis])>20000.0f)return false;
  const float fallbackLen=std::hypot(fallbackBack[0],fallbackBack[1]);
  if(!std::isfinite(fallbackLen) || fallbackLen<0.0001f)return false;
  out->focus[0]=player[0];out->focus[1]=player[1];out->focus[2]=player[2]+83.0f;
  out->backward[0]=fallbackBack[0]/fallbackLen;
  out->backward[1]=fallbackBack[1]/fallbackLen;
  out->distance=1700.0f;
  out->trackingOpponent=false;
  if(!opponent)return true;
  for(int axis=0;axis<3;++axis)
    if(!std::isfinite(opponent[axis]) || std::fabs(opponent[axis])>20000.0f)
      return true;
  const float dx=opponent[0]-player[0],dy=opponent[1]-player[1];
  const float separation=std::hypot(dx,dy);
  if(separation<=100.0f || separation>=14000.0f)return true;
  // Midpoint bias is limited: a distant target must not pull the camera away
  // from the locally controlled fighter. Target remains selected in 3D.
  const float bias=std::min(separation*0.42f,880.0f)/separation;
  out->focus[0]+=dx*bias;
  out->focus[1]+=dy*bias;
  out->focus[2]+=(opponent[2]-player[2])*bias;
  out->backward[0]=-dx/separation;
  out->backward[1]=-dy/separation;
  out->distance=std::clamp(1650.0f+separation*0.67f,1700.0f,5400.0f);
  out->trackingOpponent=true;
  return true;
}
