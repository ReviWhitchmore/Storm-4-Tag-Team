#pragma once
// Carrega o winmm.dll real (System32) e preenche a tabela de saltos.
bool ProxyInit();
