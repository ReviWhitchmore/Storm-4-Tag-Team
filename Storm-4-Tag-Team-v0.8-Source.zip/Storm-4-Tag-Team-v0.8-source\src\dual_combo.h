#pragma once
#include <cstdint>

#include "grab_defense.h"  // GrabFighterView: visao por quadro dos lutadores

// Combo em Dupla (Evolution). storm6.ini: combo_dupla=1 liga; combo_dupla_teste=1 modo de investigacao (forca o
// cenario de teste e registra estados/animacoes/posicoes). Um aliado entra no combo do companheiro usando as acoes
// nativas de apoio do Storm 4 (PL_ACT_SUP_COMBO_JOIN 0xE1 e afins), sem teleporte para o adversario.
void DualComboInstall();
void DualComboBeginBattle();
void DualComboTick(const GrabFighterView* fighters, int count, bool sceneActive, uint64_t now);
