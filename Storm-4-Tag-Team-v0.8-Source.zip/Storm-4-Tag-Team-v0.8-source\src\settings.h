#pragma once
#include <atomic>

// Opcoes do mod, salvas em storm6.ini na pasta do jogo.
// Quem controla cada lutador (J1-J3 equipe 1, J4-J6 equipe 2).
enum SlotControl {
  kSlotAuto = 0,
  kSlotPlayer = 1,  // valor legado do INI
  kSlotCpu = 2,
  kSlotPlayer1 = 3,
  kSlotPlayer2 = 4,
  kSlotPlayer3 = 5,
  kSlotPlayer4 = 6,
};
constexpr int SlotPadIndex(int control) {
  return control >= kSlotPlayer1 && control <= kSlotPlayer4 ? control - kSlotPlayer1 : -1;
}
enum CameraMode {
  kCameraDuel = 0,       // native duel
  kCameraGroup = 1,      // automatically fit all fighters
  kCameraTournament = 2, // follows the player with right-stick rotation
  kCameraConnections = 3, // elevated dynamic arena camera based on reference video
  kCameraRevolution = 4 // optional original 6-fighter target-follow camera
};

struct Settings {
  std::atomic<bool> freeForAll{false}; // reserved for experimental FFA collision/victory port
  std::atomic<bool> mode3v3{false};  // 3 contra 3 simultaneo (vale a partir da proxima luta)
  std::atomic<bool> hud{true};       // 6 paineis de vida/chakra/substituicao
  std::atomic<bool> lockon{true};    // analogico direito troca o alvo
  std::atomic<int> lockonStyle{1};  // 0 = seta acima, 1 = tronco, 2 = Revolution (cursor + fora da tela)
  std::atomic<int> camera{kCameraTournament};
  std::atomic<bool> ring{true};      // resgata extras abaixo do piso
  std::atomic<bool> cpuRealOpponent{false};  // 3v3: o "meu adversario" nativo da CPU e o alvo real dela
  std::atomic<bool> ultFree{true};   // ultimates sem cinematica e sem congelar a arena
  std::atomic<bool> awakenAtStart{false}; // one native awakening start per fighter at battle entry
  std::atomic<bool> teamUltimate{false}; // experimental native input sequence shortcut
  std::atomic<int> teamUltimateButton{0}; // 0 = L1/LB, 1 = R1/RB
  std::atomic<bool> selectP2{true};
  std::atomic<bool> jutsuClash{true};  // disputa quando dois jutsus se chocam (menu do mod; storm6.ini jutsu_clash)  // fora da luta, o controle 2 comanda o mesmo cursor do controle 1
  std::atomic<int> slot[6] = {};     // SlotControl de J1..J6
};

Settings& Cfg();
void SettingsLoad();
void SettingsSave();
