; Gerado por tools\gen_winmm_proxy.ps1
EXTERN g_proxyFn:QWORD
.code
P_0 PROC
    jmp qword ptr [g_proxyFn + 0]
P_0 ENDP
P_1 PROC
    jmp qword ptr [g_proxyFn + 8]
P_1 ENDP
P_2 PROC
    jmp qword ptr [g_proxyFn + 16]
P_2 ENDP
P_3 PROC
    jmp qword ptr [g_proxyFn + 24]
P_3 ENDP
P_4 PROC
    jmp qword ptr [g_proxyFn + 32]
P_4 ENDP
P_5 PROC
    jmp qword ptr [g_proxyFn + 40]
P_5 ENDP
P_6 PROC
    jmp qword ptr [g_proxyFn + 48]
P_6 ENDP
P_7 PROC
    jmp qword ptr [g_proxyFn + 56]
P_7 ENDP
P_8 PROC
    jmp qword ptr [g_proxyFn + 64]
P_8 ENDP
P_9 PROC
    jmp qword ptr [g_proxyFn + 72]
P_9 ENDP
P_10 PROC
    jmp qword ptr [g_proxyFn + 80]
P_10 ENDP
P_11 PROC
    jmp qword ptr [g_proxyFn + 88]
P_11 ENDP
P_12 PROC
    jmp qword ptr [g_proxyFn + 96]
P_12 ENDP
P_13 PROC
    jmp qword ptr [g_proxyFn + 104]
P_13 ENDP
P_14 PROC
    jmp qword ptr [g_proxyFn + 112]
P_14 ENDP
P_15 PROC
    jmp qword ptr [g_proxyFn + 120]
P_15 ENDP
P_16 PROC
    jmp qword ptr [g_proxyFn + 128]
P_16 ENDP
P_17 PROC
    jmp qword ptr [g_proxyFn + 136]
P_17 ENDP
P_18 PROC
    jmp qword ptr [g_proxyFn + 144]
P_18 ENDP
P_19 PROC
    jmp qword ptr [g_proxyFn + 152]
P_19 ENDP
P_20 PROC
    jmp qword ptr [g_proxyFn + 160]
P_20 ENDP
P_21 PROC
    jmp qword ptr [g_proxyFn + 168]
P_21 ENDP
P_22 PROC
    jmp qword ptr [g_proxyFn + 176]
P_22 ENDP
P_23 PROC
    jmp qword ptr [g_proxyFn + 184]
P_23 ENDP
P_24 PROC
    jmp qword ptr [g_proxyFn + 192]
P_24 ENDP
P_25 PROC
    jmp qword ptr [g_proxyFn + 200]
P_25 ENDP
P_26 PROC
    jmp qword ptr [g_proxyFn + 208]
P_26 ENDP
P_27 PROC
    jmp qword ptr [g_proxyFn + 216]
P_27 ENDP
P_28 PROC
    jmp qword ptr [g_proxyFn + 224]
P_28 ENDP
P_29 PROC
    jmp qword ptr [g_proxyFn + 232]
P_29 ENDP
P_30 PROC
    jmp qword ptr [g_proxyFn + 240]
P_30 ENDP
P_31 PROC
    jmp qword ptr [g_proxyFn + 248]
P_31 ENDP
P_32 PROC
    jmp qword ptr [g_proxyFn + 256]
P_32 ENDP
P_33 PROC
    jmp qword ptr [g_proxyFn + 264]
P_33 ENDP
P_34 PROC
    jmp qword ptr [g_proxyFn + 272]
P_34 ENDP
P_35 PROC
    jmp qword ptr [g_proxyFn + 280]
P_35 ENDP
P_36 PROC
    jmp qword ptr [g_proxyFn + 288]
P_36 ENDP
P_37 PROC
    jmp qword ptr [g_proxyFn + 296]
P_37 ENDP
P_38 PROC
    jmp qword ptr [g_proxyFn + 304]
P_38 ENDP
P_39 PROC
    jmp qword ptr [g_proxyFn + 312]
P_39 ENDP
P_40 PROC
    jmp qword ptr [g_proxyFn + 320]
P_40 ENDP
P_41 PROC
    jmp qword ptr [g_proxyFn + 328]
P_41 ENDP
P_42 PROC
    jmp qword ptr [g_proxyFn + 336]
P_42 ENDP
P_43 PROC
    jmp qword ptr [g_proxyFn + 344]
P_43 ENDP
P_44 PROC
    jmp qword ptr [g_proxyFn + 352]
P_44 ENDP
P_45 PROC
    jmp qword ptr [g_proxyFn + 360]
P_45 ENDP
P_46 PROC
    jmp qword ptr [g_proxyFn + 368]
P_46 ENDP
P_47 PROC
    jmp qword ptr [g_proxyFn + 376]
P_47 ENDP
P_48 PROC
    jmp qword ptr [g_proxyFn + 384]
P_48 ENDP
P_49 PROC
    jmp qword ptr [g_proxyFn + 392]
P_49 ENDP
P_50 PROC
    jmp qword ptr [g_proxyFn + 400]
P_50 ENDP
P_51 PROC
    jmp qword ptr [g_proxyFn + 408]
P_51 ENDP
P_52 PROC
    jmp qword ptr [g_proxyFn + 416]
P_52 ENDP
P_53 PROC
    jmp qword ptr [g_proxyFn + 424]
P_53 ENDP
P_54 PROC
    jmp qword ptr [g_proxyFn + 432]
P_54 ENDP
P_55 PROC
    jmp qword ptr [g_proxyFn + 440]
P_55 ENDP
P_56 PROC
    jmp qword ptr [g_proxyFn + 448]
P_56 ENDP
P_57 PROC
    jmp qword ptr [g_proxyFn + 456]
P_57 ENDP
P_58 PROC
    jmp qword ptr [g_proxyFn + 464]
P_58 ENDP
P_59 PROC
    jmp qword ptr [g_proxyFn + 472]
P_59 ENDP
P_60 PROC
    jmp qword ptr [g_proxyFn + 480]
P_60 ENDP
P_61 PROC
    jmp qword ptr [g_proxyFn + 488]
P_61 ENDP
P_62 PROC
    jmp qword ptr [g_proxyFn + 496]
P_62 ENDP
P_63 PROC
    jmp qword ptr [g_proxyFn + 504]
P_63 ENDP
P_64 PROC
    jmp qword ptr [g_proxyFn + 512]
P_64 ENDP
P_65 PROC
    jmp qword ptr [g_proxyFn + 520]
P_65 ENDP
P_66 PROC
    jmp qword ptr [g_proxyFn + 528]
P_66 ENDP
P_67 PROC
    jmp qword ptr [g_proxyFn + 536]
P_67 ENDP
P_68 PROC
    jmp qword ptr [g_proxyFn + 544]
P_68 ENDP
P_69 PROC
    jmp qword ptr [g_proxyFn + 552]
P_69 ENDP
P_70 PROC
    jmp qword ptr [g_proxyFn + 560]
P_70 ENDP
P_71 PROC
    jmp qword ptr [g_proxyFn + 568]
P_71 ENDP
P_72 PROC
    jmp qword ptr [g_proxyFn + 576]
P_72 ENDP
P_73 PROC
    jmp qword ptr [g_proxyFn + 584]
P_73 ENDP
P_74 PROC
    jmp qword ptr [g_proxyFn + 592]
P_74 ENDP
P_75 PROC
    jmp qword ptr [g_proxyFn + 600]
P_75 ENDP
P_76 PROC
    jmp qword ptr [g_proxyFn + 608]
P_76 ENDP
P_77 PROC
    jmp qword ptr [g_proxyFn + 616]
P_77 ENDP
P_78 PROC
    jmp qword ptr [g_proxyFn + 624]
P_78 ENDP
P_79 PROC
    jmp qword ptr [g_proxyFn + 632]
P_79 ENDP
P_80 PROC
    jmp qword ptr [g_proxyFn + 640]
P_80 ENDP
P_81 PROC
    jmp qword ptr [g_proxyFn + 648]
P_81 ENDP
P_82 PROC
    jmp qword ptr [g_proxyFn + 656]
P_82 ENDP
P_83 PROC
    jmp qword ptr [g_proxyFn + 664]
P_83 ENDP
P_84 PROC
    jmp qword ptr [g_proxyFn + 672]
P_84 ENDP
P_85 PROC
    jmp qword ptr [g_proxyFn + 680]
P_85 ENDP
P_86 PROC
    jmp qword ptr [g_proxyFn + 688]
P_86 ENDP
P_87 PROC
    jmp qword ptr [g_proxyFn + 696]
P_87 ENDP
P_88 PROC
    jmp qword ptr [g_proxyFn + 704]
P_88 ENDP
P_89 PROC
    jmp qword ptr [g_proxyFn + 712]
P_89 ENDP
P_90 PROC
    jmp qword ptr [g_proxyFn + 720]
P_90 ENDP
P_91 PROC
    jmp qword ptr [g_proxyFn + 728]
P_91 ENDP
P_92 PROC
    jmp qword ptr [g_proxyFn + 736]
P_92 ENDP
P_93 PROC
    jmp qword ptr [g_proxyFn + 744]
P_93 ENDP
P_94 PROC
    jmp qword ptr [g_proxyFn + 752]
P_94 ENDP
P_95 PROC
    jmp qword ptr [g_proxyFn + 760]
P_95 ENDP
P_96 PROC
    jmp qword ptr [g_proxyFn + 768]
P_96 ENDP
P_97 PROC
    jmp qword ptr [g_proxyFn + 776]
P_97 ENDP
P_98 PROC
    jmp qword ptr [g_proxyFn + 784]
P_98 ENDP
P_99 PROC
    jmp qword ptr [g_proxyFn + 792]
P_99 ENDP
P_100 PROC
    jmp qword ptr [g_proxyFn + 800]
P_100 ENDP
P_101 PROC
    jmp qword ptr [g_proxyFn + 808]
P_101 ENDP
P_102 PROC
    jmp qword ptr [g_proxyFn + 816]
P_102 ENDP
P_103 PROC
    jmp qword ptr [g_proxyFn + 824]
P_103 ENDP
P_104 PROC
    jmp qword ptr [g_proxyFn + 832]
P_104 ENDP
P_105 PROC
    jmp qword ptr [g_proxyFn + 840]
P_105 ENDP
P_106 PROC
    jmp qword ptr [g_proxyFn + 848]
P_106 ENDP
P_107 PROC
    jmp qword ptr [g_proxyFn + 856]
P_107 ENDP
P_108 PROC
    jmp qword ptr [g_proxyFn + 864]
P_108 ENDP
P_109 PROC
    jmp qword ptr [g_proxyFn + 872]
P_109 ENDP
P_110 PROC
    jmp qword ptr [g_proxyFn + 880]
P_110 ENDP
P_111 PROC
    jmp qword ptr [g_proxyFn + 888]
P_111 ENDP
P_112 PROC
    jmp qword ptr [g_proxyFn + 896]
P_112 ENDP
P_113 PROC
    jmp qword ptr [g_proxyFn + 904]
P_113 ENDP
P_114 PROC
    jmp qword ptr [g_proxyFn + 912]
P_114 ENDP
P_115 PROC
    jmp qword ptr [g_proxyFn + 920]
P_115 ENDP
P_116 PROC
    jmp qword ptr [g_proxyFn + 928]
P_116 ENDP
P_117 PROC
    jmp qword ptr [g_proxyFn + 936]
P_117 ENDP
P_118 PROC
    jmp qword ptr [g_proxyFn + 944]
P_118 ENDP
P_119 PROC
    jmp qword ptr [g_proxyFn + 952]
P_119 ENDP
P_120 PROC
    jmp qword ptr [g_proxyFn + 960]
P_120 ENDP
P_121 PROC
    jmp qword ptr [g_proxyFn + 968]
P_121 ENDP
P_122 PROC
    jmp qword ptr [g_proxyFn + 976]
P_122 ENDP
P_123 PROC
    jmp qword ptr [g_proxyFn + 984]
P_123 ENDP
P_124 PROC
    jmp qword ptr [g_proxyFn + 992]
P_124 ENDP
P_125 PROC
    jmp qword ptr [g_proxyFn + 1000]
P_125 ENDP
P_126 PROC
    jmp qword ptr [g_proxyFn + 1008]
P_126 ENDP
P_127 PROC
    jmp qword ptr [g_proxyFn + 1016]
P_127 ENDP
P_128 PROC
    jmp qword ptr [g_proxyFn + 1024]
P_128 ENDP
P_129 PROC
    jmp qword ptr [g_proxyFn + 1032]
P_129 ENDP
P_130 PROC
    jmp qword ptr [g_proxyFn + 1040]
P_130 ENDP
P_131 PROC
    jmp qword ptr [g_proxyFn + 1048]
P_131 ENDP
P_132 PROC
    jmp qword ptr [g_proxyFn + 1056]
P_132 ENDP
P_133 PROC
    jmp qword ptr [g_proxyFn + 1064]
P_133 ENDP
P_134 PROC
    jmp qword ptr [g_proxyFn + 1072]
P_134 ENDP
P_135 PROC
    jmp qword ptr [g_proxyFn + 1080]
P_135 ENDP
P_136 PROC
    jmp qword ptr [g_proxyFn + 1088]
P_136 ENDP
P_137 PROC
    jmp qword ptr [g_proxyFn + 1096]
P_137 ENDP
P_138 PROC
    jmp qword ptr [g_proxyFn + 1104]
P_138 ENDP
P_139 PROC
    jmp qword ptr [g_proxyFn + 1112]
P_139 ENDP
P_140 PROC
    jmp qword ptr [g_proxyFn + 1120]
P_140 ENDP
P_141 PROC
    jmp qword ptr [g_proxyFn + 1128]
P_141 ENDP
P_142 PROC
    jmp qword ptr [g_proxyFn + 1136]
P_142 ENDP
P_143 PROC
    jmp qword ptr [g_proxyFn + 1144]
P_143 ENDP
P_144 PROC
    jmp qword ptr [g_proxyFn + 1152]
P_144 ENDP
P_145 PROC
    jmp qword ptr [g_proxyFn + 1160]
P_145 ENDP
P_146 PROC
    jmp qword ptr [g_proxyFn + 1168]
P_146 ENDP
P_147 PROC
    jmp qword ptr [g_proxyFn + 1176]
P_147 ENDP
P_148 PROC
    jmp qword ptr [g_proxyFn + 1184]
P_148 ENDP
P_149 PROC
    jmp qword ptr [g_proxyFn + 1192]
P_149 ENDP
P_150 PROC
    jmp qword ptr [g_proxyFn + 1200]
P_150 ENDP
P_151 PROC
    jmp qword ptr [g_proxyFn + 1208]
P_151 ENDP
P_152 PROC
    jmp qword ptr [g_proxyFn + 1216]
P_152 ENDP
P_153 PROC
    jmp qword ptr [g_proxyFn + 1224]
P_153 ENDP
P_154 PROC
    jmp qword ptr [g_proxyFn + 1232]
P_154 ENDP
P_155 PROC
    jmp qword ptr [g_proxyFn + 1240]
P_155 ENDP
P_156 PROC
    jmp qword ptr [g_proxyFn + 1248]
P_156 ENDP
P_157 PROC
    jmp qword ptr [g_proxyFn + 1256]
P_157 ENDP
P_158 PROC
    jmp qword ptr [g_proxyFn + 1264]
P_158 ENDP
P_159 PROC
    jmp qword ptr [g_proxyFn + 1272]
P_159 ENDP
P_160 PROC
    jmp qword ptr [g_proxyFn + 1280]
P_160 ENDP
P_161 PROC
    jmp qword ptr [g_proxyFn + 1288]
P_161 ENDP
P_162 PROC
    jmp qword ptr [g_proxyFn + 1296]
P_162 ENDP
P_163 PROC
    jmp qword ptr [g_proxyFn + 1304]
P_163 ENDP
P_164 PROC
    jmp qword ptr [g_proxyFn + 1312]
P_164 ENDP
P_165 PROC
    jmp qword ptr [g_proxyFn + 1320]
P_165 ENDP
P_166 PROC
    jmp qword ptr [g_proxyFn + 1328]
P_166 ENDP
P_167 PROC
    jmp qword ptr [g_proxyFn + 1336]
P_167 ENDP
P_168 PROC
    jmp qword ptr [g_proxyFn + 1344]
P_168 ENDP
P_169 PROC
    jmp qword ptr [g_proxyFn + 1352]
P_169 ENDP
P_170 PROC
    jmp qword ptr [g_proxyFn + 1360]
P_170 ENDP
P_171 PROC
    jmp qword ptr [g_proxyFn + 1368]
P_171 ENDP
P_172 PROC
    jmp qword ptr [g_proxyFn + 1376]
P_172 ENDP
P_173 PROC
    jmp qword ptr [g_proxyFn + 1384]
P_173 ENDP
P_174 PROC
    jmp qword ptr [g_proxyFn + 1392]
P_174 ENDP
P_175 PROC
    jmp qword ptr [g_proxyFn + 1400]
P_175 ENDP
P_176 PROC
    jmp qword ptr [g_proxyFn + 1408]
P_176 ENDP
P_177 PROC
    jmp qword ptr [g_proxyFn + 1416]
P_177 ENDP
P_178 PROC
    jmp qword ptr [g_proxyFn + 1424]
P_178 ENDP
P_179 PROC
    jmp qword ptr [g_proxyFn + 1432]
P_179 ENDP
P_180 PROC
    jmp qword ptr [g_proxyFn + 1440]
P_180 ENDP
END
