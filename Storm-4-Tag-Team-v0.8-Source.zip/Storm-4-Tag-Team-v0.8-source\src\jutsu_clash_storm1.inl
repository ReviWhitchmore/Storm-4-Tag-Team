// Disputa de jutsus no visual do Storm 1 (referencia: captura do Storm 1 enviada pelo usuario, Naruto x Jiraiya).
// Pecas da interface tiradas do battle.xfbin do Storm 1 INSTALADO do usuario (tools/extrair_clash_storm1.js gera os PNG
// em <Storm 4>\storm6_storm1; nada do Storm 1 vai no pacote do mod):
//   xbattle_sousai  moldura ornamentada (4,3 361x174), barras azul (303,190 72x16), vermelha (303,211 72x16),
//                   fundo cinza (290,231 90x34);
//   xbattle_s-eff02 / s-eff04  faixas de energia laranja / azul da barra (0,24 384x72);
//   xbattle_s-eff05 / s-eff06  chamas laranja / azul (8 quadros de 96x192);  xbattle_s-eff07 estouro (192x192);
//   cmn_button00 botao B (3,2 67x67);  xcmn_playere_fd 1P (10,4 100x62), 2P (133,5 98x61), COM (5,66 173x72).
// Meio da tela: so o clarao no contato das maos, o brilho de cada lado (vermelho/laranja a esquerda, azul a direita),
// raios azuis saindo do centro e bordas azul-escuras (o cenario ja foi desligado pelo motor). Os personagens e os
// proprios jutsus sao os modelos 3D do jogo.
void S1Sprite(const ModImage* img, float sx, float sy, float sw, float sh, float cx, float cy, float h, float alpha,
              bool flip = false) {
  if (!img) return;
  const float w = h * sw / sh;
  ImagePart(img, sx, sy, sw, sh, cx - w * 0.5f, cy - h * 0.5f, w, h, alpha, flip);
}

void BuildJutsuClashStorm1Look(const ClashHud& c) {
  const ModImage* atlas = LoadModImage(L"storm6_storm1\\xbattle_sousai.png");
  const ModImage* waveL = LoadModImage(L"storm6_storm1\\xbattle_s-eff02.png");
  const ModImage* waveR = LoadModImage(L"storm6_storm1\\xbattle_s-eff04.png");
  const ModImage* flameL = LoadModImage(L"storm6_storm1\\xbattle_s-eff05.png");
  const ModImage* flameR = LoadModImage(L"storm6_storm1\\xbattle_s-eff06.png");
  const ModImage* burst = LoadModImage(L"storm6_storm1\\xbattle_s-eff07.png");
  const ModImage* buttons = LoadModImage(L"storm6_storm1\\cmn_button00.png");
  const ModImage* players = LoadModImage(L"storm6_storm1\\xcmn_playere_fd.png");
  const float W = g_w, H = g_h, s = std::min(W / 1600.0f, H / 900.0f);
  const unsigned t = unsigned(GetTickCount64() % 100000);
  const float pulse = 0.5f + 0.5f * std::sin(t * 0.021f);
  const bool live = c.result < 0;
  const float age = float(c.resultAgeMs);
  const float fade = live ? 1.0f : std::clamp(1.0f - (age - 900.0f) / 600.0f, 0.0f, 1.0f);
  if (fade <= 0.01f) return;
  uint32_t seed = 0x51A5E1u ^ (t / 45);
  auto rnd = [&seed]() { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; return (seed % 10000) / 10000.0f; };

  // ---- posicoes na tela (altura das maos), lado esquerdo/direito
  float ax = W * 0.36f, ay = H * 0.47f, bx = W * 0.64f, by = H * 0.47f;
  if (c.hasPos) {
    const float wa[3] = {c.posA[0], c.posA[1], c.posA[2] + 66.0f}, wb[3] = {c.posB[0], c.posB[1], c.posB[2] + 66.0f};  // altura das maos
    float sxa, sya, sxb, syb;
    bool backA = false, backB = false;
    if (CameraProject(wa, W / H, &sxa, &sya, &backA) && CameraProject(wb, W / H, &sxb, &syb, &backB) && !backA &&
        !backB && std::fabs(sxa) < 1.4f && std::fabs(sxb) < 1.4f && std::fabs(sya) < 1.4f && std::fabs(syb) < 1.4f) {
      ax = (sxa * 0.5f + 0.5f) * W;
      ay = (0.5f - sya * 0.5f) * H;
      bx = (sxb * 0.5f + 0.5f) * W;
      by = (0.5f - syb * 0.5f) * H;
    }
  }
  float worldMx = 0, worldMy = 0;
  const bool worldContact = ProjectClashWorldAnchors(c, &ax, &ay, &bx, &by, &worldMx, &worldMy);
  const bool aLeft = ax <= bx;
  const unsigned scoreL = aLeft ? c.scoreA : c.scoreB, scoreR = aLeft ? c.scoreB : c.scoreA;
  const int padL = aLeft ? c.padA : c.padB, padR = aLeft ? c.padB : c.padA;
  const int numL = aLeft ? c.numberA : c.numberB, numR = aLeft ? c.numberB : c.numberA;
  const unsigned total = scoreL + scoreR;
  const float shareL = total ? float(scoreL) / float(total) : 0.5f;
  const float lx = aLeft ? ax : bx, ly = aLeft ? ay : by, rx = aLeft ? bx : ax, ry = aLeft ? by : ay;
  // Contato acompanha o empurrao dos modelos 3D; uma oscilacao local menor
  // reage ao placar sem fazer a energia atravessar as maos dos lutadores.
  const float k = clash_motion::ContactFraction(scoreL, scoreR);
  const float jx = std::sin(t * 0.083f) * 2.5f * s, jy = std::cos(t * 0.067f) * 2.5f * s;
  const float mx = (worldContact ? worldMx : lx + (rx - lx) * k) + jx;
  const float my = (worldContact ? worldMy : ly + (ry - ly) * k) + jy;

  // ---- abertura (closes de camera do Storm 1): so o "MASH!" no centro; a barra entra com a vista de lado.
  if (live && c.cameraIntro && c.elapsedMs < 900) {
    const float e = float(c.elapsedMs);
    if (e >= 450) {
      const float pop = std::min(1.0f, (e - 450) / 120.0f);
      const float size = (120 - 40 * pop) * s;
      const char* mash = "MASH!";
      const float tw = TextWidth(mash, size), tx = W * 0.5f - tw * 0.5f, ty = H * 0.42f;
      for (int o = 0; o < 8; ++o) {  // contorno escuro
        const float ox = std::cos(o * 0.785f) * 4 * s, oy = std::sin(o * 0.785f) * 4 * s;
        Text(tx + ox, ty + oy, mash, size, 0.35f, 0.05f, 0.0f, 0.9f);
      }
      Text(tx, ty, mash, size, 1.0f, 0.62f, 0.10f, 1.0f);
      Rect(W * 0.5f - 2 * s, 0, 4 * s, H, 1, 1, 1, 0.55f * (1.0f - pop * 0.5f));  // divisao do "split"
    }
    return;
  }

  // ---- fundo: bordas azul-escuras e raios de luz azul saindo do contato (o cenario ja esta desligado)
  {
    const float dx = W * 0.30f, dy = H * 0.30f;
    const Rgba d{0.01f, 0.03f, 0.10f, 0.85f * fade}, cl{0.01f, 0.03f, 0.10f, 0.0f};
    { const float px[4] = {0, W, W - dx, dx}, py[4] = {0, 0, dy, dy}; const Rgba q[4] = {d, d, cl, cl}; Poly4(px, py, q); }
    { const float px[4] = {dx, W - dx, W, 0}, py[4] = {H - dy, H - dy, H, H}; const Rgba q[4] = {cl, cl, d, d}; Poly4(px, py, q); }
    { const float px[4] = {0, dx, dx, 0}, py[4] = {0, dy, H - dy, H}; const Rgba q[4] = {d, cl, cl, d}; Poly4(px, py, q); }
    { const float px[4] = {W - dx, W, W, W - dx}, py[4] = {dy, 0, H, H - dy}; const Rgba q[4] = {cl, d, d, cl}; Poly4(px, py, q); }
  }
  for (int i = 0; i < 36; ++i) {
    // Fora da faixa horizontal onde estao os personagens (o mod desenha por cima; no Storm 1 os raios ficam atras).
    float ang = rnd() * 6.2832f;
    if (std::fabs(std::sin(ang)) < 0.5f) ang += (std::sin(ang) >= 0 ? 1.0f : -1.0f) * 0.9f;
    const float inner = (0.10f + 0.12f * rnd()) * H, outer = W;
    const float w0 = (1.0f + 3.0f * rnd()) * s;
    const float x0 = mx + std::cos(ang) * inner, y0 = my + std::sin(ang) * inner;
    const float x1 = mx + std::cos(ang) * outer, y1 = my + std::sin(ang) * outer;
    const float px[4] = {x0, x1, x1, x0};
    const float py[4] = {y0 - w0 * 0.5f, y1 - w0 * 4.0f, y1 + w0 * 4.0f, y0 + w0 * 0.5f};
    const Rgba inner0{0.55f, 0.75f, 1.0f, (0.10f + 0.22f * rnd()) * fade}, outer0{0.25f, 0.45f, 1.0f, 0.0f};
    const Rgba q[4] = {inner0, outer0, outer0, inner0};
    Poly4(px, py, q);
  }

  // ---- brilho de cada lado e clarao no contato
  if (live) {
    auto glow = [&](float x, float y, float r, Rgba tone, float a) {
      for (int seg = 0; seg < 16; ++seg) {
        const float a0 = seg * 6.2832f / 16, a1 = (seg + 1) * 6.2832f / 16;
        const float px[4] = {x, x + std::cos(a0) * r, x + std::cos(a1) * r, x};
        const float py[4] = {y, y + std::sin(a0) * r, y + std::sin(a1) * r, y};
        const Rgba in{tone.r, tone.g, tone.b, a}, out{tone.r, tone.g, tone.b, 0.0f};
        const Rgba q[4] = {in, out, out, in};
        Poly4(px, py, q);
      }
    };
    const float gr = (150 + 30 * pulse) * s;
    glow((lx + mx) * 0.5f, (ly + my) * 0.5f, gr * (0.8f + 0.6f * shareL), Rgba{1.0f, 0.35f, 0.10f, 1}, 0.45f * fade);
    glow((rx + mx) * 0.5f, (ry + my) * 0.5f, gr * (0.8f + 0.6f * (1 - shareL)), Rgba{0.20f, 0.60f, 1.0f, 1}, 0.45f * fade);
    const float bs = (210 + 70 * pulse) * s;
    if (burst) {
      ImagePart(burst, 0, 0, 192, 192, mx - bs * 0.5f, my - bs * 0.5f, bs, bs, 0.95f * fade);
      ImagePart(burst, 0, 0, 192, 192, mx - bs * 0.32f, my - bs * 0.32f, bs * 0.64f, bs * 0.64f, 0.9f * fade, true);
    }
    glow(mx, my, (70 + 25 * pulse) * s, Rgba{1, 1, 1, 1}, 0.95f * fade);
    for (int i = 0; i < 4; ++i) {  // raios amarelos perto do choque (como no Storm 1)
      float x0 = mx + (rnd() - 0.5f) * 260 * s, y0 = my - (60 + 120 * rnd()) * s;
      const float dirX = (rnd() - 0.5f) * 0.8f;
      for (int seg = 0; seg < 4; ++seg) {
        const float x1 = x0 + (dirX + (rnd() - 0.5f) * 0.9f) * 34 * s, y1 = y0 + (18 + 22 * rnd()) * s;
        LockStroke(x0, y0, x1, y1, 5.0f * s, Rgba{1.0f, 0.82f, 0.15f, 0.55f * fade});
        LockStroke(x0, y0, x1, y1, 2.0f * s, Rgba{1.0f, 1.0f, 0.75f, 0.95f * fade});
        x0 = x1;
        y0 = y1;
      }
    }
    for (int i = 0; i < 14; ++i) {  // faiscas
      const float ang = rnd() * 6.2832f, len = (40 + 120 * rnd()) * s;
      LockStroke(mx, my, mx + std::cos(ang) * len, my + std::sin(ang) * len, (1.5f + 2.0f * rnd()) * s,
                 Rgba{0.85f, 0.95f, 1.0f, 0.85f * fade});
    }
  } else {
    // Resultado: clarao e estouro no perdedor (empate: no contato).
    if (age < 380) Rect(0, 0, W, H, 1, 1, 1, 0.95f * (1.0f - age / 380.0f));  // clarao branco do Storm 1
    float ex = mx, ey = my;
    if (c.result == 1) { ex = bx; ey = by; }
    if (c.result == 2) { ex = ax; ey = ay; }
    if (age < 1000 && burst) {
      const float g = std::min(1.0f, age / 300.0f), es = (200 + 460 * g) * s;
      ImagePart(burst, 0, 0, 192, 192, ex - es * 0.5f, ey - es * 0.5f, es, es, age < 550 ? 1.0f : 1.0f - (age - 550) / 450);
    }
  }

  // ---- barra do Storm 1: moldura espelhada, barra vermelha x azul com energia, estouro, B / MASH! e chamas
  const float halfW = W * 0.37f, frameH = H * 0.165f;
  const float cx = W * 0.5f, fy = H * 0.985f - frameH;
  if (atlas) {
    ImagePart(atlas, 4, 3, 361, 174, cx - halfW, fy, halfW, frameH, 0.97f * fade);
    ImagePart(atlas, 4, 3, 361, 174, cx, fy, halfW, frameH, 0.97f * fade, true);
  }
  const float barY = fy + frameH * 0.585f, barH = std::max(6.0f, frameH * 0.11f);
  const float barL = cx - halfW * 0.64f, barR = cx + halfW * 0.64f;
  const float meet = barL + (barR - barL) * (live ? shareL : (c.result == 0 ? 0.5f : (((c.result == 1) == aLeft) ? 1.0f : 0.0f)));
  if (atlas) {
    ImagePart(atlas, 292, 236, 86, 24, barL - 6 * s, barY - barH * 0.5f - 4 * s, barR - barL + 12 * s, barH + 8 * s,
              0.9f * fade);
    ImagePart(atlas, 303, 211, 72, 16, barL, barY - barH * 0.5f, meet - barL, barH, fade);
    ImagePart(atlas, 303, 190, 72, 16, meet, barY - barH * 0.5f, barR - meet, barH, fade);
  } else {
    Rect(barL, barY - barH * 0.5f, meet - barL, barH, 0.9f, 0.15f, 0.08f, fade);
    Rect(meet, barY - barH * 0.5f, barR - meet, barH, 0.15f, 0.45f, 1.0f, fade);
  }
  // Energia ondulando sobre a barra (a textura corre na direcao do encontro).
  const float scroll = float(t % 1600) / 1600.0f * 384.0f;
  const float waveH = barH * 3.2f;
  if (waveL && meet - barL > 4) {
    const float u0 = 384.0f - scroll;
    ImagePart(waveL, u0 > 192 ? u0 - 192 : u0, 24, 192, 72, barL, barY - waveH * 0.5f, meet - barL, waveH, 0.9f * fade);
  }
  if (waveR && barR - meet > 4)
    ImagePart(waveR, scroll > 192 ? scroll - 192 : scroll, 23, 192, 73, meet, barY - waveH * 0.5f, barR - meet, waveH,
              0.9f * fade, true);
  if (burst) {
    const float sb = (95 + 35 * pulse) * s;
    ImagePart(burst, 0, 0, 192, 192, meet - sb * 0.5f, barY - sb * 0.5f, sb, sb, fade);
  }
  Rect(meet - 2.5f * s, barY - barH * 1.4f, 5 * s, barH * 2.8f, 1, 1, 1, 0.95f * fade);
  // Pontas: chama atras do B, B, MASH! e 1P / 2P / COM.
  const int frame8 = int(t / 60) % 8;
  for (int side = 0; side < 2; ++side) {
    const float bxp = side == 0 ? cx - halfW * 0.80f : cx + halfW * 0.80f;
    const float byp = fy + frameH * 0.56f;
    const ModImage* flame = side == 0 ? flameL : flameR;
    if (flame) {
      const float fh = frameH * 0.95f, fw = fh * 96.0f / 192.0f;
      const float fx = side == 0 ? bxp - frameH * 0.55f : bxp + frameH * 0.55f;
      ImagePart(flame, frame8 * 96.0f, 0, 96, 192, fx - fw * 0.5f, byp - fh * 0.62f, fw, fh, 0.95f * fade);
    }
    const float bh = frameH * (live ? 0.46f + 0.05f * pulse : 0.46f);
    if (buttons) S1Sprite(buttons, 3, 2, 67, 67, bxp, byp, bh, fade);
    else Text(bxp - 10 * s, byp - 18 * s, "B", 36 * s, 1, 0.2f, 0.2f, fade);
    const float msz = 17 * s;
    const char* mash = "MASH!";
    Text(bxp - TextWidth(mash, msz) * 0.5f, byp + bh * 0.42f, mash, msz, 1.0f, 0.86f, 0.25f, fade);
    const int pad = side == 0 ? padL : padR;
    const float lh = frameH * 0.22f, lxp = side == 0 ? bxp + bh * 0.85f : bxp - bh * 0.85f, lyp = byp - bh * 0.62f;
    if (players) {
      if (pad == 0) S1Sprite(players, 10, 4, 100, 62, lxp, lyp, lh, fade);
      else if (pad == 1) S1Sprite(players, 133, 5, 98, 61, lxp, lyp, lh, fade);
      else if (pad < 0) S1Sprite(players, 5, 66, 173, 72, lxp, lyp, lh, fade);
    }
    if (!players || pad >= 2) {
      char tag[8];
      std::snprintf(tag, sizeof(tag), "%dP", pad + 1);
      Text(lxp - 12 * s, lyp - 10 * s, pad >= 0 ? tag : "COM", 18 * s, 1, 1, 1, fade);
    }
  }
  // Placar pequeno e tempo (o Storm 1 nao mostra numeros; ficam discretos).
  char line[64];
  std::snprintf(line, sizeof(line), "J%d %u", numL, scoreL);
  Text(barL, barY + barH * 1.1f, line, 15 * s, 1.0f, 0.55f, 0.35f, 0.85f * fade);
  std::snprintf(line, sizeof(line), "%u J%d", scoreR, numR);
  Text(barR - TextWidth(line, 15 * s), barY + barH * 1.1f, line, 15 * s, 0.55f, 0.8f, 1.0f, 0.85f * fade);
  if (live) {
    std::snprintf(line, sizeof(line), "%.1f", c.remainingMs / 1000.0f);
    Text(cx - TextWidth(line, 20 * s) * 0.5f, fy + frameH * 0.12f, line, 20 * s, 1, 1, 1, 0.9f * fade);
  } else {
    const char* big = c.result == 0 ? Lang("EMPATE!","DRAW!") : nullptr;
    if (!big) {
      std::snprintf(line, sizeof(line), Lang("J%d VENCEU!","J%d WINS!"), c.result == 1 ? c.numberA : c.numberB);
      big = line;
    }
    const float size = 60 * s;
    Text(W * 0.5f - TextWidth(big, size) * 0.5f, H * 0.20f, big, size, kMenuGold.r, kMenuGold.g, kMenuGold.b, fade);
  }
}
