#include "lang.h"

#include <cstdio>
#include <cstring>
#include <string>

#include "log.h"

bool LangEnglish() {
  static const bool english = [] {
    bool en = false;
    const std::wstring file = ModDir() + L"storm6.ini";
    if (FILE* stream = _wfopen(file.c_str(), L"r")) {
      char line[128];
      while (std::fgets(line, sizeof(line), stream)) {
        char key[65]{}, value[17]{};
        if (std::sscanf(line, " %64[^= ] = %16s", key, value) != 2) continue;
        if (!std::strcmp(key, "idioma")) en = !_stricmp(value, "en");
      }
      std::fclose(stream);
    }
    Log("Idioma dos textos do mod: %s.", en ? "ingles (idioma=en)" : "portugues");
    return en;
  }();
  return english;
}
