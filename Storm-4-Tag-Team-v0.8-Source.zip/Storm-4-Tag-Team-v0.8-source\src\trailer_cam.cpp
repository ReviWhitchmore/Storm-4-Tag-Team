#include "trailer_cam.h"

#include <windows.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

#include "log.h"

namespace {

constexpr float kPi = 3.14159265f;
constexpr float kCenterHeight = 70.0f;

std::atomic<int> g_mode{0};
float g_dist = 320.0f;
float g_height = 70.0f;
float g_speed = 10.0f * kPi / 180.0f;  // radianos por segundo
int g_alvo = -1;

std::atomic<ULONGLONG> g_start{0};
ULONGLONG g_last = 0;
float g_base = 0.0f;   // angulo inicial: de lado para o par lutador/alvo
float g_focus[3]{};    // posicao suavizada do lutador seguido
float g_center[3]{};   // centro suavizado de todos (modo 3)
float g_radius = 0.0f; // raio suavizado do modo 3

float Ease(float dt, float rate) { return 1.0f - std::exp(-rate * dt); }

}  // namespace

void TrailerCamLoad() {
  int mode = 0, dist = 320, height = 70, speed = 10, alvo = -1;
  const std::wstring file = ModDir() + L"storm6.ini";
  if (FILE* stream = _wfopen(file.c_str(), L"r")) {
    char line[128];
    while (std::fgets(line, sizeof(line), stream)) {
      char key[65]{};
      int value = 0;
      if (std::sscanf(line, "%64[^=]=%d", key, &value) != 2) continue;
      if (!std::strcmp(key, "camera_trailer")) mode = value;
      else if (!std::strcmp(key, "camera_trailer_dist")) dist = value;
      else if (!std::strcmp(key, "camera_trailer_altura")) height = value;
      else if (!std::strcmp(key, "camera_trailer_vel")) speed = value;
      else if (!std::strcmp(key, "camera_trailer_alvo")) alvo = value;
    }
    std::fclose(stream);
  }
  g_mode = mode >= 1 && mode <= 4 ? mode : 0;
  g_dist = static_cast<float>(std::clamp(dist, 120, 3000));
  g_height = static_cast<float>(std::clamp(height, -40, 800));
  g_speed = static_cast<float>(std::clamp(speed, -90, 90)) * kPi / 180.0f;
  g_alvo = std::clamp(alvo, -1, 5);
  if (g_mode.load())
    Log("CAMERA DE TRAILER: modo %d, distancia %.0f, altura %.0f, %d graus/s, alvo %d.", g_mode.load(), g_dist,
        g_height, speed, g_alvo);
}

bool TrailerCamEnabled() { return g_mode.load(std::memory_order_relaxed) != 0; }

void TrailerCamReset() { g_start.store(0, std::memory_order_relaxed); }

bool TrailerCamView(const float positions[][3], int count, int primary, int target, float eye[3], float aim[3]) {
  const int mode = g_mode.load(std::memory_order_relaxed);
  if (!mode || !positions || count < 1) return false;
  const int focusIndex = g_alvo >= 0 && g_alvo < count ? g_alvo : std::clamp(primary, 0, count - 1);
  const float* focus = positions[focusIndex];
  for (int a = 0; a < 3; ++a)
    if (!std::isfinite(focus[a]) || std::fabs(focus[a]) > 20000.0f) return false;

  float center[3]{};
  int alive = 0;
  for (int k = 0; k < count; ++k) {
    if (!std::isfinite(positions[k][0]) || std::fabs(positions[k][0]) > 20000.0f) continue;
    for (int a = 0; a < 3; ++a) center[a] += positions[k][a];
    ++alive;
  }
  if (!alive) return false;
  for (float& c : center) c /= static_cast<float>(alive);
  float spread = 0.0f;
  for (int k = 0; k < count; ++k)
    spread = std::max(spread, std::hypot(positions[k][0] - center[0], positions[k][1] - center[1]));

  const ULONGLONG now = GetTickCount64();
  if (g_start.load(std::memory_order_relaxed) == 0) {
    g_start.store(now, std::memory_order_relaxed);
    g_last = now;
    std::memcpy(g_focus, focus, sizeof(g_focus));
    std::memcpy(g_center, center, sizeof(g_center));
    g_radius = std::max(1500.0f, spread * 1.6f + 600.0f);
    float dx = 1.0f, dy = 0.0f;
    if (target >= 0 && target < count && target != focusIndex) {
      dx = positions[target][0] - focus[0];
      dy = positions[target][1] - focus[1];
    }
    g_base = std::atan2(dy, dx) + kPi * 0.5f;  // de lado para o par: os dois na tela
    Log("CAMERA DE TRAILER: inicio no lutador %d de %d.", focusIndex, count);
  }
  const float dt = std::clamp(static_cast<float>(now - g_last) / 1000.0f, 0.0f, 0.1f);
  g_last = now;
  const float t = static_cast<float>(now - g_start.load(std::memory_order_relaxed)) / 1000.0f;
  const float follow = Ease(dt, 3.0f);
  for (int a = 0; a < 3; ++a) {
    g_focus[a] += (focus[a] - g_focus[a]) * follow;
    g_center[a] += (center[a] - g_center[a]) * Ease(dt, 1.5f);
  }
  g_radius += (std::max(1500.0f, spread * 1.6f + 600.0f) - g_radius) * Ease(dt, 0.8f);

  float angle = g_base, distance = g_dist, eyeHeight = g_height, aimHeight = kCenterHeight;
  const float* pivot = g_focus;
  switch (mode) {
    case 1:  // orbita lenta
      angle = g_base + g_speed * t;
      break;
    case 2:  // aproximacao de lado, baixa (comeca 2,2x mais longe e chega na distancia em ~6 s)
      angle = g_base + g_speed * 0.3f * t;
      distance = g_dist * (1.0f + 1.2f * std::exp(-t / 2.5f));
      eyeHeight = std::max(15.0f, g_height * 0.5f);
      aimHeight = 85.0f;
      break;
    case 3:  // orbita larga em volta de todos
      pivot = g_center;
      angle = g_base + g_speed * 0.5f * t;
      distance = g_radius;
      eyeHeight = std::max(g_height, 380.0f);
      aimHeight = 60.0f;
      break;
    default:  // 4: heroi, camera quase no chao olhando para cima
      angle = g_base + 0.35f * std::sin(t * 0.25f);
      distance = g_dist * 0.9f;
      eyeHeight = 18.0f;
      aimHeight = 100.0f;
      break;
  }
  eye[0] = pivot[0] + std::cos(angle) * distance;
  eye[1] = pivot[1] + std::sin(angle) * distance;
  eye[2] = pivot[2] + eyeHeight;
  aim[0] = pivot[0];
  aim[1] = pivot[1];
  aim[2] = pivot[2] + aimHeight;
  return true;
}
