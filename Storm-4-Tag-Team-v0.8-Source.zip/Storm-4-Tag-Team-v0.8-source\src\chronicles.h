#pragma once
// Chronicles Mode: native game-mode selector scene + edition-specific profile.
#include <windows.h>
#include <Xinput.h>

bool ChroniclesInstall();
bool ChroniclesNativeModeVisible();
bool ChroniclesChapterScreenOpen();
int ChroniclesChapterSelection(); // selected ARC (legacy UI name)
bool ChroniclesMissionNotReady();
int ChroniclesAssistedMission(); // -1 if no battle is armed
int ChroniclesAssistedState(); // 0 idle, 1 armed, 2 roster confirmed, 3 won, 4 lost
bool ChroniclesMissionCompleted(int mission);
void ChroniclesAssistedJudgeTick(int nativeResult); // called ONLY on game's judge thread
bool ChroniclesMissionListOpen();
bool ChroniclesMissionDetailOpen();
int ChroniclesMissionSelection();
int ChroniclesArcCount();
int ChroniclesArcMissionCount(int arc);
int ChroniclesArcMissionFirst(int arc);
const char* ChroniclesMissionTitle(int index);
void ChroniclesMarkCompleted(int mission); // grava a missao como concluida no progresso
// Ao voltar ao menu de modos depois de uma missao: reabre a lista de missoes (proxima se venceu).
void ChroniclesReopenAfterMission(int mission,bool won);
const char* ChroniclesMissionId(int index);
const char* ChroniclesMissionTeams(int index);
const char* ChroniclesMissionAllies(int index);
const char* ChroniclesMissionEnemies(int index);
const char* ChroniclesFighterInSlot(int index,int side,int slot);
const char* ChroniclesFighterPreferredStyle(int index,int side,int slot);
bool ChroniclesRosterConfigured(int index);
bool ChroniclesRosterDlcNeeded(int index);
const char* ChroniclesMissionArena(int index);
const char* ChroniclesMissionObjective(int index);
const char* ChroniclesMissionSpecial(int index);
const char* ChroniclesMissionBonus(int index);
const char* ChroniclesMissionAI(int index);
const char* ChroniclesMissionDifficulty(int index);
int ChroniclesMissionAllyHealth(int index);
int ChroniclesMissionEnemyHealth(int index);
int ChroniclesMissionEnemyDamage(int index);
const char* ChroniclesMissionStatus(int index);
bool ChroniclesMissionIsBoss(int index);
int ChroniclesMissionBossPhases(int index);
const char* ChroniclesMissionBossName(int index);
const char* ChroniclesMissionBossPhase(int index,int phase);
void ChroniclesBack();
const char* ChroniclesEditionLabel();
const char* ChroniclesCampaignLabel();
const char* ChroniclesChapterTitle(int index);
const char* ChroniclesChapterSubtitle(int index);
const char* ChroniclesChapterStatus(int index);
// Controller input is reserved while the chapter overlay is open.
void ChroniclesGamepadInput(XINPUT_STATE* state);
void ChroniclesKeyboardInput();
