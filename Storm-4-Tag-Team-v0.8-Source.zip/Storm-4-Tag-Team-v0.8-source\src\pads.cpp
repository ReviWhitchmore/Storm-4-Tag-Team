// Co-op, fase de diagnostico: como cada lutador chega ao seu controle.
//
// FUN_1401B5620(dev) atualiza um "dispositivo de controle" do motor:
//   dev+0xE4 tipo (1 = XInput), dev+0xE0 indice XInput, dev+0x08 conectado,
//   dev+0x0C botoes segurados (formato do jogo), +0x10 apertados agora, +0x14 soltos,
//   dev+0x1C..+0x28 analogicos (float).
// Aqui so registramos os dispositivos e, no inicio da luta, procuramos ponteiros para eles
// dentro de cada lutador. Nada e alterado.

#include "pads.h"

#include <windows.h>
#include <MinHook.h>
#include <intrin.h>
#include <tlhelp32.h>

#include <atomic>
#include <cstring>

#include "census.h"
#include "addresses.h"
#include "log.h"

namespace {

#define kRvaDevUpdate (Addr().devUpdate)
constexpr int kMaxDev = 16;
constexpr size_t kDevSpan = 0x100;        // tamanho considerado de um dispositivo
constexpr size_t kPlayerScan = 0x18000;   // bytes varridos em cada lutador

using DevUpdate_t = void (*)(void* dev);
DevUpdate_t g_orig = nullptr;
std::atomic<uintptr_t> g_dev[kMaxDev];
std::atomic<int> g_numDev{0};

void HookDevUpdate(void* dev) {
  uintptr_t d = reinterpret_cast<uintptr_t>(dev);
  int n = g_numDev.load(std::memory_order_relaxed);
  bool known = false;
  for (int i = 0; i < n; ++i) known |= g_dev[i].load(std::memory_order_relaxed) == d;
  if (!known && n < kMaxDev) {
    g_dev[n] = d;
    g_numDev = n + 1;
    __try {
      Log("Controle: dispositivo #%d = %p  tipo=%d  indice_xinput=%d  (chamado de exe+0x%llX)", n, dev,
          *reinterpret_cast<int*>(d + 0xE4), *reinterpret_cast<int*>(d + 0xE0),
          static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base));
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
  }
  g_orig(dev);
}

// Le um qword com protecao (a varredura pode passar do fim do objeto).
bool ReadQ(uintptr_t addr, uintptr_t* out) {
  __try {
    *out = *reinterpret_cast<const uintptr_t*>(addr);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

// ---------------------------------------------------------------- vigia de hardware
// Pontos de parada de dados (DR0..DR2) nos botoes dos dispositivos 0 e 1. Durante alguns segundos
// de luta, cada leitura gera uma excecao de passo unico; o tratador anota onde aconteceu.
constexpr int kMaxHits = 64;
struct Hit {
  std::atomic<uintptr_t> rip{0};
  uintptr_t ret = 0;
  int which = 0;
  std::atomic<uint32_t> count{0};
};
Hit g_hits[kMaxHits];
std::atomic<int> g_numHits{0};
std::atomic<int> g_watchState{0};  // 0 nunca, 1 ligado, 2 terminado
PVOID g_veh = nullptr;
uintptr_t g_watchAddr[3] = {};

LONG CALLBACK WatchHandler(EXCEPTION_POINTERS* ep) {
  if (ep->ExceptionRecord->ExceptionCode != EXCEPTION_SINGLE_STEP) return EXCEPTION_CONTINUE_SEARCH;
  DWORD64 dr6 = ep->ContextRecord->Dr6;
  if (!(dr6 & 0x7)) return EXCEPTION_CONTINUE_SEARCH;
  int which = (dr6 & 1) ? 0 : (dr6 & 2) ? 1 : 2;
  uintptr_t rip = uintptr_t(ep->ContextRecord->Rip);
  uintptr_t ret = 0;
  __try {
    ret = *reinterpret_cast<uintptr_t*>(ep->ContextRecord->Rsp);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  int n = g_numHits.load();
  int i = 0;
  for (; i < n; ++i)
    if (g_hits[i].rip.load() == rip && g_hits[i].which == which) break;
  if (i == n && n < kMaxHits && g_numHits.compare_exchange_strong(n, n + 1)) {
    g_hits[i].ret = ret;
    g_hits[i].which = which;
    g_hits[i].rip = rip;
  }
  if (i < kMaxHits) g_hits[i].count.fetch_add(1);
  ep->ContextRecord->Dr6 = 0;
  return EXCEPTION_CONTINUE_EXECUTION;
}

void SetDebugRegs(bool on) {
  HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
  if (snap == INVALID_HANDLE_VALUE) return;
  THREADENTRY32 te{sizeof(te)};
  DWORD pid = GetCurrentProcessId(), self = GetCurrentThreadId();
  int done = 0;
  for (BOOL ok = Thread32First(snap, &te); ok; ok = Thread32Next(snap, &te)) {
    if (te.th32OwnerProcessID != pid || te.th32ThreadID == self) continue;
    HANDLE th = OpenThread(THREAD_GET_CONTEXT | THREAD_SET_CONTEXT | THREAD_SUSPEND_RESUME, FALSE, te.th32ThreadID);
    if (!th) continue;
    if (SuspendThread(th) != DWORD(-1)) {
      CONTEXT c{};
      c.ContextFlags = CONTEXT_DEBUG_REGISTERS;
      if (GetThreadContext(th, &c)) {
        if (on) {
          c.Dr0 = g_watchAddr[0];
          c.Dr1 = g_watchAddr[1];
          c.Dr2 = g_watchAddr[2];
          // L0/L1/L2 ligados, leitura+escrita (11), 4 bytes (11)
          c.Dr7 = (1 << 0) | (1 << 2) | (1 << 4) | (0xFull << 16) | (0xFull << 20) | (0xFull << 24);
        } else {
          c.Dr0 = c.Dr1 = c.Dr2 = 0;
          c.Dr7 = 0;
        }
        if (SetThreadContext(th, &c)) ++done;
      }
      ResumeThread(th);
    }
    CloseHandle(th);
  }
  CloseHandle(snap);
  Log("Controle: vigia de hardware %s em %d threads", on ? "LIGADA" : "desligada", done);
}

// ---------------------------------------------------------------- registros de jogador
// FUN_140E12910(rec) atualiza o "controle do jogador" do jogo: rec+0 = numero do controle
// (0 = controle 1), pede o dispositivo ao gerenciador ([[[0x148D32FF8]+8]+8] vt+0x18) e grava
// botoes em rec+0x10..+0x20 e analogicos em rec+0x50..+0x56. O jogo cria 2 registros (P1, P2),
// de 0x7C bytes cada.
#define kRvaPlayerPadUpdate (Addr().playerPadUpdate)
using PadRec_t = void (*)(void* rec);
PadRec_t g_origRec = nullptr;
std::atomic<uintptr_t> g_rec[4];
std::atomic<int> g_numRec{0};

void HookPadRec(void* rec) {
  uintptr_t r = reinterpret_cast<uintptr_t>(rec);
  int n = g_numRec.load(std::memory_order_relaxed);
  bool known = false;
  for (int i = 0; i < n; ++i) known |= g_rec[i].load(std::memory_order_relaxed) == r;
  if (!known && n < 4) {
    g_rec[n] = r;
    g_numRec = n + 1;
    __try {
      Log("Controle: registro de jogador #%d = %p  controle=%d  (chamado de exe+0x%llX)", n, rec,
          *reinterpret_cast<int*>(r) + 1,
          static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(_ReturnAddress()) - g_base));
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
  }
  g_origRec(rec);
}

// ---------------------------------------------------------------- jogadores logicos
// FUN_140A0C680(obj): para cada jogador logico b < byte[obj+0xAEC], le o numero do controle em
// dword[[obj+0xAB8] + b*4] e copia o registro desse controle (FUN_140E12F50) para o buffer do
// jogador em [obj+0xAA0] + b*0x60. Registro+0x0C.. vira buffer+0x00.. (segurados em +0x0C).
#define kRvaLogicalPads (Addr().logicalPads)
using LogicalPads_t = void (*)(void* obj);
LogicalPads_t g_origLogical = nullptr;
std::atomic<uintptr_t> g_logicalObj{0};

void HookLogicalPads(void* obj) {
  uintptr_t o = reinterpret_cast<uintptr_t>(obj);
  if (g_logicalObj.exchange(o) != o) {
    __try {
      int count = *reinterpret_cast<uint8_t*>(o + 0xAEC);
      auto* map = *reinterpret_cast<uint32_t**>(o + 0xAB8);
      uintptr_t bufs = *reinterpret_cast<uintptr_t*>(o + 0xAA0);
      Log("Controle: objeto de jogadores logicos %p: %d jogadores, buffers em %p", obj, count,
          reinterpret_cast<void*>(bufs));
      for (int b = 0; b < count && b < 8 && map; ++b)
        Log("Controle:   jogador logico %d -> controle %u (buffer %p)", b, map[b] + 1,
            reinterpret_cast<void*>(bufs + b * 0x60));
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
  }
  g_origLogical(obj);
}

void InstallLogicalHook() {
  void* target = reinterpret_cast<void*>(g_base + kRvaLogicalPads);
  static const uint8_t kExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x20, 0x55, 0x56, 0x57, 0x41, 0x56};
  if (std::memcmp(target, kExpect, sizeof(kExpect)) != 0) {
    Log("Controle: bytes de FUN_140A0C680 diferentes; jogadores logicos nao observados.");
    return;
  }
  MH_STATUS st = MH_CreateHook(target, reinterpret_cast<void*>(&HookLogicalPads),
                               reinterpret_cast<void**>(&g_origLogical));
  if (st == MH_OK) st = MH_EnableHook(target);
  Log("Controle: observacao dos jogadores logicos %s", st == MH_OK ? "instalada" : MH_StatusToString(st));
}

void InstallRecHook() {
  InstallLogicalHook();
  void* target = reinterpret_cast<void*>(g_base + kRvaPlayerPadUpdate);
  static const uint8_t kExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x18, 0x48, 0x89, 0x7C, 0x24, 0x20};
  if (std::memcmp(target, kExpect, sizeof(kExpect)) != 0) {
    Log("Controle: bytes de FUN_140E12910 diferentes; registros nao observados.");
    return;
  }
  MH_STATUS st = MH_CreateHook(target, reinterpret_cast<void*>(&HookPadRec), reinterpret_cast<void**>(&g_origRec));
  if (st == MH_OK) st = MH_EnableHook(target);
  Log("Controle: observacao dos registros de jogador %s", st == MH_OK ? "instalada" : MH_StatusToString(st));
}
}  // namespace

void PadsWatchTick(bool battleActive) {
  int st = g_watchState.load();
  uintptr_t lo = g_logicalObj.load();
  uintptr_t bufs = 0;
  if (lo) {
    __try {
      bufs = *reinterpret_cast<uintptr_t*>(lo + 0xAA0);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
  }
  if (st == 0 && battleActive && bufs) {
    g_watchAddr[0] = bufs + 0x0C;         // jogador logico 1: botoes segurados
    g_watchAddr[1] = bufs + 0x04;         // jogador logico 1: botoes apertados agora
    g_watchAddr[2] = bufs + 0x60 + 0x0C;  // jogador logico 2: botoes segurados
    if (!g_veh) g_veh = AddVectoredExceptionHandler(1, WatchHandler);
    SetDebugRegs(true);
    g_watchState = 1;
  } else if (st == 1) {
    SetDebugRegs(false);
    g_watchState = 2;
    const char* names[3] = {"J.logico1 segurados", "J.logico1 apertados", "J.logico2 segurados"};
    int n = g_numHits.load();
    Log("Controle: %d pontos de codigo acessaram os botoes:", n);
    for (int i = 0; i < n; ++i) {
      uintptr_t rip = g_hits[i].rip.load(), ret = g_hits[i].ret;
      Log("  [%s] exe+0x%llX (retorno exe+0x%llX) x%u", names[g_hits[i].which],
          static_cast<unsigned long long>(rip - g_base),
          static_cast<unsigned long long>(ret >= g_base && ret - g_base < 0x10000000 ? ret - g_base : 0),
          g_hits[i].count.load());
    }
  }
}

bool PadsInstall() {
  void* target = reinterpret_cast<void*>(g_base + kRvaDevUpdate);
  static const uint8_t kExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x74, 0x24, 0x10};
  if (std::memcmp(target, kExpect, sizeof(kExpect)) != 0) {
    Log("Controle: bytes de FUN_1401B5620 diferentes; diagnostico desativado.");
    return false;
  }
  MH_STATUS st = MH_CreateHook(target, reinterpret_cast<void*>(&HookDevUpdate), reinterpret_cast<void**>(&g_orig));
  if (st == MH_OK) st = MH_EnableHook(target);
  Log("Controle: diagnostico de dispositivos %s", st == MH_OK ? "instalado" : MH_StatusToString(st));
  InstallRecHook();
  return st == MH_OK;
}

void PadsScanFighter(int index, int side, int row, uintptr_t player) {
  int nd = g_numDev.load();
  if (nd == 0 || !player) return;
  int hits = 0;
  for (size_t off = 0; off < kPlayerScan && hits < 24; off += 8) {
    uintptr_t v;
    if (!ReadQ(player + off, &v)) break;
    for (int i = 0; i < nd; ++i) {
      uintptr_t d = g_dev[i].load();
      if (v >= d && v < d + kDevSpan) {
        Log("Controle: J%d (lado %d pos %d) lutador+0x%zX -> dispositivo #%d +0x%llX", side * 3 + row + 1, side,
            row, off, i, static_cast<unsigned long long>(v - d));
        ++hits;
      }
    }
  }
  if (!hits) Log("Controle: J%d (lado %d pos %d) sem ponteiro direto para dispositivos", side * 3 + row + 1, side, row);
  (void)index;
}

// ---------------------------------------------------------------- co-op: campo de botoes do lutador
// A cada quadro (thread do jogo), quando os botoes segurados do jogador logico 1 (controle 1) mudam,
// procura esse valor dentro do lutador J1. O campo que bate quase sempre e o "controle" que o lutador
// obedece; a CPU escreve no mesmo campo dos extras. So leitura.
namespace {
constexpr size_t kCorrBytes = 0x18000;
constexpr size_t kCorrWords = kCorrBytes / 4;
uint16_t g_corrHit[kCorrWords];
uint16_t g_corrMiss[kCorrWords];
uint32_t g_corrSnap[kCorrWords];
uintptr_t g_corrPlayer = 0;
uint32_t g_corrLast = 0;
int g_corrChanges = 0;
int g_corrReports = 0;

size_t PageCopy(void* dst, uintptr_t src, size_t size) {
  size_t done = 0;
  while (done < size) {
    size_t chunk = 0x1000 - ((src + done) & 0xFFF);
    if (chunk > size - done) chunk = size - done;
    __try {
      std::memcpy(static_cast<uint8_t*>(dst) + done, reinterpret_cast<const void*>(src + done), chunk);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      break;
    }
    done += chunk;
  }
  return done;
}

uint32_t ReadHeldP1() {
  uintptr_t lo = g_logicalObj.load(std::memory_order_relaxed);
  if (!lo) return 0;
  __try {
    uintptr_t bufs = *reinterpret_cast<uintptr_t*>(lo + 0xAA0);
    return bufs ? *reinterpret_cast<uint32_t*>(bufs + 0x0C) : 0;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return 0;
  }
}
}  // namespace

void PadsCorrelate(uintptr_t player) {
  if (!player) return;
  if (player != g_corrPlayer) {
    g_corrPlayer = player;
    std::memset(g_corrHit, 0, sizeof(g_corrHit));
    std::memset(g_corrMiss, 0, sizeof(g_corrMiss));
    g_corrLast = 0;
    g_corrChanges = 0;
    g_corrReports = 0;
  }
  uint32_t held = ReadHeldP1();
  if (held == g_corrLast) return;
  g_corrLast = held;
  if (!held) return;
  size_t got = PageCopy(g_corrSnap, player, kCorrBytes) / 4;
  for (size_t i = 0; i < got; ++i) {
    if (g_corrSnap[i] == held) {
      if (g_corrHit[i] < 0xFFFF) ++g_corrHit[i];
    } else if (g_corrHit[i] && g_corrMiss[i] < 0xFFFF) {
      ++g_corrMiss[i];
    }
  }
  ++g_corrChanges;
  if (g_corrChanges % 40 == 0 && g_corrReports < 3) {
    ++g_corrReports;
    int shown = 0;
    Log("Co-op: %d mudancas de botoes do controle 1; campos do J1 que acompanham:", g_corrChanges);
    for (int pass = 0; pass < 2 && shown < 20; ++pass)
      for (size_t i = 0; i < kCorrWords && shown < 20; ++i) {
        bool strong = g_corrHit[i] >= g_corrChanges * 3 / 4;
        bool weak = !strong && g_corrHit[i] >= 10 && g_corrMiss[i] * 4 <= g_corrHit[i];
        if ((pass == 0 && strong) || (pass == 1 && weak)) {
          Log("Co-op:   J1+0x%05zX  acertos=%u  erros=%u", i * 4, g_corrHit[i], g_corrMiss[i]);
          ++shown;
        }
      }
    if (!shown) Log("Co-op:   nenhum campo acompanhou os botoes ainda.");
  }
}
