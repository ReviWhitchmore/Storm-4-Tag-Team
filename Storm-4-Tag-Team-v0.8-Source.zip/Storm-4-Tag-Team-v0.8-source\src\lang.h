#pragma once
// Idioma dos textos desenhados pelo mod (menus, Chronicles, faixas de luta).
// storm6.ini: idioma=en para ingles; sem a chave (ou idioma=pt) fica em portugues, como sempre foi.
// Os textos do proprio jogo seguem o idioma escolhido na Steam.
bool LangEnglish();
inline const char* Lang(const char* pt, const char* en) { return LangEnglish() ? en : pt; }
