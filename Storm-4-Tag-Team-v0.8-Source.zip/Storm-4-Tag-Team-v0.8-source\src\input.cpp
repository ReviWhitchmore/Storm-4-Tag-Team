// Controles do 3v3: roteamento individual e troca de alvo no analogico direito.

#include "input.h"

#include <windows.h>
#include <Xinput.h>
#include <MinHook.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <cstring>

#include "addresses.h"
#include "camera.h"
#include "scene_probe.h"
#include "chronicles.h"
#include "parry.h"
#include "grab_defense.h"
#include "jutsu_clash.h"
#include "census.h"
#include "log.h"
#include "menu.h"
#include "promote.h"
#include "settings.h"
#include "runtime_quality_rules.h"
#include "ult.h"

namespace {

using XInputGetState_t = DWORD(WINAPI*)(DWORD, XINPUT_STATE*);
XInputGetState_t g_orig = nullptr;

constexpr SHORT kTrigger = 20000;  // quanto inclinar para contar uma troca
constexpr SHORT kRearm = 8000;     // precisa voltar perto do centro para a proxima
std::atomic<bool> g_armed[XUSER_MAX_COUNT] = {true, true, true, true};
std::atomic<bool> g_thumbDown[XUSER_MAX_COUNT] = {};
std::atomic<bool> g_teamButtonHeld[XUSER_MAX_COUNT] = {};
// ccPlayer+0x218 contem o estado de comandos, com o leitor em +0x5B8.
constexpr uintptr_t kBattlePadOffset = 0x218 + 0x5B8;
using BattlePadReadFn = void (*)(void*, uint8_t*);
using PhysicalPadReadFn = int (*)(int, void*);
BattlePadReadFn g_origBattlePadRead = nullptr;
PhysicalPadReadFn g_readPhysicalPad = nullptr;
std::atomic<bool> g_battlePadReady{false};
std::atomic<bool> g_routeLogged[XUSER_MAX_COUNT] = {};
std::atomic<bool> g_lastPadConnection[XUSER_MAX_COUNT] = {};

void HookBattlePadRead(void* backend, uint8_t* entry) {
  const uintptr_t player = reinterpret_cast<uintptr_t>(backend) - kBattlePadOffset;
  const int pad = PromotePadForPlayer(player);
  if (pad < 0) {
    g_origBattlePadRead(backend, entry);
    return;
  }

  // A rotina nativa retorna o pacote traduzido do controle fisico. O indice
  // em entry+0 e o perfil do lutador e deve continuar no slot que o jogo criou.
  uint8_t physical[0x60]{};
  const bool connected = g_readPhysicalPad(pad, physical) != 0;
  std::memset(entry + 0x04, 0, 0x24);
  if (connected) {
    std::memcpy(entry + 0x04, physical + 0x18, 0x08);
    std::memcpy(entry + 0x0C, physical + 0x10, 0x08);
    std::memcpy(entry + 0x14, physical + 0x20, 0x04);
    std::memcpy(entry + 0x18, physical + 0x28, 0x10);
  }
  const bool alreadyLogged = g_routeLogged[pad].exchange(true, std::memory_order_relaxed);
  const bool previousConnected = g_lastPadConnection[pad].exchange(connected, std::memory_order_relaxed);
  if (!alreadyLogged || previousConnected != connected)
    Log("Co-op: Player %d para lutador %p (conectado=%d%s)",
        pad + 1, reinterpret_cast<void*>(player), connected,
        alreadyLogged ? ", conexao mudou" : "");
}

// Fora da luta, o controle 2 comanda o mesmo cursor do controle 1: no modo contra a CPU a tela de
// selecao tem um cursor so por equipe, e assim o segundo jogador escolhe o personagem dele.
SHORT StrongerAxis(SHORT a, SHORT b) { return std::abs(int(b)) > std::abs(int(a)) ? b : a; }

void AddSecondPad(XINPUT_GAMEPAD& into, const XINPUT_GAMEPAD& pad) {
  into.wButtons |= pad.wButtons;
  into.bLeftTrigger = std::max(into.bLeftTrigger, pad.bLeftTrigger);
  into.bRightTrigger = std::max(into.bRightTrigger, pad.bRightTrigger);
  into.sThumbLX = StrongerAxis(into.sThumbLX, pad.sThumbLX);
  into.sThumbLY = StrongerAxis(into.sThumbLY, pad.sThumbLY);
  into.sThumbRX = StrongerAxis(into.sThumbRX, pad.sThumbRX);
  into.sThumbRY = StrongerAxis(into.sThumbRY, pad.sThumbRY);
}

// Verificacao de controles no menu: ultimo estado bruto de cada controle.
SRWLOCK g_padLock = SRWLOCK_INIT;
XINPUT_GAMEPAD g_pad[XUSER_MAX_COUNT] = {};
bool g_padConnected[XUSER_MAX_COUNT] = {};
ULONGLONG g_padTick[XUSER_MAX_COUNT] = {};

// Quem gira a camera do torneio: o P1 e quem joga na mesma equipe dele. Se dois mexerem, vale o mais forte.
std::atomic<float> g_padYaw[XUSER_MAX_COUNT] = {};

bool CameraPad(DWORD index);

void SetPadYaw(DWORD index, float value) {
  g_padYaw[index].store(value, std::memory_order_relaxed);
  float strongest = 0;
  for (DWORD pad = 0; pad < XUSER_MAX_COUNT; ++pad) {
    // A controller that changed teams or is now on CPU must not keep
    // rotating the camera with the previous battle's cached thumbstick.
    if (!CameraPad(pad)) {
      g_padYaw[pad].store(0, std::memory_order_relaxed);
      continue;
    }
    const float other = g_padYaw[pad].load(std::memory_order_relaxed);
    if (std::fabs(other) > std::fabs(strongest)) strongest = other;
  }
  CameraSetYawInput(strongest);
}

bool CameraPad(DWORD index) {
  const int own = PromoteFighterForPad(int(index));
  const int side = PromoteFighterSide(own);
  if (side < 0) return false;
  // The first assigned local pad is the camera owner, even if J1 is CPU.
  for (int pad = 0; pad < 4; ++pad) {
    const int first = PromoteFighterForPad(pad);
    const int leaderSide = PromoteFighterSide(first);
    if (leaderSide >= 0) return side == leaderSide;
  }
  return false;
}

DWORD WINAPI HookGetState(DWORD index, XINPUT_STATE* state) {
  DWORD r = SceneAutotestInput(index, state, g_orig(index, state));
  if (index < XUSER_MAX_COUNT) {
    AcquireSRWLockExclusive(&g_padLock);
    g_padConnected[index] = r == ERROR_SUCCESS && state;
    if (g_padConnected[index]) g_pad[index] = state->Gamepad;
    g_padTick[index] = GetTickCount64();
    ReleaseSRWLockExclusive(&g_padLock);
  }
  if (index == 0) MenuInput(r == ERROR_SUCCESS ? state : nullptr);
  // Menu do mod aberto: NENHUM controle chega ao jogo (antes so o controle 1 era zerado; o controle 2 - ou o mesmo
  // controle aparecendo duas vezes no Windows - navegava e confirmava no menu do jogo que fica atras do painel).
  if (state && index < XUSER_MAX_COUNT && MenuBlocksGameInput()) ZeroMemory(&state->Gamepad, sizeof(state->Gamepad));
  ParryObserveGuard(index,state,r==ERROR_SUCCESS);
  GrabDefenseObserveGuard(index,state,r==ERROR_SUCCESS);
  JutsuClashObservePad(index,state,r==ERROR_SUCCESS);
  if (r == ERROR_SUCCESS && state && index <= 1 && Cfg().selectP2.load() && !PromoteReservesRightStick() &&
      !MenuIsOpen()) {
    // O proprio controle 2 fica mudo para o jogo nao receber o mesmo botao duas vezes.
    if (index == 1) {
      ZeroMemory(&state->Gamepad, sizeof(state->Gamepad));
    } else {
      XINPUT_STATE second{};
      if (g_orig(1, &second) == ERROR_SUCCESS) AddSecondPad(state->Gamepad, second.Gamepad);
    }
  }
  // The native game-mode menu is identified by its own scene update hook.
  // Input is blocked ONLY while the in-game Chronicles chapter panel is open.
  if(index==0)ChroniclesGamepadInput(r==ERROR_SUCCESS?state:nullptr);
  if (r != ERROR_SUCCESS || !state || index >= XUSER_MAX_COUNT || !PromoteReservesRightStick()) {
    if (index < XUSER_MAX_COUNT) {
      g_armed[index] = true;
      g_teamButtonHeld[index] = false;
      SetPadYaw(index, 0);
    }
    return r;
  }

  const WORD teamButton = Cfg().teamUltimateButton.load(std::memory_order_relaxed) == 0
      ? XINPUT_GAMEPAD_LEFT_SHOULDER : XINPUT_GAMEPAD_RIGHT_SHOULDER;
  const bool teamDown = (state->Gamepad.wButtons & teamButton) != 0;
  if (!teamDown) g_teamButtonHeld[index].store(false, std::memory_order_relaxed);
  else if (Cfg().teamUltimate.load(std::memory_order_relaxed) &&
           !Cfg().freeForAll.load(std::memory_order_relaxed) &&
           Addr().timestamp == 0x5889906E &&
           !g_teamButtonHeld[index].exchange(true, std::memory_order_relaxed))
    UltTeamButtonPressed(int(index));
  // Shoulder chosen for team ultimate is dedicated to this action in combat.
  if (Cfg().teamUltimate.load(std::memory_order_relaxed) &&
      !Cfg().freeForAll.load(std::memory_order_relaxed) &&
      Addr().timestamp == 0x5889906E) state->Gamepad.wButtons &= ~teamButton;
  SHORT rx = state->Gamepad.sThumbRX;
  SHORT ry = state->Gamepad.sThumbRY;
  // Torneio: o analogico direito do P1 e dos colegas dele gira a camera; o R3 de qualquer jogador troca o alvo.
  const int cameraMode = Cfg().camera.load(std::memory_order_relaxed);
  const bool tournament = cameraMode == kCameraTournament;
  const bool revolution = cameraMode == kCameraRevolution;
  const bool revolutionLock = revolution &&
      Cfg().lockonStyle.load(std::memory_order_relaxed) == 2;
  const bool thumb = (state->Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB) != 0;
  // Analog-right flicks select a target; R3 can also advance to next opponent.
  if (tournament || revolution) {
    state->Gamepad.wButtons &= ~XINPUT_GAMEPAD_RIGHT_THUMB;
    if (!thumb) g_thumbDown[index] = false;
    else if (!g_thumbDown[index].exchange(true) && PromoteBattleActive() && Cfg().lockon.load()) {
      if (revolutionLock) PromoteToggleRevolutionLock(PromoteFighterForPad(index));
      else PromoteCycleTarget(PromoteFighterForPad(index), +1);
    }
  }
  const bool turnsCamera = tournament && CameraPad(index);
  SetPadYaw(index, turnsCamera ? rx / 32768.0f : 0.0f);
  if (turnsCamera) {
    // O analogico fica com a camera.
  } else if (revolutionLock
      ? (std::abs(int(rx)) > kTrigger || std::abs(int(ry)) > kTrigger)
      : (rx > kTrigger || rx < -kTrigger)) {
    if (g_armed[index].exchange(false) && PromoteBattleActive() && Cfg().lockon.load()) {
      if (revolutionLock)
        PromoteDirectionalRevolutionTarget(PromoteFighterForPad(index),
                                           rx/32768.0f,ry/32768.0f);
      else
        PromoteCycleTarget(PromoteFighterForPad(index),rx>0 ? +1 : -1);
    }
  } else if (rx < kRearm && rx > -kRearm &&
             (!revolutionLock || (ry < kRearm && ry > -kRearm))) {
    g_armed[index] = true;
  }
  state->Gamepad.sThumbRX = 0;
  state->Gamepad.sThumbRY = 0;
  return r;
}

}  // namespace

bool InputInstallBattle() {
  void* target = reinterpret_cast<void*>(g_base + Addr().battlePadRead);
  const auto* physical = reinterpret_cast<const uint8_t*>(g_base + Addr().physicalPadRead);
  static const uint8_t kBattleExpected[] = {0x40, 0x53, 0x48, 0x83, 0xEC, 0x20, 0x48, 0x8B, 0x0D};
  static const uint8_t kPhysicalExpected[] = {0x44, 0x8B, 0xC1, 0x48, 0x8B, 0x0D};
  if (std::memcmp(target, kBattleExpected, sizeof(kBattleExpected)) != 0 ||
      std::memcmp(physical, kPhysicalExpected, sizeof(kPhysicalExpected)) != 0) {
    Log("Co-op: rotinas de controle diferentes do esperado.");
    return false;
  }
  g_readPhysicalPad = reinterpret_cast<PhysicalPadReadFn>(physical);
  MH_STATUS status = MH_CreateHook(target, reinterpret_cast<void*>(&HookBattlePadRead),
                                   reinterpret_cast<void**>(&g_origBattlePadRead));
  if (status == MH_OK) status = MH_EnableHook(target);
  g_battlePadReady = status == MH_OK;
  Log("Co-op: roteamento por lutador %s", status == MH_OK ? "instalado" : MH_StatusToString(status));
  return status == MH_OK;
}

bool InputBattleReady() { return g_battlePadReady.load(); }

bool InputPhysicalPad(int index, uint8_t* out128) {
  if (!g_readPhysicalPad || index < 0 || index > 7 || !out128) return false;
  std::memset(out128, 0, 0x80);
  __try {
    return g_readPhysicalPad(index, out128) != 0;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

void InputClashPollRaw(int padA, int padB) {
  if (!g_orig) return;
  const int pads[2] = {padA, padB};
  for (int k = 0; k < 2; ++k) {
    const int p = pads[k];
    if (p < 0 || p >= XUSER_MAX_COUNT || (k == 1 && p == pads[0])) continue;
    // Raw XInput is essential here: the Storm 4 battle loop may stop polling
    // after the participating characters are paused by Jutsu Clash.
    XINPUT_STATE raw{};
    const DWORD status = g_orig(DWORD(p), &raw);
    JutsuClashObservePad(DWORD(p), status == ERROR_SUCCESS ? &raw : nullptr, status == ERROR_SUCCESS);
  }
}

// A native gamepad hook already observes the physical connection on every
// successful GetState. Use that cached result for the judge/HUD thread rather
// than issuing up to four EXTRA XInput calls every game frame. If the game
// stops polling an unplugged/reconnected pad, refresh the cache periodically.
bool InputPadConnected(int index) {
  if(index<0 || index>=XUSER_MAX_COUNT)return false;
  if(!g_orig)return true; // preserve previous fallback
  const ULONGLONG now=GetTickCount64();
  AcquireSRWLockShared(&g_padLock);
  const ULONGLONG observed=g_padTick[index];
  const bool connected=g_padConnected[index];
  ReleaseSRWLockShared(&g_padLock);
  if(RuntimePadCacheFresh(observed,now))return connected;
  XINPUT_STATE state{};
  const bool live=g_orig(DWORD(index),&state)==ERROR_SUCCESS;
  AcquireSRWLockExclusive(&g_padLock);
  g_padConnected[index]=live;
  if(live)g_pad[index]=state.Gamepad;
  g_padTick[index]=now;
  ReleaseSRWLockExclusive(&g_padLock);
  return live;
}

void InputBeginBattle() {
  for (auto& logged : g_routeLogged) logged.store(false, std::memory_order_relaxed);
}

bool InputPadStatus(int index, XINPUT_GAMEPAD* out) {
  if (index < 0 || index >= XUSER_MAX_COUNT) return false;
  AcquireSRWLockShared(&g_padLock);
  bool ok = g_padConnected[index] && GetTickCount64() - g_padTick[index] < 2000;
  if (ok && out) *out = g_pad[index];
  ReleaseSRWLockShared(&g_padLock);
  return ok;
}

// Teclado do jogo (Raw Input e GetKeyState): com o menu do mod aberto as teclas nao chegam ao jogo. Antes, setas e
// Enter andavam e confirmavam no menu do mod E no menu do jogo atras dele ao mesmo tempo.
using GetRawInputData_t = UINT(WINAPI*)(HRAWINPUT, UINT, LPVOID, PUINT, UINT);
using GetKeyState_t = SHORT(WINAPI*)(int);
GetRawInputData_t g_origRawInput = nullptr;
GetKeyState_t g_origKeyState = nullptr;
UINT WINAPI HookGetRawInputData(HRAWINPUT input, UINT command, LPVOID data, PUINT size, UINT header) {
  const UINT r = g_origRawInput(input, command, data, size, header);
  if (data && command == RID_INPUT && r != UINT(-1) && r >= sizeof(RAWINPUTHEADER) && MenuBlocksGameInput()) {
    auto* raw = static_cast<RAWINPUT*>(data);
    if (raw->header.dwType == RIM_TYPEKEYBOARD) {
      raw->data.keyboard.VKey = 0xFF;  // tecla inexistente: o jogo ignora
      raw->data.keyboard.MakeCode = 0;
    }
  }
  return r;
}
SHORT WINAPI HookGetKeyState(int key) {
  const SHORT r = g_origKeyState(key);
  return MenuBlocksGameInput() ? 0 : r;
}
void InstallKeyboardBlock() {
  static bool done = false;
  if (done) return;
  done = true;
  HMODULE user = GetModuleHandleW(L"user32.dll");
  void* raw = user ? reinterpret_cast<void*>(GetProcAddress(user, "GetRawInputData")) : nullptr;
  void* keyState = user ? reinterpret_cast<void*>(GetProcAddress(user, "GetKeyState")) : nullptr;
  MH_STATUS a = raw ? MH_CreateHook(raw, reinterpret_cast<void*>(&HookGetRawInputData),
                                    reinterpret_cast<void**>(&g_origRawInput)) : MH_ERROR_FUNCTION_NOT_FOUND;
  if (a == MH_OK) a = MH_EnableHook(raw);
  MH_STATUS b = keyState ? MH_CreateHook(keyState, reinterpret_cast<void*>(&HookGetKeyState),
                                         reinterpret_cast<void**>(&g_origKeyState)) : MH_ERROR_FUNCTION_NOT_FOUND;
  if (b == MH_OK) b = MH_EnableHook(keyState);
  Log("Menu: teclado do jogo bloqueado com o menu aberto (Raw Input %s, GetKeyState %s).",
      a == MH_OK ? "ok" : MH_StatusToString(a), b == MH_OK ? "ok" : MH_StatusToString(b));
}

bool InputTryInstall() {
  InstallKeyboardBlock();
  const wchar_t* names[] = {L"xinput9_1_0.dll", L"xinput1_4.dll", L"xinput1_3.dll"};
  for (const wchar_t* name : names) {
    HMODULE mod = GetModuleHandleW(name);
    if (!mod) continue;
    void* target = reinterpret_cast<void*>(GetProcAddress(mod, "XInputGetState"));
    if (!target) continue;
    MH_STATUS st = MH_CreateHook(target, reinterpret_cast<void*>(&HookGetState),
                                 reinterpret_cast<void**>(&g_orig));
    if (st == MH_OK) st = MH_EnableHook(target);
    Log("Lock-on: hook do controle em %ls %s", name, st == MH_OK ? "instalado" : MH_StatusToString(st));
    return st == MH_OK;
  }
  return false;
}
