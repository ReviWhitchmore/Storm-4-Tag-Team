#pragma once
#include <cstdint>
#include "cpu_adapt_rules.h"
// Coordenador opcional, compatibilidade 3v3/FFA e variacao discreta por personagem.
// ia_adaptativa=1 habilita, ia_nivel=0..3 altera frequencia, ia_parry_cpu=0..100.
void CpuAdaptInstall();
bool CpuAdaptEnabled();
unsigned CpuAdaptChance(unsigned base,uintptr_t player,cpuai::Action action,bool danger=false);
float CpuAdaptMashRate(float base,uintptr_t player);
unsigned CpuAdaptParryBaseChance();
bool CpuAdaptTeamUltimateEnabled();
bool CpuAdaptEnemy(int fighterA,int sideA,int fighterB,int sideB,bool ffa);
