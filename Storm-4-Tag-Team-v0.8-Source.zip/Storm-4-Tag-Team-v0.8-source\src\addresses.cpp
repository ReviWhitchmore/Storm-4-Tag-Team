#include "addresses.h"

namespace {

const GameAddrs kStorm4_109 = {
    "Storm 4 1.09 (NSUNS4.exe)", 0x5EF2F684,
    /*choke*/ 0x74B36C, /*chokeRetInWrapper*/ 0x74B18D, /*duelGlobal*/ 0x161C8C8,
    /*createInner*/ 0x74DDB8, /*sideConfigBase*/ 0x1611A80, /*memberSetup*/ 0x74E4C0, /*judge*/ 0x74D248,
    /*teardownClean*/ 0x74E434, /*teardownRemove*/ 0x74E04C,
    /*setPosition*/ 0xAC30E0, /*resetMotion*/ 0x7930D8,
    /*camTrack*/ 0x783950, /*anyDirection*/ 0x76C770, /*directionType*/ 0x76C79C, /*ultimateCreate*/ 0x7DC1F4, /*sceneStart*/ 0x76BA88, /*ultConfigRoleReturn: actor config role*/ 0x7E748E,
    /*dirCodeBegin*/ 0x76B000, /*dirCodeEnd*/ 0x76E000,
    /*hitSceneReturn*/ 0x78A3BA, /*preUltimateSceneReturn*/ 0x7DC479, /*ultimateSceneReturn*/ 0x7DC334,
    /*team ultimate scene routing not verified*/ 0, 0, 0, 0, 0, 0, 0,
    /*setView*/ 0xAC8590, /*duelViewReturn*/ 0x744032, /*duelCamLeaderSite*/ 0x742924,
    /*cameraStage*/ 0x1617840, /*cameraSweep*/ 0x8553B4, /*cameraSweepInit*/ 0x20D2F4,
    /*devUpdate*/ 0x1B5620, /*playerPadUpdate*/ 0xE12910, /*logicalPads*/ 0xA0C680,
    /*battlePadRead*/ 0xAD2220, /*physicalPadRead*/ 0xE12F50, /*faceIcon*/ 0x527F90,
    /*vtChangeState*/ 0xDA8,
};

// Evolution: mesmas funcoes, outros enderecos; a tabela virtual do lutador fica 0x10 antes
// (vt+0x1590 -> 0x1580, 0x13A0 -> 0x1390, 0xDA8 -> 0xD98, 0x16F8 -> 0x16E8).
const GameAddrs kStorm4_Evolution = {
    "Storm 4 Evolution (NSUNS4e.exe)", 0x5889906E,
    /*choke*/ 0x746CE8, /*chokeRetInWrapper*/ 0x746B09, /*duelGlobal*/ 0x1609B88,
    /*createInner*/ 0x749738, /*sideConfigBase*/ 0x15FED30, /*memberSetup*/ 0x749E40, /*judge*/ 0x748BC8,
    /*teardownClean*/ 0x749DB4, /*teardownRemove*/ 0x7499CC,
    /*setPosition*/ 0xABFAF0, /*resetMotion*/ 0x78E188,
    /*camTrack*/ 0x77EAE8, /*anyDirection*/ 0x767BFC, /*directionType*/ 0x767C28, /*ultimateCreate*/ 0x7D6D34, /*sceneStart*/ 0x766F14, /*ultConfigRoleReturn*/ 0x7E22BE,
    /*dirCodeBegin*/ 0x76648C, /*dirCodeEnd*/ 0x76948C,
    /*hitSceneReturn*/ 0x7854EA, /*preUltimateSceneReturn*/ 0x7D6FB9, /*ultimateSceneReturn*/ 0x7D6E74,
    /*teamReady*/ 0x7D9BE0, /*teamReadyChargeReturn*/ 0x7C3C62, /*teamReadyAttackReturn*/ 0x7C3CA0,
    /*teamGauge*/ 0x7D9988, /*teamGaugeAttackReturn*/ 0x7DAFC1, /*teamIntroReturn*/ 0x7D250C, /*teamSceneReturn*/ 0x7D7072,
    /*setView*/ 0xAC4C60, /*duelViewReturn*/ 0x73F742, /*duelCamLeaderSite*/ 0x73E034,
    /*cameraStage*/ 0x1604AF0, /*cameraSweep*/ 0x8505D8, /*cameraSweepInit*/ 0x20CC4C,
    /*devUpdate*/ 0x1B4BC0, /*playerPadUpdate*/ 0xE0DF70, /*logicalPads*/ 0xA08270,
    /*battlePadRead*/ 0xACE990, /*physicalPadRead*/ 0xE0E5B0, /*faceIcon*/ 0x527284,
    /*vtChangeState*/ 0xD98,
};

const GameAddrs* g_current = &kStorm4_109;

}  // namespace

bool AddrSelect(uint32_t timestamp) {
  static const GameAddrs* const kAll[] = {&kStorm4_109, &kStorm4_Evolution};
  for (const GameAddrs* a : kAll)
    if (a->timestamp == timestamp) {
      g_current = a;
      return true;
    }
  return false;
}

const GameAddrs& Addr() { return *g_current; }
