#pragma once
#include <cstdint>
// Transfer ownership from the pre-ultimate cinematic (scene 8) to the
// executable's ultimate animation (scene 9). A scene 9 may use the ORIGINAL
// team leader register even though a different on-field fighter started it.
// Only transfer to the very next same-side, same-victim scene 9.
inline bool UltimateSameCasterTransition(int preparedSide,int preparedOwner,
                                        int preparedVictim,int newSide,
                                        int newVictim,uint64_t elapsedMs,
                                        int totalFighters) {
  return preparedSide>=0 && preparedSide<2 &&
         newSide==preparedSide && preparedOwner>=0 &&
         preparedOwner<totalFighters && preparedVictim>=0 &&
         preparedVictim<totalFighters && preparedVictim!=preparedOwner &&
         newVictim==preparedVictim && totalFighters>=2 &&
         totalFighters<=6 && elapsedMs<=2500;
}
// Supremo preparado (cena 8) que acerta OUTRO adversario no caminho, nao o alvo da preparacao
// (visto no C38: J2 mirou J5 e acertou J6). Enquanto quem preparou ainda esta no avanco do Supremo
// (estados nativos 0x87 ativacao, 0x88 avanco, 0x89 acerto), o acerto e dele, e nao do lider.
inline bool UltimateDashHit(int preparedSide,int preparedOwner,int ownerState,
                            int newSide,int newVictimSide,uint64_t elapsedMs,
                            int totalFighters) {
  return preparedSide>=0 && preparedSide<2 && newSide==preparedSide &&
         preparedOwner>=0 && preparedOwner<totalFighters &&
         totalFighters>=2 && totalFighters<=6 &&
         newVictimSide==1-preparedSide &&
         ownerState>=0x87 && ownerState<=0x89 && elapsedMs<=6000;
}
