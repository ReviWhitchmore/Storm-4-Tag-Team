// Censo das buscas de membros do duelo.
//
// Quase tudo no jogo encontra um lutador perguntando "membro do lado S com
// papel R". Essas perguntas terminam em FUN_14074B36C(time, papel), que
// percorre o std::map do time e devolve &no->valor do primeiro membro cujo
// papel bate. O wrapper FUN_14074B184 chama essa funcao e devolve o lutador;
// Leader/Support saltam (jmp) para o wrapper, entao o endereco de retorno do
// wrapper e o ponto real do jogo que fez a pergunta.
//
// Este hook so observa: conta (ponto, lado, papel) e se a resposta existia.
// Nada na partida muda. O resultado vai para census.csv na pasta do jogo.

#include "census.h"

#include <windows.h>
#include <MinHook.h>
#include <intrin.h>

#include <atomic>
#include <cstdio>
#include <string>

#include "addresses.h"
#include "log.h"
#include "promote.h"

uintptr_t g_base = 0;

namespace {

// Enderecos relativos (RVA) no NSUNS4.exe 1.09, TimeDateStamp 0x5EF2F684
#define kRvaChoke (Addr().choke)  // FUN_14074B36C(team, role) -> &node->value
#define kRvaChokeRetInWrapper (Addr().chokeRetInWrapper)  // retorno dentro de FUN_14074B184
#define kRvaDuelGlobal (Addr().duelGlobal)  // *duel
constexpr uintptr_t kTeamOffset = 0x18;             // duel + 0x18 + side*0x68 = time
constexpr uintptr_t kTeamStride = 0x68;

using Choke_t = void** (*)(void* team, int role);
Choke_t g_choke = nullptr;

// Tabela de contagem sem trava (endereco aberto).
constexpr size_t kSlots = 1 << 14;
struct Entry {
  std::atomic<uint64_t> key{0};  // 0 = vazio
  std::atomic<uint64_t> calls{0};
  std::atomic<uint64_t> found{0};
  std::atomic<uint64_t> viaWrapper{0};
};
Entry g_table[kSlots];
std::atomic<uint64_t> g_total{0};
std::atomic<uint64_t> g_dropped{0};
std::atomic<uintptr_t> g_lastDuel{0};
bool g_diagnosticsEnabled=false;

// chave: site (32 bits) | papel (8) | lado+1 (8) | 1 no bit 63 para nunca ser 0
inline uint64_t MakeKey(uint32_t site, int role, int side) {
  return (1ull << 63) | (uint64_t(site) << 16) | (uint64_t(uint8_t(role)) << 8) |
         uint64_t(uint8_t(side + 1));
}

Entry* Find(uint64_t key) {
  size_t h = size_t((key * 0x9E3779B97F4A7C15ull) >> 50) & (kSlots - 1);
  for (size_t i = 0; i < 64; ++i) {
    Entry& e = g_table[(h + i) & (kSlots - 1)];
    uint64_t k = e.key.load(std::memory_order_acquire);
    if (k == key) return &e;
    if (k == 0) {
      uint64_t expected = 0;
      if (e.key.compare_exchange_strong(expected, key, std::memory_order_acq_rel)) return &e;
      if (expected == key) return &e;
    }
  }
  return nullptr;
}

void** HookChoke(void* team, int role) {
  void** res = g_choke(team, role);

  auto* retSlot = static_cast<uintptr_t*>(_AddressOfReturnAddress());
  uintptr_t ret = *retSlot;
  bool viaWrapper = ret == g_base + kRvaChokeRetInWrapper;
  // FUN_14074B184 faz "sub rsp,28h; call" -> o retorno dele fica 0x30 acima.
  if (viaWrapper) ret = retSlot[6];
  uint32_t site = (ret >= g_base && ret - g_base < 0x10000000) ? uint32_t(ret - g_base) : 0;

  if (!res) {
    res = PromoteAnswer(team, role, site);
  } else if (void** mine = PromoteContext(team, role, retSlot, site)) {
    res = mine;
  }

  int side = -1;
  uintptr_t duel = *reinterpret_cast<uintptr_t*>(g_base + kRvaDuelGlobal);
  if (duel) {
    uintptr_t t = reinterpret_cast<uintptr_t>(team);
    if (t == duel + kTeamOffset) side = 0;
    else if (t == duel + kTeamOffset + kTeamStride) side = 1;
  }

  // Native fighter routing above is always active. Only turn off the
  // multi-million-call diagnostic hash/counters during normal gameplay.
  if(g_diagnosticsEnabled){
    g_total.fetch_add(1,std::memory_order_relaxed);
    if(Entry* e=Find(MakeKey(site,role,side))){
      e->calls.fetch_add(1,std::memory_order_relaxed);
      if(res && *res)e->found.fetch_add(1,std::memory_order_relaxed);
      if(viaWrapper)e->viaWrapper.fetch_add(1,std::memory_order_relaxed);
    }else{
      g_dropped.fetch_add(1,std::memory_order_relaxed);
    }
  }
  return res;
}

}  // namespace

bool CensusDiagnosticsEnabled(){return g_diagnosticsEnabled;}
bool CensusInstall() {
  char enabled[8]{};
  g_diagnosticsEnabled =
      GetEnvironmentVariableA("STORM6_DIAGNOSTICS",enabled,sizeof(enabled))>0
      && enabled[0]=='1';
  Log("Performance: censo detalhado %s; STORM6_DIAGNOSTICS=1 para habilitar.",
      g_diagnosticsEnabled?"ATIVO":"DESATIVADO");
  void* target = reinterpret_cast<void*>(g_base + kRvaChoke);
  // Confere os primeiros bytes antes de mexer (mov [rsp+8],rbx; mov [rsp+10h],rbp)
  static const uint8_t kExpect[] = {0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x6C, 0x24, 0x10};
  if (memcmp(target, kExpect, sizeof(kExpect)) != 0) {
    Log("Censo: bytes de FUN_14074B36C diferentes do esperado; hook NAO instalado.");
    return false;
  }
  MH_STATUS st = MH_CreateHook(target, reinterpret_cast<void*>(&HookChoke),
                               reinterpret_cast<void**>(&g_choke));
  if (st == MH_OK) st = MH_EnableHook(target);
  if (st != MH_OK) {
    Log("Censo: hook falhou: %s", MH_StatusToString(st));
    return false;
  }
  Log("Censo: hook de observacao instalado em exe+0x%X", unsigned(kRvaChoke));
  return true;
}

void CensusDump() {
  uintptr_t duel = *reinterpret_cast<uintptr_t*>(g_base + kRvaDuelGlobal);
  uintptr_t last = g_lastDuel.exchange(duel);
  if (duel != last) Log("Duelo: %s (duel=%p)", duel ? "ATIVO" : "encerrado", reinterpret_cast<void*>(duel));
  if(!g_diagnosticsEnabled)return;

  std::wstring path = ModDir() + L"census.csv";
  FILE* f = _wfsopen(path.c_str(), L"w", 0x40 /* _SH_DENYNO */);
  if (!f) return;
  std::fprintf(f, "site_rva,side,role,calls,found,via_wrapper\n");
  size_t sites = 0;
  for (Entry& e : g_table) {
    uint64_t k = e.key.load(std::memory_order_acquire);
    if (!k) continue;
    ++sites;
    uint32_t site = uint32_t(k >> 16);
    int role = int(int8_t(uint8_t(k >> 8)));
    int side = int(uint8_t(k)) - 1;
    std::fprintf(f, "0x%X,%d,%d,%llu,%llu,%llu\n", site, side, role,
                 static_cast<unsigned long long>(e.calls.load()),
                 static_cast<unsigned long long>(e.found.load()),
                 static_cast<unsigned long long>(e.viaWrapper.load()));
  }
  std::fclose(f);
  Log("Censo: %llu buscas, %zu combinacoes (ponto,lado,papel)%s",
      static_cast<unsigned long long>(g_total.load()), sites,
      g_dropped.load() ? " [tabela cheia: algumas perdidas]" : "");
}
