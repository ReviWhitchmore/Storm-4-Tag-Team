// GERADO por tools/gen_wall_table.js a partir da colisao dos cenarios (nuccChunkModelHit). So arenas conferidas
// no jogo (o lutador trava na parede correndo). Paredes ja recortadas pelo limite da luta.
const WallSeg kWalls_sd03e[] = {
    {-1082.0f, 1691.0f, -665.0f, 1691.0f, 1100.0f},  // 418 de comprimento, marca 606164
};
const WallSeg kWalls_si43b[] = {
    {1750.0f, -1120.0f, 1750.0f, 1120.0f, 1100.0f},  // 2240 de comprimento, marca 899497
};
// Cenario so no pacote cifrado do Evolution: medido no jogo em 11/11/2026 (parede_teste=2, 12 corridas). O lutador para em |x| ou |y| = 1739 (parede menos o corpo, 41). Paredoes altos com o padrao do Kamui nos lados -x e +y (capturas mapa_1AF7160D_03/06); +x e -y sao beira de cubo (sem parede). Trechos limitados ao que as paradas confirmaram.
const WallSeg kWalls_medida_1af7160d[] = {
    {-1780.0f, -600.0f, -1780.0f, 1700.0f, 1100.0f},  // medida no jogo
    {-1700.0f, 1780.0f, 1700.0f, 1780.0f, 1100.0f},  // medida no jogo
};
const WallArena kWallArenas[] = {
    {0x83096146u, "SD03E BTL_NS1_sd03e", kWalls_sd03e, 1},
    {0xC35ECDE7u, "SI43B", kWalls_si43b, 1},
    {0x1AF7160Du, "EI45A BTL_NS4_si45a (dimensao do Kamui)", kWalls_medida_1af7160d, 2},
};
