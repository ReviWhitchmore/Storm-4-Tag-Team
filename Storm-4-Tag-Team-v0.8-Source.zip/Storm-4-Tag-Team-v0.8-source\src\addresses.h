#pragma once
#include <cstdint>

// Enderecos (RVA) e posicoes de tabela virtual que o mod usa, por versao do executavel.
// 1.09 = NSUNS4.exe (TimeDateStamp 0x5EF2F684). Evolution = NSUNS4e.exe (0x5889906E), achados com
// tools/sigport.cpp (assinatura dos primeiros 64 bytes de cada funcao) - ver analysis/evolution_sigport.txt.
struct GameAddrs {
  const char* name;
  uint32_t timestamp;
  // busca central de membros
  uintptr_t choke, chokeRetInWrapper, duelGlobal;
  // criacao, preparo, juiz, desmontagem
  uintptr_t createInner, sideConfigBase, memberSetup, judge, teardownClean, teardownRemove;
  uintptr_t setPosition, resetMotion;
  // ultimates / cenas especiais
  uintptr_t camTrack, anyDirection, directionType, ultimateCreate, sceneStart, ultConfigRoleReturn, dirCodeBegin, dirCodeEnd;
  uintptr_t hitSceneReturn, preUltimateSceneReturn, ultimateSceneReturn;
  uintptr_t teamReady, teamReadyChargeReturn, teamReadyAttackReturn;
  uintptr_t teamGauge, teamGaugeAttackReturn, teamIntroReturn, teamSceneReturn;
  // camera de duelo
  uintptr_t setView, duelViewReturn, duelCamLeaderSite;
  uintptr_t cameraStage, cameraSweep, cameraSweepInit;
  // controles
  uintptr_t devUpdate, playerPadUpdate, logicalPads, battlePadRead, physicalPadRead;
  uintptr_t faceIcon;
  // posicoes na tabela virtual do lutador
  uint32_t vtChangeState;
};

// Escolhe a tabela pela data do executavel. Retorna false se a versao nao e conhecida.
bool AddrSelect(uint32_t timestamp);
// Tabela escolhida (a da 1.09 antes de AddrSelect).
const GameAddrs& Addr();
