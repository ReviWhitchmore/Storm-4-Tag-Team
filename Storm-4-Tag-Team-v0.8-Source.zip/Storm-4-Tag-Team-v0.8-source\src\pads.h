#pragma once
#include <cstdint>

// Diagnostico do co-op: registra os dispositivos de controle do motor.
bool PadsInstall();
// Procura, na memoria do lutador, ponteiros para os dispositivos registrados (so leitura, log).
void PadsScanFighter(int index, int side, int row, uintptr_t player);
// Vigia de hardware nos botoes dos controles 1 e 2: chamar a cada ~5 s na thread do mod.
// Liga no primeiro chamado com luta ativa, desliga e grava o resultado no chamado seguinte.
void PadsWatchTick(bool battleActive);
// Co-op (diagnostico): chamar a cada quadro na thread do jogo com o lutador J1.
void PadsCorrelate(uintptr_t player);
