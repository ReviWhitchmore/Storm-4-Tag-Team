#pragma once
// Story catalog shared by both editions; executable details must remain
// separate. This header has NO Windows, GFX or engine dependencies.
#include <array>
#include <cstddef>
#include <cstdint>

namespace chronicles_story {
enum class Edition : uint8_t { Unsupported, Original, Evolution };
enum class MissionStatus : uint8_t { Planned, Prototype, Playable };

struct EditionAdapter {
  Edition edition;
  uint32_t timestamp;
  uintptr_t sceneCtrlRva;
  const char* label;
  const wchar_t* profileFolder;
};
constexpr EditionAdapter kOriginal{
  Edition::Original,0x5EF2F684,0x6E77F0,
  "STORM 4 ORIGINAL / 1.09", L"original"
};
constexpr EditionAdapter kEvolution{
  Edition::Evolution,0x5889906E,0x6E3D6C,
  "STORM 4 EVOLUTION",L"evolution"
};
constexpr const EditionAdapter* Resolve(uint32_t timestamp) {
  return timestamp==kEvolution.timestamp?&kEvolution:
         timestamp==kOriginal.timestamp?&kOriginal:nullptr;
}

struct Chapter {
  const char* id;
  const char* title;
  const char* synopsis;
  const char* location;
  MissionStatus status;
};
// Common narrative, independent engine mappings and progress.
constexpr std::array<Chapter,3> kChapters{{
  {"C01_TEAM7","PROLOGO / EQUIPE 7",
   "O INICIO DA EQUIPE DE NARUTO","KONOHA",MissionStatus::Prototype},
  {"C02_WAVES","PAIS DAS ONDAS",
   "A MISSAO CONTRA ZABUZA E HAKU","PONTE NARUTO",MissionStatus::Planned},
  {"C03_CHUNIN","EXAMES CHUNIN",
   "O DESAFIO QUE TESTA OS NOVOS NINJAS","ARENA DOS EXAMES",MissionStatus::Planned}
}};
constexpr int Count() {return static_cast<int>(kChapters.size());}
constexpr bool Valid(int index) {return index>=0&&index<Count();}

// The narrative timeline is shared, but presentation and battle design are
// independent for each executable. These are plans, not playable missions.
struct CampaignFlavor {
  const char* subtitle;
  const char* battleDesign;
};
constexpr std::array<CampaignFlavor,3> kOriginalFlavor{{
  {"EQUIPE 7 / TESTE DOS SINOS", "DUELO COM SUPORTE - A VALIDAR"},
  {"ZABUZA E HAKU / PAIS DAS ONDAS", "CONFRONTOS DO JOGO BASE - A VALIDAR"},
  {"EXAMES CHUNIN / TORNEIO", "CONFRONTOS DO JOGO BASE - A VALIDAR"}
}};
constexpr std::array<CampaignFlavor,3> kEvolutionFlavor{{
  {"EQUIPE 7 / EDICAO EVOLUTION", "COMBATE EM EQUIPE - A VALIDAR"},
  {"ZABUZA E HAKU / EDICAO EVOLUTION", "COMBATE EM EQUIPE - A VALIDAR"},
  {"EXAMES CHUNIN / EDICAO EVOLUTION", "COMBATE EM EQUIPE - A VALIDAR"}
}};
constexpr const CampaignFlavor* Flavor(Edition edition,int index) {
  if(!Valid(index))return nullptr;
  return edition==Edition::Original?&kOriginalFlavor[index]:
         edition==Edition::Evolution?&kEvolutionFlavor[index]:nullptr;
}
constexpr const char* CampaignTitle(Edition edition) {
  return edition==Edition::Original?"CAMPANHA ORIGINAL / NARUTO CLASSICO":
         edition==Edition::Evolution?"CAMPANHA EVOLUTION / NARUTO CLASSICO":
         "CAMPANHA INDISPONIVEL";
}

struct MissionSetup {
  const char* chapterId;
  const char* preferredRoster;
  const char* encounter;
  const char* arena;
  bool assetsVerified;
};
// These are data prototypes, not proven asset IDs. The backend MUST refuse
// launching until each edition's actual game assets and native battle calls
// are validated. Do not assign arbitrary character IDs or memory addresses.
constexpr std::array<MissionSetup,3> kOriginalMissions{{
  {"C01_TEAM7","NARUTO / SASUKE / SAKURA",
    "KAKASHI / TREINO DOS SINOS","KONOHA",false},
  {"C02_WAVES","NARUTO / SASUKE / KAKASHI",
    "ZABUZA / HAKU","PONTE",false},
  {"C03_CHUNIN","NARUTO / SASUKE / SAKURA",
    "GAARA / EXAMES CHUNIN","ARENA",false}
}};
constexpr std::array<MissionSetup,3> kEvolutionMissions{{
  {"C01_TEAM7","NARUTO / SASUKE / SAKURA (EQUIPE)",
    "KAKASHI / TESTE DOS SINOS EM EQUIPE","KONOHA",false},
  {"C02_WAVES","NARUTO / SASUKE / KAKASHI (EQUIPE)",
    "ZABUZA / HAKU - COOPERATIVO PLANEJADO","PONTE",false},
  {"C03_CHUNIN","NARUTO / SASUKE / SAKURA (EQUIPE)",
    "GAARA / EXAMES CHUNIN - EQUIPE PLANEJADA","ARENA",false}
}};
constexpr const MissionSetup* Mission(Edition edition,int index) {
  if(!Valid(index))return nullptr;
  return edition==Edition::Evolution?&kEvolutionMissions[index]:
         edition==Edition::Original?&kOriginalMissions[index]:nullptr;
}
constexpr bool CanLaunch(Edition edition,int chapter) {
  const MissionSetup* m=Mission(edition,chapter);
  return m!=nullptr&&m->assetsVerified&&
      kChapters[chapter].status==MissionStatus::Playable;
}
constexpr int Step(int selected,int direction) {
  if(!Valid(selected))selected=0;
  int next=(selected+direction)%Count();
  return next<0?next+Count():next;
}
}  // namespace chronicles_story
