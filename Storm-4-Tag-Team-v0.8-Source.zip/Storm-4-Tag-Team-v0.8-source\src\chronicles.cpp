// STORM 4 TAG TEAM - Chronicles v0.8 (Evolution + original 1.09).
// Native mode-selection scene observer. Version detection chooses one exact
// executable adapter. Story content and saved selection are edition-specific.
// No game GFX, executable, or standard story menu entries are modified.
#include "chronicles.h"
#include "scene_probe.h"
#include <MinHook.h>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <string>

#include "addresses.h"
#include "census.h"
#include "chronicles_story.h"
#include "chronicles_classic.h"
#include "chronicles_classic_rules.h"
#include "chronicles_classic_bosses.h"
#include "chronicles_classic_fighters.h"
#include "chronicles_assisted_rules.h"
#include "chronicles_en.h"
#include "lang.h"
#include "log.h"
#include "menu.h"
#include "promote.h"
#include "settings.h"

namespace {
using chronicles_story::EditionAdapter;
const EditionAdapter* g_adapter=nullptr;
std::wstring g_progressPath;

// Both verified game functions share this prologue AND the following
// virtual call. A common 20-byte prologue alone occurs >100 times.
constexpr uint8_t kKnownPrologue[]={
  0x48,0x89,0x5C,0x24,0x10,0x48,0x89,0x6C,0x24,0x18,
  0x48,0x89,0x74,0x24,0x20,0x57,0x48,0x83,0xEC,0x20,
  0x48,0x8B,0x01,0x48,0x8B,0xF9,0xFF,0x50,0x08,
  0x33,0xF6,0x39,0xB7
};
using SceneCtrlFn=void (*)(void*);
SceneCtrlFn g_originalSceneCtrl=nullptr;
std::atomic<ULONGLONG> g_lastSceneTick{0};
std::atomic<bool> g_panel{false};
std::atomic<bool> g_unavailable{false};
std::atomic<int> g_selected{0}; // selected arc
std::atomic<int> g_selectedMission{0};
std::atomic<bool> g_missionList{false};
std::atomic<bool> g_missionDetail{false};
std::atomic<int> g_assistedMission{-1};
std::atomic<int> g_assistedState{0};
std::atomic<unsigned> g_assistedToken{0};
unsigned g_seenAssistedToken=0;
int g_assistedConfirmFrames=0;
bool g_assistedRosterConfirmed=false;
bool g_assistedSawRunning=false;
std::atomic<uint64_t> g_completedBits{0};
std::atomic<bool> g_hookInstalled{false};
std::atomic<bool> g_sceneObserved{false};
WORD g_prevPadButtons=0;
bool g_prevF6=false,g_prevF7=false,g_prevF8=false,g_prevF9=false,g_prevF10=false;

int ReadNumber(const wchar_t* key,int fallback){
  if(g_progressPath.empty())return fallback;
  return GetPrivateProfileIntW(L"CHRONICLES",key,fallback,g_progressPath.c_str());
}
bool SaveNumber(const wchar_t* key,int value){
  if(g_progressPath.empty())return false;
  wchar_t buffer[12]{};
  _snwprintf_s(buffer,_countof(buffer),_TRUNCATE,L"%d",value);
  return WritePrivateProfileStringW(
    L"CHRONICLES",key,buffer,g_progressPath.c_str())!=FALSE;
}
void SaveSelection(){
  if(g_progressPath.empty())return;
  if(!SaveNumber(L"selected_arc",g_selected.load()) ||
     !SaveNumber(L"selected_mission",g_selectedMission.load()))
    Log("CHRONICLES: erro ao salvar a selecao do arco ou missao.");
}
void LoadSelection(){
  // The old selected_chapter key is intentionally not reused: it held
  // an unrelated 3-item prototype index.
  int arc=ReadNumber(L"selected_arc",0);
  if(!chronicles_classic::ValidArc(arc))arc=0;
  int mission=ReadNumber(L"selected_mission",chronicles_classic::kArcs[arc].first);
  if(!chronicles_classic::InArc(arc,mission))
    mission=chronicles_classic::kArcs[arc].first;
  g_selected=arc;
  g_selectedMission=mission;
  g_missionList=false;
  g_missionDetail=false;
}
void ConfigureProfile(const EditionAdapter& adapter) {
  const std::wstring root=ModDir()+L"storm6_chronicles";
  CreateDirectoryW(root.c_str(),nullptr);
  const std::wstring edition=root+L"\\"+adapter.profileFolder;
  CreateDirectoryW(edition.c_str(),nullptr);
  g_progressPath=edition+L"\\progress.ini";
  uint64_t completed=0;
  for(int i=0;i<chronicles_classic::MissionCount();++i){
    wchar_t key[12]{};
    _snwprintf_s(key,_countof(key),_TRUNCATE,L"C%02d",i+1);
    if(GetPrivateProfileIntW(L"CHRONICLES_COMPLETED",key,0,
                             g_progressPath.c_str())==1)
      completed |= uint64_t{1}<<i;
  }
  g_completedBits.store(completed,std::memory_order_release);
  Log("CHRONICLES: perfil %s, progresso carregado para %d missoes.",
      adapter.label,chronicles_classic::MissionCount());
}
bool GameFocused() {
  DWORD pid=0;
  GetWindowThreadProcessId(GetForegroundWindow(),&pid);
  return pid==GetCurrentProcessId();
}
bool FreshMenuScene() {
  if(!g_hookInstalled.load(std::memory_order_relaxed))return false;
  const ULONGLONG seen=g_lastSceneTick.load(std::memory_order_relaxed);
  const ULONGLONG now=GetTickCount64();
  // Numa luta do Chronicles (inclusive 1x1, onde PromoteBattleActive fica desligado) o menu nao aparece.
  return seen && now>=seen && now-seen<350 && !PromoteBattleActive() && !SceneProbeMissionFight();
}
void ClosePanel() {
  const bool wasOpen=g_panel.exchange(false);
  g_missionList=false;
  g_missionDetail=false;
  g_unavailable=false;
  if(wasOpen)Log("CHRONICLES: campanha classica fechada (%s).",
                 g_adapter?g_adapter->label:"?");
}
void TogglePanel() {
  if(g_panel.load()) {ClosePanel();return;}
  LoadSelection();
  g_panel=true;
  g_unavailable=false;
  Log("CHRONICLES: campanha classica aberta (%s, arco %d).",
      g_adapter?g_adapter->label:"?",g_selected.load()+1);
}
bool Edge(int vk,bool& previous) {
  const bool down=(GetAsyncKeyState(vk)&0x8000)!=0;
  const bool justDown=down&&!previous;
  previous=down;
  return justDown;
}
void Step(int amount) {
  if(g_missionDetail.load())return;
  if(g_missionList.load()){
    g_selectedMission=chronicles_classic::NavigateMission(
      g_selected.load(),g_selectedMission.load(),amount);
  }else{
    const int arc=chronicles_classic::NavigateArc(g_selected.load(),amount);
    g_selected=arc;
    g_selectedMission=chronicles_classic::kArcs[arc].first;
  }
  g_unavailable=false;
  SaveSelection();
}
void Back(){
  if(g_missionDetail.exchange(false)){
    g_unavailable=false;
    Log("CHRONICLES: retornando aos confrontos do arco.");
    return;
  }
  if(g_missionList.exchange(false)){
    g_unavailable=false;
    Log("CHRONICLES: voltando para lista de arcos.");
  }else ClosePanel();
}
void SelectMission() {
  if(!g_missionList.load()){
    g_missionList=true;
    g_unavailable=false;
    Log("CHRONICLES: arco %s selecionado (%s).",
      chronicles_classic::kArcs[g_selected.load()].code,
      g_adapter?g_adapter->label:"?");
    return;
  }
  const int mission=g_selectedMission.load();
  if(!chronicles_classic::ValidMission(mission))return;
  const auto& m=chronicles_classic::kMissions[mission];
  if(!g_missionDetail.exchange(true)){
    g_unavailable=false;
    Log("CHRONICLES: ficha %s aberta (%s).",m.id,
        g_adapter?g_adapter->label:"?");
    return;
  }
  // Assisted route: the player uses the EXISTING Free Battle character
  // select and battle loader, so no unverified native scene requests occur.
  // Automatic mission loading remains unavailable; never claim otherwise.
  // No Evolution a luta abre direto (SceneLaunchRequest) e o fim e tratado em scene_probe.cpp; o modo
  // assistido (abrir pelo Combate Livre) so continua valendo nas versoes sem luta direta.
  if(Addr().timestamp!=0x5889906E){
    g_assistedMission.store(mission,std::memory_order_release);
    g_assistedState.store(1,std::memory_order_release);
    g_assistedToken.fetch_add(1,std::memory_order_acq_rel);
  }
  SaveSelection();
  ClosePanel();
  Log("CHRONICLES: %s confirmada: %s vs %s (%dv%d). Abrindo a luta.",
      m.id,m.allies,m.enemies,m.teamSize,m.enemySize);
  SceneLaunchRequest(mission);
  if(!chronicles_assisted::SupportsVerification(mission))
    Log("CHRONICLES ASSISTIDO: %s possui personagens sem codigo HUD confirmado; "
        "o sistema NAO registrara vitoria automaticamente.",m.id);
}
// Depois de uma missao: reabre a lista de missoes do arco, na proxima missao se venceu (ou na mesma).
std::atomic<int> g_reopenMission{-1};
ULONGLONG g_reopenAt=0;
void ReopenTick(){
  const int mission=g_reopenMission.load();
  if(mission<0||!FreshMenuScene()||MenuIsOpen())return;
  if(GetTickCount64()<g_reopenAt)return;
  g_reopenMission=-1;
  LoadSelection();
  const int arc=chronicles_classic::ArcForMission(mission);
  if(!chronicles_classic::ValidArc(arc))return;
  g_selected=arc;
  g_selectedMission=mission;
  g_panel=true;
  g_missionList=true;
  g_missionDetail=false;
  g_unavailable=false;
  SaveSelection();
  Log("CHRONICLES: menu reaberto depois da missao (arco %s, missao %s).",
      chronicles_classic::kArcs[arc].code,chronicles_classic::kMissions[mission].id);
}
void HookSceneCtrl(void* scene) {
  if(g_originalSceneCtrl)g_originalSceneCtrl(scene);
  SceneLaunchTick(scene);
  g_lastSceneTick=GetTickCount64();
  ReopenTick();
  if(!g_sceneObserved.exchange(true))
    Log("CHRONICLES: menu de modos NATIVO detectado (%s).",
        g_adapter?g_adapter->label:"?");
}
}  // namespace

bool ChroniclesInstall() {
  g_adapter=chronicles_story::Resolve(Addr().timestamp);
  if(!g_adapter) {
    Log("CHRONICLES: versao nao suportada; nenhum hook.");
    return false;
  }
  ConfigureProfile(*g_adapter);
  const uintptr_t targetAddress=g_base+g_adapter->sceneCtrlRva;
  const auto* target=reinterpret_cast<const uint8_t*>(targetAddress);
  if(std::memcmp(target,kKnownPrologue,sizeof(kKnownPrologue))!=0) {
    Log("CHRONICLES: assinatura do menu nao confere (%s, exe+0x%llX).",
        g_adapter->label,
        static_cast<unsigned long long>(g_adapter->sceneCtrlRva));
    return false;
  }
  MH_STATUS status=MH_CreateHook(reinterpret_cast<void*>(targetAddress),
      reinterpret_cast<void*>(&HookSceneCtrl),
      reinterpret_cast<void**>(&g_originalSceneCtrl));
  if(status==MH_OK)status=MH_EnableHook(reinterpret_cast<void*>(targetAddress));
  g_hookInstalled=status==MH_OK;
  Log("CHRONICLES: %s / menu exe+0x%llX: %s",
      g_adapter->label,static_cast<unsigned long long>(g_adapter->sceneCtrlRva),
      status==MH_OK?"hook ativo":"hook NAO instalado");
  return status==MH_OK;
}
bool ChroniclesNativeModeVisible(){return FreshMenuScene();}
bool ChroniclesChapterScreenOpen(){return FreshMenuScene()&&g_panel.load();}
bool ChroniclesMissionListOpen(){return g_missionList.load();}
bool ChroniclesMissionDetailOpen(){return g_missionDetail.load();}
int ChroniclesChapterSelection(){return g_selected.load();}
int ChroniclesMissionSelection(){return g_selectedMission.load();}
bool ChroniclesMissionNotReady(){return g_unavailable.load();}
int ChroniclesArcCount(){return chronicles_classic::ArcCount();}
int ChroniclesArcMissionCount(int arc){
  return chronicles_classic::ValidArc(arc)?chronicles_classic::kArcs[arc].count:0;
}
int ChroniclesArcMissionFirst(int arc){
  return chronicles_classic::ValidArc(arc)?chronicles_classic::kArcs[arc].first:-1;
}
const char* ChroniclesEditionLabel(){
  return g_adapter?g_adapter->label:Lang("VERSAO INDEFINIDA","UNKNOWN VERSION");
}
const char* ChroniclesCampaignLabel(){
  const auto edition=g_adapter?g_adapter->edition:chronicles_story::Edition::Unsupported;
  if(LangEnglish())
    return edition==chronicles_story::Edition::Original?"ORIGINAL CAMPAIGN / CLASSIC NARUTO":
           edition==chronicles_story::Edition::Evolution?"EVOLUTION CAMPAIGN / CLASSIC NARUTO":
           "CAMPAIGN UNAVAILABLE";
  return chronicles_story::CampaignTitle(edition);
}
const char* ChroniclesChapterTitle(int arc){
  if(!chronicles_classic::ValidArc(arc))return "???";
  return LangEnglish()?chronicles_en::kArcs[arc].title:chronicles_classic::kArcs[arc].title;
}
const char* ChroniclesChapterSubtitle(int arc){
  if(!chronicles_classic::ValidArc(arc))return "";
  return LangEnglish()?chronicles_en::kArcs[arc].subtitle:chronicles_classic::kArcs[arc].subtitle;
}
const char* ChroniclesChapterStatus(int arc){
  return chronicles_classic::ValidArc(arc)?Lang("MISSOES","MISSIONS"):"";
}
void ChroniclesReopenAfterMission(int mission,bool won){
  if(!chronicles_classic::ValidMission(mission))return;
  int next=mission;
  if(won&&chronicles_classic::ValidMission(mission+1)&&
     chronicles_classic::ArcForMission(mission+1)==chronicles_classic::ArcForMission(mission))
    next=mission+1;
  g_reopenAt=GetTickCount64()+1200;  // deixa o menu de modos terminar de aparecer
  g_reopenMission=next;
}
void ChroniclesMarkCompleted(int mission){
  if(!chronicles_classic::ValidMission(mission)||g_progressPath.empty())return;
  wchar_t key[12]{};
  _snwprintf_s(key,_countof(key),_TRUNCATE,L"C%02d",mission+1);
  if(WritePrivateProfileStringW(L"CHRONICLES_COMPLETED",key,L"1",g_progressPath.c_str())){
    g_completedBits.fetch_or(uint64_t{1}<<mission,std::memory_order_acq_rel);
    Log("CHRONICLES: %s CONCLUIDA (vitoria na luta direta).",chronicles_classic::kMissions[mission].id);
  }
}
const char* ChroniclesMissionTitle(int index){
  if(!chronicles_classic::ValidMission(index))return "???";
  return LangEnglish()?chronicles_en::kTitles[index]:chronicles_classic::kMissions[index].title;
}
const char* ChroniclesMissionId(int index){
  return chronicles_classic::ValidMission(index)?
         chronicles_classic::kMissions[index].id:"";
}
const char* ChroniclesMissionTeams(int index){
  if(!chronicles_classic::ValidMission(index))return "?";
  const auto& m=chronicles_classic::kMissions[index];
  const char* labels[3][3]={{"1v1","1v2","1v3"},
                            {"2v1","2v2","2v3"},
                            {"3v1","3v2","3v3"}};
  return labels[m.teamSize-1][m.enemySize-1];
}
const char* ChroniclesMissionAllies(int i){
  return chronicles_classic::ValidMission(i)?chronicles_classic::kMissions[i].allies:"";
}
const char* ChroniclesMissionEnemies(int i){
  return chronicles_classic::ValidMission(i)?chronicles_classic::kMissions[i].enemies:"";
}
const char* ChroniclesFighterInSlot(int i,int side,int slot) {
  const auto* r=chronicles_classic::Roster(i);
  if(!r || side<0 || side>1 || slot<0 || slot>2)return "---";
  const auto& team=side==0?r->allies:r->enemies;
  if(slot>=team.count)return "---";
  const auto* info=chronicles_classic::Info(team.members[slot]);
  return info?info->display:"---";
}
const char* ChroniclesFighterPreferredStyle(int i,int side,int slot){
  const auto* r=chronicles_classic::Roster(i);
  if(!r || side<0 || side>1 || slot<0 || slot>2)return "";
  const auto& team=side==0?r->allies:r->enemies;
  if(slot>=team.count)return "";
  const auto* info=chronicles_classic::Info(team.members[slot]);
  if(!info)return "";
  return info->preferredStyle==chronicles_classic::FighterStyle::SoundFourDlc?
    Lang("DLC SOM","SOUND DLC"):info->preferredStyle==chronicles_classic::FighterStyle::Classic?
    Lang("CLASSICO","CLASSIC"):Lang("PADRAO","DEFAULT");
}
bool ChroniclesRosterConfigured(int i){
  return chronicles_classic::ValidRoster(i);
}
bool ChroniclesRosterDlcNeeded(int i){
  return chronicles_classic::RosterNeedsSoundFour(i);
}
const char* ChroniclesMissionArena(int i){
  if(!chronicles_classic::ValidMission(i))return "";
  const char* arena=chronicles_classic::kMissions[i].arena;
  return LangEnglish()?chronicles_en::Arena(arena):arena;
}
const char* ChroniclesMissionObjective(int i){
  const auto* p=chronicles_classic::Plan(i);if(!p)return "";
  return LangEnglish()?chronicles_en::kPlans[i].objective:p->objective;
}
const char* ChroniclesMissionSpecial(int i){
  const auto* p=chronicles_classic::Plan(i);if(!p)return "";
  return LangEnglish()?chronicles_en::kPlans[i].special:p->special;
}
const char* ChroniclesMissionBonus(int i){
  const auto* p=chronicles_classic::Plan(i);if(!p)return "";
  return LangEnglish()?chronicles_en::kPlans[i].bonus:p->bonus;
}
const char* ChroniclesMissionAI(int i){
  const auto* p=chronicles_classic::Plan(i);if(!p)return "";
  return LangEnglish()?chronicles_en::kPlans[i].aiStyle:p->aiStyle;
}
const char* ChroniclesMissionDifficulty(int i){
  const auto* p=chronicles_classic::Plan(i);if(!p)return "";
  return LangEnglish()?chronicles_en::Difficulty(p->difficulty):chronicles_classic::DifficultyLabel(p->difficulty);
}
int ChroniclesMissionAllyHealth(int i){
  if(!chronicles_classic::ValidMission(i))return 100;
  const auto& m=chronicles_classic::kMissions[i];
  return chronicles_classic::ProposedBalance(m.teamSize,m.enemySize).allyHealthPct;
}
int ChroniclesMissionEnemyHealth(int i){
  if(!chronicles_classic::ValidMission(i))return 100;
  const auto& m=chronicles_classic::kMissions[i];
  return chronicles_classic::ProposedBalance(m.teamSize,m.enemySize).enemyHealthPct;
}
int ChroniclesMissionEnemyDamage(int i){
  if(!chronicles_classic::ValidMission(i))return 100;
  const auto& m=chronicles_classic::kMissions[i];
  return chronicles_classic::ProposedBalance(m.teamSize,m.enemySize).enemyDamagePct;
}
bool ChroniclesMissionIsBoss(int index){
  return chronicles_classic::BossForMission(index)!=nullptr;
}
int ChroniclesMissionBossPhases(int index){
  const auto* b=chronicles_classic::BossForMission(index);
  return b?b->phaseCount:0;
}
const char* ChroniclesMissionBossName(int index){
  const auto* b=chronicles_classic::BossForMission(index);
  if(!b)return "";
  const auto* en=LangEnglish()?chronicles_en::Boss(index):nullptr;
  return en?en->name:b->name;
}
const char* ChroniclesMissionBossPhase(int index,int phase){
  const auto* b=chronicles_classic::BossForMission(index);
  if(!b)return "";
  const char* pt=chronicles_classic::BossPhaseLabel(*b,phase);
  const auto* en=LangEnglish()?chronicles_en::Boss(index):nullptr;
  return en && *pt && phase>=1 && phase<=3?en->phase[phase-1]:pt;
}
const char* ChroniclesMissionStatus(int index){
  if(!chronicles_classic::ValidMission(index))return "";
  if(ChroniclesMissionCompleted(index))return Lang("CONCLUIDA","COMPLETED");
  const auto& m=chronicles_classic::kMissions[index];
  return chronicles_classic::BossForMission(index)?Lang("CHEFE","BOSS"):
         m.soundFourDlc?Lang("DLC SOM","SOUND DLC"):m.alternate?"EXTRA":Lang("DESAFIO","CHALLENGE");
}
int ChroniclesAssistedMission(){
  return g_assistedMission.load(std::memory_order_acquire);
}
int ChroniclesAssistedState(){
  return g_assistedState.load(std::memory_order_acquire);
}
bool ChroniclesMissionCompleted(int mission){
  return chronicles_classic::ValidMission(mission) &&
      (g_completedBits.load(std::memory_order_acquire)&(uint64_t{1}<<mission))!=0;
}
void ChroniclesAssistedJudgeTick(int nativeResult){
  // Called from the original Storm 4 judge thread after its native verdict.
  // No invocation of any scene constructors or arbitrary fight IDs.
  const int mission=g_assistedMission.load(std::memory_order_acquire);
  if(!chronicles_classic::ValidMission(mission))return;
  const unsigned token=g_assistedToken.load(std::memory_order_acquire);
  if(token!=g_seenAssistedToken){
    g_seenAssistedToken=token;
    g_assistedConfirmFrames=0;
    g_assistedRosterConfirmed=false;
    g_assistedSawRunning=false;
  }
  const int current=g_assistedState.load(std::memory_order_acquire);
  if(current==3||current==4||g_progressPath.empty())return;
  if(!Cfg().mode3v3.load(std::memory_order_relaxed) ||
      Cfg().freeForAll.load(std::memory_order_relaxed) ||
      !chronicles_assisted::SupportsVerification(mission) ||
      !PromoteBattleActive())return;
  HudFighter hud[6]{};
  int target=-1;
  if(!PromoteHudSnapshot(hud,&target))return;
  const int count=PromoteFighterCount();
  if(count<2||count>6)return;
  chronicles_assisted::ObservedFighter observed[6]{};
  for(int i=0;i<count;++i){
    observed[i]={hud[i].side,hud[i].row,hud[i].portrait};
  }
  if(!chronicles_assisted::MatchRoster(mission,observed,count)) {
    if(!g_assistedRosterConfirmed)g_assistedConfirmFrames=0;
    return;
  }
  if(!g_assistedRosterConfirmed){
    if(++g_assistedConfirmFrames>=25) {
      g_assistedRosterConfirmed=true;
      g_assistedState.store(2,std::memory_order_release);
      Log("CHRONICLES ASSISTIDO: %s - escalação confirmada em partida real.",
          chronicles_classic::kMissions[mission].id);
    }
  }
  if(nativeResult==0)g_assistedSawRunning=true;
  if(!g_assistedRosterConfirmed || !g_assistedSawRunning)return;
  if(chronicles_assisted::NativeResultIsWin(nativeResult)){
    wchar_t key[12]{};
    _snwprintf_s(key,_countof(key),_TRUNCATE,L"C%02d",mission+1);
    if(WritePrivateProfileStringW(L"CHRONICLES_COMPLETED",key,L"1",
                                 g_progressPath.c_str())){
      g_completedBits.fetch_or(uint64_t{1}<<mission,std::memory_order_acq_rel);
      g_assistedState.store(3,std::memory_order_release);
      Log("CHRONICLES ASSISTIDO: %s CONCLUIDA, vitoria nativa e elenco confirmados.",
          chronicles_classic::kMissions[mission].id);
    }else{
      Log("CHRONICLES ASSISTIDO: vitoria confirmada, mas falha ao gravar progresso.");
    }
  }else if(chronicles_assisted::NativeResultIsLoss(nativeResult)){
    g_assistedState.store(4,std::memory_order_release);
    Log("CHRONICLES ASSISTIDO: %s perdida. Reabra a missao para tentar novamente.",
        chronicles_classic::kMissions[mission].id);
  }
}
void ChroniclesBack(){Back();}
void ChroniclesGamepadInput(XINPUT_STATE* state) {
  if(!state){g_prevPadButtons=0;return;}
  const WORD now=state->Gamepad.wButtons;
  const WORD pressed=now&~g_prevPadButtons;
  g_prevPadButtons=now;
  if(!FreshMenuScene()){
    if(g_panel.load())ClosePanel();
    return;
  }
  if(!GameFocused()||MenuIsOpen())return;
  if(pressed&XINPUT_GAMEPAD_Y){
    TogglePanel();
    state->Gamepad.wButtons&=~XINPUT_GAMEPAD_Y;
  }
  if(!g_panel.load())return;
  if(pressed&XINPUT_GAMEPAD_DPAD_UP)Step(-1);
  if(pressed&XINPUT_GAMEPAD_DPAD_DOWN)Step(+1);
  if(pressed&XINPUT_GAMEPAD_A)SelectMission();
  if(pressed&XINPUT_GAMEPAD_B)Back();
  ZeroMemory(&state->Gamepad,sizeof(state->Gamepad));
}
void ChroniclesKeyboardInput() {
  if(!FreshMenuScene()) {
    if(g_panel.load())ClosePanel();
    g_prevF6=g_prevF7=g_prevF8=g_prevF9=g_prevF10=false;
    return;
  }
  if(!GameFocused()||MenuIsOpen())return;
  if(Edge(VK_F6,g_prevF6))TogglePanel();
  if(!g_panel.load()) {
    Edge(VK_F7,g_prevF7);Edge(VK_F8,g_prevF8);Edge(VK_F9,g_prevF9);
    Edge(VK_F10,g_prevF10);
    return;
  }
  if(Edge(VK_F7,g_prevF7))Step(-1);
  if(Edge(VK_F8,g_prevF8))Step(1);
  if(Edge(VK_F9,g_prevF9))SelectMission();
  if(Edge(VK_F10,g_prevF10))Back();
}
