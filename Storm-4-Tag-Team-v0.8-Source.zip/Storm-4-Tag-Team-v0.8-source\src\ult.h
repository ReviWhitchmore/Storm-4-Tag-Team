#pragma once
#include <cstdint>
// Ultimates/jutsus sem cinematica e sem congelar quem nao esta no golpe (3v3).
bool UltInstall();
bool UltSceneActive();
// Dentro da criacao de uma cena nativa (a preparacao do tipo pode pausar atores antes de a cena entrar na lista).
bool UltInSceneStart();
int UltSceneFighter(int side);
int UltTeamActor(int side, int role, uintptr_t site);
// Supremo comum preparado (cena 8) neste lado nos ultimos 8 s: quem preparou e a vitima.
bool UltPreparedUltimate(int side, int* owner, int* victim);
// Quem do lado `side` esta no avanco de um Supremo que preparou (cena 8 ha < 8 s, estado 0x87..0x89) e
// portanto e o autor de um acerto do Supremo em `hitVictim`. Prefere quem mirou essa vitima; senao, o
// mais proximo dela. -1 se ninguem. Com 6 lutadores, dois do mesmo lado podem estar no avanco juntos.
int UltDashAttacker(int side, int hitVictim);
// Cinematica de Supremo criada ha menos de windowMs: lado da vitima.
bool UltRecentCinematic(int* victimSide, unsigned long long windowMs);
bool UltRecentCinematicVictim(int* victimSide, int* victim, unsigned long long windowMs);
bool UltTeamAllyRole(int fighter, uintptr_t site);
void UltTeamTick();
void UltBattleReset();
void UltReport();
// Team ultimate button diagnostic: eligibility check only, no unsafe engine call.
bool UltTeamButtonPressed(int pad);
