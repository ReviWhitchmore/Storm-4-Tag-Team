#pragma once
// Balanceamento das lutas do Chronicles: vida e dano por tamanho das equipes e fases dos chefes.
// Chamado a cada quadro da luta da missao, na thread do jogo. mission = indice 0..39.
void ChroniclesBalanceBegin(int mission);
void ChroniclesBalanceTick();
void ChroniclesBalanceEnd();