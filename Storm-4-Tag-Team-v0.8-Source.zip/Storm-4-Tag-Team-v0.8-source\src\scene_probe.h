#pragma once
#include <windows.h>
#include <Xinput.h>
// Cenas do Combate Livre (so Evolution): registra as trocas e abre lutas do Chronicles direto.
void SceneProbeInstall();
// Pede a luta da missao do Chronicles (qualquer thread). A luta abre no proximo SceneLaunchTick.
void SceneLaunchRequest(int mission);
// Chamado na thread do jogo enquanto o menu de modos esta ativo.
void SceneLaunchTick(void* modeScene);
// Modo de teste (arquivo storm6_autotest.txt com o numero da missao): aperta botoes no controle 1 ate o
// menu de modos e depois abre a missao sozinho. Chamado no hook do XInput; pode trocar r e o estado.
DWORD SceneAutotestInput(DWORD index, XINPUT_STATE* state, DWORD result);
// Verdadeiro durante uma luta aberta pelo Chronicles (do pedido ate a volta ao menu de modos).
bool SceneProbeMissionFight();
// Resultado da missao do Chronicles em andamento: 0 lutando, 1 vitoria, 2 derrota (para a faixa da HUD).
int SceneProbeMissionResult(int* mission, unsigned* elapsedMs);
