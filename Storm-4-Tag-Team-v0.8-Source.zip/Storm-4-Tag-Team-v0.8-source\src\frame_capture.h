#pragma once
#include <dxgi.h>

// Captura do proprio quadro do jogo (o backbuffer na hora do Present), salva em PNG. So o jogo: nenhuma outra janela
// da area de trabalho entra, mesmo com a janela do jogo coberta. Uso de teste/diagnostico.
// FrameCaptureRequest: pede uma captura no proximo quadro (qualquer thread). Gatilho por arquivo: se existir
// <pasta do mod>\storm6_captura.txt com um caminho .png na primeira linha, captura nesse caminho e apaga o arquivo.
void FrameCaptureRequest(const wchar_t* pngPath);
void FrameCaptureOnPresent(IDXGISwapChain* swapChain);
