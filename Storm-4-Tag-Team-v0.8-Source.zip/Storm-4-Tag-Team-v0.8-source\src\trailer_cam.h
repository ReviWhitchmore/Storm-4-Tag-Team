#pragma once
// Camera de trailer: so para filmar. Desligada por padrao; liga com camera_trailer=1..4 no storm6.ini.
//   1 = orbita lenta em volta do lutador da camera
//   2 = aproximacao lenta de lado, camera baixa
//   3 = orbita larga em volta de todos os lutadores
//   4 = heroi: camera baixa olhando para cima, balancando de lado
// Ajustes opcionais: camera_trailer_dist (distancia, padrao 320), camera_trailer_altura (padrao 70),
// camera_trailer_vel (graus por segundo, padrao 10), camera_trailer_alvo (-1 = lutador da camera,
// 0..5 = indice na lista de lutadores vivos).
// Precisa de camera=1..4: so esses modos passam as posicoes dos lutadores para a camera.
// Durante introducoes, Supremos e cenas do jogo a camera nativa continua mandando.
void TrailerCamLoad();
bool TrailerCamEnabled();
void TrailerCamReset();
bool TrailerCamView(const float positions[][3], int count, int primary, int target, float eye[3], float aim[3]);
