#pragma once
#include <cstdint>
#include <windows.h>
#include <Xinput.h>

// Fase 2 - Defesa contra Agarrao (Evolution). Liga/desliga em storm6.ini: defesa_agarrao=1.
// O defensor aperta defesa (RT/R2) quando faltam ate ~0,2 s para o agarrao normal (PL_ACT_THROW_BEGIN)
// encostar: o agarrao e cancelado ANTES do contato (sem cena de agarrao criada) e o atacante recua com o
// estado nativo PL_ACT_OFFSET_KNOCKBACK. Nao vale contra atacante despertado (inclui gigantes), Supremos,
// cenas, nem quando o defensor esta em estado que nao permite reagir.
struct GrabFighterView {
  uintptr_t player = 0;
  int side = -1;
  int number = 0;     // J1..J6
  int state = -1;     // +0xCC0
  float pos[3]{};
  bool valid = false; // vivo, em campo e com posicao lida
  int pad = -1;       // controle fisico 0..3 ou -1 (CPU)
};

void GrabDefenseInstall();
void GrabDefenseObserveGuard(DWORD pad, const XINPUT_STATE* state, bool connected);
void GrabDefenseBeginBattle();
void GrabDefenseTick(const GrabFighterView* fighters, int count, bool sceneActive, uint64_t now);
bool GrabDefenseFeedback(int* defenderNumber, int* attackerNumber);
