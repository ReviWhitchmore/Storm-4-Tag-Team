#pragma once
#include <cstdint>
#include <algorithm>
// Regras puras e portaveis de IA para os 6 lutadores.
// Mantem a IA nativa controlando sequencia/combos especificos do personagem.
namespace cpuai {
enum class Action : uint8_t { Parry, PerfectSub, GrabDefense, DualCombo, WallRun, Clash, TeamUltimate };
inline bool Enemy(int slotA,int sideA,int slotB,int sideB,bool ffa) {
  return slotA != slotB && (ffa || sideA != sideB);
}
inline int Trait(int characterId) {
  // Personalidade reproducivel por ID, nunca por slot do controle.
  const uint32_t x = static_cast<uint32_t>(characterId >= 0 ? characterId : 0);
  return int(((x * 2654435761u) ^ (x >> 3) ^ 0x9E3779B9u) % 7u) - 3;
}
inline unsigned Chance(unsigned base,int characterId,Action mechanic,int level,bool inDanger=false) {
  if(base==0)return 0;
  const int shifts[]={2,2,1,3,3,0,2};
  const int i=static_cast<int>(mechanic), variation=Trait(characterId)*(i>=0 && i<7?shifts[i]:2);
  const int levelBonus=std::clamp(level,0,3)*4;
  const int risk=inDanger && (mechanic==Action::PerfectSub || mechanic==Action::GrabDefense) ? 5 : 0;
  return static_cast<unsigned>(std::clamp(int(base)+variation+levelBonus+risk,1,95));
}
inline float MashRate(float base,int characterId,int level) {
  if(base<=0)return 0.0f;
  const float multiplier=1.0f+0.045f*float(Trait(characterId))+0.055f*float(std::clamp(level,0,3));
  return std::clamp(base*multiplier,0.5f,15.0f);
}
inline bool CpuParryWindow(bool enabled,bool nativeContact,bool validAttacker,
                            bool scene,bool specialLocked,uint64_t now,uint64_t readyAt) {
  return enabled&&nativeContact&&validAttacker&&!scene&&!specialLocked&&now>=readyAt;
}
}  // namespace cpuai
