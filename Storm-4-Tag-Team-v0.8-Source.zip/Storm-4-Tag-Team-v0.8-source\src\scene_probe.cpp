// Sonda das cenas (so Evolution): registra as trocas de cena e o pacote de parametros que o Combate Livre
// entrega a tela de carregamento VS. Serve para o Chronicles abrir a luta direto, sem a selecao.
//
// Cada cena tem um numero (tabela em .data: id, fabrica, nome): 0x192 ccSceneFreeBattle,
// 0x198 ...Root, 0x199 ...CharacterSelect, 0x19A ...MatchSelect, 0x19B ...VSLoading, 0x1C5 ccSceneBattleStageSelect.
// FUN_14072DE18 e o tratador de mensagens do Root: com o estado 2 no ccSceneFreeBattleChangeParam ele chama
// FUN_140431B94(gerente, 0x19B, parametros), que abre a carga VS com esses parametros.
#include "scene_probe.h"

#include <windows.h>
#include <MinHook.h>
#include <intrin.h>

#include <atomic>
#include <cstdio>
#include <cstring>
#include <string>

#include "addresses.h"
#include "census.h"
#include "log.h"
#include "wall_run.h"
#include "settings.h"
#include "promote.h"
#include "chronicles.h"
#include "chronicles_balance.h"
#include "chronicles_classic_fighters.h"

namespace {

constexpr uint32_t kEvolutionStamp = 0x5889906E;
constexpr uintptr_t kRootMessage = 0x72DE18;
constexpr uintptr_t kOpenSceneWithParam = 0x431B94;
constexpr uintptr_t kChangeScene = 0xAB1570;
constexpr uintptr_t kChangeSceneB = 0xAB1B10;
constexpr size_t kDumpBytes = 0x300;
// Configuracao da luta, a mesma que FUN_14074DDB8 copia ao criar cada membro: lado*0x1AC, papel*0x3C.
constexpr uintptr_t kSideConfig = 0x15FED30;
// Banco de personagens (*0x141609B50 + 0x20) e FUN_140526E1C(banco, id, traje) -> codigo do retrato.
constexpr uintptr_t kCharacterDbHolder = 0x1609B50;
constexpr uintptr_t kFaceCodeOf = 0x526E1C;
constexpr int kMaxCharacterId = 0x200;

using RootMessage_t = uintptr_t (*)(void*, void*);
using OpenScene_t = uintptr_t (*)(void*, int, void*);
using ChangeScene_t = uintptr_t (*)(void*, int);
RootMessage_t g_origRoot = nullptr;
std::atomic<void*> g_manager{nullptr};   // gerente de cenas, visto nas trocas nativas
std::atomic<int> g_pendingMission{-1};    // missao pedida pelo Chronicles
std::atomic<int> g_lastScene{0};          // ultima troca de cena vista (para o modo de teste)
int g_launchMission = -1;                 // missao sendo aberta agora
int g_autotestMission = -1;               // missao do modo de teste (0 = C01), -1 desligado
uint32_t g_autotestStage = 0;             // arena forcada pelo modo de teste (codigo), 0 = normal
int g_autotestLast = -1;                  // encadear: ultima missao (0..39) da sequencia, -1 = so uma
int g_autotestSeconds = 0;                // encadear: segundos de luta antes de voltar ao menu
bool g_autotestCpuPlayer = false;         // modo de teste: J1 tambem na CPU (mede a CPU inimiga)
// Modo de teste: "elenco=a,b,c/d,e,f" (codigos de retrato, ex.: nrt3,ssk6,kks2/itc1,mdr2,obt1) troca os lutadores da
// missao, mantendo o formato dela (use uma missao 3v3 para 3 de cada lado). So para filmar/testar; vazio = elenco da missao.
char g_autotestRoster[2][3][16]{};
ULONGLONG g_fightStartTick = 0;
bool g_returning = false;
unsigned g_forcedStage = 0;      // storm6.ini arena_forcada=
bool g_autotestPause = false;  // teste da pausa (palavra "pausa" no storm6_autotest.txt)
bool g_autotestMenu = false;   // abre a missao pelo menu do Chronicles (palavra "menu")
bool g_autotestVictory = false;  // zera a vida dos inimigos para testar o fim da missao (palavra "vitoria")
bool g_autotestJutsu = false;
bool g_autotestMashB = false;    // controle 1 aperta B sem parar (50 ms sim / 50 ms nao): teste da contagem da disputa    // J1 (controle 1) solta jutsu sem parar: testa o choque de jutsus (palavra "jutsu")
std::atomic<bool> g_autotestDone{false};
ULONGLONG g_menuSeenTick = 0;
std::atomic<bool> g_launching{false};     // pulando a selecao ate a luta abrir
std::atomic<bool> g_loadingShown{false};  // a carga VS da missao ja abriu
// Os dois lados escritos para a missao: a carga VS limpa a tabela ao terminar, entao voltam antes da luta.
uint8_t g_missionConfig[2 * 0x1AC];
uint8_t g_preMissionConfig[2 * 0x1AC]{};
bool g_preMissionConfigValid = false;
void* g_lastMenuStageCleaned = nullptr;
void* g_lastMenuUiCleaned = nullptr;
// Opcoes trocadas so durante a luta da missao (3v3 ligado, J1 no jogador); voltam no menu.
bool g_restoreSettings = false;
ULONGLONG g_launchTick = 0;  // o menu ainda roda alguns quadros depois do pedido de troca
bool g_saved3v3 = false;
int g_savedSlots[6] = {};
OpenScene_t g_origOpen = nullptr;
ChangeScene_t g_origChange = nullptr;
ChangeScene_t g_origChangeB = nullptr;

uintptr_t Rva(void* address) { return reinterpret_cast<uintptr_t>(address) - g_base; }

void DumpBlock(const char* what, const void* block) {
  if (!block) return;
  const auto* bytes = static_cast<const uint8_t*>(block);
  __try {
    for (size_t at = 0; at < kDumpBytes; at += 32) {
      char line[160];
      int used = std::snprintf(line, sizeof(line), "Sonda: %s +%03zX:", what, at);
      for (size_t i = 0; i < 32; i += 4)
        used += std::snprintf(line + used, sizeof(line) - used, " %08X", *reinterpret_cast<const uint32_t*>(bytes + at + i));
      Log("%s", line);
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    Log("Sonda: %s ilegivel", what);
  }
}

void LogSideConfig() {
  const auto* cfg = reinterpret_cast<const uint8_t*>(g_base + kSideConfig);
  __try {
    for (int side = 0; side < 2; ++side) {
      const auto* sideBlock = cfg + 0xC + side * 0x1AC;
      Log("Sonda: lado %d CPU=%d | papel0 id=0x%X traje=%d | papel1 id=0x%X traje=%d | papel2 id=0x%X traje=%d", side,
          *reinterpret_cast<const int*>(sideBlock + 0xB4), *reinterpret_cast<const int*>(sideBlock),
          *reinterpret_cast<const int*>(sideBlock + 4), *reinterpret_cast<const int*>(sideBlock + 0x3C),
          *reinterpret_cast<const int*>(sideBlock + 0x40), *reinterpret_cast<const int*>(sideBlock + 0x78),
          *reinterpret_cast<const int*>(sideBlock + 0x7C));
    }
    const auto* tail = cfg + 0xC + 2 * 0x1AC;
    Log("Sonda: depois dos lados: %X %X %X %X %X %X", *reinterpret_cast<const int*>(tail),
        *reinterpret_cast<const int*>(tail + 4), *reinterpret_cast<const int*>(tail + 8),
        *reinterpret_cast<const int*>(tail + 12), *reinterpret_cast<const int*>(tail + 16),
        *reinterpret_cast<const int*>(tail + 20));
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}

const char* FaceCode(uintptr_t db, int id, int costume) {
  using FaceCode_t = const char* (*)(uintptr_t, int, int);
  const auto faceCode = reinterpret_cast<FaceCode_t>(g_base + kFaceCodeOf);
  __try {
    const char* code = faceCode(db, id, costume);
    if (code && code[0] && strnlen_s(code, 32) < 32) return code;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  return nullptr;
}

uintptr_t CharacterDb() {
  __try {
    const uintptr_t holder = *reinterpret_cast<const uintptr_t*>(g_base + kCharacterDbHolder);
    return holder ? *reinterpret_cast<const uintptr_t*>(holder + 0x20) : 0;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return 0;
  }
}

// Lista id -> codigo do retrato (traje 0 e 1) em storm6_chronicles\evolution\personagens.txt, uma vez.
void DumpCharacterList() {
  static bool done = false;
  if (done) return;
  const uintptr_t db = CharacterDb();
  if (!db) return;
  done = true;
  const std::wstring path = ModDir() + L"storm6_chronicles\\evolution\\personagens.txt";
  FILE* file = _wfsopen(path.c_str(), L"w", 0x40);
  if (!file) return;
  int found = 0;
  for (int id = 0; id < kMaxCharacterId; ++id) {
    const char* first = FaceCode(db, id, 0);
    if (!first) continue;
    const char* second = FaceCode(db, id, 1);
    std::fprintf(file, "0x%03X %s %s\n", id, first, second ? second : "-");
    ++found;
  }
  std::fclose(file);
  Log("Sonda: %d personagens gravados em personagens.txt", found);
}

void LogParamType(const void* param) {
  __try {
    const uintptr_t vtable = *static_cast<const uintptr_t*>(param);
    Log("Sonda: tipo dos parametros: tabela exe+0x%llX", static_cast<unsigned long long>(vtable - g_base));
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}

// Lista das arenas (*0x141609B50 + 0x118: std::map codigo -> ficha) em storm6_chronicles\evolution\arenas.txt.
// Para cada ficha grava o codigo e os textos que ela aponta (nome do arquivo, nome da arena).
bool PrintableText(const char* text, char* out, size_t size) {
  __try {
    size_t n = 0;
    for (; n + 1 < size && text[n]; ++n) {
      if (text[n] < 0x20 || text[n] > 0x7E) return false;
      out[n] = text[n];
    }
    out[n] = 0;
    return n >= 3;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

void DescribeStage(FILE* file, uint32_t code, const uint8_t* entry) {
  std::fprintf(file, "0x%08X", code);
  __try {
    const auto* inner = *reinterpret_cast<const uint8_t* const*>(entry);
    std::fprintf(file, " |");
    for (int at = 0; inner && at < 0x60; at += 4) std::fprintf(file, " %08X", *reinterpret_cast<const uint32_t*>(inner + at));
    char deep[64];
    for (int at = 0; inner && at < 0x60; at += 8) {
      const auto pointer = *reinterpret_cast<const char* const*>(inner + at);
      if (reinterpret_cast<uintptr_t>(pointer) > 0x10000 && PrintableText(pointer, deep, sizeof(deep))) std::fprintf(file, " [i+%X]%s", at, deep);
      else if (PrintableText(reinterpret_cast<const char*>(inner + at), deep, sizeof(deep))) std::fprintf(file, " (i+%X)%s", at, deep);
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  char text[64];
  __try {
    for (int at = 0; at < 0x100; at += 8) {
      const auto pointer = *reinterpret_cast<const char* const*>(entry + at);
      if (reinterpret_cast<uintptr_t>(pointer) > 0x10000 && PrintableText(pointer, text, sizeof(text)))
        std::fprintf(file, " [+%X]%s", at, text);
      else if (PrintableText(reinterpret_cast<const char*>(entry + at), text, sizeof(text)))
        std::fprintf(file, " (+%X)%s", at, text);
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  std::fprintf(file, "\n");
}

uintptr_t StageMapHead() {
  __try {
    const uintptr_t holder = *reinterpret_cast<const uintptr_t*>(g_base + kCharacterDbHolder);
    const uintptr_t map = holder ? *reinterpret_cast<const uintptr_t*>(holder + 0x118) : 0;
    return map ? *reinterpret_cast<const uintptr_t*>(map) : 0;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return 0;
  }
}

int WriteStages(FILE* file, uintptr_t head) {
  int count = 0;
  __try {
    uintptr_t node = *reinterpret_cast<const uintptr_t*>(head);
    for (int guard = 0; node != head && guard < 1000; ++guard) {
      if (*reinterpret_cast<const uint8_t*>(node + 0x19)) break;
      DescribeStage(file, *reinterpret_cast<const uint32_t*>(node + 0x20),
                    *reinterpret_cast<const uint8_t* const*>(node + 0x28));
      ++count;
      uintptr_t right = *reinterpret_cast<const uintptr_t*>(node + 0x10);
      if (!*reinterpret_cast<const uint8_t*>(right + 0x19)) {
        node = right;
        while (!*reinterpret_cast<const uint8_t*>(*reinterpret_cast<const uintptr_t*>(node) + 0x19))
          node = *reinterpret_cast<const uintptr_t*>(node);
      } else {
        uintptr_t parent = *reinterpret_cast<const uintptr_t*>(node + 8);
        while (!*reinterpret_cast<const uint8_t*>(parent + 0x19) && node == *reinterpret_cast<const uintptr_t*>(parent + 0x10)) {
          node = parent;
          parent = *reinterpret_cast<const uintptr_t*>(node + 8);
        }
        node = parent;
      }
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  return count;
}

void DumpStageList() {
  static bool done = false;
  if (done) return;
  done = true;
  const uintptr_t head = StageMapHead();
  if (!head) {
    Log("Sonda: lista de arenas indisponivel");
    return;
  }
  const std::wstring path = ModDir() + L"storm6_chronicles\\evolution\\arenas.txt";
  FILE* file = _wfsopen(path.c_str(), L"w", 0x40);
  if (!file) return;
  const int count = WriteStages(file, head);
  std::fclose(file);
  Log("Sonda: %d arenas gravadas em arenas.txt", count);
}
uintptr_t HookRoot(void* scene, void* message) {
  DumpCharacterList();
  __try {
    const int id = *reinterpret_cast<const int*>(static_cast<const uint8_t*>(message) + 0xC);
    const int state = *reinterpret_cast<const int*>(static_cast<const uint8_t*>(message) + 0x18);
    Log("Sonda: Root recebeu mensagem id=0x%X estado=%d parametros=%p", id, state, message);
    if (id == 0x192 && state == 2) DumpBlock("parametros da luta", message);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  return g_origRoot(scene, message);
}

uintptr_t HookOpen(void* manager, int id, void* param) {
  g_manager.store(manager, std::memory_order_relaxed);
  if (g_launching.load() && id == 0x19A) {
    // Missao do Chronicles: a configuracao ja esta escrita, entao vai direto para a carga VS.
    Log("Chronicles: pulando a selecao, abrindo a carga VS (0x19B).");
    id = 0x19B;
    g_loadingShown = true;
  } else if (g_launching.load() && g_loadingShown.load() && id == 0x199) {
    // Depois da carga VS o Root seguiria a ordem normal e abriria a selecao de personagens.
    Log("Chronicles: carga VS terminada, abrindo a luta (0x192) com a escalacao da missao.");
    id = 0x192;
    std::memcpy(reinterpret_cast<void*>(g_base + kSideConfig + 0xC), g_missionConfig, sizeof(g_missionConfig));
  }
  if (id == 0x192) {
    g_launching = false;
    g_loadingShown = false;
  }
  Log("Sonda: abrir cena 0x%X com parametros %p (chamada exe+0x%llX)", id, param,
      static_cast<unsigned long long>(Rva(_ReturnAddress())));
  // 0x15E..0x164: lutas comuns do modo historia (ccSceneEpisodeBattle*).
  const bool story = (id >= 0x15E && id <= 0x164) || (id >= 0x14C && id <= 0x150);
  if (id == 0x19B || id == 0x192 || story) LogSideConfig();
  if (param && (id == 0x199 || id == 0x1C5 || id == 0x19B || id == 0x192 || story)) {
    char what[48];
    std::snprintf(what, sizeof(what), "parametros para 0x%X", id);
    LogParamType(param);
    DumpBlock(what, param);
  }
  return g_origOpen(manager, id, param);
}

// Carregador da luta (*0x1415FE490): registra cada mudanca de estado (+0x40) e a criacao de cada lado.
using LoaderUpdate_t = uintptr_t (*)(void*);
using CreateSide_t = uintptr_t (*)(void*, int);
LoaderUpdate_t g_origLoaderUpdate = nullptr;
CreateSide_t g_origCreateSide = nullptr;
int g_lastLoaderState = -1;

uintptr_t HookLoaderUpdate(void* loader) {
  const uintptr_t r = g_origLoaderUpdate(loader);
  __try {
    const int state = *reinterpret_cast<const int*>(static_cast<uint8_t*>(loader) + 0x40);
    if (state != g_lastLoaderState) {
      const uintptr_t mode = *reinterpret_cast<const uintptr_t*>(g_base + 0x15F5B50);
      const int path = mode ? *reinterpret_cast<const int*>(mode + 0x1D390) : -1;
      Log("Sonda: carregador estado %d -> %d (caminho %d, +98=%d +9C=%d)", g_lastLoaderState, state, path,
          *reinterpret_cast<const int*>(static_cast<uint8_t*>(loader) + 0x98),
          *reinterpret_cast<const int*>(static_cast<uint8_t*>(loader) + 0x9C));
      g_lastLoaderState = state;
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  return r;
}

// Barras de vida nativas: FUN_14063C4C0(gerente da interface, x) so cria o painel (ccUiFlashBattleGauge, global
// 0x1415F0B50) se +0x94 ou +0xF0 do gerente estiver ligado. Na luta do Chronicles os dois chegam desligados.
using GaugeCreate_t = uintptr_t (*)(void*, int);
GaugeCreate_t g_origGaugeCreate = nullptr;
std::atomic<bool> g_missionFight{false};
void* g_uiManager = nullptr;  // gerente da interface da luta, visto ao criar o painel

uintptr_t HookGaugeCreate(void* manager, int arg) {
  g_uiManager = manager;
  auto* bytes = static_cast<uint8_t*>(manager);
  __try {
    int* a = reinterpret_cast<int*>(bytes + 0x94);
    int* b = reinterpret_cast<int*>(bytes + 0xF0);
    Log("Sonda: painel de vida pedido (+94=%d +F0=%d, luta do Chronicles=%d)", *a, *b, int(g_missionFight.load()));
    if (g_missionFight.load() && !*a && !*b) *a = 1;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
  const uintptr_t r = g_origGaugeCreate(manager, arg);
  return r;
}

// FUN_14063D754(gerente): atualizacao do painel a cada quadro. Na luta da missao, depois de 30 quadros chama
// FUN_14063CC60(gerente), que e o que a luta livre usa para o painel entrar ("_root.all_nut" gotoAndPlay).
using GaugeUpdate_t = uintptr_t (*)(void*);
GaugeUpdate_t g_origGaugeUpdate = nullptr;
int g_gaugeFrames = 0;
bool g_gaugeShown = false;

// ---------------------------------------------------------------- fim da missao
// No carregador da historia o juiz nativo de fim de luta nao roda: com todos os inimigos a 0 de vida a luta
// ficava parada. O mod detecta o resultado pela vida de cada lado (lista nativa do duelo), mostra a faixa
// de vitoria/derrota (hud.cpp), grava a missao como concluida e, 6 s depois, encerra a cena da luta com
// FUN_140AB1870 (o mesmo pedido de fim que as cenas da historia usam).
std::atomic<int> g_missionResult{0};  // 0 lutando, 1 vitoria, 2 derrota
int g_pendingResult = 0;
ULONGLONG g_resultSince = 0;
std::atomic<ULONGLONG> g_resultAt{0};
bool g_resultFinished = false;
constexpr ULONGLONG kResultBannerMs = 6000;

void MissionEndTick() {
  const ULONGLONG now = GetTickCount64();
  if (g_missionResult.load() == 0) {
    float life[2]{};
    int members[2]{};
    if (!PromoteSideLife(0, &life[0], &members[0]) || !PromoteSideLife(1, &life[1], &members[1])) return;
    const int result = life[1] <= 0.0f ? 1 : life[0] <= 0.0f ? 2 : 0;
    if (result != g_pendingResult) {
      g_pendingResult = result;
      g_resultSince = now;
      return;
    }
    if (!result || now - g_resultSince < 1500) return;
    g_resultAt = now;
    g_missionResult = result;
    Log("Chronicles: missao %d terminou em %s (vida aliados %.0f, inimigos %.0f).", g_launchMission + 1,
        result == 1 ? "VITORIA" : "DERROTA", life[0], life[1]);
    if (result == 1) ChroniclesMarkCompleted(g_launchMission);
    return;
  }
  if (!g_resultFinished && now - g_resultAt.load() >= kResultBannerMs) {
    g_resultFinished = true;
    __try {
      if (void* manager = *reinterpret_cast<void**>(g_base + 0x16AACD8)) {
        reinterpret_cast<void (*)(void*)>(g_base + 0xAB1870)(manager);
        Log("Chronicles: luta encerrada; o jogo segue para o fim da missao.");
      }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("Chronicles: encerrar a luta falhou (0x%08lX)", GetExceptionCode());
    }
  }
}

uintptr_t HookGaugeUpdate(void* manager) {
  const uintptr_t r = g_origGaugeUpdate(manager);
  if (g_missionFight.load()) {
    PromoteForeignJudgeTick();
    ChroniclesBalanceTick();
    if (g_lastScene.load() == 0x150 && g_fightStartTick && GetTickCount64() - g_fightStartTick > 3000)
      MissionEndTick();
    // Teste da vitoria (palavra "vitoria" no arquivo de teste): 8 s depois da luta principal abrir,
    // zera a vida dos inimigos para ver o que o jogo faz no fim da missao.
    if (g_autotestVictory && g_fightStartTick && GetTickCount64() - g_fightStartTick > 8000) {
      static ULONGLONG lastKill = 0;
      if (GetTickCount64() - lastKill > 1000) {
        lastKill = GetTickCount64();
        for (int k = 0; k < PromoteFighterCount(); ++k)
          if (PromoteFighterSide(k) == 1) PromoteSetFighterLife(k, 0.0f);
        Log("Teste: vida dos inimigos zerada.");
      }
    }
    // Modo de teste encadeado: depois do tempo de luta, volta ao menu de modos (0x8) para a proxima missao.
    // A contagem comeca apenas depois que a cena de luta PRINCIPAL (0x150)
    // realmente abriu. Antes disso o cronometro visual ainda esta em 99.
    if (g_autotestSeconds > 0 && g_autotestLast >= 0 &&
        g_fightStartTick != 0 && g_lastScene.load() == 0x150 &&
        !g_returning && g_manager.load() &&
        GetTickCount64() - g_fightStartTick >=
          static_cast<ULONGLONG>(g_autotestSeconds) * 1000) {
      g_returning = true;
      Log("Teste: encerrando a missao %d depois de %d s na cena 0x150; retornando ao menu.",
          g_launchMission + 1, g_autotestSeconds);
      // Desabilita observadores ANTES de soltar as cenas da luta.
      g_missionFight = false;
      ChroniclesBalanceEnd();
      g_gaugeFrames = 0;
      g_gaugeShown = false;
      g_lastScene.store(0x8);
      g_origChange(g_manager.load(), 0x8);
      Log("Teste: transicao para o menu 0x8 solicitada; aguardando o menu nativo.");
    }
  }
  if (!g_missionFight.load()) {
    g_gaugeFrames = 0;
    g_gaugeShown = false;
  } else if (!g_gaugeShown && ++g_gaugeFrames >= 30) {
    g_gaugeShown = true;
    __try {
      reinterpret_cast<void (*)(void*)>(g_base + 0x63CC60)(manager);
      Log("Chronicles: painel de vida mostrado.");
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("Chronicles: mostrar o painel de vida falhou (0x%08lX)", GetExceptionCode());
    }
  }
  return r;
}

// ccSceneBossBattleFreeBattleBegin (0x14F), vtable[4] = atualizacao por quadro (FUN_140430EE0).
// So pede o fim (0xAB1870 -> Root avanca para 0x150) quando o fade (+0x128) termina (FUN_14063B4BC).
// +0x130 modo (0 entrada, 1 demo, 2 ...), +0x134 contador, +0x138 pronto, +0x148 demo.
using BeginUpdate_t = uintptr_t (*)(void*);
BeginUpdate_t g_origBeginUpdate = nullptr;
ULONGLONG g_beginLogTick = 0;

void* g_beginScene = nullptr;
ULONGLONG g_beginSince = 0;
bool g_beginForced = false;

uintptr_t HookBeginUpdate(void* scene) {
  const uintptr_t r = g_origBeginUpdate(scene);
  const ULONGLONG now = GetTickCount64();
  if (scene != g_beginScene) {
    g_beginScene = scene;
    g_beginSince = now;
    g_beginForced = false;
  }
  // Na luta do Chronicles as animacoes do "Ready/Fight" (+0x128, +0x48/+0x50) nunca terminam, entao a cena
  // fica parada aqui (relogio em 99, lutadores parados). Depois de 3 s, pede o fim como o proprio jogo faria.
  if (g_missionFight.load() && !g_beginForced && now - g_beginSince >= 3000) {
    g_beginForced = true;
    __try {
      void* manager = *reinterpret_cast<void**>(g_base + 0x16AACD8);
      if (manager) {
        reinterpret_cast<void (*)(void*)>(g_base + 0xAB1870)(manager);
        Log("Chronicles: inicio da luta destravado (0x14F -> luta principal).");
      }
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("Chronicles: destravar o inicio falhou (0x%08lX)", GetExceptionCode());
    }
  }
  if (now - g_beginLogTick >= 1000) {
    g_beginLogTick = now;
    __try {
      auto* b = static_cast<uint8_t*>(scene);
      auto* fader = *reinterpret_cast<uint8_t**>(b + 0x128);
      const int fadeDone = fader ? reinterpret_cast<int (*)(void*)>(g_base + 0x63B4BC)(fader) : -1;
      const uintptr_t flags = *reinterpret_cast<const uintptr_t*>(g_base + 0x1609B88);
      int states[2] = {-1, -1};
      for (int i = 0; i < 2; ++i) {
        auto* p = reinterpret_cast<uint8_t* (*)(int)>(g_base + 0x856690)(i);
        if (p) states[i] = *reinterpret_cast<int*>(p + 0xCC0);
      }
      Log("Sonda: inicio 0x14F modo=%d cont=%d pronto=%d fade=%p (+60=%d, fim=%d) demo=%p luta+244=%d estados=%d/%d",
          *reinterpret_cast<int*>(b + 0x130), *reinterpret_cast<int*>(b + 0x134), *reinterpret_cast<int*>(b + 0x138),
          fader, fader ? *reinterpret_cast<int*>(fader + 0x60) : -1, fadeDone, *reinterpret_cast<void**>(b + 0x148),
          flags ? *reinterpret_cast<int*>(flags + 0x244) : -1, states[0], states[1]);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("Sonda: inicio 0x14F leitura falhou");
    }
  }
  return r;
}

// FUN_1406D10A8: cria o menu de pausa da luta conforme o tipo de partida (*0x1415FF220). O Chronicles abre a
// luta com tipo 2, que nao tem menu de pausa (START nao fazia nada). So durante essa criacao, o tipo vira 0
// (Combate Livre), cujo menu de pausa e o normal; depois o valor original volta.
using PauseCreate_t = uintptr_t (*)(void*);
PauseCreate_t g_origPauseCreate = nullptr;

uintptr_t HookPauseCreate(void* scene) {
  if (!g_missionFight.load()) return g_origPauseCreate(scene);
  int* matchType = reinterpret_cast<int*>(g_base + 0x15FF220);
  const int saved = *matchType;
  *matchType = 0;
  const uintptr_t r = g_origPauseCreate(scene);
  *matchType = saved;
  Log("Chronicles: menu de pausa criado (tipo de partida %d tratado como Combate Livre).", saved);
  return r;
}

uintptr_t HookCreateSide(void* duel, int side) {
  Log("Sonda: criando lado %d", side);
  return g_origCreateSide(duel, side);
}

uintptr_t HookChange(void* manager, int id) {
  g_manager.store(manager, std::memory_order_relaxed);
  g_lastScene.store(id, std::memory_order_relaxed);
  if (id >= 0x15E && id <= 0x164) LogSideConfig();
  Log("Sonda: trocar para cena 0x%X (chamada exe+0x%llX)", id, static_cast<unsigned long long>(Rva(_ReturnAddress())));
  const uintptr_t r = g_origChange(manager, id);
  if (id == 0x150 && g_missionFight.load()) {
    // A luta esta no mapa; so AGORA comeca o cronometro de teste.
    g_fightStartTick = GetTickCount64();
    Log("Teste: cena 0x150 ativa, iniciando cronometro da missao %d.",
        g_launchMission + 1);
  }
  if (id == 0x8) {
    g_lastMenuStageCleaned = nullptr;
    g_lastMenuUiCleaned = nullptr;
  }
  // Luta principal (0x150) da missao: o carregador da historia nao mostra o painel de vida;
  // FUN_14063CC60(gerente) e o que a luta livre chama para ele entrar ("_root.all_nut", gotoAndPlay).
  if (false) {
    __try {
      reinterpret_cast<void (*)(void*)>(g_base + 0x63CC60)(g_uiManager);
      Log("Chronicles: painel de vida mostrado.");
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("Chronicles: mostrar o painel de vida falhou (0x%08lX)", GetExceptionCode());
    }
  }
  return r;
}

uintptr_t HookChangeB(void* manager, int id) {
  Log("Sonda: trocar (B) para cena 0x%X (chamada exe+0x%llX)", id,
      static_cast<unsigned long long>(Rva(_ReturnAddress())));
  return g_origChangeB(manager, id);
}

bool Hook(uintptr_t rva, void* detour, void** original, const char* name) {
  void* target = reinterpret_cast<void*>(g_base + rva);
  MH_STATUS status = MH_CreateHook(target, detour, original);
  if (status == MH_OK) status = MH_EnableHook(target);
  Log("Sonda: %s %s", name, status == MH_OK ? "instalada" : MH_StatusToString(status));
  return status == MH_OK;
}

}  // namespace

namespace {

// Arena de cada missao (codigos lidos da lista do jogo e conferidos por foto, 10/11/2026). Quando a arena exata
// do anime nao existe no Storm 4, usa a mais parecida.
constexpr uint32_t kTrainingField = 0xAA814F39;   // campo verde (STAGE_SD04B) - Campo de Treinamento
constexpr uint32_t kWavesRiver = 0xD9B2BC6D;      // rio entre rochas (SD17B) - Pais das Ondas
constexpr uint32_t kWavesLake = 0x6326BD2A;       // lago ao entardecer (SP40B) - Grande Ponte Naruto
constexpr uint32_t kLeafVillage = 0x46C73D54;     // Vila da Folha (SD62A)
constexpr uint32_t kDeathForest = 0x273AE2FE;     // floresta de raizes gigantes (SD01D) - Floresta da Morte
constexpr uint32_t kPrelimHall = 0x91D5BB1D;      // salao fechado (SD13A) - Arena das Preliminares
constexpr uint32_t kFinalsArena = 0xE45C56D2;     // patio de pedra com muro (SD50A) - Arena das Finais
constexpr uint32_t kLeafForest = 0x900D179A;      // floresta (SD03A) - Floresta de Konoha
constexpr uint32_t kBarrierRoof = 0x83096146;     // piso com barreira roxa (SD03E) - Telhados / barreira
constexpr uint32_t kInnRoom = 0x9264E213;         // interior de madeira (SD33A) - Hotel da Vila
constexpr uint32_t kOpenField = 0x0730F7EF;       // campo aberto (SD06A)
constexpr uint32_t kSanninField = 0x68AE0B1B;     // desfiladeiro ao entardecer (SD08A) - Campo dos Tres Sannin
constexpr uint32_t kHospitalRoof = 0x698DC72D;    // telhado de pedra (SI01A) - Telhado do Hospital
constexpr uint32_t kSoundForest = 0x5E42B957;     // floresta com tocos (SI06A) - Floresta do resgate
constexpr uint32_t kValleyOfEnd = 0x32967C1C;     // cachoeira com estatua (SD31A) - Vale do Fim
constexpr uint32_t kMissionStage[40] = {
    kTrainingField,                                                                // C01
    kWavesRiver, kWavesRiver, kWavesLake, kWavesLake, kWavesLake,                  // C02-C06
    kLeafVillage, kDeathForest, kDeathForest, kPrelimHall, kPrelimHall, kPrelimHall, kPrelimHall,  // C07-C13
    kFinalsArena, kFinalsArena, kFinalsArena, kLeafForest, kLeafForest,            // C14-C18
    kBarrierRoof,                                                                  // C19
    kLeafVillage, kInnRoom, kOpenField, kOpenField, kSanninField, kSanninField, kHospitalRoof,  // C20-C26
    kSoundForest, kSoundForest, kSoundForest, kSoundForest, kSoundForest, kSoundForest,  // C27-C32
    kSoundForest, kSoundForest, kSoundForest, kSoundForest, kValleyOfEnd,           // C33-C37
    kSoundForest, kSoundForest, kValleyOfEnd};                                     // C38-C40
// ---------------------------------------------------------------- luta direta do Chronicles
// Codigo do retrato de cada lutador da campanha classica (versao infancia, terminada em 1).
const char* ClassicFaceCode(chronicles_classic::Fighter fighter) {
  using F = chronicles_classic::Fighter;
  switch (fighter) {
    case F::Naruto: return "nrt1";     case F::Sasuke: return "ssk1";   case F::Sakura: return "skr1";
    // kks1 (0x42) e o Kakashi jovem; o adulto do classico e kks2.
    case F::Kakashi: return "kks2";   case F::Zabuza: return "zbz1";   case F::Haku: return "hak1";
    case F::RockLee: return "roc1";    case F::Orochimaru: return "orc1"; case F::Ino: return "ino1";
    case F::Kiba: return "kib1";       case F::Hinata: return "hnt1";   case F::Neji: return "nej1";
    case F::Gaara: return "gar1";      case F::Shikamaru: return "sik1"; case F::Temari: return "tmr1";
    case F::Shino: return "sin1";      case F::Kankuro: return "knk1";  case F::Hiruzen: return "hrz1";
    case F::Itachi: return "itc1";     case F::Kisame: return "ksm1";   case F::Kabuto: return "kbt1";
    case F::Tsunade: return "tnd1";    case F::Jiraiya: return "jry1";  case F::Choji: return "tyo1";
    case F::Jirobo: return "jrb1";     case F::Kidomaru: return "kdm1"; case F::SakonUkon: return "skn1";
    case F::Tayuya: return "tyy1";     case F::Kimimaro: return "kmm1";
    default: return nullptr;
  }
}

// Primeiro numero de personagem do jogo cujo retrato (traje 0) e esse codigo, ou -1.
int CharacterIdFor(uintptr_t db, const char* code) {
  for (int id = 0; id < kMaxCharacterId; ++id) {
    const char* face = FaceCode(db, id, 0);
    if (face && std::strcmp(face, code) == 0) return id;
  }
  return -1;
}

bool WriteTeam(uint8_t* sideBlock, const chronicles_classic::BattleTeam& team, const int ids[3], bool cpu) {
  uint8_t filled[0x3C], empty[0x3C];
  std::memcpy(filled, sideBlock, sizeof(filled));
  std::memcpy(empty, sideBlock, sizeof(empty));
  *reinterpret_cast<int*>(empty + 0x00) = 0;
  *reinterpret_cast<int*>(empty + 0x04) = 0;
  *reinterpret_cast<int*>(empty + 0x24) = -1;
  for (int role = 0; role < 3; ++role) {
    uint8_t* block = sideBlock + role * 0x3C;
    if (role < team.count) {
      std::memcpy(block, filled, sizeof(filled));
      *reinterpret_cast<int*>(block + 0x00) = ids[role];
      *reinterpret_cast<int*>(block + 0x04) = 0;
    } else {
      std::memcpy(block, empty, sizeof(empty));
    }
  }
  *reinterpret_cast<int*>(sideBlock + 0xB4) = cpu ? 1 : 0;
  return true;
}

// ---------------------------------------------------------------- valores que a fase da historia publica
// A carga VS do carregador da historia (FUN_140431FC4) espera dois valores no registro de nomes do jogo
// (*0x1416AACE8): "BossBattleIsFreeLoaded" (inteiro) e "BossBattleFreePreLoadTask" (ponteiro para uma
// tarefa cujo +0x20 == 0 libera a carga). A fase do chefe os publica (FUN_140439D..); aqui o mod publica.
constexpr uintptr_t kRegistry = 0x16AACE8;
constexpr uintptr_t kPublishInt = 0x1D0044;    // (registro, dono, nome, &int)
constexpr uintptr_t kPublishTask = 0x4374C0;   // (registro, dono, nome, &ponteiro_da_tarefa)
constexpr uintptr_t kLookup = 0xAB3840;        // (registro, nome) -> suporte do valor
constexpr uintptr_t kNameLoaded = 0xFED1A8;
constexpr uintptr_t kNameTask = 0xFED1C0;
constexpr uintptr_t kBossFreeStart = 0x42DFDC;
constexpr uintptr_t kSetSlot = 0x74AE0C;
constexpr uintptr_t kSlotDone = 0x74B8A0;
constexpr uintptr_t kLoaderGlobal = 0x15FE490;
constexpr uintptr_t kLoaderDestroy = 0x73A560;
constexpr uintptr_t kNameSelect = 0xEE71E8;    // "BattleSelectParam"
// BattleSelectParam: objeto de 0x11E0 bytes (alocador FUN_1409FD480, construtor FUN_14073B974, inicio
// FUN_14073BC04). Os dois lados ficam em +0xC0 com o mesmo formato da tabela (lado*0x1AC) e a arena em +0x418.
constexpr uintptr_t kAllocate = 0x9FD480;
constexpr uintptr_t kAllocFile = 0xFEECB0;
constexpr uintptr_t kSelectCtor = 0x73B974;
constexpr uintptr_t kSelectInit = 0x73BC04;
constexpr uintptr_t kPublishObject = 0x274D88;  // (registro, dono, nome, objeto)
constexpr size_t kSelectSize = 0x11E0;

// Dono dos valores: texto curto no formato std::string do MSVC (16 bytes de texto, tamanho, capacidade).
struct OwnerKey {
  char text[16] = "storm6chronicle";
  size_t size = 15;
  size_t capacity = 15;
};
OwnerKey g_owner;
int g_freeLoaded = 1;
void TaskNoop(void*, int) {}
void* g_taskVtable[16];
struct FakeTask {
  void** vtable;
  uint8_t data[0x58];
};
FakeTask g_task{};
void* g_taskPointer = &g_task;

bool Published(const char* what, uintptr_t nameRva) {
  using Lookup_t = uintptr_t (*)(void*, const char*);
  void* registry = *reinterpret_cast<void**>(g_base + kRegistry);
  __try {
    const uintptr_t holder = reinterpret_cast<Lookup_t>(g_base + kLookup)(registry, reinterpret_cast<const char*>(g_base + nameRva));
    const bool present = holder && *reinterpret_cast<const uintptr_t*>(holder + 8);
    Log("Chronicles: valor %s %s", what, present ? "presente" : "ausente");
    return present;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    Log("Chronicles: leitura de %s falhou", what);
    return false;
  }
}

bool PublishStoryValues() {
  using PublishInt_t = void (*)(void*, void*, const char*, int*);
  using PublishTask_t = void (*)(void*, void*, const char*, void**);
  for (auto& entry : g_taskVtable) entry = reinterpret_cast<void*>(&TaskNoop);
  g_task.vtable = g_taskVtable;
  void* registry = *reinterpret_cast<void**>(g_base + kRegistry);
  __try {
    reinterpret_cast<PublishInt_t>(g_base + kPublishInt)(registry, &g_owner,
        reinterpret_cast<const char*>(g_base + kNameLoaded), &g_freeLoaded);
    reinterpret_cast<PublishTask_t>(g_base + kPublishTask)(registry, &g_owner,
        reinterpret_cast<const char*>(g_base + kNameTask), &g_taskPointer);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    Log("Chronicles: publicar os valores da historia falhou (0x%08lX)", GetExceptionCode());
    return false;
  }
  if (!Published("BattleSelectParam", kNameSelect)) {
    using Allocate_t = void* (*)(size_t, const char*, int);
    using Method_t = void* (*)(void*);
    using PublishObject_t = void (*)(void*, void*, const char*, void*);
    __try {
      void* select = reinterpret_cast<Allocate_t>(g_base + kAllocate)(kSelectSize,
          reinterpret_cast<const char*>(g_base + kAllocFile), 0x23B);
      if (!select) return false;
      reinterpret_cast<Method_t>(g_base + kSelectCtor)(select);
      reinterpret_cast<Method_t>(g_base + kSelectInit)(select);
      auto* bytes = static_cast<uint8_t*>(select);
      const auto* table = reinterpret_cast<const uint8_t*>(g_base + kSideConfig + 0xC);
      std::memcpy(bytes + 0xC0, table, 2 * 0x1AC);
      // Os outros campos sao o inverso de FUN_14073BA80, que copia esta ficha para as variaveis globais:
      // +0x00..0x17 -> 0x15FF094 (tempo 99 etc.), +0x418 -> 0x15FED38 (codigo da arena), +0x41C -> 0x15FF220,
      // +0x420 -> 0x15FF21C, +0x428 -> 0x15FF334, +0x42C -> 0x15FF224. Aqui vem o que o jogo ja tem.
      const auto global = [](uintptr_t rva) { return *reinterpret_cast<const int*>(g_base + rva); };
      std::memcpy(bytes, reinterpret_cast<const void*>(g_base + 0x15FF094), 0x18);
      // Logo depois de abrir o jogo ainda nao ha arena escolhida (-1): usa a arena vista no Combate Livre
      // (codigo 0xE635A35B) ate o Chronicles ter a lista de arenas.
      const int stage = global(0x15FED38);
      *reinterpret_cast<int*>(bytes + 0x418) = (stage == -1 || stage == 0) ? static_cast<int>(0xE635A35Bu) : stage;
      if (g_launchMission >= 0 && g_launchMission < 40)
        *reinterpret_cast<int*>(bytes + 0x418) = static_cast<int>(kMissionStage[g_launchMission]);
      if (g_forcedStage) *reinterpret_cast<int*>(bytes + 0x418) = static_cast<int>(g_forcedStage);  // arena_forcada=
      if (g_autotestStage) *reinterpret_cast<int*>(bytes + 0x418) = static_cast<int>(g_autotestStage);
      // +0x41C vai para 0x15FF220, o tipo de partida: a fase de chefe (FUN_140439B5C) grava 2 ali.
      *reinterpret_cast<int*>(bytes + 0x41C) = 2;
      *reinterpret_cast<int*>(bytes + 0x420) = global(0x15FF21C);
      *reinterpret_cast<int*>(bytes + 0x428) = global(0x15FF334);
      *reinterpret_cast<int*>(bytes + 0x42C) = global(0x15FF224);
      Log("Chronicles: arena codigo 0x%08X, modo %d, %d, %d, %d", *reinterpret_cast<int*>(bytes + 0x418),
          *reinterpret_cast<int*>(bytes + 0x41C), *reinterpret_cast<int*>(bytes + 0x420),
          *reinterpret_cast<int*>(bytes + 0x428), *reinterpret_cast<int*>(bytes + 0x42C));      reinterpret_cast<PublishObject_t>(g_base + kPublishObject)(registry, &g_owner,
          reinterpret_cast<const char*>(g_base + kNameSelect), select);
      Log("Chronicles: BattleSelectParam criado em %p (arena 0x%X)", select, *reinterpret_cast<int*>(bytes + 0x418));
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("Chronicles: criar BattleSelectParam falhou (0x%08lX)", GetExceptionCode());
      return false;
    }
  }
  const bool loaded = Published("BossBattleIsFreeLoaded", kNameLoaded);
  const bool task = Published("BossBattleFreePreLoadTask", kNameTask);
  const bool select = Published("BattleSelectParam", kNameSelect);
  return loaded && task && select;
}

}  // namespace

void SceneLaunchRequest(int mission) {
  if (Addr().timestamp != kEvolutionStamp) {
    Log("Chronicles: abrir a luta direto ainda so funciona no Evolution.");
    return;
  }
  g_pendingMission.store(mission);
}

int SceneProbeMissionResult(int* mission, unsigned* elapsedMs) {
  const int result = g_missionResult.load();
  if (!result || !g_missionFight.load()) return 0;
  *mission = g_launchMission;
  *elapsedMs = static_cast<unsigned>(GetTickCount64() - g_resultAt.load());
  return result;
}

bool SceneProbeMissionFight() {
  // Ligado do pedido da missao ate a volta ao menu de modos (as cenas da luta nao passam pelo menu).
  return g_missionFight.load();
}

DWORD SceneAutotestInput(DWORD index, XINPUT_STATE* state, DWORD result) {
  // Teste do mapa das paredes (parede_teste=2): o J1 corre de verdade ate o limite da arena.
  if (index == 0 && state && g_autotestMission >= 0) {
    short lx = 0, ly = 0;
    WORD buttons = 0;
    if (WallRunTestInput(&lx, &ly, &buttons)) {
      if (result != ERROR_SUCCESS) ZeroMemory(state, sizeof(*state));
      state->Gamepad.sThumbLX = lx;
      state->Gamepad.sThumbLY = ly;
      state->Gamepad.wButtons |= buttons;
      return ERROR_SUCCESS;
    }
  }
  // Teste da pausa: 5 s depois da luta principal abrir, aperta START por 150 ms no controle 1.
  // So com "pausa" no arquivo de teste: num teste normal o menu de pausa congelaria a luta inteira.
  if (g_autotestPause && g_autotestMission >= 0 && index == 0 && state && g_fightStartTick &&
      g_lastScene.load(std::memory_order_relaxed) == 0x150) {
    const ULONGLONG elapsed = GetTickCount64() - g_fightStartTick;
    if (elapsed >= 5000 && elapsed < 5150) {
      static bool logged = false;
      if (!logged) {
        logged = true;
        Log("Teste: apertando START para pausar a luta.");
      }
      if (result != ERROR_SUCCESS) ZeroMemory(state, sizeof(*state));
      state->Gamepad.wButtons |= XINPUT_GAMEPAD_START;
      return ERROR_SUCCESS;
    }
  }
  // Teste do choque de jutsus: a cada 2,4 s, toque em Y (chakra) e logo depois B = jutsu; no resto do ciclo segura Y
  // para recarregar o chakra. So com "jutsu" no arquivo de teste e J1 no controle 1 (ultimo numero 0).
  if (g_autotestMashB && g_autotestMission >= 0 && index == 0 && state && g_fightStartTick &&
      g_lastScene.load(std::memory_order_relaxed) == 0x150 && GetTickCount64() - g_fightStartTick >= 3000) {
    static bool logged = false;
    if (!logged) {
      logged = true;
      Log("Teste: controle 1 apertando B sem parar (contagem da disputa).");
    }
    if (result != ERROR_SUCCESS) ZeroMemory(state, sizeof(*state));
    if ((GetTickCount64() / 50) % 2 == 0) state->Gamepad.wButtons |= XINPUT_GAMEPAD_B;
    return ERROR_SUCCESS;
  }
  if (g_autotestJutsu && g_autotestMission >= 0 && index == 0 && state && g_fightStartTick &&
      g_lastScene.load(std::memory_order_relaxed) == 0x150) {
    const ULONGLONG elapsed = GetTickCount64() - g_fightStartTick;
    if (elapsed >= 4000) {
      static bool logged = false;
      if (!logged) {
        logged = true;
        Log("Teste: controle 1 soltando jutsus (Y+B) a cada 2,4 s.");
      }
      const ULONGLONG t = elapsed % 2400;
      if (result != ERROR_SUCCESS) ZeroMemory(state, sizeof(*state));
      if (t < 70) state->Gamepad.wButtons |= XINPUT_GAMEPAD_Y;
      if (t >= 110 && t < 190) state->Gamepad.wButtons |= XINPUT_GAMEPAD_B;
      if (t >= 1100 && t < 2200) state->Gamepad.wButtons |= XINPUT_GAMEPAD_Y;
      return ERROR_SUCCESS;
    }
  }
  if (g_autotestMission < 0 || index != 0 || !state || g_autotestDone.load()) return result;
  const int scene = g_lastScene.load(std::memory_order_relaxed);
  // Teste pelo menu do Chronicles, como o jogador: Y abre o painel, A arco, A missao, A confirma.
  if (g_autotestMenu && scene == 0x8 && g_menuSeenTick) {
    const ULONGLONG t = GetTickCount64() - g_menuSeenTick;
    static const struct { ULONGLONG at; WORD button; } kSteps[] = {
        {2000, XINPUT_GAMEPAD_Y}, {3500, XINPUT_GAMEPAD_A}, {5000, XINPUT_GAMEPAD_A}, {6500, XINPUT_GAMEPAD_A}};
    if (result != ERROR_SUCCESS) ZeroMemory(state, sizeof(*state));
    for (const auto& step : kSteps)
      if (t >= step.at && t < step.at + 150) state->Gamepad.wButtons |= step.button;
    if (t >= 7000) g_autotestDone = true;
    return ERROR_SUCCESS;
  }
  // Telas de abertura ate o menu de modos (0x8): aperta START e A alternados, 120 ms a cada 1,2 s.
  if (scene == 0x8 || g_menuSeenTick) return result;
  const ULONGLONG phase = GetTickCount64() % 1200;
  if (result != ERROR_SUCCESS) ZeroMemory(state, sizeof(*state));
  if (phase < 120) state->Gamepad.wButtons |= ((GetTickCount64() / 1200) % 2) ? XINPUT_GAMEPAD_A : XINPUT_GAMEPAD_START;
  return ERROR_SUCCESS;
}

void SceneLaunchTick(void* modeScene) {
  if (g_missionFight.load() && g_lastScene.load(std::memory_order_relaxed) == 0x150) {
    static void* reported = nullptr;
    if (reported != modeScene) {
      reported = modeScene;
      Log("Chronicles: AVISO - a cena do menu de modos (%p) ainda roda durante a luta.", modeScene);
    }
  }
  if (g_autotestMission >= 0 && !g_autotestDone.load()) {
    // No menu de modos: espera 2 s e pede a missao do teste, uma vez.
    if (!g_menuSeenTick) {
      g_menuSeenTick = GetTickCount64();
      Log("Teste: menu de modos alcancado; abrindo a missao %d em 2 s.", g_autotestMission + 1);
    } else if (!g_autotestMenu && GetTickCount64() - g_menuSeenTick > 2000) {
      g_autotestDone = true;
      g_pendingMission.store(g_autotestMission);
    }
  } else if (g_autotestLast >= 0 && g_autotestDone.load() && g_returning && g_autotestMission < g_autotestLast) {
    // De volta ao menu depois de uma luta encadeada: proxima missao.
    Log("Teste: menu reconstruido, proximo desafio sera C%02d.", g_autotestMission + 2);
    g_returning = false;
    g_autotestMission += 1;
    g_autotestDone = false;
    g_menuSeenTick = 0;
  }
  if (g_restoreSettings && g_pendingMission.load() < 0 && GetTickCount64() - g_launchTick > 5000) {
    // De volta ao menu de modos: devolve as opcoes do jogador.
    Settings& cfgMod = Cfg();
    cfgMod.mode3v3 = g_saved3v3;
    for (int i = 0; i < 6; ++i) cfgMod.slot[i] = g_savedSlots[i];
    if (g_preMissionConfigValid) {
      std::memcpy(reinterpret_cast<void*>(g_base + kSideConfig + 0xC),
                  g_preMissionConfig, sizeof(g_preMissionConfig));
      g_preMissionConfigValid = false;
      Log("Chronicles: configuracao original das duas equipes restaurada no menu.");
    }
    g_restoreSettings = false;
    g_missionFight = false;
    ChroniclesBalanceEnd();
    Log("Chronicles: opcoes do mod restauradas.");
    // A barra de ajuda foi escondida ao abrir a luta: o menu volta a mostra-la (FUN_140666044(barra, 1)).
    __try {
      if (void* keyHelp = *reinterpret_cast<void**>(g_base + 0x1609BA8))
        reinterpret_cast<void (*)(void*, int)>(g_base + 0x666044)(keyHelp, 1);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
    // Volta ao menu do Chronicles na lista de missoes (proxima missao se venceu).
    if (g_launchMission >= 0) ChroniclesReopenAfterMission(g_launchMission, g_missionResult.load() == 1);
  }
  const int mission = g_pendingMission.exchange(-1);
  if (mission < 0) return;
  DumpStageList();
  g_launchMission = mission;
  const auto* roster = chronicles_classic::Roster(mission);
  void* manager = g_manager.load();
  const uintptr_t db = CharacterDb();
  if (!roster || !manager || !db || !g_origChange) {
    Log("Chronicles: luta %d nao pode abrir (escalacao=%d gerente=%p banco=%p)", mission + 1, roster != nullptr,
        manager, reinterpret_cast<void*>(db));
    return;
  }
  int ids[2][3] = {{-1, -1, -1}, {-1, -1, -1}};
  const chronicles_classic::BattleTeam* teams[2] = {&roster->allies, &roster->enemies};
  for (int side = 0; side < 2; ++side) {
    for (int slot = 0; slot < teams[side]->count; ++slot) {
      const char* code = ClassicFaceCode(teams[side]->members[slot]);
      if (g_autotestMission >= 0 && g_autotestRoster[side][slot][0]) code = g_autotestRoster[side][slot];
      ids[side][slot] = code ? CharacterIdFor(db, code) : -1;
      Log("Chronicles: lado %d vaga %d = %s -> personagem 0x%X", side, slot, code ? code : "?", ids[side][slot]);
      if (ids[side][slot] < 0) {
        Log("Chronicles: personagem sem numero no jogo (DLC ausente?); luta cancelada.");
        return;
      }
    }
  }
  auto* cfg = reinterpret_cast<uint8_t*>(g_base + kSideConfig + 0xC);
  if (!g_preMissionConfigValid) {
    std::memcpy(g_preMissionConfig, cfg, sizeof(g_preMissionConfig));
    g_preMissionConfigValid = true;
  }
  WriteTeam(cfg, roster->allies, ids[0], false);
  WriteTeam(cfg + 0x1AC, roster->enemies, ids[1], true);
  std::memcpy(g_missionConfig, cfg, sizeof(g_missionConfig));
  LogSideConfig();
  // Missao precisa do 3v3 (aliados em campo) e do jogador no J1; o resto fica com a CPU.
  Settings& cfgMod = Cfg();
  if (!g_restoreSettings) {
    g_saved3v3 = cfgMod.mode3v3.load();
    for (int i = 0; i < 6; ++i) g_savedSlots[i] = cfgMod.slot[i].load();
    g_restoreSettings = true;
  }
  g_launchTick = GetTickCount64();
  g_missionFight = true;
  g_fightStartTick = 0;
  g_missionResult = 0;
  g_pendingResult = 0;
  g_resultFinished = false;
  g_returning = false;
  Log("Teste: luta da missao %d aberta.", mission + 1);
  ChroniclesBalanceBegin(mission);
  g_gaugeShown = false;
  g_gaugeFrames = 0;
  // O 1v1 deve usar o modo NATIVO. Os hooks extras de 3v3 não podem
  // interferir no juiz/estado Ready do jogo com apenas dois personagens.
  const bool needsSimultaneous = roster->allies.count > 1 || roster->enemies.count > 1;
  cfgMod.mode3v3 = needsSimultaneous;
  Log("Chronicles: combate %dv%d usando %s.",
      roster->allies.count, roster->enemies.count,
      needsSimultaneous ? "Tag Team simultaneo" : "1v1 nativo");
  // Co-op: o time do jogador segue a configuracao de controles do mod, como no Combate Livre.
  // Controle atribuido (Player 1..4) fica; "Automatico" vira o controle livre (J2 -> controle 2,
  // J3 -> controle 3) se ele estiver conectado, senao CPU (regra em HookSetup, promote.cpp).
  // CPU escolhida pelo jogador continua CPU. Os inimigos sao sempre CPU.
  for (int i = 0; i < 3; ++i) {
    const int saved = g_savedSlots[i];
    if (SlotPadIndex(saved) >= 0) cfgMod.slot[i] = saved;
    else cfgMod.slot[i] = (i > 0 && saved == kSlotCpu) ? kSlotCpu : kSlotAuto;
  }
  if (g_autotestCpuPlayer) cfgMod.slot[0] = kSlotCpu;
  for (int i = 3; i < 6; ++i) cfgMod.slot[i] = kSlotCpu;
  Log("Chronicles: controles do time J1=%d J2=%d J3=%d (0 auto, 2 CPU, 3..6 controle 1..4).",
      cfgMod.slot[0].load(), cfgMod.slot[1].load(), cfgMod.slot[2].load());
  // Mesmo caminho das lutas do modo historia: ccSceneBossBattleFreeBattleRoot (0x14C) abre a carga VS
  // (0x14D) e a luta (0x14E) direto, usando a tabela de configuracao, sem telas de selecao.
  if (!PublishStoryValues()) {
    Log("Chronicles: valores da historia indisponiveis; luta cancelada.");
    return;
  }
  // Cada fase de chefe chama FUN_14042DFDC antes de abrir 0x14C: cria o carregador (*0x1415FE490) no modo
  // "luta livre" (+0x98/+0x9C = 1), que tambem carrega os arquivos comuns da luta (ex.: 1cmnprm).
  __try {
    // Um carregador antigo ja terminado faria a carga VS pular direto (estado >= 0xF) sem criar ninguem:
    // descarta (FUN_14073A560) antes de criar um novo.
    const uintptr_t old = *reinterpret_cast<const uintptr_t*>(g_base + kLoaderGlobal);
    if (old) Log("Chronicles: carregador antigo no estado %d descartado.", *reinterpret_cast<const int*>(old + 0x40));
    reinterpret_cast<void (*)()>(g_base + kLoaderDestroy)();
    reinterpret_cast<void (*)()>(g_base + kBossFreeStart)();
    // FUN_14042DFDC liga +0x98/+0x9C ("ja carregado" pela fase do chefe): o carregador pularia do passo 4
    // para o 12, sem os passos 5..11 que criam os lutadores. Aqui ninguem foi carregado antes.
    if (uint8_t* loader = *reinterpret_cast<uint8_t**>(g_base + kLoaderGlobal)) {
      *reinterpret_cast<int*>(loader + 0x98) = 0;
      *reinterpret_cast<int*>(loader + 0x9C) = 0;
    }
    Log("Chronicles: carregador da luta preparado.");
    // Como as fases de chefe (ex.: FUN_1403F1A24): cada lutador vai para sua vaga do duelo
    // (duelo + 0x250 + vaga*0x8F48) por FUN_14074AE0C, seguido de FUN_14074B8A0(vaga, 0).
    using SetSlot_t = void (*)(void*, int, int, int, int, int, int, int, int, int, int, int);
    using SlotDone_t = void (*)(void*, int);
    uint8_t* duel = *reinterpret_cast<uint8_t**>(g_base + Addr().duelGlobal);
    if (!duel) {
      Log("Chronicles: duelo ainda nao existe; luta cancelada.");
      return;
    }
    for (int side = 0; side < 2; ++side) {
      for (int slot = 0; slot < teams[side]->count; ++slot) {
        void* entry = duel + 0x250 + (side * 3 + slot) * 0x8F48;
        reinterpret_cast<SetSlot_t>(g_base + kSetSlot)(entry, ids[side][slot], 0, 1, 0, 0, 0, 0, 0, -1, 0, side);
        reinterpret_cast<SlotDone_t>(g_base + kSlotDone)(entry, 0);
        Log("Chronicles: vaga %d do duelo = personagem 0x%X", side * 3 + slot, ids[side][slot]);
      }
      // Vagas sem lutador: zera a contagem (+8) que FUN_140749738 confere, para nao criar ninguem nelas.
      for (int slot = teams[side]->count; slot < 3; ++slot)
        *reinterpret_cast<int*>(duel + 0x250 + (side * 3 + slot) * 0x8F48 + 8) = 0;
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    Log("Chronicles: preparar o carregador falhou (0x%08lX)", GetExceptionCode());
    return;
  }
  Log("Chronicles: abrindo a luta %d pelo carregador da historia (0x14C).", mission + 1);
  // Antes de trocar para a historia, o menu (FUN_1406E4790) desliga o cenario dele: FUN_1404CE4DC e
  // FUN_1404CF428(.., 0) no objeto *0x141609C10. Sem isso o Naruto do fundo do menu ficava na luta.
  __try {
    if (void* menuStage = *reinterpret_cast<void**>(g_base + 0x1609C10)) {
      // A antiga limpeza escrevia zero em menuStage+8 sem o construtor do
      // menu saber; nas missoes encadeadas o modelo do Naruto voltava preso.
      // Chama somente os metodos nativos e uma vez por instancia.
      if (menuStage != g_lastMenuStageCleaned) {
        reinterpret_cast<void (*)(void*)>(g_base + 0x4CE4DC)(menuStage);
        reinterpret_cast<void (*)(void*, int)>(g_base + 0x4CF428)(menuStage, 0);
        g_lastMenuStageCleaned = menuStage;
        Log("Chronicles: cenario do menu desligado pelo metodo nativo.");
      }
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    Log("Chronicles: desligar o cenario do menu falhou (0x%08lX)", GetExceptionCode());
  }
  // O Naruto 3D do menu (ccGameModeSelectNaruto) fica em *0x141609C80 + 0xA0. As cenas que saem do menu para
  // uma luta chamam FUN_14066A1E4(*0x141609C80), que descarrega o modelo e o fundo do menu.
  __try {
    if (void* menuUi = *reinterpret_cast<void**>(g_base + 0x1609C80)) {
      if (menuUi != g_lastMenuUiCleaned) {
        reinterpret_cast<void (*)(void*)>(g_base + 0x66A1E4)(menuUi);
        g_lastMenuUiCleaned = menuUi;
        Log("Chronicles: Naruto do menu descarregado uma vez.");
      }
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    Log("Chronicles: descarregar o Naruto do menu falhou (0x%08lX)", GetExceptionCode());
  }
  // Barra de ajuda do menu ("Neste modo..." + BACK/START/Y/A/B), ccUiFlashKeyHelp em *0x141609BA8.
  // As cenas do jogo limpam os textos com FUN_1406659B0, poem os novos e aplicam com FUN_140665CD4(barra, 1).
  __try {
    if (void* keyHelp = *reinterpret_cast<void**>(g_base + 0x1609BA8)) {
      reinterpret_cast<void (*)(void*)>(g_base + 0x665C9C)(keyHelp);  // desempilha os estados guardados
      reinterpret_cast<void (*)(void*)>(g_base + 0x6659B0)(keyHelp);  // apaga os textos ("Neste modo...")
      // A frase "Neste modo..." e um texto separado da barra (nao sai ao limpar): as cenas do jogo que nao usam a
      // barra a ESCONDEM depois de limpar com FUN_140666044(barra, 0) (ex.: exe+0x59D09F, 0x5DD549).
      reinterpret_cast<void (*)(void*, int)>(g_base + 0x666044)(keyHelp, 0);
      Log("Chronicles: barra de ajuda do menu limpa e escondida.");
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    Log("Chronicles: limpar a barra de ajuda falhou (0x%08lX)", GetExceptionCode());
  }
  g_origChange(manager, 0x14C);
  // Como o menu de modos faz ao escolher um modo (FUN_1406E4BF1): libera a tela dele (+0x80) e marca a saida
  // (+0x60 = 1, +0x54 = 0x24). Sem isso o menu continuava desenhado por cima da luta.
  if (auto* scene = static_cast<uint8_t*>(modeScene)) {
    __try {
      if (void* screen = *reinterpret_cast<void**>(scene + 0x80)) {
        // A tela e a animacao modesel.swf (classe com vtable 0x1410669A8). A frase "Neste modo..." e o texto
        // rolante dela (SetScrollText) e a descarga do .swf nao e imediata: antes de liberar, esconde a frase
        // (FUN_14065B850, DisbleScrollText), a interface (FUN_14065C178(tela,0), DisibleUI) e a barra dela
        // (FUN_14065C150(tela,0), SetDisibleKeyHelp), como o proprio menu faz ao criar a tela (exe+0x6E3A12).
        reinterpret_cast<void (*)(void*)>(g_base + 0x65B850)(screen);
        reinterpret_cast<void (*)(void*, int)>(g_base + 0x65C178)(screen, 0);
        reinterpret_cast<void (*)(void*, int)>(g_base + 0x65C150)(screen, 0);
        auto** vtable = *reinterpret_cast<void***>(screen);
        reinterpret_cast<void (*)(void*, int)>(vtable[0])(screen, 1);
        *reinterpret_cast<void**>(scene + 0x80) = nullptr;
      }
      *reinterpret_cast<int*>(scene + 0x60) = 1;
      *reinterpret_cast<int*>(scene + 0x54) = 0x24;
      Log("Chronicles: tela do menu de modos liberada.");
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      Log("Chronicles: liberar a tela do menu falhou (0x%08lX)", GetExceptionCode());
    }
  }
}

void SceneProbeInstall() {
  if (Addr().timestamp != kEvolutionStamp) return;
  // storm6.ini arena_forcada=<codigo hex>: as lutas abertas pelo Chronicles usam essa arena (ex.: C35ECDE7 = SI43B, a
  // floresta com paredao da corrida na parede). 0 ou ausente = arena de cada missao.
  if (FILE* ini = _wfopen((ModDir() + L"storm6.ini").c_str(), L"r")) {
    char line[128];
    while (std::fgets(line, sizeof(line), ini)) {
      unsigned code = 0;
      if (std::sscanf(line, "arena_forcada=%x", &code) == 1) g_forcedStage = code;
    }
    std::fclose(ini);
    if (g_forcedStage) Log("Chronicles: arena forcada 0x%08X nas lutas das missoes (arena_forcada).", g_forcedStage);
  }
  if (FILE* file = _wfsopen((ModDir() + L"storm6_autotest.txt").c_str(), L"r", 0x40)) {
    int mission = 0;
    if (std::fscanf(file, "%d", &mission) == 1 && mission >= 1 && mission <= 40) g_autotestMission = mission - 1;
    unsigned stage = 0;
    int count = 1, seconds = 0, cpu = 0;
    if (std::fscanf(file, "%x %d %d %d", &stage, &count, &seconds, &cpu) >= 1) g_autotestStage = stage;
    if (g_autotestMission >= 0 && seconds > 0) {
      // Tambem encerra um teste ISOLADO com duracao: count=1.
      g_autotestLast = std::min(39, g_autotestMission + std::max(1, count) - 1);
      g_autotestSeconds = seconds;
    }
    g_autotestCpuPlayer = cpu != 0;
    char words[64]{};
    std::rewind(file);
    std::fread(words, 1, sizeof(words) - 1, file);
    g_autotestMenu = std::strstr(words, "menu") != nullptr;
    g_autotestPause = std::strstr(words, "pausa") != nullptr;
    g_autotestVictory = std::strstr(words, "vitoria") != nullptr;
    g_autotestJutsu = std::strstr(words, "jutsu") != nullptr;
    g_autotestMashB = std::strstr(words, "apertoB") != nullptr;
    char all[256]{};
    std::rewind(file);
    std::fread(all, 1, sizeof(all) - 1, file);
    if (const char* e = std::strstr(all, "elenco=")) {
      e += 7;
      int side = 0, slot = 0;
      for (; *e && *e != ' ' && *e != '\t' && *e != '\r' && *e != '\n' && side < 2; ++e) {
        if (*e == ',') { ++slot; continue; }
        if (*e == '/') { ++side; slot = 0; continue; }
        if (slot > 2) continue;
        char* code = g_autotestRoster[side][slot];
        const size_t n = std::strlen(code);
        if (n + 1 < sizeof(g_autotestRoster[0][0])) code[n] = *e;
      }
      Log("Teste: elenco trocado %s,%s,%s / %s,%s,%s.", g_autotestRoster[0][0], g_autotestRoster[0][1],
          g_autotestRoster[0][2], g_autotestRoster[1][0], g_autotestRoster[1][1], g_autotestRoster[1][2]);
    }
    std::fclose(file);
    Log("Teste: modo de teste ligado, missao %d.", g_autotestMission + 1);
  }
  Hook(kRootMessage, reinterpret_cast<void*>(&HookRoot), reinterpret_cast<void**>(&g_origRoot), "mensagens do Root");
  Hook(kOpenSceneWithParam, reinterpret_cast<void*>(&HookOpen), reinterpret_cast<void**>(&g_origOpen), "abrir cena");
  Hook(kChangeScene, reinterpret_cast<void*>(&HookChange), reinterpret_cast<void**>(&g_origChange), "trocar cena");
  Hook(kChangeSceneB, reinterpret_cast<void*>(&HookChangeB), reinterpret_cast<void**>(&g_origChangeB), "trocar cena B");
  Hook(0x73A588, reinterpret_cast<void*>(&HookLoaderUpdate), reinterpret_cast<void**>(&g_origLoaderUpdate), "carregador");
  Hook(0x74996C, reinterpret_cast<void*>(&HookCreateSide), reinterpret_cast<void**>(&g_origCreateSide), "criar lado");
  Hook(0x63C4C0, reinterpret_cast<void*>(&HookGaugeCreate), reinterpret_cast<void**>(&g_origGaugeCreate), "painel de vida");
  Hook(0x63D754, reinterpret_cast<void*>(&HookGaugeUpdate), reinterpret_cast<void**>(&g_origGaugeUpdate), "painel por quadro");
  Hook(0x430EE0, reinterpret_cast<void*>(&HookBeginUpdate), reinterpret_cast<void**>(&g_origBeginUpdate), "inicio da luta");
  Hook(0x6D10A8, reinterpret_cast<void*>(&HookPauseCreate), reinterpret_cast<void**>(&g_origPauseCreate), "menu de pausa");
}
