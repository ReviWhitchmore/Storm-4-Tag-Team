#pragma once
#include <windows.h>

#include <cstdint>

#include "grab_defense.h"  // GrabFighterView

// Wall Running (Evolution). storm6.ini: parede=1 liga nas arenas verificadas (lista em wall_run_mechanic.inl);
// parede_cpu=0..100 (% de chance da CPU subir), parede_tempo_ms (tempo maximo na parede). parede_teste=N: modos de
// teste (2 mapa do limite, 3 onde fica a parede, 4 demonstracao com o controle 1, 5 luta na parede nativa, 6 pose).
void WallRunInstall();
void WallRunBeginBattle();
// Testes (parede_teste=2 e 4): analogico e botoes que o controle 1 deve "segurar" agora. false = nada a injetar.
bool WallRunTestInput(short* lx, short* ly, WORD* buttons);
// true enquanto o lutador corre na parede (outras mecanicas, como o Combo em Dupla, nao devem chama-lo).
bool WallRunActive(uintptr_t player);
void WallRunTick(const GrabFighterView* fighters, int count, bool sceneActive, uint64_t now);
