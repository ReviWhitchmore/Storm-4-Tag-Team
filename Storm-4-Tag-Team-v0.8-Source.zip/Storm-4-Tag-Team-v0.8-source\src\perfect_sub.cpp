#include "perfect_sub.h"

#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

#include "addresses.h"
#include "census.h"
#include "cpu_adapt.h"
#include "settings.h"
#include "log.h"
#include "perfect_sub_rules.h"

namespace {
std::atomic<bool> g_enabled{true};
std::atomic<unsigned> g_windowMs{perfectsub::kDefaultWindowMs};
// A CPU do jogo substitui 0,5-1,2 s depois do golpe (nunca dentro da janela): para ela participar, cada
// substituicao da CPU tem esta chance (%) de contar como perfeita. 0 desliga para a CPU.
std::atomic<unsigned> g_cpuChance{25};
uint32_t g_rng = 0x2545F491u;
uint32_t NextRandom() {
  g_rng ^= g_rng << 13;
  g_rng ^= g_rng >> 17;
  g_rng ^= g_rng << 5;
  return g_rng;
}

struct SubTrack {
  int prev = -1;
  uint64_t damageAt = 0;
  int attacker = -1;
  float before[3]{};
  bool pending = false;
  uint64_t subAt = 0;
  int pendingAttacker = -1;
  float pendingBefore[3]{};
  uint64_t appliedAt = 0;
  float applied[3]{};
  bool checked = false;
  int followLogs = 0;  // DIAGNOSTICO: proximas trocas de estado depois de reaparecer
  uint64_t followUntil = 0;
};
SubTrack g_track[6]{};
std::atomic<uint64_t> g_feedbackUntil{0};
std::atomic<int> g_feedbackNumber{0};
unsigned g_logLines = 0;

bool Awakened(uintptr_t player) {
  __try {
    auto** vtable = *reinterpret_cast<int (***)(uintptr_t)>(player);
    return vtable && vtable[0x11A8 / sizeof(void*)] && vtable[0x11A8 / sizeof(void*)](player) != 0;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return true;
  }
}

bool Place(uintptr_t player, const float pos[3]) {
  __try {
    using SetPositionFn = void (*)(void*, const float*);
    using ResetMotionFn = void (*)(void*);
    reinterpret_cast<SetPositionFn>(g_base + Addr().setPosition)(reinterpret_cast<void*>(player), pos);
    reinterpret_cast<ResetMotionFn>(g_base + Addr().resetMotion)(reinterpret_cast<void*>(player));
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

float Dist2D(const float* a, const float* b) {
  const float dx = a[0] - b[0], dy = a[1] - b[1];
  return std::sqrt(dx * dx + dy * dy);
}

// Adversario vivo mais perto de um ponto, ate maxDistance; -1 se nenhum.
int NearestEnemyTo(const GrabFighterView* f, int n, int k, const float* point, float maxDistance) {
  int best = -1;
  float d = 0;
  for (int e = 0; e < n; ++e) {
    if (!f[e].valid || !CpuAdaptEnemy(k,f[k].side,e,f[e].side,Cfg().freeForAll.load(std::memory_order_relaxed))) continue;
    const float dist = Dist2D(f[e].pos, point);
    if (dist <= maxDistance && (best < 0 || dist < d)) {
      best = e;
      d = dist;
    }
  }
  return best;
}

// Atacante provavel: o adversario mais perto em estado de ataque; senao, o adversario mais perto.
int LikelyAttacker(const GrabFighterView* f, int n, int k) {
  int best = -1, bestAttack = -1;
  float d = 0, dAttack = 0;
  for (int e = 0; e < n; ++e) {
    if (!f[e].valid || !CpuAdaptEnemy(k,f[k].side,e,f[e].side,Cfg().freeForAll.load(std::memory_order_relaxed))) continue;
    const float dist = Dist2D(f[e].pos, f[k].pos);
    if (best < 0 || dist < d) {
      best = e;
      d = dist;
    }
    if (perfectsub::AttackState(f[e].state) && (bestAttack < 0 || dist < dAttack)) {
      bestAttack = e;
      dAttack = dist;
    }
  }
  return bestAttack >= 0 ? bestAttack : best;
}
}  // namespace

void PerfectSubInstall() {
  if (Addr().timestamp != 0x5889906E) {
    g_enabled = false;
    Log("SUBSTITUICAO PERFEITA: disponivel somente no Evolution verificado.");
    return;
  }
  bool enabled = true;
  unsigned window = perfectsub::kDefaultWindowMs, cpu = 25;
  const std::wstring file = ModDir() + L"storm6.ini";
  if (FILE* stream = _wfopen(file.c_str(), L"r")) {
    char line[128];
    while (std::fgets(line, sizeof(line), stream)) {
      char key[65]{};
      int value = 0;
      if (std::sscanf(line, "%64[^=]=%d", key, &value) != 2) continue;
      if (!std::strcmp(key, "substituicao_perfeita")) enabled = value != 0;
      else if (!std::strcmp(key, "substituicao_perfeita_janela_ms") && value >= 50 && value <= 400)
        window = unsigned(value);
      else if (!std::strcmp(key, "substituicao_perfeita_cpu") && value >= 0 && value <= 100) cpu = unsigned(value);
    }
    std::fclose(stream);
  }
  g_enabled = enabled;
  g_windowMs = window;
  g_cpuChance = cpu;
  Log("SUBSTITUICAO PERFEITA: %s janela=%ums depois do golpe comecar; CPU %u%%.",
      enabled ? "ATIVA" : "desligada (storm6.ini substituicao_perfeita=1)", window, cpu);
}

void PerfectSubBeginBattle() {
  for (auto& t : g_track) t = {};
  g_feedbackUntil = 0;
  g_logLines = 0;
  g_rng ^= static_cast<uint32_t>(GetTickCount64());
  if (!g_rng) g_rng = 0x2545F491u;
}

void PerfectSubTick(const GrabFighterView* f, int n, bool sceneActive, uint64_t now) {
  if (n < 2 || n > 6) return;
  const bool enabled = g_enabled.load(std::memory_order_relaxed);
  const unsigned window = g_windowMs.load(std::memory_order_relaxed);
  for (int k = 0; k < n; ++k) {
    SubTrack& t = g_track[k];
    const int s = f[k].valid ? f[k].state : -1;
    const int prev = t.prev;
    t.prev = s;
    if (s < 0 || s == prev) {
      // Conferencia: 120 ms depois de colocar, o jogo manteve a posicao?
      if (t.appliedAt && !t.checked && now - t.appliedAt >= 120 && f[k].valid) {
        t.checked = true;
        if (g_logLines < 150) {
          ++g_logLines;
          Log("SUBSTITUICAO PERFEITA: J%d 120 ms depois esta a %.0f do ponto colocado (estado 0x%X).",
              f[k].number, Dist2D(f[k].pos, t.applied), s);
        }
      }
      continue;
    }
    if (t.followLogs > 0 && now <= t.followUntil && g_logLines < 150) {
      --t.followLogs;
      ++g_logLines;
      Log("SUBSTITUICAO: J%d depois de reaparecer 0x%X -> 0x%X.", f[k].number, prev, s);
    }
    if (perfectsub::DamageState(s) && !perfectsub::DamageState(prev)) {
      t.damageAt = now;
      t.attacker = LikelyAttacker(f, n, k);
      std::memcpy(t.before, f[k].pos, sizeof(t.before));
    }
    if (perfectsub::SubOutState(s) && !perfectsub::SubOutState(prev)) {
      const bool fromDamage = perfectsub::DamageState(prev);
      const uint64_t delta = fromDamage && t.damageAt ? now - t.damageAt : 0;
      const unsigned cpuChance=CpuAdaptChance(g_cpuChance.load(std::memory_order_relaxed),f[k].player,cpuai::Action::PerfectSub);
      const bool cpuLuck = fromDamage && f[k].pad < 0 && cpuChance > 0 &&
                           NextRandom() % 100 < cpuChance;
      const bool perfect = fromDamage && (perfectsub::Perfect(t.damageAt, now, window) || cpuLuck);
      const int a = t.attacker;
      const bool ok = enabled && perfect && a >= 0 && a < n && f[a].valid && !sceneActive && !Awakened(f[a].player);
      if (g_logLines < 150) {
        ++g_logLines;
        Log("SUBSTITUICAO: J%d 0x%X -> 0x%X, %llu ms depois do golpe (0x%X); atacante J%d%s.", f[k].number, prev, s,
            static_cast<unsigned long long>(delta), prev, a >= 0 && a < n ? f[a].number : 0,
            ok ? " -> PERFEITA" : perfect ? " (perfeita, mas bloqueada)" : "");
      }
      t.pending = ok;
      if (ok) {
        t.subAt = now;
        t.pendingAttacker = a;
        std::memcpy(t.pendingBefore, t.before, sizeof(t.before));
      }
    }
    if (perfectsub::SubInState(s) && !perfectsub::SubInState(prev)) {
      t.followLogs = 4;
      t.followUntil = now + 2500;
      // Quem bateu: a substituicao do jogo (WARP_ENEMY) leva para perto dele; senao, quem estava perto de onde o
      // golpe pegou. Ninguem perto (golpe de longe): substituicao normal.
      int a = NearestEnemyTo(f, n, k, f[k].pos, 450.0f);
      if (a < 0) a = NearestEnemyTo(f, n, k, t.pending ? t.pendingBefore : t.before, 450.0f);
      if (a < 0) a = t.pending ? t.pendingAttacker : t.attacker;
      if (g_logLines < 150 && a >= 0 && a < n) {
        ++g_logLines;
        Log("SUBSTITUICAO: J%d reaparece (0x%X) a %.0f do atacante J%d.", f[k].number, s, Dist2D(f[k].pos, f[a].pos),
            f[a].number);
      }
      const bool attackerClose = a >= 0 && a < n && f[a].valid &&
          (Dist2D(f[a].pos, f[k].pos) <= 450.0f || Dist2D(f[a].pos, t.pendingBefore) <= 450.0f);
      if (t.pending && !attackerClose) {
        Log("SUBSTITUICAO PERFEITA: J%d sem atacante por perto (golpe de longe); substituicao normal.", f[k].number);
      } else if (t.pending && now - t.subAt < 2000 && !sceneActive) {
        float spot[3];
        if (perfectsub::LateralSpot(f[a].pos, t.pendingBefore, f[k].pos, spot) && Place(f[k].player, spot)) {
          std::memcpy(t.applied, spot, sizeof(spot));
          t.appliedAt = now;
          t.checked = false;
          g_feedbackNumber = f[k].number;
          g_feedbackUntil = now + 900;
          Log("SUBSTITUICAO PERFEITA: J%d reapareceu ao lado de J%d (%.0f,%.0f).", f[k].number, f[a].number, spot[0],
              spot[1]);
        } else {
          Log("SUBSTITUICAO PERFEITA: J%d sem lugar seguro ao lado de J%d; substituicao normal.", f[k].number,
              f[a].number);
        }
      }
      t.pending = false;
    }
  }
}

bool PerfectSubFeedback(int* number) {
  const uint64_t until = g_feedbackUntil.load(std::memory_order_relaxed);
  if (!until || GetTickCount64() > until) return false;
  if (number) *number = g_feedbackNumber;
  return true;
}
