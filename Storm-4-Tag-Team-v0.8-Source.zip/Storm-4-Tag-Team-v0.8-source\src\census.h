#pragma once
#include <cstdint>

// Endereco base do NSUNS4.exe em memoria.
extern uintptr_t g_base;

// Instala o hook de observacao na busca central de membros (FUN_14074B36C).
bool CensusInstall();
// Enabled only for diagnostics, STORM6_DIAGNOSTICS=1 before starting game.
bool CensusDiagnosticsEnabled();
// Grava census.csv e um resumo no log. Chamar periodicamente (thread do mod).
void CensusDump();
