#pragma once
#include <cstdint>

namespace parry {
constexpr uint64_t kWindowMs=180;
constexpr uint64_t kCooldownMs=900;
constexpr int kNativeGuardHit=0x4A;
constexpr int kNativeGuardHitAir=0x4B;
constexpr int kNativeGuardHitAirFall=0x4C;
constexpr int kNativeGuardBreak=0x32;
constexpr int kNativeDamageNumb=0x31;

// A perfect guard is a distinct rising edge of RT/R2 within the hit window.
// Holding the button never repeats a parry. Native block remains unchanged.
struct Timing {
  bool held=false;
  bool armed=false;
  uint64_t pressedAt=0;
  uint64_t cooldownUntil=0;
};
inline void SampleGuard(Timing& s,bool pressed,uint64_t now) {
  if(!pressed) {s.held=false;return;}
  if(s.held)return;
  s.held=true;
  s.pressedAt=now;
  s.armed=true;
}
inline bool OnGuardContact(Timing& s,uint64_t now,
                           uint64_t windowMs=kWindowMs,
                           uint64_t cooldownMs=kCooldownMs) {
  if(!s.armed || !s.held || now<s.pressedAt ||
     now-s.pressedAt>windowMs || now<s.cooldownUntil)return false;
  s.armed=false;
  s.cooldownUntil=now+cooldownMs;
  return true;
}
inline bool IsNativeGuardContact(int state) {
  return state==kNativeGuardHit ||
         state==kNativeGuardHitAir ||
         state==kNativeGuardHitAirFall;
}
inline bool AttackAction(int action) {
  return (action>=0x3F && action<=0x42) || // normal combo
         action==0x48 ||                 // throw
         (action>=0x4D && action<=0x4F);  // skill/directional
}
inline bool UniqueNearbyAttacker(float closest,float second,float maxDistance=180,
                                 float separation=65) {
  return closest>=0 && closest<=maxDistance &&
         (second<0 || second>maxDistance || second-closest>=separation);
}
}  // namespace parry
