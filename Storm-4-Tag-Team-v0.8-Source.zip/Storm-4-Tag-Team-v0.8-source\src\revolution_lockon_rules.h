#pragma once
#include <algorithm>
#include <cmath>

// Standalone Revolution-like controller targeting rule. All points are
// already projected to screen-space; no proprietary game code is used.
// A candidate needs to lie substantially in the intended stick direction.
inline int RevolutionDirectionalPick(const float stickX, const float stickY,
                                     const float playerXY[2],
                                     const float candidates[6][2],
                                     const bool eligible[6], int count,
                                     int current) {
  if (!playerXY || !candidates || !eligible || count < 1 || count > 6)
    return -1;
  const float stickLength = std::hypot(stickX, stickY);
  if (!std::isfinite(stickLength) || stickLength < 0.45f) return -1;
  const float sx = stickX / stickLength, sy = stickY / stickLength;
  int best = -1;
  float bestScore = -1.0e30f;
  for (int i = 0; i < count; ++i) {
    if (!eligible[i] || i == current) continue;
    const float dx = candidates[i][0] - playerXY[0];
    const float dy = candidates[i][1] - playerXY[1];
    const float distance = std::hypot(dx, dy);
    if (!std::isfinite(distance) || distance < 0.001f) continue;
    const float alignment = (sx * dx + sy * dy) / distance;
    if (alignment < 0.35f) continue;
    const float score = alignment - std::min(distance, 4.0f) * 0.035f;
    if (score > bestScore) {
      bestScore = score;
      best = i;
    }
  }
  return best;
}

inline bool RevolutionOffscreen(float nx, float ny, bool behind) {
  return behind || !std::isfinite(nx) || !std::isfinite(ny) ||
         std::fabs(nx) > 0.94f || std::fabs(ny) > 0.86f;
}
