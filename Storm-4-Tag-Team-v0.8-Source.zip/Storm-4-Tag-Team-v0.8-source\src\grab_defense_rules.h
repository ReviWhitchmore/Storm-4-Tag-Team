#pragma once
#include <cstdint>

// Fase 2 - Defesa contra Agarrao. Regras puras (sem memoria do jogo), testadas em tools/grab_defense_tests.cpp.
// Nomes dos estados: tabela PL_ACT_* do NSUNS4e.exe (Evolution) em 0x1415255C0, 0x20 bytes por estado.
namespace grabdef {
constexpr int kThrowBegin = 0x48;        // PL_ACT_THROW_BEGIN: agarrao normal em andamento
constexpr int kOffsetKnockback = 0x5A;   // PL_ACT_OFFSET_KNOCKBACK: recuo nativo de choque
constexpr float kContactDistance = 85.0f;  // o agarrao pega a ~80 unidades (DIRECTION_ATK/DMG nos testes)
constexpr unsigned kDefaultWindowMs = 200;

// Estados em que o defensor pode reagir: parado, correndo, parando, aterrissando, andando, defendendo.
// Danos, esquivas, Supremos, despertar e cenas ficam de fora (o agarrao segue normal).
inline bool DefenderCanReact(int state) {
  return state == 0x1 || state == 0x2 || state == 0x3 || state == 0x8 ||
         (state >= 0xA && state <= 0xC) || state == 0x49 || state == 0x4A;
}

// Tempo ate o contato em ms pela distancia e pela velocidade de aproximacao (unidades/s).
// 0 se ja esta na distancia de contato; -1 se nao esta se aproximando.
inline int TimeToContactMs(float distance, float closingPerSecond) {
  if (distance <= kContactDistance) return 0;
  if (!(closingPerSecond > 1.0f)) return -1;
  const float ms = (distance - kContactDistance) / closingPerSecond * 1000.0f;
  return ms > 100000.0f ? 100000 : int(ms);
}

inline bool InWindow(int timeToContactMs, unsigned windowMs) {
  return timeToContactMs >= 0 && timeToContactMs <= int(windowMs);
}

// Uma tentativa por agarrao: apertar cedo demais gasta a chance (segurar ou repetir nao vale).
struct Attempt {
  int attacker = -1;
  uint64_t grabStartedAt = 0;
  bool decided = false;
};
}  // namespace grabdef
