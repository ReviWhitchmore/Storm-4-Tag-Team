#pragma once
#include <cmath>
// Model-space targeting anchors. The player position is at the feet.
// A stable 3D anchor is projected by the current game camera each frame.
// Heights are in the same world units as the old Storm 4 lock-on hook.
struct LockOnAnchors {
  float feet[3]{};
  float torso[3]{};
  float crown[3]{};
};
inline LockOnAnchors LockOnModelAnchors(const float origin[3]) {
  LockOnAnchors anchor{};
  if (!origin) return anchor;
  for (int axis = 0; axis < 3; ++axis)
    anchor.feet[axis] = anchor.torso[axis] = anchor.crown[axis] = origin[axis];
  anchor.torso[2] += 72.0f;  // trunk/chest of the character, not ground
  anchor.crown[2] += 156.0f; // top of head; projected from same model origin
  return anchor;
}
inline bool LockOnVisible(float nx, float ny, bool behind) {
  return !behind && std::isfinite(nx) && std::isfinite(ny) &&
         nx > -0.99f && nx < 0.99f && ny > -0.99f && ny < 0.99f;
}
