#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

// Movimento inspirado no Ultimate Ninja 5: o choque avanca conforme a
// diferenca de apertos, mas um unico B nao empurra ambos instantaneamente.
// Regras independentes do motor do jogo para teste/ajuste seguro.
namespace clash_motion {
constexpr float kMaxTravel = 110.0f;  // unidades nativas; ambos se deslocam juntos
constexpr float kResponseMs = 175.0f;

// Pontos do adversario anulam o avanco; a resistencia cresce com os apertos
// acumulados, evitando saltos ao comeco da disputa.
inline float Pressure(unsigned scoreA, unsigned scoreB) {
  const float diff = static_cast<float>(static_cast<double>(scoreA) - static_cast<double>(scoreB));
  const float resistance = 9.0f + 0.28f * (static_cast<float>(scoreA) + static_cast<float>(scoreB));
  return std::clamp(diff / resistance, -1.0f, 1.0f);
}
inline float Target(unsigned scoreA, unsigned scoreB) {
  return Pressure(scoreA, scoreB) * kMaxTravel;
}

// Suavizacao independente da taxa de quadros: 30/60/120 FPS tem a mesma inercia.
// dt limitado a 80 ms, para o jogo nao teletransportar personagens apos uma pausa.
inline float Step(float current, float wanted, uint64_t deltaMs) {
  const float dt = static_cast<float>(std::min<uint64_t>(deltaMs, 80));
  return current + (wanted - current) * (1.0f - std::exp(-dt / kResponseMs));
}

// Pequena oscilacao dentro do contato durante a disputa; a maior parte do
// deslocamento deve vir da POSICAO REAL dos modelos, nao de uma HUD independente.
inline float ContactFraction(unsigned scoreA, unsigned scoreB) {
  return std::clamp(0.5f + Pressure(scoreA, scoreB) * 0.065f, 0.435f, 0.565f);
}
}  // namespace clash_motion
