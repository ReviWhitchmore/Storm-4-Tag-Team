#include "parry.h"
#include <MinHook.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <intrin.h>
#include "addresses.h"
#include "census.h"
#include "cpu_adapt.h"
#include "jutsu_clash.h"
#include "settings.h"
#include "log.h"
#include "parry_rules.h"
#include "promote.h"
#include "ult.h"

namespace {
constexpr int kMaxActionHooks=12;
constexpr DWORD kTriggerThreshold=42; // Xbox RT / R2
using ChangeActionFn=void (*)(uintptr_t player,int action);
struct ActionHook {
 uintptr_t target=0;
 ChangeActionFn original=nullptr;
};
ActionHook g_hooks[kMaxActionHooks]{};
int g_hookCount=0; // written/read on the game's judge thread
std::atomic<bool> g_enabled{false};
std::atomic<unsigned> g_windowMs{180};
std::atomic<unsigned> g_cooldownMs{900};
std::array<parry::Timing,4> g_pads{};
SRWLOCK g_guardLock=SRWLOCK_INIT;
std::atomic<ULONGLONG> g_lastAttack[6]{};
std::atomic<ULONGLONG> g_pending[6]{};
std::atomic<ULONGLONG> g_feedbackUntil{0};
std::atomic<int> g_feedbackDefender{-1},g_feedbackAttacker{-1};
std::atomic<unsigned> g_missReports{0},g_hookReports{0};
std::atomic<ULONGLONG> g_cpuParryReady[6]{};
std::atomic<uint32_t> g_cpuRoll{0xA67163E9u};
unsigned NextCpuRoll() {
 uint32_t prior=g_cpuRoll.load(std::memory_order_relaxed);
 uint32_t next;
 do {next=prior^(prior<<13);next^=next>>17;next^=next<<5;}
 while(!g_cpuRoll.compare_exchange_weak(prior,next,std::memory_order_relaxed));
 return next;
}

// DIAGNOSTICO (Fase 1): quem coloca lutadores nos estados em que os lideres congelam
// (0xA/0xB, 0x28/0x2B). Registra cada par (estado, chamador) uma vez por luta, com contagem.
constexpr bool kStateTrace=true;
struct TraceSeen{int state;uintptr_t ret;unsigned count;};
TraceSeen g_traceSeen[64]{};
int g_traceCount=0;
// DIAGNOSTICO (Fase 2): estados do agarrao (nomes PL_ACT_* da tabela do exe em 0x1415255C0).
bool GrabTraceState(int s) {
 return s==0x48 ||               // THROW_BEGIN (agarrao)
        s==0x9B || s==0x9C ||    // ATK_GUARDBREAK(_PUPPET_OWNER)
        (s>=0x32&&s<=0x35) ||    // DMG_GUARDBREAK*
        s==0x38 || s==0x63 ||    // DMG_GUARDBREAK_AWAKE, ATK_GUARDBREAK_PUPPET
        s==0x79 || s==0x7A ||    // DMG_COMBO_THROW*
        s==0x59 || s==0x5A || s==0x5B;  // OFFSET_KNOCKBACK*
}
std::atomic<unsigned> g_grabTraceLines{0};
void TraceAction(uintptr_t player,int action,void* ret) {
 if(!PromoteBattleActive())return;
 const int fighter=PromoteFighterByPlayer(player);
 if(fighter<0||fighter>=6)return;
 const uintptr_t rva=reinterpret_cast<uintptr_t>(ret)-g_base;
 if(GrabTraceState(action)) {
   if(g_grabTraceLines.fetch_add(1)<200) {
     int before=-1;
     __try{before=*reinterpret_cast<const int*>(player+0xCC0);}__except(EXCEPTION_EXECUTE_HANDLER){}
     Log("AGARRAO TRACE: indice %d entra 0x%X (antes 0x%X) chamado de exe+0x%llX.",
         fighter,action,before,static_cast<unsigned long long>(rva));
   }
   return;
 }
 // DIAGNOSTICO (Jutsu Clash): quem entra em jutsu e quando (ate 150 linhas por sessao).
 if(action==0x4D||action==0x4E||action==0x66||action==0x98) {
   static std::atomic<unsigned> jutsuLines{0};
   if(jutsuLines.fetch_add(1)<150)
     Log("JUTSU TRACE: indice %d entra 0x%X chamado de exe+0x%llX.",fighter,action,static_cast<unsigned long long>(rva));
   return;
 }
 if(action!=0xA&&action!=0xB&&action!=0x28&&action!=0x2B&&action!=0x87&&action!=0x88)return;
 for(int i=0;i<g_traceCount;++i)
   if(g_traceSeen[i].state==action&&g_traceSeen[i].ret==rva){++g_traceSeen[i].count;return;}
 if(g_traceCount>=64)return;
 g_traceSeen[g_traceCount++]={action,rva,1};
 int before=-1;
 __try{before=*reinterpret_cast<const int*>(player+0xCC0);}__except(EXCEPTION_EXECUTE_HANDLER){}
 Log("ESTADO TRACE: indice %d entra 0x%X (antes 0x%X) chamado de exe+0x%llX.",
     fighter,action,before,static_cast<unsigned long long>(rva));
}
void ObserveAction(uintptr_t player,int action) {
 if(!g_enabled.load(std::memory_order_relaxed)||!PromoteBattleActive())return;
 const int fighter=PromoteFighterByPlayer(player);
 if(fighter<0||fighter>=6)return;
 const ULONGLONG now=GetTickCount64();
 if(parry::AttackAction(action))
   g_lastAttack[fighter].store(now,std::memory_order_relaxed);
 if(!parry::IsNativeGuardContact(action)||UltSceneActive())return;
 const int pad=PromotePadForPlayer(player);
 if(pad<0) {
   // CPU so tenta parry numa defesa nativa REAL. O agressor e identificado
   // depois, na thread do juiz; sem alvo inequivoco, nao ha atordoamento.
   if(!CpuAdaptEnabled() || Cfg().freeForAll.load(std::memory_order_relaxed) ||
      JutsuClashProtects(player))return;
   const auto chance=CpuAdaptChance(CpuAdaptParryBaseChance(),player,cpuai::Action::Parry);
   if(!chance || now<g_cpuParryReady[fighter].load(std::memory_order_relaxed))return;
   g_cpuParryReady[fighter].store(now+g_cooldownMs.load(std::memory_order_relaxed),std::memory_order_relaxed);
   if(NextCpuRoll()%100>=chance)return;
   g_pending[fighter].store(now,std::memory_order_release);
   return;
 }
 if(pad>=4)return;
 bool perfect=false;
 AcquireSRWLockExclusive(&g_guardLock);
 perfect=parry::OnGuardContact(g_pads[pad],now,g_windowMs,g_cooldownMs);
 ReleaseSRWLockExclusive(&g_guardLock);
 if(perfect){
   g_pending[fighter].store(now,std::memory_order_release);
   Log("PARRY BETA: defesa precisa confirmada J%d, estado nativo=0x%X (pad %d).",
       fighter+1,action,pad+1);
 }
}
template<int Index> void HookAction(uintptr_t player,int action) {
 // Observe BEFORE native transition, without modifying its arguments.
 ObserveAction(player,action);
 if(kStateTrace)TraceAction(player,action,_ReturnAddress());
 ChangeActionFn original=g_hooks[Index].original;
 // JUTSU CLASH: o empurrao mutuo de dois jutsus vira a disputa (os dois ficam na pose do jutsu).
 if(original && JutsuClashInterceptOffset(player,action,
        reinterpret_cast<uintptr_t>(_ReturnAddress())-g_base,original))return;
 if(original)original(player,action);
}
constexpr std::array<ChangeActionFn,kMaxActionHooks> kThunks={{
 &HookAction<0>,&HookAction<1>,&HookAction<2>,&HookAction<3>,
 &HookAction<4>,&HookAction<5>,&HookAction<6>,&HookAction<7>,
 &HookAction<8>,&HookAction<9>,&HookAction<10>,&HookAction<11>
}};

void InstallForActor(int fighter) {
 const uintptr_t player=PromoteFighterPlayer(fighter);
 if(!player)return;
 __try {
   const auto* vtable=*reinterpret_cast<const uintptr_t* const*>(player);
   if(!vtable)return;
   const uintptr_t addr=vtable[Addr().vtChangeState/sizeof(uintptr_t)];
   // Only patch executable main-module .text functions of known Evolution,
   // never other injected modules, virtual tables, data or heap code.
   if(addr<g_base+0x1000||addr>=g_base+0xEAA000){
     if(g_hookReports.fetch_add(1)<8)
       Log("PARRY BETA: metodo de estado J%d fora do modulo conhecido, ignorado.",fighter+1);
     return;
   }
   for(int i=0;i<g_hookCount;++i)
     if(g_hooks[i].target==addr)return;
   if(g_hookCount>=kMaxActionHooks) {
     if(g_hookReports.fetch_add(1)<8)
       Log("PARRY BETA: limite de ganchos de estado atingido.");
     return;
   }
   const int slot=g_hookCount;
   ChangeActionFn trampoline=nullptr;
   MH_STATUS status=MH_CreateHook(reinterpret_cast<void*>(addr),
       reinterpret_cast<void*>(kThunks[slot]),
       reinterpret_cast<void**>(&trampoline));
   if(status!=MH_OK) {
     if(g_hookReports.fetch_add(1)<8)
       Log("PARRY BETA: nao foi possivel rastrear estado J%d (%s).",
           fighter+1,MH_StatusToString(status));
     return;
   }
   g_hooks[slot].target=addr;
   g_hooks[slot].original=trampoline;
   ++g_hookCount;
   status=MH_EnableHook(reinterpret_cast<void*>(addr));
   Log("PARRY BETA: observacao de mudanca de estado J%d exe+0x%llX %s.",
       fighter+1,static_cast<unsigned long long>(addr-g_base),
       MH_StatusToString(status));
 } __except(EXCEPTION_EXECUTE_HANDLER) {
   Log("PARRY BETA: objeto de estado J%d indisponivel.",fighter+1);
 }
}
} // namespace

void ParryInstall() {
 if(Addr().timestamp!=0x5889906E) {
   Log("PARRY BETA: disponivel somente no Evolution verificado.");
   return;
 }
 const std::wstring file=ModDir()+L"storm6.ini";
 FILE* stream=_wfopen(file.c_str(),L"r");
 bool enabled=false;unsigned window=180,cooldown=900;
 if(stream){
   char line[128];
   while(std::fgets(line,sizeof(line),stream)){
     char key[65]{};int value=0;
     if(std::sscanf(line,"%64[^=]=%d",key,&value)!=2)continue;
     if(!std::strcmp(key,"parry"))enabled=value!=0;
     else if(!std::strcmp(key,"parry_window_ms")&&value>=80&&value<=300)
       window=unsigned(value);
     else if(!std::strcmp(key,"parry_cooldown_ms")&&value>=500&&value<=3000)
       cooldown=unsigned(value);
   }
   std::fclose(stream);
 }
 g_windowMs=window;
 g_cooldownMs=cooldown;
 g_enabled=enabled;
 Log("PARRY BETA: %s janela=%ums, intervalo=%ums. Defenda com RT/R2.",
     enabled?"ATIVO":"desativado (storm6.ini parry=1)",window,cooldown);
}
void ParryBeginBattle() {
 for(auto& t:g_lastAttack)t=0;
 for(auto& t:g_pending)t=0;
 for(auto& ready:g_cpuParryReady)ready=0;
 g_feedbackUntil=0;g_feedbackAttacker=-1;g_feedbackDefender=-1;
 AcquireSRWLockExclusive(&g_guardLock);
 for(auto& pad:g_pads)pad={};
 ReleaseSRWLockExclusive(&g_guardLock);
 g_grabTraceLines=0;
 if(g_traceCount){
   for(int i=0;i<g_traceCount;++i)
     Log("ESTADO TRACE resumo: 0x%X de exe+0x%llX x%u.",g_traceSeen[i].state,
         static_cast<unsigned long long>(g_traceSeen[i].ret),g_traceSeen[i].count);
   g_traceCount=0;
 }
 if((!g_enabled&&!kStateTrace)||Addr().timestamp!=0x5889906E)return;
 const int count=std::min(6,PromoteFighterCount());
 for(int i=0;i<count;++i)InstallForActor(i);
 Log("PARRY BETA: observando %d lutadores, %d estados nativos registrados.",
     count,g_hookCount);
}
void ParryObserveGuard(DWORD pad,const XINPUT_STATE* state,bool connected) {
 if(!g_enabled||pad>=4)return;
 if(!PromoteBattleActive()||UltSceneActive())return;
 const bool held=connected&&state&&state->Gamepad.bRightTrigger>=kTriggerThreshold;
 AcquireSRWLockExclusive(&g_guardLock);
 parry::SampleGuard(g_pads[pad],held,GetTickCount64());
 ReleaseSRWLockExclusive(&g_guardLock);
}
bool ParryRecentAttack(int fighter,uint64_t now) {
 if(fighter<0||fighter>=6)return false;
 const uint64_t event=g_lastAttack[fighter].load(std::memory_order_relaxed);
 return event!=0&&now>=event&&now-event<=950;
}
void ParryBattleTick() {
 if(!g_enabled||!PromoteBattleActive()||UltSceneActive())return;
 const uint64_t now=GetTickCount64();
 const int count=std::min(6,PromoteFighterCount());
 for(int defender=0;defender<count;++defender) {
   const uint64_t hit=g_pending[defender].exchange(0,std::memory_order_acq_rel);
   if(!hit||now<hit||now-hit>300)continue;
   const int attacker=PromoteParryAttacker(defender,now);
   if(attacker<0) {
     if(g_missReports.fetch_add(1)<10)
       Log("PARRY BETA: golpe defendido por J%d, mas agressor ambiguo; atordoamento cancelado.",
           defender+1);
     continue;
   }
   const uintptr_t enemy=PromoteFighterPlayer(attacker);
   if(!enemy)continue;
   __try {
     const auto* vt=*reinterpret_cast<const uintptr_t* const*>(enemy);
     if(!vt)continue;
     const auto native=reinterpret_cast<ChangeActionFn>(
         vt[Addr().vtChangeState/sizeof(uintptr_t)]);
     if(!native)continue;
     native(enemy,parry::kNativeGuardBreak);
     g_feedbackDefender=defender;
     g_feedbackAttacker=attacker;
     g_feedbackUntil=now+900;
     Log("PARRY BETA ACERTO: J%d contra J%d; estado nativo STUN=0x%X solicitado.",
         defender+1,attacker+1,parry::kNativeGuardBreak);
   } __except(EXCEPTION_EXECUTE_HANDLER) {
     Log("PARRY BETA: falha segura ao aplicar atordoamento no J%d.",attacker+1);
   }
 }
}
bool ParryFeedback(int* defender,int* attacker) {
 const uint64_t until=g_feedbackUntil.load(std::memory_order_relaxed);
 if(!until||GetTickCount64()>until||!PromoteBattleActive())return false;
 if(defender)*defender=g_feedbackDefender;
 if(attacker)*attacker=g_feedbackAttacker;
 return true;
}
