#pragma once
#include <cstdint>
#include <windows.h>
#include <Xinput.h>

// Experimental native perfect-guard hook for Evolution. Registered only if
// storm6.ini has parry=1. Never replaces the standard guard command.
void ParryInstall();
void ParryObserveGuard(DWORD pad,const XINPUT_STATE* state,bool connected);
void ParryBeginBattle(); // called on the game's judge thread after roster capture
void ParryBattleTick();  // called on the game's judge thread after native judge
bool ParryRecentAttack(int fighter,uint64_t now);
bool ParryFeedback(int* defender,int* attacker);
