#include "jutsu_clash_3d.h"

#include <windows.h>

#include <cstring>

#include "addresses.h"
#include "census.h"
#include "log.h"

namespace clash3d {
namespace {
struct Native {
  const char* name;
  uintptr_t rva;
  uint8_t bytes[12];
  bool ok;
};
// Comeco de cada funcao no Evolution (lido do NSUNS4e.exe local).
Native g_setAction{"troca de acao", 0x7A97D4, {0x89, 0x91, 0xC8, 0x0C, 0x00, 0x00, 0xBA, 0x01, 0x00, 0x00, 0x00, 0x89}};
Native g_playAnm{"animacao direta", 0x779804, {0x48, 0x89, 0x5C, 0x24, 0x08, 0x57, 0x48, 0x83, 0xEC, 0x30, 0x83, 0xB9}};
Native g_bgOff{"desligar cenario", 0x7F0B20, {0x40, 0x53, 0x48, 0x83, 0xEC, 0x20, 0x48, 0x8B, 0xD9, 0x48, 0x8B, 0x0D}};
Native g_bgOn{"ligar cenario", 0x7F0B6C, {0x40, 0x53, 0x48, 0x83, 0xEC, 0x20, 0x48, 0x8B, 0xD9, 0x48, 0x8B, 0x0D}};

bool Check(Native& n) {
  __try {
    n.ok = std::memcmp(reinterpret_cast<const void*>(g_base + n.rva), n.bytes, sizeof(n.bytes)) == 0;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    n.ok = false;
  }
  return n.ok;
}
}  // namespace

void Install() {
  if (Addr().timestamp != 0x5889906E) {
    Log("JUTSU CLASH 3D: so no Evolution verificado; funcoes nativas desligadas.");
    return;
  }
  Native* all[] = {&g_setAction, &g_playAnm, &g_bgOff, &g_bgOn};
  for (Native* n : all)
    Log("JUTSU CLASH 3D: %s exe+0x%llX %s.", n->name, static_cast<unsigned long long>(n->rva),
        Check(*n) ? "conferida" : "DIFERENTE do esperado (nao sera usada)");
}

bool SetActionNow(uintptr_t player, int action) {
  if (!g_setAction.ok || !player) return false;
  __try {
    reinterpret_cast<void (*)(uintptr_t, int)>(g_base + g_setAction.rva)(player, action);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

bool PlayAnm(uintptr_t player, int anm) {
  if (!g_playAnm.ok || !player || anm < 0 || anm >= 1009) return false;
  __try {
    using Fn = const char* (*)(uintptr_t, int64_t, int64_t, int64_t, int, int);
    reinterpret_cast<Fn>(g_base + g_playAnm.rva)(player, anm, 0, 0xFFFFFFFFll, 0, 0);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

bool BackgroundDraw(uintptr_t player, bool on) {
  Native& n = on ? g_bgOn : g_bgOff;
  if (!n.ok || !player) return false;
  __try {
    reinterpret_cast<int64_t (*)(uintptr_t)>(g_base + n.rva)(player);
    return true;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

int CurrentAnm(uintptr_t player) {
  __try {
    return player ? *reinterpret_cast<const int*>(player + 0x1080) : -1;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return -1;
  }
}

float AnmValue(uintptr_t player) {
  __try {
    return player ? *reinterpret_cast<const float*>(player + 0x1084) : 0.0f;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return 0.0f;
  }
}
}  // namespace clash3d
