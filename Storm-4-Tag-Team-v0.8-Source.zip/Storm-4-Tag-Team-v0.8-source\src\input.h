#pragma once
#include <cstdint>
#include <windows.h>
#include <Xinput.h>

// Instala o hook de XInputGetState se a DLL do XInput ja estiver carregada.
bool InputTryInstall();
bool InputInstallBattle();
bool InputBattleReady();
bool InputPadConnected(int index);
void InputBeginBattle();

// Estado bruto do controle `index` (0-3) na ultima leitura do jogo, antes de o mod alterar algo.
// Retorna false se o controle nao esta conectado ou ainda nao foi lido.
bool InputPadStatus(int index, XINPUT_GAMEPAD* out);
// Continue observando B/Bolinha durante o choque, mesmo quando o jogo pausa os lutadores
// e deixa de consultar XInput. Chama a funcao original (sem os remapeamentos de gameplay).
void InputClashPollRaw(int padA, int padB);
// Leitor de controle do proprio jogo (8 entradas: 0-3 XInput, 4.. outros tipos). Copia o pacote (0x80 bytes) e
// devolve se o dispositivo esta conectado.
bool InputPhysicalPad(int index, uint8_t* out128);
