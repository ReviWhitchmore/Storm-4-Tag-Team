#include "menu.h"

#include <atomic>

#include "log.h"
#include "promote.h"
#include "settings.h"

namespace {

std::atomic<bool> g_open{false};
std::atomic<int> g_sel{0};
std::atomic<ULONGLONG> g_closedAt{0};
WORD g_prevButtons = 0;
bool g_prevKey[256] = {};

bool GameFocused() {
  DWORD pid = 0;
  GetWindowThreadProcessId(GetForegroundWindow(), &pid);
  return pid == GetCurrentProcessId();
}

bool KeyPressed(int vk) {
  bool down = (GetAsyncKeyState(vk) & 0x8000) != 0;
  bool pressed = down && !g_prevKey[vk];
  g_prevKey[vk] = down;
  return pressed;
}

void Toggle(int item, int dir) {
  Settings& c = Cfg();
  if (item >= kItemSlot0 && item < kItemSlot0 + 6) {
    const int i = item - kItemSlot0;
    const int count = 6;
    constexpr int options[count] = {kSlotAuto, kSlotCpu, kSlotPlayer1, kSlotPlayer2, kSlotPlayer3, kSlotPlayer4};
    const int old = c.slot[i].load();
    int current = 0;
    for (int option = 1; option < count; ++option)
      if (options[option] == old) current = option;
    bool assigned[4] = {};
    for (int other = 0; other < 6; ++other) {
      const int pad = SlotPadIndex(c.slot[other].load());
      if (other != i && pad >= 0) assigned[pad] = true;
    }
    int pad;
    do {
      current = (current + dir + count) % count;
      pad = SlotPadIndex(options[current]);
    } while (pad >= 0 && assigned[pad]);
    c.slot[i] = options[current];
  } else {
    switch (item) {
      case kItem3v3: {
        // Mode cycle: original Versus -> 3v3 teams -> FFA research slot.
        // The FFA-specific collision/victory rules are NOT hooked yet.
        const int current = c.freeForAll.load() ? 2 : (c.mode3v3.load() ? 1 : 0);
        const int next = (current + dir + 3) % 3;
        c.freeForAll = next == 2;
        c.mode3v3 = next != 0;
        break;
      }
      case kItemHud: c.hud = !c.hud; break;
      case kItemLockon: c.lockon = !c.lockon; break;
      case kItemLockStyle: c.lockonStyle = (c.lockonStyle.load() + dir + 3) % 3; break;
      case kItemCamera: c.camera = (c.camera.load() + dir + 5) % 5; break;
      case kItemRing: c.ring = !c.ring; break;
      case kItemUlt: c.ultFree = !c.ultFree; break;
      case kItemSelectP2: c.selectP2 = !c.selectP2; break;
      case kItemTeamUltimate: c.teamUltimate = !c.teamUltimate; break;
      case kItemTeamUltimateButton: c.teamUltimateButton = 1 - c.teamUltimateButton.load(); break;
      case kItemAwakenStart: c.awakenAtStart = !c.awakenAtStart; break;
      case kItemJutsuClash: c.jutsuClash = !c.jutsuClash; break;
      case kItemClose:
        g_open = false;
        g_closedAt = GetTickCount64();
        return;
    }
  }
  SettingsSave();
  Log("Menu: modo3v3=%d FFA_experimental=%d hud=%d lockon=%d jutsu_clash=%d J=%d%d%d%d%d%d",
      int(c.mode3v3), int(c.freeForAll), int(c.hud), int(c.lockon), int(c.jutsuClash),
      c.slot[0].load(), c.slot[1].load(), c.slot[2].load(), c.slot[3].load(), c.slot[4].load(),
      c.slot[5].load());
}

}  // namespace

bool MenuIsOpen() { return g_open.load(); }
bool MenuBlocksGameInput() {
  if (g_open.load()) return true;
  const ULONGLONG closed = g_closedAt.load();
  return closed && GetTickCount64() - closed < 250;
}
int MenuSelection() { return g_sel.load(); }

void MenuInput(XINPUT_STATE* state) {
  WORD buttons = state ? state->Gamepad.wButtons : 0;
  WORD pressed = buttons & ~g_prevButtons;
  g_prevButtons = buttons;

  bool focused = GameFocused();
  bool kOpen = focused && KeyPressed(VK_F1);
  bool kUp = focused && KeyPressed(VK_UP), kDown = focused && KeyPressed(VK_DOWN);
  bool kOk = focused && KeyPressed(VK_RETURN), kBack = focused && KeyPressed(VK_ESCAPE);
  bool kLeft = focused && KeyPressed(VK_LEFT), kRight = focused && KeyPressed(VK_RIGHT);

  if (PromoteReservesRightStick()) {  // o menu nao abre durante a luta, mesmo pausada
    g_open = false;
    return;
  }

  bool open = g_open.load();
  if (!open) {
    if ((pressed & XINPUT_GAMEPAD_BACK) || kOpen) {
      g_open = true;
      g_sel = 0;
      Log("Menu: aberto");
    }
  } else {
    int sel = g_sel.load();
    if ((pressed & XINPUT_GAMEPAD_DPAD_UP) || kUp) sel = (sel + kItemCount - 1) % kItemCount;
    if ((pressed & XINPUT_GAMEPAD_DPAD_DOWN) || kDown) sel = (sel + 1) % kItemCount;
    g_sel = sel;
    if ((pressed & (XINPUT_GAMEPAD_A | XINPUT_GAMEPAD_DPAD_RIGHT)) || kOk || kRight) Toggle(sel, +1);
    if ((pressed & XINPUT_GAMEPAD_DPAD_LEFT) || kLeft) Toggle(sel, -1);
    if ((pressed & (XINPUT_GAMEPAD_B | XINPUT_GAMEPAD_BACK)) || kBack || kOpen) {
      g_open = false;
      g_closedAt = GetTickCount64();
      Log("Menu: fechado");
    }
  }
  // Com o menu aberto (inclusive no quadro em que fechou), o jogo nao recebe o controle.
  if ((open || g_open.load()) && state) ZeroMemory(&state->Gamepad, sizeof(state->Gamepad));
}
