// Camera de contato 3D: usa pontos da tecnica no mundo para os dois lados
// e para o ponto de impacto. So ativada por chave de TESTE no storm6.ini.
bool ProjectClashWorldAnchors(const ClashHud& c, float* ax, float* ay,
                              float* bx, float* by, float* cx, float* cy) {
  if (!c.worldContactPreview || !c.hasPos || !ax || !ay || !bx || !by || !cx || !cy ||
      !(g_w > 0.0f) || !(g_h > 0.0f)) return false;
  clash_motion::WorldAnchors w{};
  if (!clash_motion::MakeWorldAnchors(c.posA, c.posB, c.scoreA, c.scoreB, &w))
    return false;
  auto project = [](const float pos[3], float* x, float* y) {
    float sx = 0, sy = 0;
    bool behind = false;
    if (!CameraProject(pos, g_w / g_h, &sx, &sy, &behind) || behind ||
        std::fabs(sx) > 1.45f || std::fabs(sy) > 1.45f) return false;
    *x = (sx * 0.5f + 0.5f) * g_w;
    *y = (0.5f - sy * 0.5f) * g_h;
    return std::isfinite(*x) && std::isfinite(*y);
  };
  float aX, aY, bX, bY, cX, cY;
  if (!project(w.sourceA, &aX, &aY) || !project(w.sourceB, &bX, &bY) ||
      !project(w.contact, &cX, &cY)) return false;
  *ax = aX; *ay = aY; *bx = bX; *by = bY; *cx = cX; *cy = cY;
  return true;
}
