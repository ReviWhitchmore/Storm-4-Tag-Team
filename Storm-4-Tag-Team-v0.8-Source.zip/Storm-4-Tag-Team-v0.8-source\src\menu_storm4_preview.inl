// APENAS VISUAL: prototipo Storm 4 ativado exclusivamente pelo marcador local
// "storm6_menu_storm4_preview.flag" na pasta do jogo. Nao altera menu.cpp,
// Cfg(), inputs, missoes, HUD, combate, nem a assinatura Revi Whitchmore.
// A ausencia do marcador preserva os menus originais exatamente como antes.
bool Storm4MenuPreviewEnabled() {
  static const bool on = [] {
    const auto path = ModDir() + L"storm6_menu_storm4_preview.flag";
    return GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES;
  }();
  return on;
}

constexpr Rgba kPrevBg{0.014f,0.026f,0.058f,0.91f};
constexpr Rgba kPrevPanel{0.044f,0.075f,0.139f,0.87f};
constexpr Rgba kPrevRow{0.074f,0.122f,0.200f,0.86f};
constexpr Rgba kPrevOrange{1.0f,0.53f,0.11f,1.0f};
constexpr Rgba kPrevBlue{0.36f,0.65f,0.98f,1.0f};
constexpr Rgba kPrevText{1.0f,0.963f,0.89f,1.0f};

void PreviewFrame(const MenuView& v,float w,float h) {
  v.Fill(2,4,w,h,{0,0,0,0.40f});
  v.Fill(0,0,w,h,kPrevPanel);
  v.Fill(0,0,w,2,{0.42f,0.63f,0.90f,0.75f});
  v.Fill(0,0,2,h,{0.42f,0.63f,0.90f,0.65f});
  v.Fill(w-2,0,2,h,{0.35f,0.51f,0.79f,0.65f});
  v.Fill(0,h-2,w,2,{0.35f,0.51f,0.79f,0.65f});
  for(int i=0;i<4;++i) {
    const float y=30+i*78.0f;
    v.Stroke(w-82,y,w-42,y+25,1.6f,{0.34f,0.62f,1.0f,0.16f});
  }
}

void PreviewChoice(const MenuView& v,float x,float y,float w,float h,bool selected) {
  const float glow=selected?0.88f+0.12f*std::sin(GetTickCount64()*0.006):0.0f;
  v.Blade(x+10,y+2,w-20,h-4,11,
          selected?Rgba{0.39f,0.16f,0.07f,0.97f}:kPrevRow,
          selected?Rgba{0.19f,0.075f,0.053f,0.95f}:kMenuDeep);
  if(selected) {
    v.Fill(x+6,y+1,w-12,2,{1.0f,0.55f,0.13f,glow});
    v.Fill(x+6,y+h-3,w-12,2,{1.0f,0.55f,0.13f,glow});
    v.Fill(x+5,y+3,4,h-6,kPrevOrange);
    v.Stroke(x+w-32,y+10,x+w-22,y+h/2,3,kPrevOrange);
    v.Stroke(x+w-22,y+h/2,x+w-32,y+h-10,3,kPrevOrange);
  } else {
    v.Fill(x+6,y+h-2,w-12,1,{0.48f,0.65f,0.86f,0.37f});
  }
  v.Stroke(x+27,y+18,x+37,y+30,2.2f,selected?kMenuGold:kPrevBlue);
  v.Stroke(x+37,y+18,x+27,y+30,2.2f,selected?kMenuGold:kPrevBlue);
}

void PreviewChrome(const MenuView& p,const char* title,const char* subtitle) {
  // Deixa o proprio cenario do jogo aparecer suavemente atras dos paineis.
  Rect(0,0,g_w,g_h,0.007f,0.018f,0.037f,0.71f);
  p.Fill(0,0,1600,900,{0.006f,0.017f,0.044f,0.26f});
  p.Blade(36,28,873,122,37,
          {0.91f,0.39f,0.080f,0.96f},{0.19f,0.054f,0.030f,0.95f});
  p.Blade(44,33,831,108,31,
          {0.075f,0.074f,0.102f,0.94f},{0.018f,0.026f,0.053f,0.98f});
  p.Fill(55,140,817,3,kPrevOrange);
  p.Brush(92,47,title,53,kPrevText);
  p.Label(95,109,subtitle,18,kMenuGold);
  for(int i=0;i<9;++i) {
    const float x=1000.0f+i*56;
    p.Stroke(x,35,x-62,145,4,{0.24f,0.59f,1.0f,0.18f});
  }
  p.Label(1338,45,"VISUAL",23,kPrevText);
  p.Label(1338,73,Lang("TESTE / BETA","TEST / BETA"),18,kMenuGold);
  p.Fill(70,809,1450,2,kPrevOrange);
  p.Fill(72,819,1426,49,{0.006f,0.017f,0.045f,0.78f});
  p.Label(92,829,Lang("DPAD / SETAS : NAVEGAR","DPAD / ARROWS : NAVIGATE"),18,kPrevText);
  p.Label(430,829,Lang("A / ENTER : ALTERAR","A / ENTER : CHANGE"),18,kPrevText);
  p.Label(750,829,Lang("B / ESC / SELECT : VOLTAR","B / ESC / SELECT : BACK"),18,kPrevText);
  p.Label(1210,829,"F1 / SELECT",19,kMenuGold);
  // Nao desenhar sobre o canto inferior direito: assinatura original e desenhada depois.
}

void PreviewPadStatus(const MenuView& p,float x,float y) {
  p.Label(x,y,Lang("CONTROLES CONECTADOS","CONNECTED CONTROLLERS"),17,kMenuGold);
  for(int i=0;i<4;++i) {
    XINPUT_GAMEPAD pad{};
    const bool active=InputPadStatus(i,&pad);
    char tag[16]; std::snprintf(tag,sizeof(tag),"P%d",i+1);
    const float px=x+i*133.0f;
    p.Fill(px,y+32,118,44,{0.026f,0.051f,0.110f,0.82f});
    p.Fill(px,y+32,4,44,active?kMenuMint:kMenuEdge);
    p.Label(px+18,y+43,tag,20,kPrevText);
    p.Label(px+56,y+45,active?"OK":"OFF",16,active?kMenuMint:kMenuMuted);
  }
}

void BuildStorm4MenuPreview() {
  constexpr float W=1600,H=900;
  const float s=std::min(g_w/W,g_h/H);
  const MenuView p{(g_w-W*s)/2,(g_h-H*s)/2,s};
  const Settings& c=Cfg();
  const int selected=MenuSelection();
  const bool team=selected>=kItemSlot0 && selected<kItemClose;
  const bool close=selected==kItemClose;
  const int page=(!team && !close && selected>=6)?1:0;
  PreviewChrome(p,team?"PLAYER SETUP":selected==kItemJutsuClash?"JUTSU CLASH SETTINGS":"TAG TEAM MOD SETTINGS",
                Lang("NARUTO SHIPPUDEN STORM 4 / REVI WHITCHMORE / PRE-VISUALIZACAO","NARUTO SHIPPUDEN STORM 4 / REVI WHITCHMORE / PREVIEW"));
  const MenuView left=p.At(65,183),right=p.At(868,183);
  PreviewFrame(left,748,603);
  PreviewFrame(right,665,603);

  if(team) {
    left.Brush(25,15,Lang("CONFIGURACAO DOS JOGADORES","PLAYER SETUP"),29,kMenuGold);
    static const char* const players[]={"Player 1","Player 2","Player 3","Player 4"};
    for(int i=0;i<6;++i) {
      const float y=65+i*77.0f;
      const bool sel=selected==kItemSlot0+i;
      PreviewChoice(left,16,y,710,69,sel);
      char number[12];std::snprintf(number,sizeof(number),"J%d",i+1);
      left.Brush(65,y+14,number,31,kPrevText);
      left.Blade(138,y+15,190,39,13,
                 i<3?Rgba{0.83f,0.41f,0.09f,0.95f}:Rgba{0.17f,0.45f,0.87f,0.95f},
                 kPrevBg);
      left.Label(164,y+24,i<3?Lang("EQUIPE 1","TEAM 1"):Lang("EQUIPE 2","TEAM 2"),22,kPrevText);
      const int control=c.slot[i].load();
      const int pad=SlotPadIndex(control);
      const char* val=pad>=0?players[pad]:control==kSlotCpu?"CPU":Lang("AUTOMATICO","AUTO");
      left.Right(684,y+22,val,23,sel?kMenuGold:kPrevText);
    }
    right.Brush(28,18,"MATCH RULES",38,kMenuGold);
    right.Label(29,80,Lang("BATALHA 3 CONTRA 3","3 VS 3 BATTLE"),25,kPrevText);
    right.Label(29,120,Lang("J1 - J3  /  Equipe 1","J1 - J3  /  Team 1"),20,kPrevBlue);
    right.Label(29,153,Lang("J4 - J6  /  Equipe 2","J4 - J6  /  Team 2"),20,kPrevOrange);
    right.Fill(27,200,605,2,kMenuGold);
    right.Label(29,219,Lang("Use o direcional para selecionar uma vaga.","Use the D-pad to pick a slot."),20,kPrevText);
    right.Label(29,256,Lang("Altere entre CPU, automatico e Players.","Switch between CPU, auto and Players."),19,kMenuMuted);
    right.Label(29,299,Lang("A escolha vale para a proxima batalha.","Changes apply to the next battle."),19,kMenuMuted);
    right.Fill(27,363,605,2,{0.4f,0.7f,1.0f,0.45f});
    PreviewPadStatus(right,29,392);
    right.Label(30,513,Lang("PREVIEW VISUAL: nenhuma mecanica alterada.","VISUAL PREVIEW: no mechanics changed."),18,kMenuGold);
  } else {
    left.Brush(25,15,page?Lang("CONFIGURACOES / 2","SETTINGS / 2"):Lang("CONFIGURACOES / 1","SETTINGS / 1"),30,kMenuGold);
    const int camera=c.camera.load();
    struct Row{const char* name;const char* help;const char* value;};
    const char* const on=Lang("LIGADO","ON");
    const char* const off=Lang("DESLIGADO","OFF");
    const Row rows[]={
      {Lang("Modo de batalha","Battle mode"),Lang("Combate simultaneo de equipes","Simultaneous team combat"),c.freeForAll.load()?"FFA BETA":c.mode3v3.load()?"3V3":"VERSUS"},
      {Lang("HUD de combate","Battle HUD"),Lang("Vida, chakra e retratos de 6 lutadores","Health, chakra and portraits for 6 fighters"),c.hud.load()?on:off},
      {"Lock-on",Lang("Troca de alvo no analogico direito","Switch target with the right stick"),c.lockon.load()?on:off},
      {Lang("Estilo do lock-on","Lock-on style"),Lang("Visual do indicador de alvo","Target marker look"),c.lockonStyle.load()==2?"REVOLUTION":c.lockonStyle.load()==1?Lang("NO CORPO","ON BODY"):Lang("SETA","ARROW")},
      {Lang("Camera","Camera"),Lang("Enquadramento da arena","Arena framing"),camera==kCameraRevolution?"REVOLUTION":camera==kCameraConnections?"CONNECTIONS":camera==kCameraTournament?Lang("TORNEIO","TOURNAMENT"):camera==kCameraGroup?Lang("GRUPO","GROUP"):Lang("DUELO","DUEL")},
      {Lang("Resgate de piso","Floor rescue"),Lang("Recoloca os lutadores dentro da arena","Puts fighters back inside the arena"),c.ring.load()?on:off},
      {Lang("Ultimates livres","Free ultimates"),Lang("Mantem a luta durante jutsus supremos","The fight goes on during ultimate jutsu"),c.ultFree.load()?on:off},
      {Lang("Selecao com P2","P2 selection"),Lang("Segundo controle no menu","Second controller in menus"),c.selectP2.load()?on:off},
      {Lang("Supremo em equipe","Team ultimate"),Lang("Habilita supremo de equipe (beta)","Enables team ultimates (beta)"),c.teamUltimate.load()?on:off},
      {Lang("Botao do supremo","Ultimate button"),Lang("Atalho do supremo em equipe","Team ultimate shortcut"),c.teamUltimateButton.load()==0?"L1 / LB":"R1 / RB"},
      {Lang("Despertar no inicio","Awaken at start"),Lang("Despertar na entrada de luta","Awakening when the fight begins"),c.awakenAtStart.load()?on:off},
      {"Jutsu Clash (beta)",Lang("Confronto quando dois jutsus se chocam","Struggle when two jutsu collide"),c.jutsuClash.load()?on:off}
    };
    static_assert(sizeof(rows)/sizeof(rows[0])==kItemSlot0,"Nunca remover opcoes reais.");
    for(int j=0;j<6;++j) {
      const int i=page*6+j;
      const auto& row=rows[i];
      const float y=62+j*81.0f;
      PreviewChoice(left,16,y,710,72,selected==i);
      left.Label(63,y+9,row.name,22,kPrevText);
      left.Label(63,y+40,row.help,16,kMenuMuted);
      left.Right(683,y+21,row.value,21,selected==i?kMenuGold:kPrevText);
    }
    const int effective=close?0:selected;
    const auto& option=rows[std::clamp(effective,0,kItemSlot0-1)];
    right.Brush(27,20,selected==kItemJutsuClash?"JUTSU CLASH":option.name,37,kMenuGold);
    right.Fill(29,87,598,2,kPrevOrange);
    right.Label(30,108,option.help,21,kPrevText);
    right.Label(30,154,Lang("ESTADO ATUAL:","CURRENT STATE:"),19,kMenuMuted);
    right.Brush(30,189,option.value,36,kMenuGold);
    right.Fill(30,266,595,2,{0.45f,0.74f,1.0f,0.45f});
    if(selected==kItemJutsuClash) {
      right.Label(30,286,Lang("B / BOLINHA  -  Pressione repetidamente","B / CIRCLE  -  Press repeatedly"),19,kPrevText);
      right.Label(30,328,Lang("Disputa de forca com energia em movimento.","Power struggle with moving energy."),19,kMenuMuted);
      right.Label(30,370,Lang("O visual do confronto permanece original.","The clash visuals stay original."),18,kMenuMuted);
    } else {
      right.Label(30,290,Lang("As opcoes e os controles sao os mesmos.","Options and controls are unchanged."),20,kPrevText);
      right.Label(30,332,Lang("Apenas molduras, cor, fonte e selecao","Only frames, colors, font and selection"),18,kMenuMuted);
      right.Label(30,364,Lang("receberam o tema experimental.","use the experimental theme."),18,kMenuMuted);
    }
    right.Fill(30,416,595,2,kPrevBlue);
    PreviewPadStatus(right,30,432);
    right.Label(30,535,Lang("PAGINA 1/2: a lista muda com a selecao.","PAGE 1/2: the list follows the selection."),17,kMenuMuted);
  }
  const bool selClose=selected==kItemClose;
  PreviewChoice(p,1276,748,232,48,selClose);
  p.Brush(1336,754,Lang("FECHAR","CLOSE"),27,selClose?kMenuGold:kPrevText);
}

void BuildStorm4ChroniclesPreview() {
  const float W=1600,H=900,s=std::min(g_w/W,g_h/H);
  const MenuView p{(g_w-W*s)/2,(g_h-H*s)/2,s};
  if(!ChroniclesChapterScreenOpen()) {
    // Teaser: so aparencia, mesma tecla Y/F6 para abrir de sempre.
    const MenuView teaser=p.At(886,682);
    PreviewFrame(teaser,625,110);
    teaser.Brush(27,9,"CHRONICLES MODE",40,kMenuGold);
    teaser.Label(32,65,Lang("Y / F6   -   ABRIR NARUTO CLASSICO","Y / F6   -   OPEN CLASSIC NARUTO"),21,kPrevText);
    return;
  }
  PreviewChrome(p,"CHRONICLES MODE",Lang("MISSOES, ARCOS E REGRAS ORIGINAIS / VISUAL EXPERIMENTAL","MISSIONS, ARCS AND ORIGINAL RULES / EXPERIMENTAL VISUAL"));
  const MenuView left=p.At(64,185),right=p.At(868,185);
  PreviewFrame(left,748,607);
  PreviewFrame(right,664,607);
  const int arc=ChroniclesChapterSelection();
  const bool missions=ChroniclesMissionListOpen();
  const bool detail=ChroniclesMissionDetailOpen();
  left.Brush(25,18,detail?Lang("FICHA DA MISSAO","MISSION CARD"):missions?Lang("SELECIONE A MISSAO","SELECT A MISSION"):Lang("SELECIONE O ARCO","SELECT AN ARC"),30,kMenuGold);
  if(missions || detail) {
    const int first=ChroniclesArcMissionFirst(arc);
    const int count=ChroniclesArcMissionCount(arc);
    const int focus=ChroniclesMissionSelection();
    const int page=std::max(0,(focus-first)/6);
    for(int j=0;j<6;++j) {
      const int i=first+page*6+j;
      if(i>=first+count) break;
      const float y=70+j*80.0f;
      PreviewChoice(left,16,y,710,70,focus==i);
      left.Brush(61,y+14,ChroniclesMissionId(i),30,kPrevText);
      left.Label(169,y+10,ChroniclesMissionTitle(i),23,focus==i?kMenuGold:kPrevText);
      left.Label(169,y+42,ChroniclesMissionStatus(i),16,kMenuMuted);
    }
    if(focus>=0 && focus<40) {
      right.Brush(27,20,ChroniclesMissionTitle(focus),33,kMenuGold);
      right.Label(29,95,"ARENA",18,kMenuGold);
      right.Label(194,95,ChroniclesMissionArena(focus),20,kPrevText);
      right.Label(29,140,Lang("EQUIPES","TEAMS"),18,kMenuGold);
      right.Label(194,140,ChroniclesMissionTeams(focus),20,kPrevText);
      right.Label(29,185,Lang("DIFICULDADE","DIFFICULTY"),18,kMenuGold);
      right.Label(194,185,ChroniclesMissionDifficulty(focus),20,kPrevText);
      right.Fill(27,231,610,2,kPrevOrange);
      right.Label(29,251,Lang("OBJETIVO","OBJECTIVE"),19,kMenuGold);
      right.Label(29,287,ChroniclesMissionObjective(focus),19,kPrevText);
      right.Label(29,350,Lang("REGRA ESPECIAL","SPECIAL RULE"),19,kMenuGold);
      right.Label(29,386,ChroniclesMissionSpecial(focus),19,kPrevText);
      right.Fill(27,467,610,2,kPrevBlue);
      right.Label(29,488,ChroniclesMissionStatus(focus),20,kPrevText);
    }
  } else {
    for(int i=0;i<ChroniclesArcCount() && i<6;++i) {
      const float y=70+i*80.0f;
      PreviewChoice(left,16,y,710,70,i==arc);
      char number[16];std::snprintf(number,sizeof(number),"%02d",i+1);
      left.Brush(64,y+11,number,32,kPrevText);
      left.Label(148,y+10,ChroniclesChapterTitle(i),23,i==arc?kMenuGold:kPrevText);
      left.Label(148,y+43,ChroniclesChapterSubtitle(i),16,kMenuMuted);
    }
    right.Brush(28,20,Lang("NARUTO CLASSICO","CLASSIC NARUTO"),37,kMenuGold);
    right.Label(30,95,ChroniclesChapterTitle(arc),25,kPrevText);
    right.Label(30,143,ChroniclesChapterSubtitle(arc),21,kMenuMuted);
    char count[64];std::snprintf(count,sizeof(count),ChroniclesArcMissionCount(arc)==1?Lang("%d MISSAO","%d MISSION"):Lang("%d MISSOES","%d MISSIONS"),ChroniclesArcMissionCount(arc));
    right.Label(30,220,count,26,kMenuGold);
    right.Fill(28,288,598,2,kPrevOrange);
    right.Label(29,319,ChroniclesCampaignLabel(),20,kPrevText);
    right.Label(29,390,ChroniclesEditionLabel(),20,kMenuMuted);
  }
  p.Label(78,757,Lang("DPAD / F7-F8 : NAVEGAR      A / F9 : ABRIR","DPAD / F7-F8 : NAVIGATE      A / F9 : OPEN"),21,kPrevText);
  p.Label(78,782,Lang("B / F10 : VOLTAR      Y / F6 : FECHAR","B / F10 : BACK      Y / F6 : CLOSE"),19,kMenuGold);
}
