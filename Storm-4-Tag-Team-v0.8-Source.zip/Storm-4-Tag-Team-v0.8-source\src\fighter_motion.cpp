#include "fighter_motion.h"

#include <windows.h>

#include <cmath>

namespace fighter {
int State(uintptr_t player) {
  __try {
    return player ? *reinterpret_cast<const int*>(player + 0xCC0) : -1;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return -1;
  }
}

int Anm(uintptr_t player) {
  __try {
    return player ? *reinterpret_cast<const int*>(player + 0x1080) : -1;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return -1;
  }
}

bool Pos(uintptr_t player, float out[3]) {
  __try {
    if (!player) return false;
    const float* p = reinterpret_cast<const float*>(player + 0x70);
    out[0] = p[0];
    out[1] = p[1];
    out[2] = p[2];
    return std::isfinite(out[0]) && std::isfinite(out[1]) && std::isfinite(out[2]);
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return false;
  }
}

void SetPos(uintptr_t player, const float p[3]) {
  __try {
    float* at = reinterpret_cast<float*>(player + 0x70);
    at[0] = p[0];
    at[1] = p[1];
    at[2] = p[2];
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}

void FaceToward(uintptr_t player, float tx, float ty) {
  __try {
    float* base = reinterpret_cast<float*>(player);
    const float px = base[0x70 / 4], py = base[0x74 / 4];
    float dx = tx - px, dy = ty - py;
    const float len = std::sqrt(dx * dx + dy * dy);
    if (!(len > 1.0f)) return;
    dx /= len;
    dy /= len;
    const int dirs[] = {0xA8, 0xB4, 0xC0, 0xE4, 0xF0, 0xFC};
    for (int off : dirs) {
      base[off / 4] = dx;
      base[off / 4 + 1] = dy;
      base[off / 4 + 2] = 0.0f;
    }
    base[0x108 / 4] = -dy;
    base[0x10C / 4] = -dx;
    base[0x118 / 4] = dx;
    base[0x11C / 4] = -dy;
  } __except (EXCEPTION_EXECUTE_HANDLER) {
  }
}

float Distance2D(const float a[3], const float b[3]) { return std::hypot(a[0] - b[0], a[1] - b[1]); }
}  // namespace fighter
